// modules/claude.js — Guardian site module + CESL execution tracing
// Targets: claude.ai

class ClaudeModule extends GuardianModule {
  constructor(urck) {
    super('claude', ['claude.ai'], urck);
    this._observer     = null;
    this._lastText     = null;
    this._lastUserText = null;
  }

  attach() {
    this._observer = new MutationObserver(() => {
      // ── Capture AI responses ─────────────────────────────────────────────
      // Claude uses .font-claude-message for AI responses
      const responses = document.querySelectorAll('.font-claude-message, [data-is-streaming]');
      const last = responses[responses.length - 1];
      if (!last) return;

      const text = last.innerText?.trim();
      const isStreaming = !!document.querySelector('[data-is-streaming]');

      if (text && text !== this._lastText && text.length > 10) {
        this._lastText = text;

        this.emit('guardian.chat.response', {
          text:           text.slice(0, 2000),
          role:           'assistant',
          provider:       'claude',
          conversationId: window.location.pathname.split('/').pop(),
          timestamp:      Date.now(),
          // Mark complete only when not streaming — GateForge uses this to resolve listenForResponse
          complete:       !isStreaming && text.length > 20,
        });

        // CESL: trace the observe action
        if (typeof CFR !== 'undefined') {
          CFR.cesl.record(
            { type: 'observe', provider: 'claude', gate: 'chat' },
            { type: 'Observe', eventType: 'chat.response', selector: '.font-claude-message' },
            { selector: '.font-claude-message', fingerprint: text.slice(0,30), url: window.location.href },
            'guardian-firefox',
            'success',
            { url: window.location.href },
            { url: window.location.href, domFingerprint: text.slice(0,40) },
            { latency: 0, retries: 0, confidence: isStreaming ? 0.7 : 0.98 }
          );
        }
      }

      // ── Capture user messages ────────────────────────────────────────────
      const userMsgs = document.querySelectorAll('[data-testid="user-message"]');
      const lastUser = userMsgs[userMsgs.length - 1];
      if (lastUser) {
        const userText = lastUser.innerText?.trim();
        if (userText && userText !== this._lastUserText && userText.length > 1) {
          this._lastUserText = userText;
          this.emit('guardian.chat.message', {
            text:           userText.slice(0, 2000),
            role:           'user',
            provider:       'claude',
            conversationId: window.location.pathname.split('/').pop(),
            timestamp:      Date.now(),
          });
        }
      }
    });

    this._observer.observe(document.body, { childList: true, subtree: true });

    // CESL: record the attach action
    if (typeof CFR !== 'undefined') {
      CFR.cesl.record(
        { type: 'Observe', provider: 'claude' },
        { type: 'Observe', eventType: 'mount', selector: 'document.body' },
        { selector: 'document.body', url: window.location.href },
        'guardian-firefox', 'success',
        { url: window.location.href }, { url: window.location.href }, { latency: 0, retries: 0, confidence: 1.0 }
      );
    }
  }

  detach() {
    this._observer?.disconnect();
    this._observer = null;
  }
}
