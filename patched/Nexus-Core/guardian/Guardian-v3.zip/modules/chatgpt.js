// modules/chatgpt.js — Guardian site module + CESL execution tracing
// Targets: chatgpt.com, chat.openai.com

class ChatGPTModule extends GuardianModule {
  constructor(urck) {
    super('chatgpt', ['chatgpt.com', 'chat.openai.com'], urck);
    this._observer    = null;
    this._lastMessage = null;
    this._lastUserText = null;
  }

  attach() {
    this._observer = new MutationObserver(() => {
      // ── Capture assistant responses ─────────────────────────────────────
      const messages = document.querySelectorAll('[data-message-author-role]');
      const last = messages[messages.length - 1];
      if (!last) return;

      const text = last.innerText?.trim();
      const role = last.getAttribute('data-message-author-role');

      if (text && text !== this._lastMessage) {
        this._lastMessage = text;
        const eventType = role === 'assistant' ? 'guardian.chat.response' : 'guardian.chat.message';

        this.emit(eventType, {
          text:           text.slice(0, 2000),
          role,
          provider:       'chatgpt',
          conversationId: this._getConvId(),
          timestamp:      Date.now(),
          // CESL: mark as complete when response is stable (not streaming)
          complete:       role === 'assistant' && !document.querySelector('[data-testid="stop-button"]'),
        });

        // CESL: emit execution trace for the observe action
        if (typeof CFR !== 'undefined') {
          CFR.cesl.record(
            { type: 'observe', provider: 'chatgpt', gate: 'chat' },
            { type: 'Observe', eventType: 'chat.response', selector: '[data-message-author-role]' },
            { selector: '[data-message-author-role]', fingerprint: role+':'+text.slice(0,20), url: window.location.href },
            'guardian-firefox',
            'success',
            { url: window.location.href },
            { url: window.location.href, domFingerprint: text.slice(0,40) },
            { latency: 0, retries: 0, confidence: 0.95 }
          );
        }
      }

      // ── Capture user messages ────────────────────────────────────────────
      const userMsgs = document.querySelectorAll('[data-message-author-role="user"]');
      const lastUser = userMsgs[userMsgs.length - 1];
      if (lastUser) {
        const userText = lastUser.innerText?.trim();
        if (userText && userText !== this._lastUserText && userText.length > 1) {
          this._lastUserText = userText;
          this.emit('guardian.chat.message', {
            text:           userText.slice(0, 2000),
            role:           'user',
            provider:       'chatgpt',
            conversationId: this._getConvId(),
            timestamp:      Date.now(),
          });
        }
      }
    });

    this._observer.observe(document.body, { childList: true, subtree: true });

    // CESL: record the attach action
    if (typeof CFR !== 'undefined') {
      CFR.cesl.record(
        { type: 'Observe', provider: 'chatgpt' },
        { type: 'Observe', eventType: 'mount', selector: 'document.body' },
        { selector: 'document.body', url: window.location.href },
        'guardian-firefox', 'success',
        { url: window.location.href }, { url: window.location.href }, { latency: 0, retries: 0, confidence: 1.0 }
      );
    }
  }

  _getConvId() {
    const match = window.location.pathname.match(/\/c\/([a-z0-9-]+)/);
    return match ? match[1] : null;
  }

  detach() {
    this._observer?.disconnect();
    this._observer = null;
  }
}
