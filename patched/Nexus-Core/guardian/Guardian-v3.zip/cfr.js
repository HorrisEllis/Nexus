/**
 * CFR — Constraint Field Runtime v1.0.0
 * Guardian Kernel — replaces URCK
 *
 * Three coupled systems in one closed loop:
 *   CFR  → Causal field kernel (ring buffer, graph, macro detection, SNR)
 *   CESL → Canonical Execution Layer (intent → action → mutation traces)
 *   RAT  → Reproducible Automation Traces (deterministic event-sourced truth)
 *
 * Drop-in replacement for urck.js — exposes the same URCK surface
 * plus CFR/CESL/RAT extensions.
 *
 * Every browser action MUST emit an AutomationTraceEvent.
 * If it cannot be replayed it is INVALID execution (CESL §0).
 */

'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// IDENTITY + HASH
// ─────────────────────────────────────────────────────────────────────────────

function newId() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function')
    return crypto.randomUUID();
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b).map(x => x.toString(16).padStart(2,'0'));
  return [h.slice(0,4),h.slice(4,6),h.slice(6,8),h.slice(8,10),h.slice(10,16)].map(a=>a.join('')).join('-');
}

function shortId(id) {
  if (!id) return '?';
  const p = id.split('-');
  return p[p.length-1] || id.slice(-12);
}

function canonicalize(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number') return String(v);
  if (typeof v === 'string') return JSON.stringify(v);
  if (Array.isArray(v)) return '['+v.map(canonicalize).join(',')+']';
  if (typeof v === 'object') {
    const keys = Object.keys(v).sort();
    return '{'+keys.map(k=>JSON.stringify(k)+':'+canonicalize(v[k])).join(',')+'}';
  }
  return JSON.stringify(v);
}

function hash64(s) {
  let h1 = 0x811c9dc5|0, h2 = 0xc4a6c57b|0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1^c, 0x01000193);
    h2 = Math.imul(h2^c, 0x01000193)^(h1>>>13);
  }
  return ((h1>>>0).toString(16).padStart(8,'0'))+((h2>>>0).toString(16).padStart(8,'0'));
}

function contentHash(type, payload, source) {
  return hash64(canonicalize({ type, payload: payload ?? {}, source: source ?? 'unknown' }));
}

function stateHash(url, domSnapshot, nodeSet) {
  return hash64(canonicalize({ url: url||'', dom: domSnapshot||'', nodes: nodeSet||[] }));
}

function dedupKey(type, payload, source, replayOf) {
  return contentHash(type, payload, source) + '::' + (replayOf||'');
}

// ─────────────────────────────────────────────────────────────────────────────
// SNR GATE — Signal-to-Noise filter (CFR field system)
// Strips noise from payloads before ingestion + computes SNR score
// ─────────────────────────────────────────────────────────────────────────────

const SNR_NOISE_PATTERN = /[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g;
const SNR_HIGH_SIGNAL_TYPES = new Set([
  'guardian.chat.response','guardian.chat.message','guardian.picker.capture',
  'guardian.cookies.capture','guardian.bridge.callto','guardian.nexus.dispatched',
  'cesl.action','cesl.result','rat.trace','guardian.pipeline.start','guardian.pipeline.done'
]);
const SNR_LOW_SIGNAL_TYPES = new Set([
  'guardian.tab.navigate','guardian.session.connect','guardian.session.disconnect'
]);

function snrClean(data) {
  if (typeof data === 'string') return data.replace(SNR_NOISE_PATTERN,'').trim();
  if (data && typeof data === 'object') {
    const out = {};
    for (const k of Object.keys(data)) out[k] = snrClean(data[k]);
    return out;
  }
  return data;
}

function snrScore(type, payload) {
  if (SNR_HIGH_SIGNAL_TYPES.has(type)) return 1.0;
  if (SNR_LOW_SIGNAL_TYPES.has(type))  return 0.3;
  // Score by payload density: more data = higher signal
  const size = JSON.stringify(payload||{}).length;
  return Math.min(1.0, 0.5 + size / 2000);
}

// ─────────────────────────────────────────────────────────────────────────────
// FIDELITY FIELD — tracks system stability (CFR field)
// High fidelity = stable, trustworthy execution
// Low fidelity  = degraded, prioritize stability over new features
// ─────────────────────────────────────────────────────────────────────────────

function createFidelityField() {
  let _index = 1.0;
  const _history = [];
  const MAX_HIST = 100;

  function update(delta, reason) {
    _index = Math.max(0, Math.min(1.0, _index + delta));
    _history.push({ ts: Date.now(), delta, reason, index: _index });
    if (_history.length > MAX_HIST) _history.shift();
  }

  function onError(severity = 'error') {
    update(severity === 'critical' ? -0.1 : -0.05, severity);
  }

  function onSuccess() { update(+0.01, 'success'); }
  function onTimeout() { update(-0.03, 'timeout'); }
  function onReplay()  { update(+0.02, 'replay_verified'); }

  return {
    onError, onSuccess, onTimeout, onReplay,
    get index()   { return _index; },
    get history() { return [..._history]; },
    get stable()  { return _index >= 0.7; },
    toJSON() { return { index: _index, stable: _index >= 0.7 }; }
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CLOCK
// ─────────────────────────────────────────────────────────────────────────────

function createClock() {
  let _tick = 0, _seq = 0;
  return {
    nextTick() { return ++_tick; },
    nextSeq()  { return ++_seq;  },
    get tick() { return _tick; },
    get seq()  { return _seq;  },
    reset() { _tick = 0; _seq = 0; },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CAUSAL GRAPH
// ─────────────────────────────────────────────────────────────────────────────

const ET_EXPLICIT = 'causal/explicit';
const ET_RULE     = 'causal/rule';
const ET_ADAPTER  = 'causal/adapter';
const ET_OBS      = 'observational';
const CAUSAL_ET   = new Set([ET_EXPLICIT, ET_RULE, ET_ADAPTER]);

function isCausal(edge) { return CAUSAL_ET.has(edge.edgeType); }

function createCausalStore() {
  const edgeMap   = new Map();
  const childMap  = new Map();
  const causalMap = new Map();
  let _size = 0, _cv = 0;
  const _dc = new Map();

  function addEdge(from, to, edgeType, ruleName, dt, confidence = 1.0) {
    if (edgeMap.has(to)) throw new Error(`Diamond: ${to} already has parent`);
    const edge = Object.freeze({ fromId:from, toId:to, edgeType, ruleName:ruleName||'', dtTicks:dt||0, confidence });
    edgeMap.set(to, edge);
    if (!childMap.has(from)) childMap.set(from, new Set());
    childMap.get(from).add(to);
    if (isCausal(edge)) {
      if (!causalMap.has(from)) causalMap.set(from, new Set());
      causalMap.get(from).add(to);
    }
    _size++;
  }

  function getEdge(childId)    { return edgeMap.get(childId)||null; }
  function getChildren(pid)    { return [...(childMap.get(pid)||[])]; }
  function invalidateCache()   { _cv++; }

  function prune(id) {
    const edge = edgeMap.get(id);
    if (edge) {
      edgeMap.delete(id);
      const s = childMap.get(edge.fromId); if (s) { s.delete(id); if (!s.size) childMap.delete(edge.fromId); }
      const c = causalMap.get(edge.fromId); if (c) { c.delete(id); if (!c.size) causalMap.delete(edge.fromId); }
      _size = Math.max(0, _size-1);
    }
    childMap.delete(id); causalMap.delete(id); invalidateCache();
  }

  function traceToRoot(id, maxDepth=50) {
    const path=[]; let cur=id, depth=0;
    while (cur && depth<maxDepth) {
      const edge=edgeMap.get(cur); if (!edge||!isCausal(edge)) break;
      path.push({id:cur,edge}); cur=edge.fromId; depth++;
    }
    return path;
  }

  function descendants(rootId, maxDepth=50) {
    const ck=`${rootId}:${maxDepth}:${_cv}`;
    if (_dc.has(ck)) return _dc.get(ck);
    const result=[], queue=[[rootId,0]], seen=new Set();
    while (queue.length) {
      const [id,depth]=queue.shift();
      if (seen.has(id)||depth>maxDepth) continue;
      seen.add(id);
      for (const cid of (causalMap.get(id)||[])) { result.push(cid); queue.push([cid,depth+1]); }
    }
    if (_dc.size>200) _dc.clear();
    _dc.set(ck, result);
    return result;
  }

  function clear() { edgeMap.clear(); childMap.clear(); causalMap.clear(); _size=0; _dc.clear(); }
  return { addEdge, getEdge, getChildren, prune, traceToRoot, descendants, invalidateCache, clear, get size() { return _size; } };
}

function createCalltoMap() {
  const map=new Map(); let orphans=0;
  return {
    register(calltoId, eventId) { map.set(calltoId, eventId); },
    resolve(calltoId)  { const id=map.get(calltoId); if (!id) { orphans++; return null; } return id; },
    clear()            { map.clear(); orphans=0; },
    get orphanCount()  { return orphans; }
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// RING BUFFER
// ─────────────────────────────────────────────────────────────────────────────

function createRingBuffer(cap) {
  const buf=new Array(cap); let head=0, size=0;
  function push(item) {
    const evicted = size===cap ? buf[head] : null;
    buf[head]=item; head=(head+1)%cap; if (size<cap) size++;
    return evicted;
  }
  function get(i) {
    if (i<0||i>=size) return undefined;
    return buf[size<cap?i:(head+i)%cap];
  }
  function last()            { return size===0?undefined:buf[(head-1+cap)%cap]; }
  function rangeView(s,e)    { const a=Math.max(0,s),b=Math.min(size-1,e); if(a>b)return[]; const o=new Array(b-a+1); for(let i=a;i<=b;i++)o[i-a]=get(i); return o; }
  function toArray()         { const o=new Array(size); for(let i=0;i<size;i++)o[i]=get(i); return o; }
  function findLast(fn)      { for(let i=size-1;i>=0;i--){const item=get(i);if(fn(item))return item;}return null; }
  function clear()           { head=0; size=0; }
  return { push, get, last, rangeView, toArray, findLast, clear, get length() { return size; } };
}

// ─────────────────────────────────────────────────────────────────────────────
// CESL — Canonical Execution Layer
// AutomationTraceEvent emitted for every browser action
// ─────────────────────────────────────────────────────────────────────────────

const CESL_VERSION = '1.0.0';

function createCESL(ingestFn, fidelity) {
  // Active state snapshots: action-in-flight tracking
  const _pending = new Map(); // traceId → { preStateHash, startTs, intent, action }

  /**
   * Begin a browser action. Returns a traceId.
   * Must be paired with cesl.end(traceId, result, postContext).
   *
   * intent:  { type: string, gate?: string, identity?: string }
   * action:  { type: 'Click'|'Type'|'Query'|'Evaluate'|'Observe'|'Navigate', selector?, text?, url? }
   * node:    { selector?, fingerprint?, url? }  — resolved CanonicalNode
   * adapter: 'guardian-firefox'|'guardian-chrome'|'guardian-bidi'
   */
  function begin(intent, action, node, adapter, preContext) {
    const traceId = newId();
    const preStateHash = stateHash(
      preContext?.url || (typeof window !== 'undefined' ? window.location?.href : ''),
      preContext?.domFingerprint || '',
      preContext?.activeNodeSet || []
    );

    const entry = Object.freeze({
      traceId,
      intent:       Object.freeze(intent || {}),
      action:       Object.freeze(action || {}),
      resolvedNode: Object.freeze(node || {}),
      resolverVersion: CESL_VERSION,
      graphSnapshotHash: preContext?.graphHash || hash64(canonicalize(node||{})),
      chosenAdapter: adapter || 'guardian-firefox',
      preStateHash,
      startTs: Date.now(),
    });
    _pending.set(traceId, entry);

    // Emit begin event — RAT picks this up
    ingestFn('cesl.action', {
      traceId,
      phase: 'begin',
      intent,
      action,
      resolvedNode: node,
      adapter: adapter||'guardian-firefox',
      preStateHash,
      resolverVersion: CESL_VERSION,
    }, { source: 'cesl', tabId: preContext?.tabId });

    return traceId;
  }

  /**
   * End a browser action and emit the full AutomationTraceEvent.
   * result: 'success'|'failure'|'partial'
   * postContext: { url?, domFingerprint?, activeNodeSet?, graphHash? }
   * meta: { latency?, retries?, confidence? }
   */
  function end(traceId, result, postContext, meta) {
    const pending = _pending.get(traceId);
    if (!pending) {
      // Orphan end — still emit so nothing is silent
      ingestFn('cesl.orphan', { traceId, result }, { source: 'cesl' });
      return null;
    }
    _pending.delete(traceId);

    const postStateHash = stateHash(
      postContext?.url || '',
      postContext?.domFingerprint || '',
      postContext?.activeNodeSet || []
    );
    const latency = Date.now() - pending.startTs;
    const confidence = meta?.confidence ?? 1.0;

    // CESL §0: if result !== success, adjust fidelity
    if (result === 'failure')  fidelity.onError('error');
    else if (result === 'partial') fidelity.onError('warn');
    else                       fidelity.onSuccess();

    /** @type {AutomationTraceEvent} */
    const trace = Object.freeze({
      id:               newId(),
      // intent layer
      intent:           pending.intent,
      // execution layer
      action:           pending.action,
      // resolution layer
      resolvedNode:     pending.resolvedNode,
      resolverVersion:  CESL_VERSION,
      graphSnapshotHash: pending.graphSnapshotHash,
      // execution routing
      chosenAdapter:    pending.chosenAdapter,
      // pre/post state (REQUIRED for replay validity)
      preStateHash:     pending.preStateHash,
      postStateHash,
      // execution outcome
      result,
      // determinism metadata
      timestamp:        pending.startTs,
      deterministicSeed: traceId,
      // performance + behavior
      metadata: Object.freeze({
        latency,
        retries:    meta?.retries    ?? 0,
        confidence,
      }),
      // CFR fidelity at time of execution
      fidelityAtExecution: fidelity.index,
    });

    // Emit as RAT event — immutable, event-sourced truth
    ingestFn('rat.trace', trace, {
      source: 'cesl:rat',
      tabId: postContext?.tabId,
    });

    return trace;
  }

  /**
   * Quick single-shot trace for synchronous actions that can't split begin/end.
   */
  function record(intent, action, node, adapter, result, preCtx, postCtx, meta) {
    const tid = begin(intent, action, node, adapter, preCtx);
    return end(tid, result||'success', postCtx||preCtx, meta);
  }

  /** Abort a pending trace (e.g. on killswitch) */
  function abort(traceId, reason) {
    if (!_pending.has(traceId)) return;
    end(traceId, 'failure', {}, { confidence: 0, retries: 0 });
    ingestFn('cesl.aborted', { traceId, reason }, { source: 'cesl' });
  }

  function pendingCount() { return _pending.size; }

  return { begin, end, record, abort, pendingCount, version: CESL_VERSION };
}

// ─────────────────────────────────────────────────────────────────────────────
// FORENSIC CONTEXT SYNTHESIZER (CFR AI context injection)
// Distills recent events into a prompt block for AI providers
// ─────────────────────────────────────────────────────────────────────────────

function createForensicSynthesizer(ringGetAll, fidelity) {
  function getFlightPath(limit=20, typePriority=null) {
    const all = ringGetAll();
    let events = typePriority
      ? all.filter(e=>e.type===typePriority).slice(-Math.ceil(limit/2))
          .concat(all.filter(e=>e.type!==typePriority).slice(-Math.floor(limit/2)))
          .sort((a,b)=>a.seq-b.seq)
      : all.slice(-limit);

    return events
      .map(e => `[${e.type}|snr:${(e.snr||0).toFixed(2)}] ${JSON.stringify(e.payload).slice(0,200)}`)
      .join('\n');
  }

  function preparePrompt(userIntent, gateCtx={}) {
    const flightPath = getFlightPath(15, 'rat.trace');
    return `### CFR SYSTEM REALITY (v${CESL_VERSION})
Fidelity: ${fidelity.index.toFixed(3)} ${fidelity.stable?'[STABLE]':'[DEGRADED — prioritize stability]'}
Field: Guardian-Firefox · CESL+RAT+RBS active

### FLIGHT PATH (last 15 events)
${flightPath}

### GATE CONTEXT
${JSON.stringify(gateCtx).slice(0,500)}

### INTENT
${userIntent}`;
  }

  return { getFlightPath, preparePrompt };
}

// ─────────────────────────────────────────────────────────────────────────────
// MACRO DETECTOR
// ─────────────────────────────────────────────────────────────────────────────

function createMacroDetector() {
  const MACRO_WINDOW=4, MACRO_THRESHOLD=3;
  const macros=[]; const _window=['','','','']; let _head=0;
  const _counts=new Map();

  function update(ev) {
    _window[_head]=ev.type; _head=(_head+1)%MACRO_WINDOW;
    for (let len=2; len<=MACRO_WINDOW; len++) {
      const w=[]; const count=Math.min(len,MACRO_WINDOW);
      for (let i=count;i>=1;i--) { const idx=((_head-i)+MACRO_WINDOW*100)%MACRO_WINDOW; if(_window[idx]) w.push(_window[idx]); }
      if (w.length<len) continue;
      const key=w.join(' → ');
      const prev=_counts.get(key)||0, next=prev+1;
      _counts.set(key, next);
      if (next===MACRO_THRESHOLD && !macros.find(m=>m.pattern===key)) {
        macros.push({ id:newId(), pattern:key, count:next, firstSeenSeq:ev.seq, eventTs:ev.eventTs, triggerEventId:ev.id });
      } else if (next>MACRO_THRESHOLD) {
        const m=macros.find(m=>m.pattern===key); if(m) m.count=next;
      }
    }
  }
  return { update, get macros() { return macros; } };
}

// ─────────────────────────────────────────────────────────────────────────────
// BUILT-IN GATES
// ─────────────────────────────────────────────────────────────────────────────

const BUILTIN_GATES = {
  DOM_STABILITY:    'gate:dom_stability',
  SESSION_BOUNDARY: 'gate:session_boundary',
  ERROR_ESCALATION: 'gate:error_escalation',
  FIDELITY_ALERT:   'gate:fidelity_alert',
  CESL_ORPHAN:      'gate:cesl_orphan',
};

// ─────────────────────────────────────────────────────────────────────────────
// CFR KERNEL — main factory
// ─────────────────────────────────────────────────────────────────────────────

function createKernel({ ringCap=10000 } = {}) {
  const ring      = createRingBuffer(ringCap);
  const idIndex   = new Map();
  const typeIndex = new Map();
  const causal    = createCausalStore();
  const callto    = createCalltoMap();
  const seenMap   = new Map();
  const clock     = createClock();
  const fidelity  = createFidelityField();
  const macro     = createMacroDetector();
  const listeners = [];
  let droppedCount=0, _gateDepth=0, _version=0;
  const GATE_DEPTH_MAX=20;

  // CESL + forensic synthesizer — wired to ingest (defined below via closure)
  let _cesl=null, _synth=null;

  function _addToTypeIndex(type, id) {
    if (!typeIndex.has(type)) typeIndex.set(type, []);
    typeIndex.get(type).push(id);
  }

  function ingest(type, payload, meta={}) {
    const isReplay = !!meta.replayOf;
    if (isReplay) {
      const dk = dedupKey(type, payload, meta.source, meta.replayOf);
      if (seenMap.has(dk)) { droppedCount++; return seenMap.get(dk); }
    }

    // CFR: SNR clean + score
    const cleanedPayload = snrClean(payload);
    const snr = snrScore(type, cleanedPayload);

    const evEventTs = (meta.origEventTs != null) ? meta.origEventTs : clock.nextTick();
    const ev = Object.freeze({
      id:          newId(),
      seq:         clock.nextSeq(),
      ts:          Date.now(),
      eventTs:     evEventTs,
      type,
      payload:     Object.freeze(cleanedPayload ?? {}),
      snr,                                       // CFR: signal-to-noise ratio
      fidelity:    fidelity.index,               // CFR: fidelity at ingest time
      causedBy:    meta.causedBy   || null,
      edgeType:    meta.edgeType   || null,
      source:      meta.source     || 'guardian',
      sessionId:   meta.sessionId  || null,
      tabId:       meta.tabId      || null,
      srcBusName:  meta.srcBusName || null,
      replayOf:    meta.replayOf   || null,
      contentHash: contentHash(type, cleanedPayload, meta.source),
    });

    const evicted = ring.push(ev);
    if (evicted) {
      idIndex.delete(evicted.id);
      const bucket=typeIndex.get(evicted.type);
      if (bucket) { const pos=bucket.indexOf(evicted.id); if(pos>=0)bucket.splice(pos,1); if(!bucket.length)typeIndex.delete(evicted.type); }
      causal.prune(evicted.id);
    }
    idIndex.set(ev.id, ev);
    _addToTypeIndex(ev.type, ev.id);

    if (isReplay) {
      seenMap.set(dedupKey(type, cleanedPayload, meta.source, meta.replayOf), ev);
      if (seenMap.size>500) { const fk=seenMap.keys().next().value; seenMap.delete(fk); }
    }
    _version++;

    // Causal edge
    if (ev.causedBy) {
      const parent=idIndex.get(ev.causedBy);
      if (parent) {
        const et = ev.edgeType || (ev.source?.startsWith('gate:')?ET_RULE:ET_EXPLICIT);
        try {
          causal.addEdge(parent.id, ev.id, et, ev.source||'', ev.eventTs-parent.eventTs,
            et===ET_RULE||et===ET_ADAPTER?1.0:0.9);
          causal.invalidateCache();
        } catch {}
      }
    }

    // CFR: fidelity update from error types
    if (type==='cesl.action'&&ev.payload.phase==='begin') { /* no-op, wait for result */ }
    if (type==='rat.trace')  {
      if (ev.payload.result==='failure') fidelity.onError('error');
      else if (ev.payload.result==='success') fidelity.onSuccess();
    }
    if (type.includes('.error')||type.includes('command:failed')) fidelity.onError();
    if (type==='replay.verified') fidelity.onReplay();

    macro.update(ev);
    _runGates(ev);
    for (const L of listeners) { try { L(ev); } catch {} }
    return ev;
  }

  // Initialize CESL and synth after ingest is defined
  _cesl  = createCESL(ingest, fidelity);
  _synth = createForensicSynthesizer(() => ring.toArray(), fidelity);

  function _runGates(ev) {
    if (_gateDepth>=GATE_DEPTH_MAX) return;
    _gateDepth++;
    try {
      if (ev.type==='command:failed') {
        const r=(ev.payload.retryCount||ev.payload.retries)||0;
        if (r>=3) ingest('alert:critical',{reason:'command_max_retries',originalId:ev.id,retries:r},{source:BUILTIN_GATES.ERROR_ESCALATION,causedBy:ev.id,edgeType:ET_RULE});
      }
      if (ev.type==='page:navigated') {
        ingest('session:boundary',{from:ev.payload.from,to:ev.payload.to,trigger:'navigation'},{source:BUILTIN_GATES.SESSION_BOUNDARY,causedBy:ev.id,edgeType:ET_RULE});
      }
      // CFR: alert when fidelity drops below threshold
      if (fidelity.index<0.5) {
        const last=ring.findLast(e=>e.type==='alert:fidelity_degraded');
        if (!last||Date.now()-last.ts>30000) {
          ingest('alert:fidelity_degraded',{fidelity:fidelity.index,reason:'field_degraded'},{source:BUILTIN_GATES.FIDELITY_ALERT,edgeType:ET_RULE});
        }
      }
    } finally { _gateDepth--; }
  }

  // ── Public API ──────────────────────────────────────────────────────────────

  function findById(id)          { return idIndex.get(id)||null; }
  function rangeView(start,end)  { return ring.rangeView(start,end); }
  function getAll()              { return ring.toArray(); }
  function traceToRoot(id,max)   { return causal.traceToRoot(id,max); }
  function descendants(id,max)   { return causal.descendants(id,max); }
  function edgeMeta(childId)     { return causal.getEdge(childId); }
  function getChildren(id)       { return causal.getChildren(id); }
  function subscribe(fn)         { listeners.push(fn); return ()=>{ const i=listeners.indexOf(fn); if(i>=0)listeners.splice(i,1); }; }
  function registerCallto(id,ev) { callto.register(id,ev); }
  function resolveCallto(id)     { return callto.resolve(id); }

  // CFR forensic context for AI prompts
  function getForensicContext(limit=20) { return _synth.getFlightPath(limit); }
  function preparePrompt(userIntent, gateCtx) { return _synth.preparePrompt(userIntent, gateCtx); }

  function captures() {
    return ring.toArray().filter(e => {
      const def = GUARDIAN_EVENT_TYPES[e.type];
      return def && def.capture===true;
    });
  }

  function query(filter={}) {
    return ring.toArray().filter(e => {
      if (filter.type   && e.type   !==filter.type)   return false;
      if (filter.since  && e.ts      <filter.since)   return false;
      if (filter.tabId  && e.tabId  !==filter.tabId)  return false;
      if (filter.source && e.source !==filter.source) return false;
      return true;
    });
  }

  function last(type) { return ring.findLast(e=>e.type===type); }

  function reset() {
    ring.clear(); idIndex.clear(); typeIndex.clear(); causal.clear(); callto.clear();
    seenMap.clear(); clock.reset(); _version=0; droppedCount=0; _gateDepth=0;
  }

  function stats() {
    return {
      events: ring.length,
      fidelity: fidelity.toJSON(),
      macros: macro.macros.length,
      edges: causal.size,
      version: _version,
      ceslPending: _cesl.pendingCount(),
      calltoOrphans: callto.orphanCount,
    };
  }

  return {
    // Core event ingestion
    ingest,
    // Queries
    findById, rangeView, getAll, captures, query, last,
    // Causal graph
    traceToRoot, descendants, edgeMeta, getChildren,
    // Subscriptions
    subscribe,
    // Callto registry
    registerCallto, resolveCallto,
    // CESL execution tracing
    cesl: { get begin()      { return _cesl.begin.bind(_cesl); },
            get end()        { return _cesl.end.bind(_cesl);   },
            get record()     { return _cesl.record.bind(_cesl);},
            get abort()      { return _cesl.abort.bind(_cesl); },
            get pendingCount(){ return _cesl.pendingCount();    },
            get version()    { return _cesl.version;           } },
    // CFR forensic AI context
    getForensicContext, preparePrompt,
    // CFR fidelity
    fidelity,
    // State
    reset, stats,
    get length()        { return ring.length; },
    get version()       { return _version; },
    get droppedCount()  { return droppedCount; },
    get macros()        { return macro.macros; },
    get edgeCount()     { return causal.size; },
    get calltoOrphans() { return callto.orphanCount; },
    get clock()         { return clock; },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// GUARDIAN EVENT TYPE REGISTRY (unchanged from URCK — extended with CESL/RAT)
// ─────────────────────────────────────────────────────────────────────────────

const GUARDIAN_EVENT_TYPES = {
  'guardian.picker.start':       { capture: false },
  'guardian.picker.capture':     { capture: true  },
  'guardian.picker.stop':        { capture: false },
  'guardian.cookies.capture':    { capture: true  },
  'guardian.ig.dm':              { capture: true  },
  'guardian.ig.post':            { capture: true  },
  'guardian.threads.post':       { capture: true  },
  'guardian.chat.message':       { capture: true  },
  'guardian.chat.response':      { capture: true  },
  'guardian.session.connect':    { capture: false },
  'guardian.session.disconnect': { capture: false },
  'guardian.tab.navigate':       { capture: false },
  'guardian.voice.save':         { capture: true  },
  'guardian.bridge.callto':      { capture: true  },
  'guardian.bridge.result':      { capture: true  },
  // CESL/RAT additions
  'cesl.action':                 { capture: true  },
  'rat.trace':                   { capture: true  },
  'cesl.aborted':                { capture: true  },
  'cesl.orphan':                 { capture: false },
  'guardian.nexus.dispatched':   { capture: true  },
  'guardian.nexus.error':        { capture: true  },
  'guardian.pipeline.start':     { capture: true  },
  'guardian.pipeline.done':      { capture: true  },
  'alert:fidelity_degraded':     { capture: true  },
};

// ─────────────────────────────────────────────────────────────────────────────
// SINGLETON — drop-in URCK replacement named CFR (also aliased as URCK)
// ─────────────────────────────────────────────────────────────────────────────

const CFR = createKernel({ ringCap: 10000 });

// URCK-compatible alias — all existing code calling URCK.ingest() keeps working
const URCK = CFR;

// Expose globally
if (typeof window     !== 'undefined') { window.CFR     = CFR;     window.URCK     = URCK; }
if (typeof globalThis !== 'undefined') { globalThis.CFR  = CFR;     globalThis.URCK = URCK; }

// Legacy URCK helpers
if (typeof window !== 'undefined') {
  window.URCK_shortId         = shortId;
  window.URCK_GUARDIAN_EVENTS = GUARDIAN_EVENT_TYPES;
  window.EDGE_CAUSAL_EXPLICIT = ET_EXPLICIT;
  window.EDGE_CAUSAL_RULE     = ET_RULE;
  window.EDGE_CAUSAL_ADAPTER  = ET_ADAPTER;
  // CFR extras
  window.CFR_stateHash        = stateHash;
  window.CFR_CESL_VERSION     = CESL_VERSION;
}
