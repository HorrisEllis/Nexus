'use strict';
// ── core/SISOBus.js ───────────────────────────────────────────────────────────
// SISOBus — sovereign event bus. All inter-module communication routes here.
// Zero knowledge of any other module.
//
// Constitutional law (CFR §02 — PULSE AUTHORITY):
//   No state change is valid unless emitted as an immutable packet on the bus.
//   You cannot mutate state directly. You can only emit a new event.
//   The entire history of the system is a replayable event stream.
//
// Sourced from topo-kernel SISOBus + SISO (Core) Stream patterns.

const crypto     = require('crypto');
const { Event }  = require('./Event');

// ── Event type constants ──────────────────────────────────────────────────────

const EVENT_TYPES = Object.freeze({
  // SNR layer
  SIGNAL_RAW:           'signal.raw',
  SIGNAL_PASSED:        'signal.passed',
  SIGNAL_DROPPED:       'signal.dropped',

  // Plugin layer
  PLUGIN_LOADED:        'plugin.loaded',
  PLUGIN_UNLOADED:      'plugin.unloaded',
  PLUGIN_ERROR:         'plugin.error',
  PLUGIN_ENABLED:       'plugin.enabled',
  PLUGIN_DISABLED:      'plugin.disabled',
  PIPELINE_CHANGED:     'pipeline.changed',

  // Watcher layer
  WATCHER_FILE_ADD:     'watcher.file.add',
  WATCHER_FILE_CHANGE:  'watcher.file.change',
  WATCHER_FILE_REMOVE:  'watcher.file.remove',

  // System
  SYSTEM_BOOT:          'system.boot',
  SYSTEM_READY:         'system.ready',
  SYSTEM_ERROR:         'system.error',
  SYSTEM_SHUTDOWN:      'system.shutdown',

  // Toast / notifications (CFR §08 checkpoint toasts)
  TOAST_INFO:           'toast.info',
  TOAST_WARN:           'toast.warn',
  TOAST_ERROR:          'toast.error',
});

// ── SISOBus ───────────────────────────────────────────────────────────────────

class SISOBus {
  constructor(opts = {}) {
    this._id         = 'bus-' + crypto.randomBytes(4).toString('hex');
    this._handlers   = new Map();   // type → Set<fn>
    this._wildcards  = new Set();   // fn for '*' subscriptions
    this._gates      = new Map();   // id → Gate (SISO-style gate transforms)
    this._ringBuffer = [];          // recent events
    this._ringSize   = opts.ringSize || 2000;
    this._processing = new Set();   // in-flight gate:eventId keys (loop prevention)
    this._stats      = { emitted: 0, delivered: 0, errors: 0 };
  }

  // ── Subscriptions ─────────────────────────────────────────────────────────

  /**
   * Subscribe to a named event type, or '*' for all events.
   * @returns {function} unsubscribe
   */
  on(type, fn) {
    if (typeof fn !== 'function') throw new Error('SISOBus.on: fn must be a function');
    if (type === '*') {
      this._wildcards.add(fn);
      return () => this._wildcards.delete(fn);
    }
    if (!this._handlers.has(type)) this._handlers.set(type, new Set());
    this._handlers.get(type).add(fn);
    return () => this._handlers.get(type)?.delete(fn);
  }

  /** Subscribe once — auto-unsubscribes after first delivery */
  once(type, fn) {
    const unsub = this.on(type, (event) => { unsub(); fn(event); });
    return unsub;
  }

  // ── SISO Gates on the bus ────────────────────────────────────────────────
  // Gates registered here are applied BEFORE subscribers are notified.
  // They transform events in-flight. Use for SNR pipeline integration.

  registerGate(gate) {
    this._gates.set(gate.id, gate);
    return this;
  }

  unregisterGate(id) {
    this._gates.delete(id);
    return this;
  }

  // ── Emit ──────────────────────────────────────────────────────────────────

  /**
   * Emit an event. Runs matching gates (transform), then delivers to subscribers.
   * Gate errors are caught and re-emitted as system.error — never silent.
   *
   * @param {string} type
   * @param {object} data
   * @param {object} [meta]
   * @returns {Event}
   */
  emit(type, data = {}, meta = {}) {
    const event = new Event(type, data, meta);
    this._stats.emitted++;

    // Ring buffer
    this._ringBuffer.push(event);
    if (this._ringBuffer.length > this._ringSize) this._ringBuffer.shift();

    // Run matching gates (SISO §2.3 — infinite loop prevention via _processedBy)
    for (const [gateId, gate] of this._gates) {
      const key = `${gateId}:${event.id}`;
      if (this._processing.has(key)) continue;
      try {
        if (gate.matches(event)) {
          this._processing.add(key);
          gate.transform(event, this);
          this._processing.delete(key);
        }
      } catch (err) {
        this._processing.delete(key);
        // Re-emit as system error — never swallow
        if (type !== EVENT_TYPES.SYSTEM_ERROR) {
          this.emit(EVENT_TYPES.SYSTEM_ERROR, {
            gateId, error: err.message, eventId: event.id, eventType: type,
          });
        }
      }
    }

    // Deliver to typed subscribers
    const handlers = this._handlers.get(type);
    if (handlers) {
      for (const fn of handlers) {
        try { fn(event); this._stats.delivered++; }
        catch (e) { this._stats.errors++; }
      }
    }

    // Wildcards
    for (const fn of this._wildcards) {
      try { fn(event); }
      catch (e) { this._stats.errors++; }
    }

    return event;
  }

  // ── Introspection ─────────────────────────────────────────────────────────

  stats() {
    return { ...this._stats, id: this._id, ringSize: this._ringBuffer.length };
  }

  recent(n = 20) {
    return this._ringBuffer.slice(-n);
  }

  recentByType(type, n = 20) {
    return this._ringBuffer.filter(e => e.type === type).slice(-n);
  }

  health() {
    return { id: this._id, ...this._stats };
  }
}

module.exports = { SISOBus, EVENT_TYPES };
