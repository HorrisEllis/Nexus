'use strict';
// ── core/snr-passthrough.js ───────────────────────────────────────────────────
// SNR PASSTHROUGH — pluggable signal processing pipeline
// Version: 1.0.0  |  COBALT: core.snr-passthrough  |  bootPhase: 6
//
// Architecture:
//   INPUT → [plugin chain] → OUTPUT
//   Plugins are lenses applied left-to-right. Each can pass, mutate, drop, or
//   fork a signal. Any plugin can emit feedback that re-enters the input.
//
// Feedback loop:
//   OUTPUT → LOGGER → AGENT → corrected signal → INPUT
//   Driven by the feedback-loop plugin (built-in, opt-in via config).
//
// Plugin contract:  see PLUGIN_SCHEMA at bottom of file.
// HTTP API:         port 7825 (configurable via SNR_PORT env)
//
// Usage:
//   const snr = require('./core/snr-passthrough');
//   await snr.init({ plugins: ['gate', 'tag', 'whitelist'] });
//
//   // Or standalone:
//   node core/snr-passthrough.js

const http   = require('http');
const crypto = require('crypto');

const PORT       = parseInt(process.env.SNR_PORT    || '7825');
const NEXUS_PORT = parseInt(process.env.NEXUS_PORT  || '3748');
const NEXUS_BASE = `http://127.0.0.1:${NEXUS_PORT}`;
const MODULE_ID  = 'core.snr-passthrough';
const VERSION    = '1.0.0';

// ── uid ───────────────────────────────────────────────────────────────────────
function uid() { return crypto.randomUUID(); }

// ── Signal object ─────────────────────────────────────────────────────────────
// Every value entering the pipeline is wrapped in a Signal envelope.
// Plugins see and mutate the signal, never raw payloads.
function mkSignal(payload, meta = {}) {
  return {
    uuid:       uid(),
    ts:         Date.now(),
    payload,                         // arbitrary — plugin decides what it means
    meta: {
      source:   meta.source   || 'api',
      topic:    meta.topic    || 'default',
      tags:     meta.tags     || [],
      snrScore: meta.snrScore ?? null,   // set by snr-gate plugin
      passed:   meta.passed   ?? true,   // false = dropped by a gate
      drop:     null,                    // { plugin, reason } if dropped
      feedback: meta.feedback ?? false,  // true = this signal is a correction
      loopDepth:meta.loopDepth ?? 0,     // how many feedback iterations deep
      ...meta,
    },
    history: [],   // [ { plugin, action, ts, note } ]
  };
}

// ── Plugin registry ───────────────────────────────────────────────────────────
const _registry  = new Map();  // name → plugin instance
const _pipeline  = [];         // ordered plugin names (active chain)
const _log       = [];         // recent processed signals (ring buffer)
const _dropLog   = [];         // dropped signals
const _feedQueue = [];         // feedback-loop queue
const LOG_MAX    = 500;

// ── Event emitter (tiny, no deps) ─────────────────────────────────────────────
const _listeners = {};
function on(event, fn)   { (_listeners[event] = _listeners[event] || []).push(fn); }
function emit(event, data) { (_listeners[event] || []).forEach(fn => { try { fn(data); } catch(_){} }); }

// ── Core pipeline runner ──────────────────────────────────────────────────────
async function runPipeline(signal) {
  let s = signal;

  for (const name of _pipeline) {
    const plugin = _registry.get(name);
    if (!plugin || !plugin.enabled) continue;

    try {
      const result = await plugin.process(s);

      if (result === null || result === false) {
        // Plugin dropped the signal
        s.meta.passed = false;
        s.meta.drop   = { plugin: name, reason: 'plugin returned null/false', ts: Date.now() };
        s.history.push({ plugin: name, action: 'drop', ts: Date.now() });
        _push(_dropLog, s);
        emit('signal.dropped', s);
        _writeNexus('snr.signal.dropped', { uuid: s.uuid, plugin: name, topic: s.meta.topic });
        return s;
      }

      if (typeof result === 'object' && result !== null) {
        // Plugin mutated / replaced signal
        s = result;
      }

      s.history.push({ plugin: name, action: 'pass', ts: Date.now() });

    } catch (err) {
      s.history.push({ plugin: name, action: 'error', ts: Date.now(), note: err.message });
      // By default: errors are non-fatal, signal continues. Plugins can change this.
    }
  }

  s.meta.passed = true;
  _push(_log, s);
  emit('signal.passed', s);
  _writeNexus('snr.signal.passed', {
    uuid:     s.uuid,
    topic:    s.meta.topic,
    snrScore: s.meta.snrScore,
    tags:     s.meta.tags,
    feedback: s.meta.feedback,
  });

  // Feedback loop: queue corrective re-entry if enabled
  if (_registry.has('feedback-loop') && _registry.get('feedback-loop').enabled) {
    _feedQueue.push(s);
  }

  return s;
}

// ── Ring buffer push ──────────────────────────────────────────────────────────
function _push(arr, item) {
  arr.push(item);
  if (arr.length > LOG_MAX) arr.shift();
}

// ── NEXUS write ───────────────────────────────────────────────────────────────
async function _writeNexus(type, payload) {
  try {
    const data = JSON.stringify({
      uuid: uid(), type, source: MODULE_ID,
      payload, ts: Date.now(),
    });
    await _post(NEXUS_BASE + '/api/event', data);
  } catch (_) { /* NEXUS offline — silent */ }
}

function _post(url, body) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const req = http.request({
      host: parsed.hostname, port: parseInt(parsed.port),
      path: parsed.pathname + parsed.search, method: 'POST',
      headers: {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(body),
        'x-nexus-key':    process.env.NEXUS_API_KEY || 'Nexus-James-2026-Erosmancer',
      },
    }, res => {
      let raw = '';
      res.on('data', d => { raw += d; });
      res.on('end',  () => { try { resolve(JSON.parse(raw)); } catch { resolve(raw); } });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ──────────────────────────────────────────────────────────────────────────────
//  BUILT-IN PLUGINS
// ──────────────────────────────────────────────────────────────────────────────

// ── 1. SNR GATE ───────────────────────────────────────────────────────────────
// Scores the signal and drops it if below threshold.
// Like a DNS resolver: authoritative gate at the front.
const snrGatePlugin = {
  name:        'snr-gate',
  label:       'SNR Gate',
  description: 'Scores incoming signals 0–1 and drops those below threshold.',
  enabled:     true,
  config: {
    threshold:   0.25,          // drop signals below this
    scoreField:  'snrScore',    // where to write score in meta
    scorer:      null,          // function(signal) → 0–1 | null = built-in heuristics
  },

  process(signal) {
    const cfg = this.config;

    // Built-in heuristic scorer
    let score = cfg.scorer ? cfg.scorer(signal) : _defaultSnrScore(signal);
    score = Math.max(0, Math.min(1, score));
    signal.meta.snrScore = score;

    if (score < cfg.threshold) {
      signal.meta.drop = { plugin: this.name, reason: `snrScore ${score.toFixed(3)} < threshold ${cfg.threshold}` };
      return null;  // drop
    }
    return signal;
  },
};

function _defaultSnrScore(signal) {
  const p = signal.payload;
  if (!p) return 0.1;

  // Heuristics: longer content = more signal. Presence of known high-value keys.
  let score = 0.40;
  const text = JSON.stringify(p);
  if (text.length > 200)   score += 0.10;
  if (text.length > 1000)  score += 0.10;
  if (p.type)              score += 0.05;
  if (p.content || p.text) score += 0.10;
  if (p.error)             score -= 0.20;
  if (p.retry)             score -= 0.10;
  // Jitter to prevent identical score runs
  score += (Math.random() - 0.5) * 0.05;
  return score;
}

// ── 2. TAGGER ─────────────────────────────────────────────────────────────────
// Adds tags to signals based on content patterns. Like an ad-blocker's list.
const taggerPlugin = {
  name:        'tagger',
  label:       'Tagger',
  description: 'Applies tag rules to signals. Config-driven, no code changes needed.',
  enabled:     true,
  config: {
    rules: [
      // { match: fn(signal) → bool, tags: ['tag1'] }
      { match: s => s.meta.topic === 'agent',      tags: ['agent'] },
      { match: s => s.meta.feedback === true,       tags: ['feedback', 'correction'] },
      { match: s => (s.meta.snrScore ?? 1) > 0.80, tags: ['high-signal'] },
      { match: s => (s.meta.snrScore ?? 1) < 0.40, tags: ['low-signal'] },
      { match: s => s.meta.loopDepth > 0,          tags: [`loop-${s.meta.loopDepth}`] },
    ],
  },

  process(signal) {
    for (const rule of this.config.rules) {
      try {
        if (rule.match(signal)) {
          signal.meta.tags = [...new Set([...signal.meta.tags, ...rule.tags])];
        }
      } catch (_) {}
    }
    return signal;
  },
};

// ── 3. WHITELIST / BLACKLIST ──────────────────────────────────────────────────
// DNS-style allow/deny by topic, source, or tag.
const listPlugin = {
  name:        'list-filter',
  label:       'Whitelist / Blacklist',
  description: 'Allow/deny signals by topic, source, or tag. Blacklist checked first.',
  enabled:     true,
  config: {
    blacklist: {
      topics:  [],       // ['spam', 'heartbeat']
      sources: [],       // ['unknown']
      tags:    [],       // ['junk']
    },
    whitelist: {
      topics:  [],       // [] = allow all
      sources: [],
      tags:    [],
    },
    mode: 'blacklist-first',  // 'blacklist-first' | 'whitelist-only'
  },

  process(signal) {
    const { blacklist, whitelist, mode } = this.config;
    const { topic, source, tags } = signal.meta;

    // Blacklist check (always runs in blacklist-first mode)
    if (blacklist.topics.includes(topic))   return null;
    if (blacklist.sources.includes(source)) return null;
    if (tags.some(t => blacklist.tags.includes(t))) return null;

    // Whitelist check
    if (mode === 'whitelist-only') {
      const wTopicOk  = !whitelist.topics.length  || whitelist.topics.includes(topic);
      const wSourceOk = !whitelist.sources.length || whitelist.sources.includes(source);
      const wTagOk    = !whitelist.tags.length    || tags.some(t => whitelist.tags.includes(t));
      if (!wTopicOk || !wSourceOk || !wTagOk) return null;
    }

    return signal;
  },
};

// ── 4. CHECKPOINT ─────────────────────────────────────────────────────────────
// Progress gates with failure-mode toasts. Like a CI/CD pipeline step.
const checkpointPlugin = {
  name:        'checkpoint',
  label:       'Checkpoint',
  description: 'Named progress gates. Failed checks emit toast events and optionally drop.',
  enabled:     true,
  config: {
    checks: [
      // { name, test: fn(signal) → bool, dropOnFail: false, severity: 'warn' }
      {
        name:       'has-payload',
        test:       s => s.payload !== null && s.payload !== undefined,
        dropOnFail: true,
        severity:   'error',
      },
      {
        name:       'not-empty',
        test:       s => JSON.stringify(s.payload).length > 2,
        dropOnFail: false,
        severity:   'warn',
      },
    ],
  },

  process(signal) {
    for (const check of this.config.checks) {
      let passed = false;
      try { passed = check.test(signal); } catch (_) {}

      if (!passed) {
        // Emit toast
        _writeNexus(`toast.${check.severity}`, {
          message:   `SNR checkpoint failed: ${check.name}`,
          signalUuid: signal.uuid,
          topic:     signal.meta.topic,
        });

        signal.meta.tags.push(`checkpoint-fail:${check.name}`);

        if (check.dropOnFail) {
          signal.meta.drop = { plugin: this.name, reason: `checkpoint failed: ${check.name}` };
          return null;
        }
      } else {
        signal.meta.tags.push(`checkpoint-ok:${check.name}`);
      }
    }
    return signal;
  },
};

// ── 5. BEHAVIOR PATTERN ENGINE ────────────────────────────────────────────────
// Detects behavioral patterns across signals. Stateful across pipeline runs.
const bpePlugin = {
  name:        'behavior-pattern',
  label:       'Behavior Pattern Engine',
  description: 'Detects repeating patterns. Tracks source burst rates, topic sequences, anomalies.',
  enabled:     true,
  config: {
    burstWindow:    5000,    // ms window for burst detection
    burstThreshold: 10,      // signals in window = burst
    anomalyZScore:  2.5,     // z-score threshold for anomaly tagging
  },

  _sourceCounts: {},   // { source: [ts, ts, ...] }
  _topicSeq:    [],    // last 20 topics seen
  _topicCounts: {},    // { topic: count }

  process(signal) {
    const { source, topic } = signal.meta;
    const now = Date.now();
    const cfg  = this.config;

    // ── Burst detection ───
    if (!this._sourceCounts[source]) this._sourceCounts[source] = [];
    const times = this._sourceCounts[source];
    times.push(now);
    // trim window
    while (times.length && now - times[0] > cfg.burstWindow) times.shift();
    if (times.length >= cfg.burstThreshold) {
      signal.meta.tags.push('burst');
      signal.meta.burst = { source, count: times.length, windowMs: cfg.burstWindow };
    }

    // ── Topic sequence ────
    this._topicSeq.push(topic);
    if (this._topicSeq.length > 20) this._topicSeq.shift();
    this._topicCounts[topic] = (this._topicCounts[topic] || 0) + 1;

    // ── Anomaly: z-score on topic frequency ──
    const counts = Object.values(this._topicCounts);
    if (counts.length > 3) {
      const mean = counts.reduce((a, b) => a + b, 0) / counts.length;
      const std  = Math.sqrt(counts.reduce((a, b) => a + (b - mean) ** 2, 0) / counts.length) || 1;
      const z    = ((this._topicCounts[topic] || 0) - mean) / std;
      if (Math.abs(z) > cfg.anomalyZScore) {
        signal.meta.tags.push('anomaly');
        signal.meta.anomaly = { topic, z: +z.toFixed(2), mean: +mean.toFixed(1) };
      }
    }

    return signal;
  },

  stats() {
    return {
      topicCounts: this._topicCounts,
      topTopics:   Object.entries(this._topicCounts)
        .sort((a, b) => b[1] - a[1]).slice(0, 10).map(([t, c]) => ({ topic: t, count: c })),
      recentSequence: this._topicSeq.slice(-10),
    };
  },
};

// ── 6. CONTEXT INJECTOR ───────────────────────────────────────────────────────
// Appends system context (crystals, memory, agent state) to signal payloads.
const contextInjectorPlugin = {
  name:        'context-injector',
  label:       'Context Injector',
  description: 'Enriches signals with system context before they reach output. Pulls from NEXUS memory tables.',
  enabled:     false,  // opt-in — requires running NEXUS stack
  config: {
    injectCrystals: true,
    injectMemory:   true,
    maxCrystals:    3,
    maxMemory:      5,
  },

  // Context cache (refreshes every 30s)
  _cache:     null,
  _cacheAt:   0,

  async process(signal) {
    const cfg = this.config;
    const now = Date.now();

    // Refresh cache
    if (!this._cache || now - this._cacheAt > 30000) {
      try {
        this._cache = await _fetchNexus('/api/memory?table=crystals&n=20');
        this._cacheAt = now;
      } catch (_) { this._cache = []; }
    }

    const stable = (Array.isArray(this._cache) ? this._cache : [])
      .filter(c => c.state === 'stable')
      .slice(0, cfg.maxCrystals)
      .map(c => c.statement);

    if (stable.length && signal.payload && typeof signal.payload === 'object') {
      signal.payload._context = { crystals: stable };
      signal.meta.tags.push('context-injected');
    }

    return signal;
  },
};

async function _fetchNexus(path) {
  return new Promise((resolve, reject) => {
    http.get(NEXUS_BASE + path, res => {
      let raw = '';
      res.on('data', d => { raw += d; });
      res.on('end', () => { try { resolve(JSON.parse(raw)); } catch { resolve(raw); } });
    }).on('error', reject);
  });
}

// ── 7. RESONANCE FIELD ────────────────────────────────────────────────────────
// Computes a resonance score: how much this signal aligns with recent system state.
// Geometric: builds a moving field from recent signal vectors, scores distance.
const resonancePlugin = {
  name:        'resonance-field',
  label:       'Resonance Field',
  description: 'Scores signal resonance against recent system state. High resonance = familiar territory.',
  enabled:     true,
  config: {
    windowSize:    50,   // recent signals to build field from
    axes:          ['snrScore', 'loopDepth'],   // signal meta axes used
  },

  _field: [],  // recent [snrScore, loopDepth] vectors

  process(signal) {
    const axes = this.config.axes;
    const vec  = axes.map(a => {
      const v = signal.meta[a] ?? 0;
      return typeof v === 'number' ? v : 0;
    });

    // Compute mean field vector
    if (this._field.length > 2) {
      const mean = axes.map((_, i) => this._field.reduce((s, v) => s + v[i], 0) / this._field.length);
      // Euclidean distance from mean
      const dist = Math.sqrt(vec.reduce((s, v, i) => s + (v - mean[i]) ** 2, 0));
      // Resonance = 1 - normalized distance (capped)
      const maxDist = Math.sqrt(axes.length);
      signal.meta.resonance = +(1 - Math.min(dist / maxDist, 1)).toFixed(3);
    } else {
      signal.meta.resonance = 0.5;  // neutral until field builds
    }

    // Update field
    this._field.push(vec);
    if (this._field.length > this.config.windowSize) this._field.shift();

    return signal;
  },
};

// ── 8. ANALYTICS ─────────────────────────────────────────────────────────────
// Accumulates throughput, pass rate, latency stats. No-op on signal.
const analyticsPlugin = {
  name:        'analytics',
  label:       'Analytics',
  description: 'Passive stats accumulator. Throughput, pass rate, mean SNR, topic distribution.',
  enabled:     true,
  config: {},

  _stats: {
    total:     0,
    passed:    0,
    dropped:   0,
    meanSnr:   0,
    topics:    {},
    loopbacks: 0,
    startedAt: Date.now(),
  },

  process(signal) {
    const s = this._stats;
    s.total++;
    if (signal.meta.feedback) s.loopbacks++;
    const snr = signal.meta.snrScore ?? 0.5;
    s.meanSnr = (s.meanSnr * (s.total - 1) + snr) / s.total;
    s.topics[signal.meta.topic] = (s.topics[signal.meta.topic] || 0) + 1;
    return signal;
  },

  stats() {
    const s = this._stats;
    const upMs = Date.now() - s.startedAt;
    return {
      ...s,
      meanSnr:     +s.meanSnr.toFixed(3),
      uptimeMs:    upMs,
      throughputHz: +(s.total / (upMs / 1000)).toFixed(2),
      topTopics:   Object.entries(s.topics)
        .sort((a, b) => b[1] - a[1]).slice(0, 10).map(([t, c]) => ({ topic: t, count: c })),
    };
  },
};

// ── 9. FIRST PRINCIPLES ───────────────────────────────────────────────────────
// Validates signals against first-principle invariants.
// Any signal violating a principle gets flagged (not dropped by default).
const firstPrinciplesPlugin = {
  name:        'first-principles',
  label:       'First Principles',
  description: 'Validates signals against configurable invariants. Violations are flagged, not dropped.',
  enabled:     true,
  config: {
    principles: [
      {
        id:   'P1',
        name: 'non-empty payload',
        test: s => s.payload !== null && s.payload !== undefined,
      },
      {
        id:   'P2',
        name: 'known source',
        test: s => s.meta.source !== 'unknown',
      },
      {
        id:   'P3',
        name: 'loop depth bounded',
        test: s => s.meta.loopDepth < 10,
      },
    ],
    dropOnViolation: false,
  },

  process(signal) {
    const violations = [];
    for (const p of this.config.principles) {
      let ok = false;
      try { ok = p.test(signal); } catch (_) {}
      if (!ok) violations.push({ id: p.id, name: p.name });
    }

    if (violations.length) {
      signal.meta.tags.push('principle-violation');
      signal.meta.violations = violations;
      _writeNexus('toast.warn', {
        message:    `SNR first-principles violation: ${violations.map(v => v.id).join(', ')}`,
        signalUuid: signal.uuid,
      });

      if (this.config.dropOnViolation) {
        signal.meta.drop = { plugin: this.name, reason: `principle violation: ${violations.map(v => v.id).join(', ')}` };
        return null;
      }
    }

    return signal;
  },
};

// ── 10. FEEDBACK LOOP ─────────────────────────────────────────────────────────
// Routes passed signals to an agent for correction, then re-enters them.
// The agent call is fire-and-forget to NEXUS; the corrected signal arrives
// via POST /snr/input with feedback:true header.
const feedbackLoopPlugin = {
  name:        'feedback-loop',
  label:       'Feedback Loop',
  description: 'Submits passed signals to a NEXUS agent for correction. Corrected signals re-enter the pipeline.',
  enabled:     false,  // opt-in — requires NEXUS agent stack
  config: {
    agentRoute:   'guardian-claude',
    maxLoopDepth: 3,        // don't loop infinitely
    triggerTag:   null,     // null = all signals; 'needs-correction' = only tagged signals
    scoreThreshold: 0.60,   // only loop signals with SNR >= this (low-quality signals not worth correcting)
  },

  _pending: new Map(),  // uuid → signal (awaiting correction)

  async process(signal) {
    const cfg = this.config;

    // Only loop if in bounds
    if (signal.meta.loopDepth >= cfg.maxLoopDepth)  return signal;
    if ((signal.meta.snrScore ?? 0) < cfg.scoreThreshold) return signal;
    if (cfg.triggerTag && !signal.meta.tags.includes(cfg.triggerTag)) return signal;

    // Don't re-loop corrections of corrections
    if (signal.meta.feedback && signal.meta.loopDepth >= 1) return signal;

    this._pending.set(signal.uuid, signal);

    // Post to NEXUS agent system
    const prompt = `You are a signal correction agent. Review this signal and respond with an improved version of the payload. Return ONLY the corrected JSON payload, no commentary.\n\nSIGNAL:\n${JSON.stringify(signal.payload, null, 2)}\n\nCORRECTED_PAYLOAD:`;

    await _writeNexus('agent.call.requested', {
      correlationUuid: signal.uuid,
      routedTo:        cfg.agentRoute,
      prompt,
      source:          MODULE_ID,
      feedbackLoop:    true,
      loopDepth:       signal.meta.loopDepth,
    });

    return signal;  // original still passes; correction will re-enter later
  },

  // Called by the /snr/feedback endpoint when an agent correction arrives
  async applyCorrection(correlationUuid, correctedPayload) {
    const original = this._pending.get(correlationUuid);
    if (!original) return null;
    this._pending.delete(correlationUuid);

    const corrected = mkSignal(correctedPayload, {
      ...original.meta,
      feedback:  true,
      loopDepth: (original.meta.loopDepth || 0) + 1,
      tags:      [...original.meta.tags, 'corrected'],
      source:    original.meta.source,
      topic:     original.meta.topic,
    });
    corrected.history.push({ plugin: 'feedback-loop', action: 'correction-received', ts: Date.now(), note: `original: ${correlationUuid}` });

    return runPipeline(corrected);
  },
};

// ── Register all built-in plugins ──────────────────────────────────────────────
const BUILT_IN_PLUGINS = [
  snrGatePlugin,
  checkpointPlugin,
  listPlugin,
  taggerPlugin,
  firstPrinciplesPlugin,
  bpePlugin,
  resonancePlugin,
  contextInjectorPlugin,
  feedbackLoopPlugin,
  analyticsPlugin,
];

for (const p of BUILT_IN_PLUGINS) {
  _registry.set(p.name, p);
}

// Default pipeline order (can be reconfigured at runtime)
const DEFAULT_PIPELINE = [
  'checkpoint',
  'snr-gate',
  'list-filter',
  'tagger',
  'first-principles',
  'behavior-pattern',
  'resonance-field',
  'context-injector',
  'feedback-loop',
  'analytics',
];

// ── Pipeline management ───────────────────────────────────────────────────────
function setPipeline(names) {
  _pipeline.length = 0;
  for (const n of names) {
    if (_registry.has(n)) _pipeline.push(n);
    else console.warn(`[snr] unknown plugin: ${n}`);
  }
  console.log(`[snr] pipeline: ${_pipeline.join(' → ')}`);
}

// Register a custom plugin
function registerPlugin(plugin) {
  _validatePluginSchema(plugin);
  _registry.set(plugin.name, plugin);
  console.log(`[snr] registered plugin: ${plugin.name}`);
}

// ── Plugin schema validation ──────────────────────────────────────────────────
// See PLUGIN_SCHEMA export at bottom of file.
function _validatePluginSchema(p) {
  const required = ['name', 'label', 'description', 'enabled', 'process'];
  for (const field of required) {
    if (!(field in p)) throw new Error(`Plugin missing required field: '${field}'`);
  }
  if (typeof p.process !== 'function') throw new Error(`Plugin.process must be a function`);
  if (typeof p.name !== 'string' || !p.name.length) throw new Error(`Plugin.name must be a non-empty string`);
}

// ──────────────────────────────────────────────────────────────────────────────
//  HTTP API  (port 7825)
// ──────────────────────────────────────────────────────────────────────────────

function startServer() {
  const server = http.createServer(async (req, res) => {
    const url    = new URL(req.url, `http://127.0.0.1:${PORT}`);
    const method = req.method;
    const path   = url.pathname;

    // CORS for cockpit
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-nexus-key');
    if (method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

    function json(code, obj) {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(obj));
    }

    async function body() {
      return new Promise((resolve, reject) => {
        let raw = '';
        req.on('data', d => { raw += d; });
        req.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { resolve({}); } });
        req.on('error', reject);
      });
    }

    try {

      // ── POST /snr/input ──────────────────────────────────────────────────
      // Main entry point. Accepts a payload, runs the pipeline, returns result.
      if (method === 'POST' && path === '/snr/input') {
        const b = await body();
        const signal = mkSignal(b.payload ?? b, {
          source:    b.source    || req.headers['x-snr-source'] || 'api',
          topic:     b.topic     || req.headers['x-snr-topic']  || 'default',
          tags:      b.tags      || [],
          feedback:  b.feedback  || false,
          loopDepth: b.loopDepth || 0,
        });
        const result = await runPipeline(signal);
        return json(200, { ok: result.meta.passed, signal: result });
      }

      // ── POST /snr/batch ──────────────────────────────────────────────────
      // Process multiple signals. Returns array of results.
      if (method === 'POST' && path === '/snr/batch') {
        const b = await body();
        const payloads = Array.isArray(b) ? b : (b.signals || []);
        const results  = [];
        for (const p of payloads.slice(0, 100)) {
          const signal = mkSignal(p.payload ?? p, {
            source:   p.source   || 'batch',
            topic:    p.topic    || 'default',
            tags:     p.tags     || [],
            feedback: p.feedback || false,
          });
          results.push(await runPipeline(signal));
        }
        return json(200, { ok: true, count: results.length, results });
      }

      // ── POST /snr/feedback ───────────────────────────────────────────────
      // Agent correction callback. Re-enters corrected signal into pipeline.
      if (method === 'POST' && path === '/snr/feedback') {
        const b = await body();
        if (!b.correlationUuid) return json(400, { ok: false, error: 'correlationUuid required' });
        const fbPlugin = _registry.get('feedback-loop');
        if (!fbPlugin) return json(404, { ok: false, error: 'feedback-loop plugin not registered' });
        const corrected = await fbPlugin.applyCorrection(b.correlationUuid, b.payload);
        return json(200, { ok: true, corrected: !!corrected, signal: corrected });
      }

      // ── GET /snr/status ──────────────────────────────────────────────────
      if (method === 'GET' && path === '/snr/status') {
        return json(200, {
          ok:       true,
          version:  VERSION,
          pipeline: _pipeline,
          plugins:  [..._registry.values()].map(p => ({
            name: p.name, label: p.label, enabled: p.enabled,
            inPipeline: _pipeline.includes(p.name),
          })),
          log:    { passed: _log.length, dropped: _dropLog.length },
          analytics: analyticsPlugin.stats(),
        });
      }

      // ── GET /snr/log ─────────────────────────────────────────────────────
      if (method === 'GET' && path === '/snr/log') {
        const n = parseInt(url.searchParams.get('n') || '20');
        return json(200, {
          passed:  _log.slice(-n),
          dropped: _dropLog.slice(-n),
        });
      }

      // ── GET /snr/plugins ─────────────────────────────────────────────────
      if (method === 'GET' && path === '/snr/plugins') {
        return json(200, {
          plugins: [..._registry.values()].map(p => ({
            name:        p.name,
            label:       p.label,
            description: p.description,
            enabled:     p.enabled,
            config:      p.config,
            inPipeline:  _pipeline.includes(p.name),
          })),
          schema: PLUGIN_SCHEMA,
        });
      }

      // ── PUT /snr/plugins/:name ────────────────────────────────────────────
      // Enable/disable or reconfigure a plugin.
      if (method === 'PUT' && path.startsWith('/snr/plugins/')) {
        const name   = path.split('/')[3];
        const plugin = _registry.get(name);
        if (!plugin) return json(404, { ok: false, error: `plugin not found: ${name}` });
        const b = await body();
        if ('enabled' in b)   plugin.enabled = !!b.enabled;
        if (b.config)         Object.assign(plugin.config, b.config);
        return json(200, { ok: true, plugin: { name: plugin.name, enabled: plugin.enabled, config: plugin.config } });
      }

      // ── PUT /snr/pipeline ─────────────────────────────────────────────────
      // Reorder or change the active plugin chain.
      if (method === 'PUT' && path === '/snr/pipeline') {
        const b = await body();
        if (!Array.isArray(b.pipeline)) return json(400, { ok: false, error: 'pipeline must be an array of plugin names' });
        setPipeline(b.pipeline);
        return json(200, { ok: true, pipeline: _pipeline });
      }

      // ── POST /snr/plugins/register ────────────────────────────────────────
      // Register a custom plugin from JSON definition (limited — no arbitrary code exec).
      // For full plugin registration, require() the file and call registerPlugin().
      if (method === 'POST' && path === '/snr/plugins/register') {
        const b = await body();
        // JSON-based plugins can only define: name, label, description, enabled, config.
        // They cannot supply a process function via HTTP (security boundary).
        // process() defaults to pass-through.
        const plugin = {
          name:        b.name,
          label:       b.label        || b.name,
          description: b.description  || '',
          enabled:     b.enabled      ?? true,
          config:      b.config       || {},
          process(signal) { return signal; },  // pass-through stub
        };
        try {
          registerPlugin(plugin);
          return json(200, { ok: true, note: 'Plugin registered as pass-through stub. Supply a process() via require() for real logic.', name: plugin.name });
        } catch (err) {
          return json(400, { ok: false, error: err.message });
        }
      }

      // ── GET /snr/analytics ────────────────────────────────────────────────
      if (method === 'GET' && path === '/snr/analytics') {
        return json(200, {
          analytics:  analyticsPlugin.stats(),
          bpe:        bpePlugin.stats(),
        });
      }

      // ── GET /health ───────────────────────────────────────────────────────
      if (method === 'GET' && (path === '/health' || path === '/snr/health')) {
        return json(200, {
          ok: true, module: MODULE_ID, version: VERSION, port: PORT,
          pipeline: _pipeline.length, plugins: _registry.size,
          uptime: process.uptime(),
        });
      }

      // ── GET / — API index ─────────────────────────────────────────────────
      if (method === 'GET' && path === '/') {
        return json(200, {
          module:  MODULE_ID,
          version: VERSION,
          port:    PORT,
          routes: [
            'POST /snr/input       — process a single signal through the pipeline',
            'POST /snr/batch       — process up to 100 signals',
            'POST /snr/feedback    — receive agent correction (feedback loop)',
            'GET  /snr/status      — pipeline status, plugin list, analytics',
            'GET  /snr/log?n=20    — recent passed + dropped signals',
            'GET  /snr/plugins     — plugin registry + schema',
            'PUT  /snr/plugins/:n  — enable/disable or reconfigure a plugin',
            'PUT  /snr/pipeline    — reorder the plugin chain',
            'POST /snr/plugins/register — register a stub plugin by JSON',
            'GET  /snr/analytics   — throughput, BPE stats',
            'GET  /health          — health check',
          ],
        });
      }

      json(404, { ok: false, error: 'Not found' });

    } catch (err) {
      json(500, { ok: false, error: err.message });
    }
  });

  server.listen(PORT, '127.0.0.1', () => {
    console.log(`[snr-passthrough] listening on http://127.0.0.1:${PORT}`);
    console.log(`[snr-passthrough] pipeline: ${_pipeline.join(' → ')}`);
  });

  return server;
}

// ──────────────────────────────────────────────────────────────────────────────
//  MODULE API
// ──────────────────────────────────────────────────────────────────────────────

function init(cfg = {}) {
  const pipelineNames = cfg.pipeline || DEFAULT_PIPELINE;
  setPipeline(pipelineNames);

  if (cfg.plugins) {
    for (const p of cfg.plugins) {
      if (typeof p === 'object') registerPlugin(p);
    }
  }

  if (cfg.enableServer !== false) startServer();
  return { process: runPipeline, registerPlugin, setPipeline, on };
}

// ──────────────────────────────────────────────────────────────────────────────
//  PLUGIN SCHEMA — The contract every plugin must satisfy
// ──────────────────────────────────────────────────────────────────────────────

const PLUGIN_SCHEMA = {
  title:       'SNR Passthrough Plugin Schema v1.0.0',
  description: 'Contract for plugins in the NEXUS SNR signal pipeline.',
  required:    ['name', 'label', 'description', 'enabled', 'process'],
  properties: {
    name: {
      type:        'string',
      description: 'Unique kebab-case identifier. Used as pipeline reference and API key.',
      example:     'my-plugin',
    },
    label: {
      type:        'string',
      description: 'Human-readable display name. Used in UI and CLI output.',
      example:     'My Plugin',
    },
    description: {
      type:        'string',
      description: 'What this plugin does and when to use it.',
    },
    enabled: {
      type:        'boolean',
      description: 'Whether this plugin is active. Can be toggled at runtime via PUT /snr/plugins/:name.',
      default:     true,
    },
    config: {
      type:        'object',
      description: 'Plugin-specific configuration. All fields are runtime-mutable via the API. Use flat primitives (string, number, boolean, array).',
      example:     '{ "threshold": 0.5, "tags": ["important"] }',
    },
    process: {
      type:        'function',
      signature:   'async process(signal: Signal) → Signal | null | false',
      description: `
The core plugin function. Receives a Signal envelope. Must return one of:
  - The same or mutated Signal object: signal passes, pipeline continues.
  - A new Signal object: replaces the signal in the pipeline.
  - null or false: signal is dropped. Pipeline halts for this signal.
      
Never throw intentionally — errors are caught and logged as non-fatal by default.
Mutate signal.meta.tags, signal.meta.snrScore, signal.payload freely.
Do NOT mutate signal.uuid or signal.ts.
Async is fully supported.`,
      example: `
process(signal) {
  // Read
  const score = signal.meta.snrScore;
  // Mutate
  signal.meta.tags.push('processed');
  signal.payload.enriched = true;
  // Return signal to continue, null to drop
  return score > 0.3 ? signal : null;
}`,
    },
    stats: {
      type:        'function',
      signature:   'stats() → object',
      description: 'Optional. Returns plugin-specific stats for the /snr/analytics endpoint.',
      required:    false,
    },
  },
  signalShape: {
    title:       'Signal Envelope',
    description: 'The object every plugin receives and returns.',
    properties: {
      uuid:    'string  — unique signal ID (do not mutate)',
      ts:      'number  — creation timestamp ms (do not mutate)',
      payload: 'any     — the actual data. Plugins may mutate freely.',
      meta: {
        source:    'string   — origin identifier',
        topic:     'string   — routing / categorization key',
        tags:      'string[] — append-only array of string labels',
        snrScore:  'number   — 0–1 set by snr-gate plugin',
        passed:    'boolean  — false if dropped by any plugin',
        drop:      '{ plugin, reason } | null — set on drop',
        feedback:  'boolean  — true if this is a corrected re-entry',
        loopDepth: 'number   — feedback iteration count (0 = original)',
        resonance: 'number   — 0–1 set by resonance-field plugin',
        burst:     'object | null — set by behavior-pattern on burst detection',
        anomaly:   'object | null — set by behavior-pattern on anomaly detection',
        violations:'array | null — set by first-principles on violation',
      },
      history: 'array of { plugin, action, ts, note? } — pipeline trace',
    },
  },
  examplePlugin: `
// ── Example: Rate Limiter Plugin ─────────────────────────────────
const rateLimiterPlugin = {
  name:        'rate-limiter',
  label:       'Rate Limiter',
  description: 'Drops signals from a source exceeding N/sec.',
  enabled:     true,
  config: {
    maxPerSecond: 10,
    perSource:    true,
  },

  _windows: {},   // { source: [ts, ts, ...] }

  process(signal) {
    const key = this.config.perSource ? signal.meta.source : 'global';
    const now = Date.now();
    if (!this._windows[key]) this._windows[key] = [];
    const w = this._windows[key];
    w.push(now);
    while (w.length && now - w[0] > 1000) w.shift();
    if (w.length > this.config.maxPerSecond) {
      signal.meta.drop = { plugin: this.name, reason: 'rate limit exceeded' };
      return null;
    }
    return signal;
  },
};
module.exports = rateLimiterPlugin;
`,
};

// ── Standalone entry ──────────────────────────────────────────────────────────
if (require.main === module) {
  setPipeline(DEFAULT_PIPELINE);
  startServer();
}

module.exports = {
  init,
  runPipeline,
  registerPlugin,
  setPipeline,
  mkSignal,
  on,
  PLUGIN_SCHEMA,
  DEFAULT_PIPELINE,
  plugins: {
    snrGate:          snrGatePlugin,
    tagger:           taggerPlugin,
    listFilter:       listPlugin,
    checkpoint:       checkpointPlugin,
    behaviorPattern:  bpePlugin,
    contextInjector:  contextInjectorPlugin,
    resonanceField:   resonancePlugin,
    analytics:        analyticsPlugin,
    firstPrinciples:  firstPrinciplesPlugin,
    feedbackLoop:     feedbackLoopPlugin,
  },
};
