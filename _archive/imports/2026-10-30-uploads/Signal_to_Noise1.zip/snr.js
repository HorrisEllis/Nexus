#!/usr/bin/env node
'use strict';
// ── cli/snr.js ────────────────────────────────────────────────────────────────
// SNR KERNEL — CLI Interface
//
// Interactive REPL + command dispatcher for the SNR kernel.
// All kernel state changes go through the kernel's bus.
// The CLI is an observer — it never mutates state directly.
//
// Commands:
//   feed <json>        — feed a signal through the pipeline + SNR
//   status             — print kernel status
//   pipeline           — show active plugin pipeline
//   pipeline set <n,n> — reorder pipeline (comma-separated names)
//   plugins            — list all loaded plugins
//   plugin enable <n>  — enable a plugin
//   plugin disable <n> — disable a plugin
//   plugin config <n> <key> <val> — configure a plugin
//   pipeline append <n> — add plugin to end of pipeline
//   pipeline remove <n> — remove plugin from pipeline
//   trust [sourceId]   — show IME trust scores
//   whitelist <id>     — whitelist a source
//   blacklist <id>     — blacklist a source
//   threshold <0-1>    — set SNR pass threshold
//   log [n]            — show last N stream log entries
//   stats              — show analytics plugin stats
//   events [n]         — show last N bus events
//   watch              — toggle live event printing
//   rescan             — force plugin folder rescan
//   help               — show this help
//   exit / quit        — shutdown and exit

const readline = require('readline');
const path     = require('path');

// Boot kernel
const { SNRKernel } = require(path.join(__dirname, '..', 'core', 'Kernel'));

const kernel = new SNRKernel({
  logLevel: 'EVENTS',
  watchPlugins: true,
});

// ── Colors ────────────────────────────────────────────────────────────────────
const C = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  dim:    '\x1b[2m',
  green:  '\x1b[32m',
  cyan:   '\x1b[36m',
  yellow: '\x1b[33m',
  red:    '\x1b[31m',
  magenta:'\x1b[35m',
  blue:   '\x1b[34m',
  white:  '\x1b[37m',
};

const g  = s => C.green  + s + C.reset;
const c  = s => C.cyan   + s + C.reset;
const y  = s => C.yellow + s + C.reset;
const r  = s => C.red    + s + C.reset;
const d  = s => C.dim    + s + C.reset;
const b  = s => C.bold   + s + C.reset;
const m  = s => C.magenta + s + C.reset;

// ── State ─────────────────────────────────────────────────────────────────────
let _liveWatch = false;
let _rl;

// ── Bus listeners ─────────────────────────────────────────────────────────────

kernel.on('signal.passed', (event) => {
  if (!_liveWatch) return;
  const { signal, snr, gateScores } = event.data;
  const scores = gateScores
    ? Object.entries(gateScores).map(([k, v]) => `${d(k)}:${g(v.toFixed(2))}`).join(' ')
    : '';
  print(`${g('▶ PASS')} ${d(signal.sourceId)} snr=${g(snr.toFixed(3))} field=${c(signal.field)} ${scores}`);
});

kernel.on('signal.dropped', (event) => {
  if (!_liveWatch) return;
  const { signal, snr, reason } = event.data;
  print(`${r('▼ DROP')} ${d(signal?.sourceId)} snr=${r((snr||0).toFixed(3))} reason=${y(reason)}`);
});

kernel.on('plugin.loaded', (event) => {
  print(`${g('↑ PLUGIN')} ${b(event.data.name)} loaded from ${d(event.data.filename)}`);
});

kernel.on('plugin.unloaded', (event) => {
  print(`${y('↓ PLUGIN')} ${b(event.data.name)} unloaded`);
});

kernel.on('plugin.error', (event) => {
  print(`${r('✗ PLUGIN ERROR')} ${event.data.filename || event.data.name}: ${event.data.error}`);
});

kernel.on('pipeline.changed', (event) => {
  print(`${c('⟳ PIPELINE')} ${event.data.pipeline.join(' → ') || d('(empty)')}`);
});

kernel.on('system.error', (event) => {
  print(`${r('⚠ SYSTEM ERROR')} ${event.data.error}`);
});

// ── Utilities ─────────────────────────────────────────────────────────────────

function print(msg) {
  if (_rl) {
    process.stdout.write('\r\x1b[K');  // clear current line
    console.log(msg);
    _rl.prompt(true);
  } else {
    console.log(msg);
  }
}

function printTable(rows, cols) {
  const widths = cols.map(col => Math.max(col.length, ...rows.map(r => String(r[col] ?? '').length)));
  const header = cols.map((c, i) => b(c.padEnd(widths[i]))).join('  ');
  const sep    = widths.map(w => '─'.repeat(w)).join('──');
  print(header);
  print(d(sep));
  for (const row of rows) {
    print(cols.map((col, i) => String(row[col] ?? '').padEnd(widths[i])).join('  '));
  }
}

function parseJSON(str) {
  try { return JSON.parse(str); } catch (_) { return null; }
}

// ── Command handlers ──────────────────────────────────────────────────────────

const commands = {

  feed(args) {
    const raw = args.join(' ');
    let signal = parseJSON(raw);
    if (!signal) {
      // Try shorthand: feed relational connection 0.7
      // feed <field> <axis> <value> [sourceId]
      const parts = raw.trim().split(/\s+/);
      if (parts.length >= 3) {
        signal = {
          field:    parts[0],
          axis:     parts[1],
          value:    parseFloat(parts[2]),
          sourceId: parts[3] || 'cli',
          ts:       Date.now(),
        };
      } else {
        print(r('Usage: feed <json> | feed <field> <axis> <value> [sourceId]'));
        return;
      }
    }
    if (!signal.ts)       signal.ts       = Date.now();
    if (!signal.sourceId) signal.sourceId = 'cli';

    const result = kernel.feed(signal);
    const status = result.passed ? g('PASS') : r('DROP');
    const snr    = result.snr !== undefined ? ` snr=${c(result.snr.toFixed(4))}` : '';
    const reason = result.reason ? ` reason=${y(result.reason)}` : '';
    print(`${b('Signal')} ${status}${snr}${reason}`);
    if (result.gateScores) {
      const gs = Object.entries(result.gateScores)
        .map(([k, v]) => `  ${d(k.padEnd(12))} ${v >= 0.5 ? g(v.toFixed(3)) : r(v.toFixed(3))}`)
        .join('\n');
      print(b('Gate Scores:'));
      print(gs);
    }
    if (result.posterior !== undefined) {
      print(`${b('Trust:')} posterior=${c(result.posterior.toFixed(4))} composite=${c((result.composite||0).toFixed(4))}`);
    }
  },

  status() {
    const s = kernel.status();
    print(b('\n── SNR KERNEL STATUS ──────────────────────────────'));
    print(`Version:   ${c(s.version)}`);
    print(`Pipeline:  ${s.pipeline.length ? s.pipeline.map(n => g(n)).join(' → ') : d('(empty)')}`);
    print(`Plugins:   ${s.plugins.length} loaded`);
    print(`SNR:       processed=${c(s.snr.processed)} passed=${g(s.snr.passed)} dropped=${r(s.snr.dropped)}`);
    print(`Bus:       emitted=${c(s.bus.emitted)} id=${d(s.bus.id)}`);
    print(`Watcher:   ${s.watcher.running ? g('running') : r('stopped')} watching=${c(s.watcher.watchCount)} files`);
    print(`Log:       ${s.log.entries} entries (level=${c(s.log.level)})`);
  },

  pipeline(args) {
    if (!args.length) {
      const s   = kernel.status();
      const pip = s.pipeline;
      if (!pip.length) { print(d('(pipeline empty)')); return; }
      pip.forEach((name, i) => {
        const p = s.plugins.find(x => x.name === name);
        const en = p?.enabled !== false ? g('●') : r('○');
        print(`  ${d(String(i + 1).padStart(2))}  ${en} ${b(name)}`);
      });
      return;
    }
    const sub = args[0];
    if (sub === 'set') {
      const names = args.slice(1).join(' ').split(',').map(s => s.trim()).filter(Boolean);
      kernel.setPipeline(names);
    } else if (sub === 'append') {
      kernel.appendPlugin(args[1]);
    } else if (sub === 'remove') {
      kernel.removeFromPipeline(args[1]);
    } else if (sub === 'clear') {
      kernel.setPipeline([]);
    } else {
      print(r('Usage: pipeline | pipeline set <name,...> | pipeline append <name> | pipeline remove <name>'));
    }
  },

  plugins() {
    const s = kernel.status();
    const rows = s.plugins.map(p => ({
      name:      p.name,
      enabled:   p.enabled ? g('yes') : r('no'),
      pipeline:  p.inPipeline ? g('yes') : d('no'),
    }));
    if (!rows.length) { print(d('No plugins loaded')); return; }
    printTable(rows, ['name', 'enabled', 'pipeline']);
  },

  plugin(args) {
    const [sub, name, ...rest] = args;
    if (!sub || !name) {
      print(r('Usage: plugin enable|disable|config <name> [key val]'));
      return;
    }
    if (sub === 'enable') {
      const ok = kernel.enablePlugin(name);
      print(ok ? g(`Plugin '${name}' enabled`) : r(`Plugin '${name}' not found`));
    } else if (sub === 'disable') {
      const ok = kernel.disablePlugin(name);
      print(ok ? y(`Plugin '${name}' disabled`) : r(`Plugin '${name}' not found`));
    } else if (sub === 'config') {
      const [key, ...valParts] = rest;
      const valStr = valParts.join(' ');
      let val;
      try { val = JSON.parse(valStr); } catch (_) { val = valStr; }
      const ok = kernel.configurePlugin(name, { [key]: val });
      print(ok ? g(`Plugin '${name}' config.${key} = ${JSON.stringify(val)}`) : r(`Plugin '${name}' not found`));
    } else {
      print(r('Unknown subcommand: ' + sub));
    }
  },

  trust(args) {
    if (args[0]) {
      const t = kernel.trust(args[0]);
      if (!t) { print(r(`No trust record for '${args[0]}'`)); return; }
      print(b(`\n── Trust: ${args[0]} ──`));
      Object.entries(t).forEach(([k, v]) => print(`  ${d(k.padEnd(14))} ${c(String(v))}`));
    } else {
      const all = kernel.allTrust();
      const entries = Object.entries(all);
      if (!entries.length) { print(d('No trust records yet')); return; }
      const rows = entries.map(([id, t]) => ({
        sourceId: id,
        trust:    c(t.trustScore.toFixed(4)),
        passed:   g(String(t.passed)),
        failed:   r(String(t.failed)),
        total:    String(t.totalSignals),
        passRate: (t.passRate * 100).toFixed(1) + '%',
      }));
      printTable(rows, ['sourceId', 'trust', 'passed', 'failed', 'total', 'passRate']);
    }
  },

  whitelist(args) {
    if (!args[0]) { print(r('Usage: whitelist <sourceId>')); return; }
    kernel.whitelist(args[0]);
    print(g(`Whitelisted: ${args[0]}`));
  },

  blacklist(args) {
    if (!args[0]) { print(r('Usage: blacklist <sourceId>')); return; }
    kernel.blacklist(args[0]);
    print(r(`Blacklisted: ${args[0]}`));
  },

  threshold(args) {
    const v = parseFloat(args[0]);
    if (isNaN(v) || v < 0 || v > 1) { print(r('Usage: threshold <0.0-1.0>')); return; }
    kernel.setThreshold(v);
    print(g(`SNR threshold set to ${v}`));
  },

  log(args) {
    const n       = parseInt(args[0]) || 20;
    const entries = kernel.log.tail(n);
    if (!entries.length) { print(d('Log empty')); return; }
    print(b(`\n── Stream Log (last ${entries.length}) ──`));
    for (const e of entries) {
      const claimed = e.claimed ? g(e.claimed) : d('pending');
      print(`  ${d(String(e.seq).padStart(4))} ${d(new Date(e.time).toISOString().substr(11,12))} ${c(e.type.padEnd(28))} ${claimed}`);
    }
  },

  stats() {
    const all = kernel.allPluginStats();
    for (const [name, s] of Object.entries(all)) {
      if (!s) continue;
      print(b(`\n── ${name} ──`));
      if (s.total !== undefined) {
        print(`  total=${c(s.total)} throughput=${c(s.throughputHz + 'hz')} meanSnr=${c(s.meanSnr)}`);
        if (s.topTopics?.length) {
          print(`  topTopics: ${s.topTopics.slice(0, 5).map(t => `${c(t.topic)}:${t.count}`).join(', ')}`);
        }
      } else {
        print('  ' + JSON.stringify(s, null, 2).replace(/\n/g, '\n  '));
      }
    }
  },

  events(args) {
    const n = parseInt(args[0]) || 20;
    const recent = kernel.recentEvents(n);
    print(b(`\n── Recent Bus Events (last ${recent.length}) ──`));
    for (const e of recent) {
      const ts = new Date(e.ts).toISOString().substr(11, 12);
      print(`  ${d(ts)} ${c(e.type.padEnd(28))} ${d(e.id)}`);
    }
  },

  watch() {
    _liveWatch = !_liveWatch;
    print(_liveWatch ? g('Live watch ON — signals will be printed as they flow') : y('Live watch OFF'));
  },

  rescan() {
    kernel._watcher.rescan();
    print(c('Plugin folder rescanned'));
  },

  help() {
    print(b('\n── SNR Kernel CLI ─────────────────────────────────────────────'));
    print(`  ${g('feed')} <json>             Feed a signal through the pipeline`);
    print(`  ${g('feed')} <field> <axis> <val> [src]  Shorthand signal entry`);
    print(`  ${g('status')}                  Kernel status overview`);
    print(`  ${g('pipeline')}                Show active pipeline`);
    print(`  ${g('pipeline set')} <n,...>    Reorder pipeline`);
    print(`  ${g('pipeline append')} <n>     Add plugin to pipeline`);
    print(`  ${g('pipeline remove')} <n>     Remove plugin from pipeline`);
    print(`  ${g('plugins')}                 List all loaded plugins`);
    print(`  ${g('plugin enable')} <n>       Enable a plugin`);
    print(`  ${g('plugin disable')} <n>      Disable a plugin`);
    print(`  ${g('plugin config')} <n> <k> <v>  Configure a plugin field`);
    print(`  ${g('trust')} [sourceId]        Show IME trust scores`);
    print(`  ${g('whitelist')} <id>          Whitelist a source (bypass SNR)`);
    print(`  ${g('blacklist')} <id>          Blacklist a source (always drop)`);
    print(`  ${g('threshold')} <0-1>         Set SNR pass threshold`);
    print(`  ${g('log')} [n]                 Show stream log entries`);
    print(`  ${g('stats')}                   Show plugin analytics`);
    print(`  ${g('events')} [n]              Show recent bus events`);
    print(`  ${g('watch')}                   Toggle live signal printing`);
    print(`  ${g('rescan')}                  Force plugin folder rescan`);
    print(`  ${g('exit')} / ${g('quit')}           Shutdown and exit`);
    print('');
  },
};

// ── REPL ──────────────────────────────────────────────────────────────────────

function dispatch(line) {
  const parts   = line.trim().split(/\s+/);
  const cmd     = parts[0]?.toLowerCase();
  const args    = parts.slice(1);

  if (!cmd) return;

  if (cmd === 'exit' || cmd === 'quit') {
    print(d('Shutting down...'));
    kernel.shutdown();
    process.exit(0);
  }

  if (commands[cmd]) {
    try {
      commands[cmd](args);
    } catch (err) {
      print(r(`Error: ${err.message}`));
    }
  } else {
    print(r(`Unknown command: ${cmd}`) + d(' — type "help" for commands'));
  }
}

function banner() {
  console.log('');
  console.log(b(C.green + '  SNR KERNEL' + C.reset + C.dim + ' v2.0.0' + C.reset));
  console.log(C.dim + '  SISO · Bayesian SNR · Plugin Bus · Hot Reload' + C.reset);
  console.log(C.dim + '  ─────────────────────────────────────────────' + C.reset);
  console.log('');
}

function main() {
  banner();

  // Wait a tick for plugin bootstrap to complete, then show status
  setTimeout(() => {
    commands.status([]);
    console.log('');
    console.log(d('  Type "help" for commands. Type "watch" to see live signals.'));
    console.log('');

    kernel.ready();

    _rl = readline.createInterface({
      input:  process.stdin,
      output: process.stdout,
      prompt: C.cyan + 'snr' + C.reset + C.dim + '>' + C.reset + ' ',
    });

    _rl.prompt();

    _rl.on('line', (line) => {
      dispatch(line);
      _rl.prompt();
    });

    _rl.on('close', () => {
      print(d('EOF — shutting down'));
      kernel.shutdown();
      process.exit(0);
    });

    // Pipe mode: non-interactive (node cli/snr.js <<< 'feed relational a 0.5')
    if (!process.stdin.isTTY) {
      _rl.once('close', () => process.exit(0));
    }
  }, 100);
}

main();
