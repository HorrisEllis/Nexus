'use strict';
// ── core/Gate.js ──────────────────────────────────────────────────────────────
// SISO Gate primitive — the shape of the arrow in →E→E→
//
// A Gate has a unique signature (its identity in the stream's lookup table).
// It declares which events it claims via matches(), then transforms them.
//
// Constitutional constraints:
//   - No side effects beyond emitting events onto the bus
//   - Deterministic: same input → same output
//   - Single responsibility: each gate does one thing
//
// Infinite-loop prevention (SISO paper §2.3):
//   Override matches() to check !event.wasProcessedBy(this.id) when
//   your transform emits events of the same type.

class Gate {
  /**
   * @param {string} id  — unique kebab-case identifier
   */
  constructor(id) {
    if (!id || typeof id !== 'string') throw new Error('Gate: id required');
    this.id = id;
  }

  /**
   * Does this gate claim this event?
   * Default: claim events whose type === this.id
   * Override for more specific matching.
   *
   * @param {Event} event
   * @returns {boolean}
   */
  matches(event) {
    return event.type === this.id;
  }

  /**
   * Transform the event. May call bus.emit() zero or more times.
   * The original event is consumed — never re-emitted as-is.
   *
   * @param {Event} event
   * @param {SISOBus} bus
   */
  transform(event, bus) {
    // Override in subclass or use functional factory below
  }
}

/**
 * Functional factory — create a gate without subclassing.
 *
 * @param {string}   id
 * @param {function} matchFn    — (event) → bool
 * @param {function} transformFn — (event, bus) → void
 * @returns {Gate}
 */
function gate(id, matchFn, transformFn) {
  const g = new Gate(id);
  g.matches   = matchFn   || ((e) => e.type === id);
  g.transform = transformFn;
  return g;
}

module.exports = { Gate, gate };
