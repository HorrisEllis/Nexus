'use strict';
// ── plugins/checkpoint.js ─────────────────────────────────────────────────────
// CHECKPOINT — named progress gates with failure-mode toasts.
// Like a CI/CD pipeline step — named checks that must pass before continuing.
// Failed checks are tagged on the signal; dropOnFail checks halt the pipeline.

const plugin = {
  name:        'checkpoint',
  label:       'Checkpoint',
  description: 'Named progress gates. Failed checks tag the signal; dropOnFail drops it.',
  enabled:     true,
  config: {
    checks: [
      {
        name:       'has-payload',
        test:       s => s.payload !== null && s.payload !== undefined,
        dropOnFail: true,
        severity:   'error',
      },
      {
        name:       'not-empty',
        test:       s => JSON.stringify(s.payload || s).length > 2,
        dropOnFail: false,
        severity:   'warn',
      },
    ],
  },

  process(signal) {
    for (const check of this.config.checks) {
      let passed = false;
      try { passed = check.test(signal); } catch (_) {}

      if (!passed) {
        if (!signal.tags) signal.tags = [];
        signal.tags.push(`checkpoint-fail:${check.name}`);
        if (check.dropOnFail) return null;
      } else {
        if (!signal.tags) signal.tags = [];
        signal.tags.push(`checkpoint-ok:${check.name}`);
      }
    }
    return signal;
  },
};

module.exports = plugin;
