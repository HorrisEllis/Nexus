'use strict';
// ── core/StreamLog.js ─────────────────────────────────────────────────────────
// StreamLog — the audit trail.
//
// A shared object that streams write to. One log sees every event
// across a stream tree. Not a gate. Not a primitive.
// Self-observation by the infrastructure that already makes decisions.
//
// Levels (each includes everything below):
//   OFF    — nothing
//   EVENTS — sequence, timestamp, type, claimed/pending
//   DEEP   — sub-streams with parent/child IDs
//   DATA   — includes event payloads

const LEVELS = { OFF: 0, EVENTS: 1, DEEP: 2, DATA: 3 };
let _streamIdCounter = 0;

class StreamLog {
  constructor(level = 'EVENTS') {
    this.level   = level;
    this.entries = [];
    this.seq     = 0;
  }

  /**
   * Called by Stream.emit(). The stream passes what it already knows.
   * No extra work unless logging is on.
   */
  record({ streamId, parentStreamId, eventType, gateClaimed, eventData }) {
    const lvl = LEVELS[this.level] || 0;
    if (lvl === 0) return;

    const entry = {
      seq:     this.seq++,
      time:    Date.now(),
      type:    eventType,
      claimed: gateClaimed,
    };

    if (lvl >= 2) {
      entry.streamId = streamId;
      if (parentStreamId != null) entry.parentStreamId = parentStreamId;
    }

    if (lvl >= 3) {
      entry.data = eventData;
    }

    this.entries.push(entry);
  }

  nextStreamId() {
    return ++_streamIdCounter;
  }

  /** Read the full log — observation, not consumption */
  sample() {
    return {
      level:   this.level,
      count:   this.entries.length,
      entries: [...this.entries],
    };
  }

  /** Last N entries */
  tail(n = 50) {
    return this.entries.slice(-n);
  }

  /** Clear — for long-running systems that need to shed history */
  clear() {
    this.entries = [];
    this.seq = 0;
  }
}

module.exports = { StreamLog };
