'use strict';
// ── plugins/behavior-pattern.js ───────────────────────────────────────────────
// BEHAVIOR PATTERN ENGINE — detects behavioral patterns across signals.
// Stateful across pipeline runs. Tracks source burst rates, topic sequences,
// and anomaly z-scores. Tags signals with burst/anomaly markers.

const plugin = {
  name:        'behavior-pattern',
  label:       'Behavior Pattern Engine',
  description: 'Detects repeating patterns. Tracks source burst rates, topic sequences, anomalies.',
  enabled:     true,
  config: {
    burstWindow:    5000,   // ms window for burst detection
    burstThreshold: 10,     // signals in window = burst
    anomalyZScore:  2.5,    // z-score threshold for anomaly tagging
  },

  _sourceCounts: {},   // { source: [ts, ts, ...] }
  _topicSeq:    [],    // last 20 topics seen
  _topicCounts: {},    // { topic: count }

  process(signal) {
    const source = signal.sourceId || signal.source || 'unknown';
    const topic  = signal.topic    || signal.field  || 'default';
    const now    = Date.now();
    const cfg    = this.config;

    if (!signal.tags) signal.tags = [];

    // ── Burst detection ───
    if (!this._sourceCounts[source]) this._sourceCounts[source] = [];
    const times = this._sourceCounts[source];
    times.push(now);
    while (times.length && now - times[0] > cfg.burstWindow) times.shift();
    if (times.length >= cfg.burstThreshold) {
      signal.tags.push('burst');
      signal.burst = { source, count: times.length, windowMs: cfg.burstWindow };
    }

    // ── Topic sequence ────
    this._topicSeq.push(topic);
    if (this._topicSeq.length > 20) this._topicSeq.shift();
    this._topicCounts[topic] = (this._topicCounts[topic] || 0) + 1;

    // ── Anomaly: z-score on topic frequency ──
    const counts = Object.values(this._topicCounts);
    if (counts.length > 3) {
      const mean = counts.reduce((a, b) => a + b, 0) / counts.length;
      const std  = Math.sqrt(counts.reduce((a, b) => a + (b - mean) ** 2, 0) / counts.length) || 1;
      const z    = ((this._topicCounts[topic] || 0) - mean) / std;
      if (Math.abs(z) > cfg.anomalyZScore) {
        signal.tags.push('anomaly');
        signal.anomaly = { topic, z: +z.toFixed(2), mean: +mean.toFixed(1) };
      }
    }

    return signal;
  },

  stats() {
    return {
      topicCounts: this._topicCounts,
      topTopics: Object.entries(this._topicCounts)
        .sort((a, b) => b[1] - a[1]).slice(0, 10).map(([t, c]) => ({ topic: t, count: c })),
      recentSequence: this._topicSeq.slice(-10),
    };
  },
};

module.exports = plugin;
