'use strict';
// ── core/Stream.js ────────────────────────────────────────────────────────────
// SISO Stream — the processing loop. →E→E→
//
// Gates register by signature. Events arrive via emit().
// The stream looks up the event type in the gate table (O(1)).
// If a gate claims it, transform runs immediately (depth-first).
// If nothing claims it, the event lands in pending (residue).
//
// Pending events = what's left when processing settles.
// sampleHere() reads a cross-section of the live flow.
//
// StreamLog (if provided) writes every decision — shared across sub-streams.

const { StreamLog } = require('./StreamLog');

class Stream {
  /**
   * @param {object} [opts]
   * @param {StreamLog} [opts.log]
   * @param {string|null} [opts.parentStreamId]
   */
  constructor({ log = null, parentStreamId = null } = {}) {
    this.gates          = new Map();   // signature → Gate
    this.pending        = [];          // events with no claiming gate
    this.eventCount     = 0;
    this.log            = log;
    this.streamId       = log ? log.nextStreamId() : null;
    this.parentStreamId = parentStreamId;
  }

  /**
   * Register a gate. Signature must be unique — collision is a hard error.
   * @param {Gate} gate
   */
  register(gate) {
    if (this.gates.has(gate.id)) {
      throw new Error(`Signature collision: '${gate.id}'`);
    }
    this.gates.set(gate.id, gate);
  }

  /**
   * Emit an event. Processed immediately (depth-first).
   * If no gate claims it → lands in pending.
   * @param {Event} event
   */
  emit(event) {
    this.eventCount++;

    // Find claiming gate — O(1) lookup by event type, then scan for match predicates
    let claimingGate = null;
    for (const [, g] of this.gates) {
      try {
        if (g.matches(event)) { claimingGate = g; break; }
      } catch (_) {}
    }

    if (this.log) {
      this.log.record({
        streamId:       this.streamId,
        parentStreamId: this.parentStreamId,
        eventType:      event.type,
        gateClaimed:    claimingGate ? claimingGate.id : null,
        eventData:      event.data,
      });
    }

    if (claimingGate) {
      event._markProcessed(claimingGate.id);
      claimingGate.transform(event, this);
    } else {
      this.pending.push(event);
    }
  }

  /**
   * Not getResult. The flow is ongoing.
   * We choose to look now — this is a cross-section of →E→E→
   * @returns {{ pending, eventCount, gateCount }}
   */
  sampleHere() {
    return {
      pending:    [...this.pending],
      eventCount: this.eventCount,
      gateCount:  this.gates.size,
    };
  }

  /** Clear pending events (after consuming them) */
  drain() {
    const drained = [...this.pending];
    this.pending = [];
    return drained;
  }
}

module.exports = { Stream };
