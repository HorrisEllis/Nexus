'use strict';
// ── core/Kernel.js ────────────────────────────────────────────────────────────
// SNR KERNEL — sovereign entry point. The system. One object. One bus.
//
// Architecture (SISO paper + CFR §03):
//   INPUT signal
//     ↓
//   [Plugin Gate Chain] — loaded from plugins/ folder, watched live
//     ↓
//   [SNR Engine]        — 8-gate Bayesian pipeline
//     ↓
//   OUTPUT (passed to bus subscribers)
//
// Boot sequence:
//   1. SISOBus starts     — event sovereignty established
//   2. PluginWatcher starts — discovers plugins/ files, emits WATCHER_FILE_ADD
//   3. PluginLoader binds — responds to watcher events, loads plugins
//   4. SNREngine starts   — reads threshold/config from kernel opts
//   5. system.ready emitted
//
// Usage:
//   const kernel = new SNRKernel();
//   kernel.on('signal.passed', e => console.log(e.data));
//   kernel.feed({ sourceId: 'x', field: 'relational', axis: 'connection', value: 0.7, ts: Date.now() });
//
// CLI entry: cli/snr.js
// Plugin manager: plugin-manager/app.py

const path = require('path');

const { SISOBus, EVENT_TYPES } = require('./SISOBus');
const { SNREngine }            = require('./SNREngine');
const { PluginWatcher }        = require('./PluginWatcher');
const { PluginLoader }         = require('./PluginLoader');
const { Stream }               = require('./Stream');
const { StreamLog }            = require('./StreamLog');

const VERSION = '2.0.0';

class SNRKernel {
  /**
   * @param {object} [opts]
   * @param {string}  [opts.pluginsDir]       — path to plugins folder (default: ../plugins)
   * @param {number}  [opts.snrThreshold]     — SNR pass threshold 0-1 (default: 0.55)
   * @param {number}  [opts.ringSize]         — bus ring buffer size (default: 2000)
   * @param {string}  [opts.logLevel]         — StreamLog level: OFF|EVENTS|DEEP|DATA
   * @param {string[]} [opts.pipeline]        — ordered plugin names for processing
   * @param {boolean} [opts.watchPlugins]     — enable fs.watch (default: true)
   */
  constructor(opts = {}) {
    this._opts = {
      pluginsDir:   opts.pluginsDir   || path.join(__dirname, '..', 'plugins'),
      snrThreshold: opts.snrThreshold ?? 0.55,
      ringSize:     opts.ringSize     || 2000,
      logLevel:     opts.logLevel     || 'EVENTS',
      pipeline:     opts.pipeline     || null,   // null = auto (load order)
      watchPlugins: opts.watchPlugins !== false,
    };

    // ── Core primitives ────────────────────────────────────────────────────
    this.bus       = new SISOBus({ ringSize: this._opts.ringSize });
    this.log       = new StreamLog(this._opts.logLevel);
    this.stream    = new Stream({ log: this.log });

    // ── Plugin registry (shared by loader + kernel) ────────────────────────
    this._registry = new Map();   // name → plugin object
    this._pipeline = [];          // ordered plugin names (active chain)

    // ── Subsystems ─────────────────────────────────────────────────────────
    this.snr     = new SNREngine(this.bus, { threshold: this._opts.snrThreshold });
    this._watcher = new PluginWatcher(this.bus, this._opts.pluginsDir);
    this._loader  = new PluginLoader(this.bus, this._registry);

    // ── Pipeline management ────────────────────────────────────────────────
    this._bindPipelineEvents();

    // ── Boot ───────────────────────────────────────────────────────────────
    this.bus.emit(EVENT_TYPES.SYSTEM_BOOT, { version: VERSION, ts: Date.now() });
    this._watcher.start();
    if (!this._opts.watchPlugins) this._watcher.stop();
  }

  // ── Signal entry point ────────────────────────────────────────────────────

  /**
   * Feed a signal through the plugin chain, then the SNR engine.
   *
   * Plugin chain: each enabled plugin in pipeline order processes the signal.
   * If any plugin returns null/false → signal is dropped before SNR.
   * SNR then scores the (possibly mutated) signal.
   *
   * @param {object} rawSignal
   * @returns {object} result from SNREngine.feed()
   */
  feed(rawSignal) {
    // Wrap in SNR signal envelope
    let signal = this._mkSignal(rawSignal);

    // ── Plugin gate chain ────────────────────────────────────────────────
    for (const name of this._pipeline) {
      const plugin = this._registry.get(name);
      if (!plugin || !plugin.enabled) continue;

      let result;
      try {
        result = plugin.process(signal);
      } catch (err) {
        this.bus.emit(EVENT_TYPES.PLUGIN_ERROR, {
          name, error: err.message, phase: 'process',
        });
        continue;  // non-fatal: signal continues
      }

      if (result === null || result === false) {
        // Plugin dropped the signal
        this.bus.emit(EVENT_TYPES.SIGNAL_DROPPED, {
          signal, reason: `plugin:${name}`, snr: 0,
        });
        return { passed: false, snr: 0, reason: `plugin:${name}`, droppedBy: name };
      }

      if (typeof result === 'object' && result !== null) {
        signal = result;  // plugin may mutate/replace signal
      }
    }

    // ── SNR Engine ───────────────────────────────────────────────────────
    return this.snr.feed(signal);
  }

  /** Feed a batch of signals */
  feedBatch(signals) {
    return signals.map(s => this.feed(s));
  }

  // ── Subscriptions ─────────────────────────────────────────────────────────

  on(type, fn)   { return this.bus.on(type, fn); }
  once(type, fn) { return this.bus.once(type, fn); }

  // ── Pipeline management ───────────────────────────────────────────────────

  setPipeline(names) {
    this._pipeline = names.filter(n => {
      if (!this._registry.has(n)) {
        console.warn(`[kernel] unknown plugin in pipeline: ${n}`);
        return false;
      }
      return true;
    });
    this.bus.emit(EVENT_TYPES.PIPELINE_CHANGED, { pipeline: [...this._pipeline] });
    return this;
  }

  /** Append a plugin to the end of the pipeline */
  appendPlugin(name) {
    if (!this._registry.has(name)) return this;
    if (!this._pipeline.includes(name)) this._pipeline.push(name);
    this.bus.emit(EVENT_TYPES.PIPELINE_CHANGED, { pipeline: [...this._pipeline] });
    return this;
  }

  removeFromPipeline(name) {
    this._pipeline = this._pipeline.filter(n => n !== name);
    this.bus.emit(EVENT_TYPES.PIPELINE_CHANGED, { pipeline: [...this._pipeline] });
    return this;
  }

  // ── Plugin controls ───────────────────────────────────────────────────────

  enablePlugin(name)  { return this._setEnabled(name, true); }
  disablePlugin(name) { return this._setEnabled(name, false); }

  _setEnabled(name, enabled) {
    const plugin = this._registry.get(name);
    if (!plugin) return false;
    plugin.enabled = enabled;
    this.bus.emit(enabled ? EVENT_TYPES.PLUGIN_ENABLED : EVENT_TYPES.PLUGIN_DISABLED, { name });
    return true;
  }

  configurePlugin(name, config) {
    const plugin = this._registry.get(name);
    if (!plugin) return false;
    Object.assign(plugin.config, config);
    return true;
  }

  // ── SNR controls ──────────────────────────────────────────────────────────

  whitelist(sourceId) { this.snr.whitelist(sourceId); return this; }
  blacklist(sourceId) { this.snr.blacklist(sourceId); return this; }
  unlist(sourceId)    { this.snr.unlist(sourceId);    return this; }
  setThreshold(v)     { this.snr.setThreshold(v);     return this; }

  // ── Introspection ─────────────────────────────────────────────────────────

  trust(sourceId) { return this.snr.trustOf(sourceId); }
  allTrust()      { return this.snr.allTrust(); }

  status() {
    return {
      version:    VERSION,
      pipeline:   [...this._pipeline],
      plugins:    [...this._registry.values()].map(p => ({
        name:       p.name,
        label:      p.label,
        enabled:    p.enabled,
        inPipeline: this._pipeline.includes(p.name),
      })),
      snr:        this.snr.stats(),
      bus:        this.bus.stats(),
      watcher:    this._watcher.status(),
      log:        { entries: this.log.entries.length, level: this.log.level },
    };
  }

  pluginStats(name) {
    const plugin = this._registry.get(name);
    if (!plugin) return null;
    return plugin.stats ? plugin.stats() : { name, note: 'no stats() method' };
  }

  allPluginStats() {
    const out = {};
    for (const [name, plugin] of this._registry) {
      out[name] = plugin.stats ? plugin.stats() : null;
    }
    return out;
  }

  recentEvents(n = 20) { return this.bus.recent(n); }

  ready() {
    this.bus.emit(EVENT_TYPES.SYSTEM_READY, { version: VERSION, ts: Date.now() });
    return this;
  }

  shutdown() {
    this._watcher.stop();
    this.bus.emit(EVENT_TYPES.SYSTEM_SHUTDOWN, { ts: Date.now() });
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  _mkSignal(raw) {
    // Ensure signal has the minimum shape for the SNR engine
    return {
      sourceId: raw.sourceId || 'unknown',
      field:    raw.field    || 'relational',
      axis:     raw.axis     || 'default',
      value:    typeof raw.value === 'number' ? raw.value : 0,
      values:   raw.values   || undefined,
      ts:       raw.ts       || Date.now(),
      meta:     raw.meta     || {},
      payload:  raw.payload  || raw,  // preserve original for plugin access
      // SNR passthrough compat fields
      topic:    raw.topic    || raw.field || 'default',
      tags:     Array.isArray(raw.tags) ? [...raw.tags] : [],
      ...raw,
    };
  }

  _bindPipelineEvents() {
    // When a plugin is loaded, auto-append to pipeline (if not already there)
    this.bus.on(EVENT_TYPES.PLUGIN_LOADED, (event) => {
      const { name } = event.data;
      if (!this._pipeline.includes(name)) {
        this._pipeline.push(name);
        this.bus.emit(EVENT_TYPES.PIPELINE_CHANGED, { pipeline: [...this._pipeline] });
      }
    });

    // When a plugin is unloaded, remove from pipeline
    this.bus.on(EVENT_TYPES.PLUGIN_UNLOADED, (event) => {
      const { name } = event.data;
      this._pipeline = this._pipeline.filter(n => n !== name);
      this.bus.emit(EVENT_TYPES.PIPELINE_CHANGED, { pipeline: [...this._pipeline] });
    });

    // If explicit pipeline is configured, apply it once all plugins are loaded
    if (this._opts.pipeline) {
      this.bus.once(EVENT_TYPES.SYSTEM_READY, () => {
        this.setPipeline(this._opts.pipeline);
      });
    }
  }
}

module.exports = { SNRKernel, VERSION };
