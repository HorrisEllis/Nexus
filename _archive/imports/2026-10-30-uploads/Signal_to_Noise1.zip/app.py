"""
plugin-manager/app.py
─────────────────────────────────────────────────────────────────────────────
SNR KERNEL — Plugin Manager
A small Flask server that proxies the SNR kernel HTTP API and adds a
plugin file manager: create, edit, delete plugin .js files directly.

The kernel (cli/snr.js) must be running separately.
This manager talks to the kernel's HTTP API (default: port 7825)
and manages the plugins/ directory on disk.

Routes:
  GET  /                      — HTML dashboard
  GET  /api/status            — kernel status
  GET  /api/plugins           — all plugins (registry + disk files)
  POST /api/plugins/<name>/enable
  POST /api/plugins/<name>/disable
  GET  /api/plugins/<name>/source  — read plugin .js file
  PUT  /api/plugins/<name>/source  — write plugin .js file
  POST /api/plugins/new       — create new plugin from template
  DELETE /api/plugins/<name>  — delete plugin .js file
  GET  /api/pipeline          — current pipeline order
  PUT  /api/pipeline          — set pipeline order
  GET  /api/trust             — all IME trust scores
  GET  /api/events            — recent bus events
  GET  /api/log               — stream log tail
  POST /api/feed              — inject a test signal
  GET  /api/schema            — plugin schema

Usage:
  cd plugin-manager && pip install flask requests
  python app.py
  # open http://localhost:7826
"""

import os
import re
import json
import time
import pathlib
from flask import Flask, request, jsonify, send_from_directory

try:
    import requests as req_lib
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    import urllib.request, urllib.error

# ── Config ────────────────────────────────────────────────────────────────────

KERNEL_PORT   = int(os.environ.get('SNR_PORT',    '7825'))
MANAGER_PORT  = int(os.environ.get('MANAGER_PORT','7826'))
KERNEL_BASE   = f'http://127.0.0.1:{KERNEL_PORT}'
PLUGINS_DIR   = pathlib.Path(__file__).parent.parent / 'plugins'
PLUGINS_DIR.mkdir(exist_ok=True)

app = Flask(__name__, static_folder='static', template_folder='templates')

# ── Kernel proxy helpers ──────────────────────────────────────────────────────

def _kernel(method, path, data=None, timeout=2.0):
    url = KERNEL_BASE + path
    try:
        if HAS_REQUESTS:
            if method == 'GET':
                r = req_lib.get(url, timeout=timeout)
            elif method == 'POST':
                r = req_lib.post(url, json=data, timeout=timeout)
            elif method == 'PUT':
                r = req_lib.put(url, json=data, timeout=timeout)
            elif method == 'DELETE':
                r = req_lib.delete(url, timeout=timeout)
            else:
                return None, f'Unknown method: {method}'
            return r.json(), None
        else:
            # stdlib fallback
            body = json.dumps(data).encode() if data else None
            req = urllib.request.Request(url, data=body, method=method,
                headers={'Content-Type': 'application/json'} if body else {})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read()), None
    except Exception as e:
        return None, str(e)

def kernel_ok():
    _, err = _kernel('GET', '/health')
    return err is None

# ── Plugin file helpers ───────────────────────────────────────────────────────

def list_plugin_files():
    return sorted([f.name for f in PLUGINS_DIR.glob('*.js')])

def plugin_path(name):
    # Safety: strip any path traversal
    safe = re.sub(r'[^a-zA-Z0-9_\-]', '', name)
    return PLUGINS_DIR / f'{safe}.js'

PLUGIN_TEMPLATE = '''\\'use strict\\';
// ── plugins/{name}.js ─────────────────────────────────────────────────────────
// {label} — {description}

const plugin = {{
  name:        \\'{name}\\',
  label:       \\'{label}\\',
  description: \\'{description}\\',
  enabled:     true,
  config: {{
    // Add config fields here
  }},

  process(signal) {{
    // Transform or gate the signal.
    // Return signal to pass, null to drop.
    return signal;
  }},
}};

module.exports = plugin;
'''

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return DASHBOARD_HTML

@app.route('/api/status')
def api_status():
    data, err = _kernel('GET', '/snr/status')
    if err:
        return jsonify({ 'ok': False, 'error': err, 'kernelOnline': False }), 503
    return jsonify({ 'ok': True, 'kernelOnline': True, **data })

@app.route('/api/plugins', methods=['GET'])
def api_plugins():
    disk_files = list_plugin_files()
    kernel_data, err = _kernel('GET', '/snr/plugins')
    kernel_plugins = kernel_data.get('plugins', []) if kernel_data else []

    # Merge disk + kernel info
    kernel_map = { p['name']: p for p in kernel_plugins }

    result = []
    for fname in disk_files:
        name = fname[:-3]  # strip .js
        kp   = kernel_map.get(name, {})
        result.append({
            'name':        name,
            'filename':    fname,
            'label':       kp.get('label', name),
            'description': kp.get('description', ''),
            'enabled':     kp.get('enabled', None),
            'inPipeline':  kp.get('inPipeline', False),
            'inKernel':    name in kernel_map,
            'onDisk':      True,
        })

    # Kernel-only plugins (not on disk — built-in or dynamically registered)
    disk_names = { f[:-3] for f in disk_files }
    for kp in kernel_plugins:
        if kp['name'] not in disk_names:
            result.append({
                'name':        kp['name'],
                'filename':    None,
                'label':       kp.get('label', kp['name']),
                'description': kp.get('description', ''),
                'enabled':     kp.get('enabled', True),
                'inPipeline':  kp.get('inPipeline', False),
                'inKernel':    True,
                'onDisk':      False,
            })

    return jsonify({ 'ok': True, 'plugins': result, 'diskFiles': disk_files })

@app.route('/api/plugins/<name>/enable', methods=['POST'])
def api_enable_plugin(name):
    data, err = _kernel('PUT', f'/snr/plugins/{name}', { 'enabled': True })
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/plugins/<name>/disable', methods=['POST'])
def api_disable_plugin(name):
    data, err = _kernel('PUT', f'/snr/plugins/{name}', { 'enabled': False })
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/plugins/<name>/source', methods=['GET'])
def api_get_source(name):
    fp = plugin_path(name)
    if not fp.exists():
        return jsonify({ 'ok': False, 'error': 'File not found' }), 404
    return jsonify({ 'ok': True, 'name': name, 'source': fp.read_text() })

@app.route('/api/plugins/<name>/source', methods=['PUT'])
def api_put_source(name):
    body = request.get_json(force=True, silent=True) or {}
    source = body.get('source', '')
    if not source.strip():
        return jsonify({ 'ok': False, 'error': 'source required' }), 400
    fp = plugin_path(name)
    fp.write_text(source)
    return jsonify({ 'ok': True, 'name': name, 'saved': True })

@app.route('/api/plugins/new', methods=['POST'])
def api_new_plugin():
    body = request.get_json(force=True, silent=True) or {}
    name  = re.sub(r'[^a-z0-9\-]', '', body.get('name', '').lower().replace(' ', '-'))
    label = body.get('label', name)
    desc  = body.get('description', 'A custom SNR plugin.')
    if not name:
        return jsonify({ 'ok': False, 'error': 'name required' }), 400
    fp = plugin_path(name)
    if fp.exists():
        return jsonify({ 'ok': False, 'error': f"Plugin '{name}' already exists" }), 409

    source = PLUGIN_TEMPLATE.format(name=name, label=label, description=desc)
    # Fix escaped quotes in template
    source = source.replace("\\'", "'")
    fp.write_text(source)
    return jsonify({ 'ok': True, 'name': name, 'filename': fp.name })

@app.route('/api/plugins/<name>', methods=['DELETE'])
def api_delete_plugin(name):
    fp = plugin_path(name)
    if not fp.exists():
        return jsonify({ 'ok': False, 'error': 'File not found' }), 404
    fp.unlink()
    return jsonify({ 'ok': True, 'deleted': name })

@app.route('/api/pipeline', methods=['GET'])
def api_get_pipeline():
    data, err = _kernel('GET', '/snr/status')
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, 'pipeline': data.get('pipeline', []) })

@app.route('/api/pipeline', methods=['PUT'])
def api_set_pipeline():
    body = request.get_json(force=True, silent=True) or {}
    pipeline = body.get('pipeline', [])
    data, err = _kernel('PUT', '/snr/pipeline', { 'pipeline': pipeline })
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/trust')
def api_trust():
    data, err = _kernel('GET', '/snr/analytics')
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/events')
def api_events():
    n    = request.args.get('n', 20)
    data, err = _kernel('GET', f'/snr/log?n={n}')
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/log')
def api_log():
    n = request.args.get('n', 50)
    data, err = _kernel('GET', f'/snr/log?n={n}')
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/feed', methods=['POST'])
def api_feed():
    body = request.get_json(force=True, silent=True) or {}
    data, err = _kernel('POST', '/snr/input', body)
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, **data })

@app.route('/api/schema')
def api_schema():
    data, err = _kernel('GET', '/snr/plugins')
    if err:
        return jsonify({ 'ok': False, 'error': err }), 503
    return jsonify({ 'ok': True, 'schema': data.get('schema', {}) })

@app.route('/health')
def health():
    return jsonify({ 'ok': True, 'manager': 'snr-plugin-manager', 'port': MANAGER_PORT })

# ── Dashboard HTML ─────────────────────────────────────────────────────────────

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SNR Plugin Manager</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600&family=Syne:wght@600;800&display=swap');
:root {
  --bg:      #07090f;  --bg1:   #0d1018;  --bg2:   #111520;
  --border:  #1a2030;  --border2: #243040;
  --g: #00ff88; --c: #00cfff; --m: #cc44ff; --y: #f5c842; --r: #ff3655;
  --text: #8fb8d0; --dim: #3a5570; --mono: 'JetBrains Mono', monospace;
  --sans: 'Syne', sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:var(--mono);font-size:12px;height:100vh;overflow:hidden}
.app{display:grid;grid-template-rows:44px 1fr;grid-template-columns:260px 1fr;height:100vh}
header{grid-column:1/-1;display:flex;align-items:center;gap:16px;padding:0 18px;border-bottom:1px solid var(--border2);background:var(--bg1)}
.logo{font-family:var(--sans);font-weight:800;font-size:14px;letter-spacing:.1em;color:var(--g)}
.logo span{color:var(--dim);font-size:10px;margin-left:6px}
.kernel-status{margin-left:auto;font-size:10px;letter-spacing:.1em;display:flex;align-items:center;gap:8px}
.dot{width:7px;height:7px;border-radius:50%;background:var(--dim)}
.dot.online{background:var(--g);box-shadow:0 0 8px rgba(0,255,136,.6)}
.dot.offline{background:var(--r)}
aside{background:var(--bg1);border-right:1px solid var(--border);overflow-y:auto;padding:12px 0}
.section-head{font-size:9px;letter-spacing:.2em;color:var(--dim);padding:10px 16px 6px;text-transform:uppercase}
.plugin-item{display:flex;align-items:center;gap:8px;padding:7px 16px;cursor:pointer;border-left:2px solid transparent;transition:all .15s}
.plugin-item:hover{background:rgba(0,207,255,.05);border-left-color:var(--c)}
.plugin-item.active{background:rgba(0,207,255,.08);border-left-color:var(--c);color:var(--c)}
.plugin-item.in-pipeline{border-left-color:var(--g)}
.plugin-item.in-pipeline:hover,.plugin-item.in-pipeline.active{border-left-color:var(--g);color:var(--g)}
.pname{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}
.ptag{font-size:9px;padding:1px 6px;border-radius:2px;border:1px solid;letter-spacing:.06em}
.ptag-en{border-color:rgba(0,255,136,.3);color:var(--g)}
.ptag-dis{border-color:rgba(255,54,85,.3);color:var(--r)}
.ptag-pip{border-color:rgba(0,207,255,.2);color:var(--c)}
main{overflow-y:auto;padding:20px}
.panel-head{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.panel-title{font-family:var(--sans);font-size:18px;letter-spacing:.1em}
.btn{font-family:var(--mono);font-size:10px;letter-spacing:.08em;border:1px solid;padding:4px 12px;border-radius:2px;cursor:pointer;background:transparent;transition:all .15s}
.btn-g{border-color:rgba(0,255,136,.4);color:var(--g)} .btn-g:hover{background:rgba(0,255,136,.1)}
.btn-r{border-color:rgba(255,54,85,.4);color:var(--r)} .btn-r:hover{background:rgba(255,54,85,.1)}
.btn-c{border-color:rgba(0,207,255,.4);color:var(--c)} .btn-c:hover{background:rgba(0,207,255,.1)}
.btn-y{border-color:rgba(245,200,66,.4);color:var(--y)} .btn-y:hover{background:rgba(245,200,66,.1)}
.card{background:var(--bg1);border:1px solid var(--border);border-radius:2px;padding:14px 16px;margin-bottom:10px}
.card-title{font-size:10px;letter-spacing:.14em;color:var(--dim);margin-bottom:8px;text-transform:uppercase}
textarea.source{width:100%;height:420px;background:var(--bg2);border:1px solid var(--border2);color:var(--text);font-family:var(--mono);font-size:11px;line-height:1.7;padding:12px;resize:vertical;border-radius:2px;outline:none}
textarea.source:focus{border-color:var(--c)}
.kv{display:flex;gap:10px;align-items:baseline;padding:5px 0;border-bottom:1px solid var(--border)}
.kv:last-child{border-bottom:none}
.k{flex:0 0 120px;color:var(--dim);font-size:10px;letter-spacing:.1em}
.v{color:var(--text)}
.v-g{color:var(--g)} .v-r{color:var(--r)} .v-c{color:var(--c)} .v-y{color:var(--y)}
.pipeline-list{display:flex;flex-direction:column;gap:4px}
.pipeline-row{display:flex;align-items:center;gap:8px;padding:6px 10px;background:var(--bg2);border:1px solid var(--border);border-radius:2px}
.pipeline-idx{font-size:9px;color:var(--dim);width:16px}
.pill{font-size:9px;padding:1px 8px;border-radius:10px;background:rgba(0,255,136,.12);color:var(--g);border:1px solid rgba(0,255,136,.25)}
.new-form{display:grid;grid-template-columns:1fr 1fr 2fr auto;gap:8px;align-items:end;margin-bottom:16px}
.new-form input{background:var(--bg2);border:1px solid var(--border2);color:var(--text);font-family:var(--mono);font-size:11px;padding:6px 10px;border-radius:2px;outline:none;width:100%}
.new-form input:focus{border-color:var(--c)}
.new-form label{font-size:9px;color:var(--dim);letter-spacing:.1em;display:block;margin-bottom:4px}
.toast{position:fixed;bottom:20px;right:20px;background:var(--bg1);border:1px solid var(--border2);border-radius:2px;padding:10px 16px;font-size:11px;z-index:100;transform:translateY(80px);transition:transform .2s;max-width:320px}
.toast.show{transform:translateY(0)}
.toast.ok{border-color:rgba(0,255,136,.4);color:var(--g)}
.toast.err{border-color:rgba(255,54,85,.4);color:var(--r)}
.tab-bar{display:flex;gap:2px;margin-bottom:16px}
.tab{padding:6px 14px;font-size:10px;letter-spacing:.1em;border-bottom:1px solid var(--border);cursor:pointer;color:var(--dim)}
.tab.active{color:var(--c);border-bottom-color:var(--c)}
</style>
</head>
<body>
<div class="app">
  <header>
    <div class="logo">SNR KERNEL <span>PLUGIN MANAGER</span></div>
    <div class="kernel-status">
      <div class="dot" id="kernel-dot"></div>
      <span id="kernel-label">checking...</span>
    </div>
  </header>
  <aside>
    <div class="section-head">Pipeline</div>
    <div id="pipeline-sidebar"></div>
    <div class="section-head" style="margin-top:12px">All Plugins</div>
    <div id="plugin-list"></div>
    <div style="padding:12px 16px">
      <button class="btn btn-g" onclick="showNewForm()" style="width:100%">+ New Plugin</button>
    </div>
  </aside>
  <main id="main-content">
    <div class="panel-head">
      <div class="panel-title" style="color:var(--c)">OVERVIEW</div>
      <button class="btn btn-c" onclick="refresh()">↻ Refresh</button>
    </div>
    <div id="overview-content"></div>
  </main>
</div>
<div class="toast" id="toast"></div>

<script>
let _plugins = [];
let _pipeline = [];
let _kernelOnline = false;
let _selectedPlugin = null;

async function api(method, path, data) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (data) opts.body = JSON.stringify(data);
  const r = await fetch('/api' + path, opts);
  return r.json();
}

function toast(msg, ok=true) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show ' + (ok ? 'ok' : 'err');
  setTimeout(() => el.className = 'toast', 2800);
}

async function refresh() {
  const [status, pluginsData] = await Promise.all([
    api('GET', '/status'),
    api('GET', '/plugins'),
  ]);
  _kernelOnline = status.kernelOnline || false;
  document.getElementById('kernel-dot').className   = 'dot ' + (_kernelOnline ? 'online' : 'offline');
  document.getElementById('kernel-label').textContent = _kernelOnline ? 'kernel online' : 'kernel offline';

  _plugins  = pluginsData.plugins || [];
  _pipeline = status.pipeline || [];
  renderSidebar();
  if (!_selectedPlugin) renderOverview(status);
}

function renderSidebar() {
  // Pipeline section
  const pip = document.getElementById('pipeline-sidebar');
  pip.innerHTML = _pipeline.map((name, i) =>
    `<div class="plugin-item in-pipeline ${_selectedPlugin===name?'active':''}" onclick="selectPlugin('${name}')">
      <span style="color:var(--dim);font-size:9px;width:14px">${i+1}</span>
      <span class="pname">${name}</span>
    </div>`
  ).join('') || '<div style="padding:6px 16px;color:var(--dim);font-size:10px">empty</div>';

  // All plugins
  const list = document.getElementById('plugin-list');
  list.innerHTML = _plugins.map(p =>
    `<div class="plugin-item ${p.inPipeline?'in-pipeline':''} ${_selectedPlugin===p.name?'active':''}" onclick="selectPlugin('${p.name}')">
      <span class="pname">${p.name}</span>
      ${p.enabled===true?'<span class="ptag ptag-en">on</span>':p.enabled===false?'<span class="ptag ptag-dis">off</span>':''}
      ${p.inPipeline?'<span class="ptag ptag-pip">pipe</span>':''}
    </div>`
  ).join('') || '<div style="padding:6px 16px;color:var(--dim);font-size:10px">none</div>';
}

function renderOverview(status) {
  const el = document.getElementById('main-content');
  if (!_kernelOnline) {
    el.innerHTML = `<div class="panel-head"><div class="panel-title" style="color:var(--r)">KERNEL OFFLINE</div><button class="btn btn-c" onclick="refresh()">↻ Retry</button></div>
    <div class="card"><p style="color:var(--r)">Cannot connect to kernel on port ${status.kernelPort||7825}. Start the kernel with: <code>node cli/snr.js</code></p></div>`;
    return;
  }
  const snr = status.snr || {};
  el.innerHTML = `
  <div class="panel-head">
    <div class="panel-title" style="color:var(--c)">OVERVIEW</div>
    <button class="btn btn-c" onclick="refresh()">↻ Refresh</button>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:16px">
    <div class="card">
      <div class="card-title">SNR Stats</div>
      <div class="kv"><div class="k">processed</div><div class="v v-c">${snr.processed||0}</div></div>
      <div class="kv"><div class="k">passed</div><div class="v v-g">${snr.passed||0}</div></div>
      <div class="kv"><div class="k">dropped</div><div class="v v-r">${snr.dropped||0}</div></div>
    </div>
    <div class="card">
      <div class="card-title">Pipeline</div>
      ${(_pipeline).map((n,i) => `<div class="kv"><div class="k">${i+1}</div><div class="v v-g">${n}</div></div>`).join('')||'<div class="kv"><div class="v" style="color:var(--dim)">empty</div></div>'}
    </div>
    <div class="card">
      <div class="card-title">Plugins</div>
      <div class="kv"><div class="k">loaded</div><div class="v v-c">${_plugins.length}</div></div>
      <div class="kv"><div class="k">in pipeline</div><div class="v v-g">${_pipeline.length}</div></div>
      <div class="kv"><div class="k">enabled</div><div class="v v-g">${_plugins.filter(p=>p.enabled).length}</div></div>
    </div>
  </div>
  <div class="card">
    <div class="card-title">All Plugins</div>
    <table style="width:100%;border-collapse:collapse;font-size:11px">
      <tr style="color:var(--dim);font-size:9px;letter-spacing:.12em">
        <th style="text-align:left;padding:4px 8px">NAME</th>
        <th style="text-align:left;padding:4px 8px">ENABLED</th>
        <th style="text-align:left;padding:4px 8px">PIPELINE</th>
        <th style="text-align:left;padding:4px 8px">ON DISK</th>
        <th style="padding:4px 8px"></th>
      </tr>
      ${_plugins.map(p => `<tr style="border-top:1px solid var(--border)">
        <td style="padding:6px 8px;cursor:pointer;color:var(--c)" onclick="selectPlugin('${p.name}')">${p.name}</td>
        <td style="padding:6px 8px">${p.enabled===true?'<span style="color:var(--g)">yes</span>':p.enabled===false?'<span style="color:var(--r)">no</span>':'<span style="color:var(--dim)">—</span>'}</td>
        <td style="padding:6px 8px">${p.inPipeline?'<span style="color:var(--g)">yes</span>':'<span style="color:var(--dim)">no</span>'}</td>
        <td style="padding:6px 8px">${p.onDisk?'<span style="color:var(--g)">yes</span>':'<span style="color:var(--dim)">kernel only</span>'}</td>
        <td style="padding:6px 8px;text-align:right">
          ${p.enabled!==false?`<button class="btn btn-y" onclick="disablePlugin('${p.name}')">disable</button>`:
                              `<button class="btn btn-g" onclick="enablePlugin('${p.name}')">enable</button>`}
          <button class="btn btn-c" onclick="selectPlugin('${p.name}')">edit</button>
        </td>
      </tr>`).join('')}
    </table>
  </div>`;
}

async function selectPlugin(name) {
  _selectedPlugin = name;
  renderSidebar();
  const el = document.getElementById('main-content');
  const p  = _plugins.find(x => x.name === name) || { name, onDisk: false };
  let source = '';
  if (p.onDisk) {
    const r = await api('GET', `/plugins/${name}/source`);
    source = r.source || '';
  }
  el.innerHTML = `
  <div class="panel-head">
    <div class="panel-title" style="color:var(--g)">${name}</div>
    <div style="display:flex;gap:6px;margin-left:auto">
      ${p.enabled===false?`<button class="btn btn-g" onclick="enablePlugin('${name}')">Enable</button>`:`<button class="btn btn-y" onclick="disablePlugin('${name}')">Disable</button>`}
      ${p.inPipeline?`<button class="btn btn-r" onclick="removeFromPipeline('${name}')">Remove from Pipeline</button>`:`<button class="btn btn-c" onclick="addToPipeline('${name}')">Add to Pipeline</button>`}
      ${p.onDisk?`<button class="btn btn-r" onclick="deletePlugin('${name}')">Delete File</button>`:''}
      <button class="btn btn-c" onclick="refresh();_selectedPlugin=null;">✕ Close</button>
    </div>
  </div>
  <div class="card">
    <div class="card-title">Info</div>
    <div class="kv"><div class="k">name</div><div class="v v-c">${name}</div></div>
    <div class="kv"><div class="k">label</div><div class="v">${p.label||'—'}</div></div>
    <div class="kv"><div class="k">enabled</div><div class="v ${p.enabled?'v-g':'v-r'}">${p.enabled}</div></div>
    <div class="kv"><div class="k">in pipeline</div><div class="v ${p.inPipeline?'v-g':'v-dim'}">${p.inPipeline}</div></div>
    <div class="kv"><div class="k">on disk</div><div class="v">${p.onDisk}</div></div>
  </div>
  ${p.onDisk ? `
  <div class="card">
    <div class="card-title">Source — plugins/${name}.js</div>
    <textarea class="source" id="source-editor">${source.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</textarea>
    <div style="display:flex;gap:8px;margin-top:10px">
      <button class="btn btn-g" onclick="saveSource('${name}')">Save File</button>
      <span style="color:var(--dim);font-size:10px;align-self:center">File saved → kernel hot-reloads automatically</span>
    </div>
  </div>` : '<div class="card" style="color:var(--dim)">Plugin is kernel-only (not a physical file). Restart kernel to modify.</div>'}`;
}

async function saveSource(name) {
  const source = document.getElementById('source-editor').value;
  const r = await api('PUT', `/plugins/${name}/source`, { source });
  toast(r.ok ? `${name}.js saved — kernel will hot-reload` : r.error, r.ok);
}

async function enablePlugin(name) {
  const r = await api('POST', `/plugins/${name}/enable`);
  toast(r.ok ? `${name} enabled` : r.error, r.ok);
  await refresh();
  if (_selectedPlugin === name) selectPlugin(name);
}

async function disablePlugin(name) {
  const r = await api('POST', `/plugins/${name}/disable`);
  toast(r.ok ? `${name} disabled` : r.error, r.ok);
  await refresh();
  if (_selectedPlugin === name) selectPlugin(name);
}

async function addToPipeline(name) {
  const newPipeline = [..._pipeline.filter(n=>n!==name), name];
  const r = await api('PUT', '/pipeline', { pipeline: newPipeline });
  toast(r.ok ? `${name} added to pipeline` : r.error, r.ok);
  await refresh();
}

async function removeFromPipeline(name) {
  const newPipeline = _pipeline.filter(n=>n!==name);
  const r = await api('PUT', '/pipeline', { pipeline: newPipeline });
  toast(r.ok ? `${name} removed from pipeline` : r.error, r.ok);
  await refresh();
}

async function deletePlugin(name) {
  if (!confirm(`Delete plugins/${name}.js from disk?`)) return;
  const r = await api('DELETE', `/plugins/${name}`);
  toast(r.ok ? `${name} deleted` : r.error, r.ok);
  _selectedPlugin = null;
  await refresh();
}

function showNewForm() {
  const el = document.getElementById('main-content');
  el.innerHTML = `
  <div class="panel-head">
    <div class="panel-title" style="color:var(--g)">New Plugin</div>
  </div>
  <div class="card">
    <div class="card-title">Create Plugin File</div>
    <div class="new-form">
      <div><label>NAME (kebab-case)</label><input id="np-name" placeholder="my-plugin"></div>
      <div><label>LABEL</label><input id="np-label" placeholder="My Plugin"></div>
      <div><label>DESCRIPTION</label><input id="np-desc" placeholder="What does it do?"></div>
      <button class="btn btn-g" onclick="createPlugin()" style="align-self:end">Create</button>
    </div>
    <p style="color:var(--dim);font-size:10px">A plugin .js file will be created in the plugins/ folder with a pass-through template. The kernel will hot-reload it automatically.</p>
  </div>`;
}

async function createPlugin() {
  const name  = document.getElementById('np-name').value.trim();
  const label = document.getElementById('np-label').value.trim() || name;
  const desc  = document.getElementById('np-desc').value.trim() || 'A custom SNR plugin.';
  if (!name) { toast('Name required', false); return; }
  const r = await api('POST', '/plugins/new', { name, label, description: desc });
  if (r.ok) {
    toast(`${r.filename} created`);
    await refresh();
    selectPlugin(name);
  } else {
    toast(r.error, false);
  }
}

// Auto-refresh every 5s
setInterval(refresh, 5000);
refresh();
</script>
</body>
</html>"""

# ── Entry ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print(f'')
    print(f'  SNR Plugin Manager')
    print(f'  ──────────────────────────────────────')
    print(f'  Manager:  http://localhost:{MANAGER_PORT}')
    print(f'  Kernel:   {KERNEL_BASE} (must be running separately)')
    print(f'  Plugins:  {PLUGINS_DIR}')
    print(f'')
    app.run(host='0.0.0.0', port=MANAGER_PORT, debug=False)
