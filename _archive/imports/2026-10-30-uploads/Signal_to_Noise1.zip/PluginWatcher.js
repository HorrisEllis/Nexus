'use strict';
// ── core/PluginWatcher.js ─────────────────────────────────────────────────────
// PLUGIN WATCHER — event bus bridge for the plugins/ folder.
//
// Watches the plugins/ directory using fs.watch (no external deps).
// When a .js file is added, changed, or removed:
//   → emits WATCHER_FILE_* events onto the SISOBus
//   → PluginLoader (in Kernel) responds by hot-loading/unloading
//
// This implements the SISO paper's architectural principle:
//   "Plugins are gates registered by signature."
// The watcher is the discovery mechanism that feeds the gate registry.
//
// Uses a debounce per file to handle editor temp-file churn.
// Falls back gracefully if fs.watch is unavailable (CI envs).

const fs    = require('fs');
const path  = require('path');
const { EVENT_TYPES } = require('./SISOBus');

const DEBOUNCE_MS = 150;
const PLUGIN_EXT  = '.js';

class PluginWatcher {
  /**
   * @param {SISOBus} bus
   * @param {string}  pluginsDir   — absolute path to plugins folder
   */
  constructor(bus, pluginsDir) {
    if (!bus)        throw new Error('PluginWatcher: bus required');
    if (!pluginsDir) throw new Error('PluginWatcher: pluginsDir required');

    this._bus        = bus;
    this._dir        = pluginsDir;
    this._watcher    = null;
    this._debounces  = new Map();   // filename → timeout handle
    this._known      = new Set();   // currently tracked plugin files
    this._running    = false;
  }

  /**
   * Start watching. Emits PLUGIN_LOADED for all existing files first.
   */
  start() {
    if (this._running) return this;
    this._running = true;

    // Ensure directory exists
    if (!fs.existsSync(this._dir)) {
      fs.mkdirSync(this._dir, { recursive: true });
    }

    // Bootstrap: emit add events for all existing plugins
    try {
      const files = fs.readdirSync(this._dir).filter(f => f.endsWith(PLUGIN_EXT));
      for (const file of files) {
        this._known.add(file);
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_ADD, {
          file,
          filePath: path.join(this._dir, file),
          source: 'bootstrap',
        });
      }
    } catch (err) {
      this._bus.emit(EVENT_TYPES.SYSTEM_ERROR, {
        source: 'PluginWatcher.bootstrap',
        error: err.message,
      });
    }

    // Start fs.watch
    try {
      this._watcher = fs.watch(this._dir, { persistent: false }, (eventType, filename) => {
        if (!filename || !filename.endsWith(PLUGIN_EXT)) return;
        this._debounce(filename, () => this._handleChange(filename));
      });

      this._watcher.on('error', (err) => {
        this._bus.emit(EVENT_TYPES.SYSTEM_ERROR, {
          source: 'PluginWatcher.watch',
          error: err.message,
        });
      });

    } catch (err) {
      // fs.watch unavailable — emit warning but don't crash
      this._bus.emit(EVENT_TYPES.TOAST_WARN, {
        message: `PluginWatcher: fs.watch unavailable (${err.message}). Hot-reload disabled.`,
      });
    }

    return this;
  }

  stop() {
    if (this._watcher) {
      this._watcher.close();
      this._watcher = null;
    }
    // Clear all debounce timers
    for (const handle of this._debounces.values()) clearTimeout(handle);
    this._debounces.clear();
    this._running = false;
    return this;
  }

  /** Manually trigger a re-scan (useful for testing) */
  rescan() {
    if (!fs.existsSync(this._dir)) return;
    const currentFiles = new Set(
      fs.readdirSync(this._dir).filter(f => f.endsWith(PLUGIN_EXT))
    );

    // Additions
    for (const file of currentFiles) {
      if (!this._known.has(file)) {
        this._known.add(file);
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_ADD, {
          file,
          filePath: path.join(this._dir, file),
          source: 'rescan',
        });
      }
    }

    // Removals
    for (const file of this._known) {
      if (!currentFiles.has(file)) {
        this._known.delete(file);
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_REMOVE, {
          file,
          filePath: path.join(this._dir, file),
          source: 'rescan',
        });
      }
    }
  }

  // ── Internal ────────────────────────────────────────────────────────────────

  _debounce(filename, fn) {
    if (this._debounces.has(filename)) clearTimeout(this._debounces.get(filename));
    this._debounces.set(filename, setTimeout(() => {
      this._debounces.delete(filename);
      fn();
    }, DEBOUNCE_MS));
  }

  _handleChange(filename) {
    const filePath = path.join(this._dir, filename);
    const exists   = fs.existsSync(filePath);

    if (exists) {
      if (this._known.has(filename)) {
        // Modified
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_CHANGE, { file: filename, filePath, source: 'watch' });
      } else {
        // New file
        this._known.add(filename);
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_ADD, { file: filename, filePath, source: 'watch' });
      }
    } else {
      if (this._known.has(filename)) {
        // Deleted
        this._known.delete(filename);
        this._bus.emit(EVENT_TYPES.WATCHER_FILE_REMOVE, { file: filename, filePath, source: 'watch' });
      }
    }
  }

  status() {
    return {
      running:    this._running,
      dir:        this._dir,
      watching:   [...this._known],
      watchCount: this._known.size,
    };
  }
}

module.exports = { PluginWatcher };
