'use strict';
// ── plugins/analytics.js ─────────────────────────────────────────────────────
// ANALYTICS — passive stats accumulator. Throughput, pass rate, mean SNR, 
// topic distribution. No-op on signal (never drops, never mutates).

const plugin = {
  name:        'analytics',
  label:       'Analytics',
  description: 'Passive stats accumulator. Throughput, pass rate, mean SNR, topic distribution.',
  enabled:     true,
  config: {},

  _stats: {
    total:     0,
    loopbacks: 0,
    meanSnr:   0,
    topics:    {},
    fields:    {},
    startedAt: Date.now(),
  },

  process(signal) {
    const s = this._stats;
    s.total++;
    if (signal.feedback || signal.loopback) s.loopbacks++;

    const snr = signal.snrScore ?? signal.snr ?? 0.5;
    s.meanSnr = (s.meanSnr * (s.total - 1) + snr) / s.total;

    const topic = signal.topic || signal.field || 'default';
    s.topics[topic] = (s.topics[topic] || 0) + 1;

    const field = signal.field || 'unknown';
    s.fields[field] = (s.fields[field] || 0) + 1;

    return signal;
  },

  stats() {
    const s = this._stats;
    const upMs = Date.now() - s.startedAt;
    return {
      ...s,
      meanSnr:      +s.meanSnr.toFixed(3),
      uptimeMs:     upMs,
      uptimeSec:    +(upMs / 1000).toFixed(1),
      throughputHz: +(s.total / (upMs / 1000)).toFixed(2),
      topTopics: Object.entries(s.topics)
        .sort((a, b) => b[1] - a[1]).slice(0, 10).map(([t, c]) => ({ topic: t, count: c })),
      topFields: Object.entries(s.fields)
        .sort((a, b) => b[1] - a[1]).slice(0, 5).map(([f, c]) => ({ field: f, count: c })),
    };
  },
};

module.exports = plugin;
