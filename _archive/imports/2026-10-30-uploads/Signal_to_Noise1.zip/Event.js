'use strict';
// ── core/Event.js ─────────────────────────────────────────────────────────────
// SISO Event primitive — the immutable datum flowing through the stream.
// Every signal that enters the SNR kernel is wrapped in one of these.
//
// Constitutional law: Events are immutable. Gates emit NEW events.
// You cannot mutate an event. You can only emit a replacement.
//
// Sourced from SISO (Core) + topo-kernel SISOEvent patterns.

const crypto = require('crypto');

class Event {
  /**
   * @param {string} type         — event type / gate signature
   * @param {object} data         — arbitrary payload (frozen)
   * @param {object} [meta]       — routing metadata
   * @param {string} [meta.sourceId]
   * @param {string} [meta.sessionId]
   * @param {string} [meta.causedBy]  — event ID that caused this one
   */
  constructor(type, data = {}, meta = {}) {
    if (!type || typeof type !== 'string') throw new Error('Event: type required');

    this.id        = 'evt-' + crypto.randomBytes(4).toString('hex');
    this.type      = type;
    this.data      = data;
    this.ts        = Date.now();
    this.sourceId  = meta.sourceId  || null;
    this.sessionId = meta.sessionId || null;
    this.causedBy  = meta.causedBy  || null;

    // Infinite-loop prevention (SISO paper §2.3)
    // Mutable but private — gates check this, never expose externally
    this._processedBy = new Set();

    Object.freeze(this);  // data is frozen; _processedBy tracked by bus
  }

  wasProcessedBy(gateId) {
    return this._processedBy.has(gateId);
  }

  // Called by bus, not by event consumers
  _markProcessed(gateId) {
    this._processedBy.add(gateId);
  }
}

module.exports = { Event };
