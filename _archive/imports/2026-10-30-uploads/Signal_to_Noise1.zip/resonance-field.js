'use strict';
// ── plugins/resonance-field.js ────────────────────────────────────────────────
// RESONANCE FIELD — scores signal resonance against recent system state.
// High resonance = familiar territory. Low resonance = outlier.
// Uses Euclidean distance from the mean field vector across recent signals.
// CFR §04: Node.energy — life force computed from field resonance.

const plugin = {
  name:        'resonance-field',
  label:       'Resonance Field',
  description: 'Scores signal resonance against recent system state. High resonance = familiar territory.',
  enabled:     true,
  config: {
    windowSize: 50,
    axes:       ['snrScore', 'loopDepth'],  // meta axes to compare
  },

  _field: [],  // recent [snrScore, loopDepth] vectors

  process(signal) {
    const axes = this.config.axes;
    const meta = signal.meta || signal;
    const vec  = axes.map(a => {
      const v = meta[a] ?? signal[a] ?? 0;
      return typeof v === 'number' ? v : 0;
    });

    if (this._field.length > 2) {
      const mean   = axes.map((_, i) => this._field.reduce((s, v) => s + v[i], 0) / this._field.length);
      const dist   = Math.sqrt(vec.reduce((s, v, i) => s + (v - mean[i]) ** 2, 0));
      const maxDist = Math.sqrt(axes.length);
      signal.resonance = +(1 - Math.min(dist / maxDist, 1)).toFixed(3);
    } else {
      signal.resonance = 0.5;
    }

    this._field.push(vec);
    if (this._field.length > this.config.windowSize) this._field.shift();

    return signal;
  },
};

module.exports = plugin;
