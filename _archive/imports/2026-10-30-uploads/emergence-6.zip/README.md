# Emergence (+ its foundation, WARP)

This repository has two folders, side by side on purpose:

- **`warp/`** -- the foundation. A small, general-purpose toolkit the
  application is built on. You don't need to open this folder to use
  the application.
- **`emergence/`** -- the actual application. **Start here:**
  [`emergence/README.md`](./emergence/README.md).

They need to stay side by side -- `emergence` looks for `warp` right
next to it.
