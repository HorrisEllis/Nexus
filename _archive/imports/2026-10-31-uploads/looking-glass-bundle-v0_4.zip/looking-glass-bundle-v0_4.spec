# README.md

# Looking Glass

A UI renderer and app host. Start with `SPEC.md` (what it is and why), then
`PHASEMAP.md` (phased build plan with dependencies, files, and exit tests).
`EDITOR.md` is the editor architecture spec (Track E, proposed amendments to phase 4 and 11).

---

# PHASEMAP.md

# Looking Glass — Phase Map (v0.3, draft)

Companion to `SPEC.md`. Looking Glass is a UI renderer and app host. It is self-contained
and depends on nothing outside itself.

Legend: **DECIDED** = you said it. **PROPOSED** = suggestion, not confirmed. Sizes are
relative effort (S / M / L), not time estimates.

Rule for every phase: it must pass its exit test before the next one starts.

---

## 1. Summary

| # | Phase | Size | Depends on | Delivers |
|---|---|---|---|---|
| 0 | Foundations and decisions | S | none | Workspace that builds one exe |
| 1 | Window + one rectangle from data | S | 0 | Borderless GPU window drawing a rectangle from a data file |
| 2 | Elements, layout, variables and bindings | M | 1 | Rect, text, button as typed data; props bind to variables; hot reload |
| 3 | Layers as a runtime operation | M | 2 | Dynamic layers, compositor, toast on a second layer |
| 4 | Motion and visual effects | L | 2, 3 | Springs/tweens/timelines, SDF shapes, shadows, gradients, blur-behind, frame pacing |
| 5 | Event bus / interaction contract | M | 2, 3 | Typed events, gates, observers, per-layer contracts |
| 6 | Lifecycle, performance, motion budget | L | 3, 4, 5 | Active/idle/unloaded layers, threads, buffering, culling |
| 7 | Signal providers + live demo | M | 2, 5 | Time, input, system metrics, files, sockets feed variables; live system monitor |
| 8 | Host, app model, preferences, cross-app | M | 3, 5 | Many apps in one host; shared theme and prefs; app-to-app messaging and embedding |
| 9 | Scripting, permissions, multi-language | L | 5, 8 | WASM layers, capability permissions |
| 10 | Snapshot, replay, governor | L | 6, 7 | Layer snapshot/restore, deterministic replay, feedback-driven throttling |
| 11 | Self-hosted UI editor | L | 8, 9 | Editor built from the same elements, editing the live scene |
| 12 | Packaging and distribution | M | 8 | Single exe, installer, signing, auto-update, other OSes |

### Dependency graph

```
0 -> 1 -> 2 -> 3 -> 4
2 + 3 -> 5
3 + 4 + 5 -> 6
2 + 5 -> 7
3 + 5 -> 8 -> 9 -> 11
6 + 7 -> 10
8 -> 12
```

Parallel work once unblocked: phases 4 and 5 together after 3; phases 6, 7, and 8 once
their inputs are done.

---

## 2. Proposed repo layout

```
looking-glass/
  Cargo.toml                    workspace
  crates/
    lg-core/                    element schema, scene tree, ids, layer model
    lg-vars/                    variables, bindings, small expression set
    lg-layout/                  small flexbox-like layout
    lg-render/                  wgpu renderer, SDF shapes, text, textures, compositor, effects
    lg-motion/                  springs, tweens, timelines, frame clock
    lg-bus/                     events, gates, observers, contracts
    lg-runtime/                 lifecycle policies, scheduler, threads, governor, snapshots
    lg-signals/                 signal providers (time, input, metrics, files, sockets)
    lg-host/                    app registration, local IPC, cross-app messaging
    lg-prefs/                   preferences / theme store
    lg-wasm/                    WASM layer host (phase 9)
    lg-editor/                  editor elements and app (phase 11)
  apps/
    lg-shell/                   the borderless host exe
    lg-demo/                    one small demo per phase
  schemas/
    element.schema.json  layer.schema.json  event.schema.json
    contract.schema.json prefs.schema.json  signal.schema.json
  scenes/
    rect.json  button.json  toast.json  monitor.json
  docs/
```

Language and crates (PROPOSED): Rust. `winit` (window), `wgpu` (GPU), `serde` and
`serde_json` (data), `notify` (hot reload), a text crate such as `cosmic-text` or
`glyphon`, `sysinfo` (system metrics), `wasmtime` in phase 9. Shapes are drawn as signed
distance fields in shaders. Windows first (PROPOSED); keep the platform layer thin so
other OSes follow.

---

## 3. Phases

### Phase 0 — Foundations and decisions (S)
**Depends on:** nothing.
**Do:**
- Create the Cargo workspace and an empty `lg-shell` that builds to one exe.
- Settle: language (Rust), data format (JSON first), Windows first.
- Decide Open Questions 1 and 2 or defer them to phases 6 and 10.
**Files:** `Cargo.toml`, `apps/lg-shell/src/main.rs`, `docs/decisions.md`.
**Exit test:** `cargo build --release` yields one exe that starts and exits cleanly.

### Phase 1 — Window + one rectangle from data (S)
The smallest representable unit. No layers, no bus.
**Depends on:** 0.
**Do:** borderless window via `winit` with own drag/resize hit-testing and HiDPI scale;
GPU context via `wgpu`; draw one rectangle read from `scenes/rect.json`.
**Files:** `crates/lg-core/src/element.rs`, `crates/lg-render/src/rect.rs`,
`apps/lg-shell/src/main.rs`, `scenes/rect.json`.
**Exit test:** editing the JSON and restarting changes the rectangle; resizing keeps it
sharp and correctly scaled.

### Phase 2 — Elements, layout, variables and bindings (M)
**Depends on:** 1.
**Do:**
- Element schema: props, states, events, slots. Elements: rectangle, text, button.
- **Variables:** a named, typed value store. Any prop is a literal or a variable
  reference. Events write variables. Keep the expression set tiny (map range, clamp,
  mix); no general scripting until phase 9.
- Scene tree of schema instances; small flexbox-like layout; text rendering; hit testing;
  button states; hot reload of `scenes/*.json`.
**Files:** `schemas/element.schema.json`, `crates/lg-core/src/{schema,tree}.rs`,
`crates/lg-vars/src/lib.rs`, `crates/lg-layout/src/lib.rs`, `crates/lg-render/src/{text,shapes}.rs`.
**Exit test:** a button writes a variable on click and a text element bound to that
variable updates; editing `button.json` live updates the window.

### Phase 3 — Layers as a runtime operation (M)
**Depends on:** 2.
**Do:**
- Layer model: id, tags (names such as "meta" are conventions only), depth, bounds,
  lifecycle policy, owner.
- Operations: `layer.add`, `layer.remove`, `element.move` (re-parent).
- Per-layer GPU texture sized to the layer's bounds; compositor blends by depth.
- Start with one layer; remove empty layers; return to one.
**Files:** `schemas/layer.schema.json`, `crates/lg-core/src/layer.rs`,
`crates/lg-render/src/{compositor,texture}.rs`, `scenes/toast.json`.
**Exit test:** a button spawns a toast on a second layer; dismissing removes the layer;
no layer names are hard-coded in the engine.

### Phase 4 — Motion and visual effects (L)
**Depends on:** 2, 3 (blur-behind needs the compositor).
**Do:**
- **Motion as data:** springs, tweens, easing, timelines, staggers declared on elements
  or variables. Interruptible. Driven by a frame clock with frame pacing matched to the
  display's refresh rate.
- **Alive:** a time variable and ambient motion (breathing, noise drift, light following
  the cursor), each with an intensity setting.
- **Look:** SDF rounded shapes, soft shadows, glows, gradients in a perceptual color
  space, frosted-glass blur of whatever is under a layer, and a custom-shader element.
- Design tokens (color, radius, spacing, motion curves) so styling is shared, not
  hard-coded.
- Build order: SDF + shadow + gradient first, then blur-behind. The overall look is
  Open Question 9.
**Files:** `crates/lg-motion/src/{spring,tween,timeline,clock}.rs`,
`crates/lg-render/src/{sdf,shadow,gradient,blur,shader_element}.rs`.
**Exit test:** a button, a toast, and a panel animate smoothly at the display's refresh
rate; interrupting an animation mid-flight never snaps or stalls; ambient motion can be
turned fully off.

### Phase 5 — Event bus / interaction contract (M)
**Depends on:** 2, 3.
**Do:**
- Typed events named `{layer}:{noun}:{verb}`; one gate per event type (collisions are
  errors); read-only observers; ring buffer with sequence numbers.
- Each layer declares what it emits and accepts; the bus rejects violations.
- Layers talk only through the bus. Interaction primitive: element + target + action
  (close, toast, pop-up).
**Files:** `schemas/{event,contract}.schema.json`, `crates/lg-bus/src/{event,gate,stream,contract}.rs`.
**Exit test:** close, toast, and pop-up work through the bus only; a layer sending an
undeclared event is rejected and logged.

### Phase 6 — Lifecycle, performance, motion budget (L)
**Depends on:** 3, 4, 5.
**Do:**
- Lifecycle: active, idle (keeps texture, thread sleeps, last frame reused), unloaded
  (texture freed; data tree stays). Per-layer policy: always-warm, sleep-when-idle,
  unload-when-empty.
- **Motion budget:** a layer renders frames only while something animates; ambient motion
  has an intensity cap; power state or load can turn it down.
- Dirty regions, occlusion culling, transparent means free; per-layer threads;
  double/triple buffering.
- Resolve Open Question 1 (threads or processes) with measurements.
**Files:** `crates/lg-runtime/src/{lifecycle,scheduler,buffers,budget}.rs`,
`crates/lg-render/src/{dirty,cull}.rs`, `apps/lg-demo/src/stress.rs`.
**Exit test:** with many sparse layers an idle layer uses effectively no CPU; an unloaded
layer frees its texture; with nothing animating the whole app idles near zero frames;
wake latency is measured per policy.

### Phase 7 — Signal providers + live demo (M)
**Depends on:** 2, 5.
**Do:**
- A provider is anything that feeds variables: clock, mouse/keyboard, system metrics,
  file watcher, sockets, HTTP/SSE. Providers are plugins behind one trait.
- **Live system monitor demo:** CPU, memory, and network bars as spring-smoothed shapes
  driven by variables; a toast on a spike.
**Files:** `schemas/signal.schema.json`, `crates/lg-signals/src/{provider,time,input,metrics,net}.rs`,
`scenes/monitor.json`, `apps/lg-demo/src/monitor.rs`.
**Exit test:** the monitor updates live from real system data with no network service
running; removing a provider leaves the scene valid.

### Phase 8 — Host, app model, preferences, cross-app (M)
**Depends on:** 3, 5.
**Do:**
- Host protocol: apps register with the host over local IPC, declare their contract, and
  load live (not static packages).
- Preferences store in the meta layer: theme, fonts, accent, density, per-app overrides,
  exposed as variables so every app inherits.
- Cross-app: shared state, messaging over the bus, embedding another app's elements.
**Files:** `schemas/prefs.schema.json`, `crates/lg-host/src/{registry,ipc,session}.rs`,
`crates/lg-prefs/src/lib.rs`, `apps/lg-demo/src/two_apps.rs`.
**Exit test:** two separate demo apps run in one host; changing the accent color once
updates both; one embeds an element from the other.

### Phase 9 — Scripting, permissions, multi-language (L)
**Depends on:** 5, 8.
**Do:**
- Permission model (Open Question 3): what a layer may read or change in others; whether
  the meta layer rewrites layers below it live or only observes and routes.
- WASM host so any language that compiles to WASM can be a layer; sandboxed; cheap to
  load and unload. Rendering stays in the native core.
- Optional embedded scripting (QuickJS or Lua) for behavior; this is where the phase 2
  expression set may grow.
**Files:** `crates/lg-wasm/src/{host,api,perms}.rs`, `apps/lg-demo/wasm-toast/`.
**Exit test:** a WASM layer draws a toast through the bus; it is denied an action its
permissions do not grant.

### Phase 10 — Snapshot, replay, governor (L)
**Depends on:** 6, 7.
**Do:**
- Snapshot and restore of a layer's data tree on unload and wake; record the event
  stream; replay it deterministically; replay a bounded slice for debugging. The format
  is Looking Glass's own (Open Question 8).
- **Governor:** a feedback loop that reads signals (frame time, memory, CPU) and throttles
  or unloads layers and trims ambient motion. Start with a simple controller (Open
  Question 2).
**Files:** `crates/lg-runtime/src/{governor,snapshot,replay}.rs`.
**Exit test:** under simulated load, idle layers unload and memory drops; an unloaded
layer wakes with identical state; a recorded session replays to the same pixels.

### Phase 11 — Self-hosted UI editor (L)
**Depends on:** 8, 9.
**Do:** the editor is an app built from the same elements, running on the meta layer (or
its own), editing the live scene tree and saving scenes; schema-driven property panels;
layer inspector; drag to re-parent between layers; motion curve editor.
**Files:** `crates/lg-editor/src/*`, `apps/lg-demo/editor/`.
**Exit test:** use the editor to change an element of the editor itself and see it update
live, then undo it.

### Phase 12 — Packaging and distribution (M)
**Depends on:** 8.
**Do:** single-file release exe, installer, code signing, auto-update; Linux and macOS
ports behind the thin platform layer.
**Files:** `docs/release.md`, packaging scripts.
**Exit test:** a clean machine installs and runs Looking Glass with no other software.

---

## 4. Risks and gates

- **Scope.** Do not start a phase until the previous exit test passes.
- **Phases 4 and 6 pull against each other.** Beauty wants continuous frames; the
  lifecycle wants idle layers. The motion budget in phase 6 is how they coexist; design
  phase 4 to expose intensity controls from the start.
- **Phases 6 and 10 are the hard ones.** Keep phase 6 measurement-driven and the phase 10
  controller simple.
- **Folding back in.** The self-hosting editor stays in phase 11, after a working scene,
  bus, and runtime.
- **Open questions** (see `SPEC.md`): 1 and 2 to phases 0, 6, and 10; 3 to phase 9;
  4 to phase 6; 6 to phase 11; 7 and 8 to phase 10; 9 (the look) to phase 4.

---

# EDITOR.md

# Looking Glass — Editor Spec (v0.2, draft)

Companion to `SPEC.md` (v0.3) and `PHASEMAP.md` (v0.3). Status: concept stage, nothing built.
Origin: design conversation, 2026-10-18. v0.2 removes AI generation and replaces it with
deterministic code generation from the elements, in the way the WordPress block editor
builds a page from its blocks.

Structured in the spec-engine's ten slots (meta, purpose, schema, api, events, integration,
failure_modes, build_order, axioms, tests) with `## SECTION: <id>` markers, so it can be
seeded slot by slot. Open questions sit after the last slot.

Legend (same as `SPEC.md`):
- **DECIDED** = you said it or agreed to it directly.
- **PROPOSED** = a suggestion you have not confirmed.
- **OPEN** = unresolved question.

---

## SECTION: meta

- Name: **Looking Glass Editor** (working name, see E-OQ8).
- Version: `0.2.0-draft`. Status: proposed.
- Depends on `SPEC.md` §2.1 (UI is typed data), §2.2 (layers), §2.3 (bus/contract),
  §2.6 (variables, bindings, motion), §2.7 (signal providers).
- Touches `PHASEMAP.md` phases 2, 3, 4, 5, 8, 9, and 11. Proposed amendments are listed in
  `build_order`.
- New crates (PROPOSED):

```
crates/
  lg-editor-core/    document, ops, transactions, undo/redo, validation, queries (headless)
  lg-gen/            deterministic code generation: per-element emitters, serializer,
                     parser for round-trip, drift detection
  lg-export/         emitter packs for targets beyond scene JSON (gated on E-OQ1)
  lg-editor/         the editor UI, built from Looking Glass elements (= PHASEMAP phase 11)
```

  Particles are a renderer and motion feature, not an editor feature. They go into
  `lg-render` and `lg-motion` (see `build_order`, amendment A1).

---

## SECTION: purpose

### What you asked for (DECIDED)
- A full UI editor that automatically produces beautiful, animated UI, with **particles**
  and **styles driven by variables or events**.
- Enterprise grade and fully expanded, not a toy.
- **No AI.** The editor writes the code itself, based on the UI elements you place and set,
  the way WordPress builds a page from its blocks. (This replaces the earlier "visual
  editing plus AI" answer.)
- Architecture spec first.
- "Agnostic" (what the editor's output can target): **on hold** at your request. See E-OQ1.

### What "automatically code" means here (PROPOSED)
Looking Glass has no markup and no code-as-source (`SPEC.md` §2.1). The scene document
*is* the program. So the editor does not write code; it writes **typed scene data**, which
the runtime executes directly. "Code" in any other language is an *export*, a projection
of the document (E-OQ1).

That gives the central design rule: **the editor has no format of its own.** It edits
Looking Glass scenes using the same operations the runtime already understands
(`layer.add`, `element.move`, ...). Anything the editor makes runs without the editor.

### The WordPress model (PROPOSED, following your direction)
The WordPress block editor works like this: every block has a type and attributes, and a
fixed `save` function turns those attributes into markup. The page is the blocks serialized
in order, each wrapped in a comment marker so the editor can parse the page back into blocks.
Nothing is guessed; the same blocks always produce the same markup.

Looking Glass does the same with elements:
- Every element schema carries an **emitter**: a fixed, deterministic mapping from its props
  (plus styles, motion, and bindings) to output.
- As you edit, every op re-emits only the elements it touched, and the code view updates
  live. The canvas and code are two views of the same document.
- Generated code carries **element markers** (the equivalent of `<!-- wp:paragraph -->`),
  so the code can be parsed back into elements.
- Code edited by hand that no longer matches what its emitter would produce is flagged,
  just as WordPress flags an "invalid block." You choose to keep it as a **raw** element (the
  equivalent of WordPress's Custom HTML block) or to regenerate it.
- The first target is the scene JSON itself. Other languages are additional emitter packs
  (E-OQ1).

### Goals (PROPOSED)
1. Every visual property can be a literal, a token, a variable binding, or a style rule
   reacting to state, variables, or events.
2. Motion, particles, and ambient life are authored as data with live preview, never as
   animation code.
3. Every change, whether from a person, a script, a plugin, or a replay, is one kind of
   thing: an **op**, validated by one set of gates, undoable, and logged.
4. Code is generated from elements by fixed emitters. Same document in, byte-identical code
   out. There is no AI, no model, and no network involved.
5. Inspector panels are generated from element schemas, so new element types (including
   plugin elements) are editable without new editor code.

### Non-goals (for now)
- A web or Chromium-based editor shell (conflicts with `SPEC.md` goals; see E-OQ2).
- Exporters before E-OQ1 is decided.
- Multi-user real-time collaboration before single-user op logs are proven (E-OQ5).

---

## SECTION: schema

All data is JSON first, matching `PHASEMAP.md` phase 0. These are additions to or
refinements of the phase 2 element schema. They are runtime schema, not editor-only.

### 1. Prop values: literal, token, binding
```json
{
  "fill":    "#3a7bff",
  "radius":  { "$token": "radius.md" },
  "width":   { "$var": "cpu.load", "map": [0, 1, 0, 240], "clamp": true },
  "opacity": { "$var": "toast.visible", "mix": [0, 1] }
}
```
Expression set stays at map-range, clamp, and mix (`SPEC.md` OQ10). Style rules need
comparisons; see E-OQ7.

### 2. Style rules (variable- and event-driven styles)
Ordered rules on an element. A rule's `when` is a condition on element state, a variable,
or a recent event. The last matching rule wins per prop. Changes animate with the named motion.
```json
"styles": [
  { "when": { "state": "hover" },                      "set": { "fill": { "$token": "color.accent.hi" } }, "motion": "spring.snappy" },
  { "when": { "state": "pressed" },                    "set": { "scale": 0.97 },                           "motion": "spring.snappy" },
  { "when": { "var": "cpu.load", "gt": 0.85 },         "set": { "fill": { "$token": "color.danger" }, "glow": 12 }, "motion": "tween.200.out" },
  { "when": { "event": "app:alert:raise", "within_ms": 600 }, "set": { "shake": 1 },                   "motion": "spring.wobbly" }
]
```

### 3. Motion (from `SPEC.md` §2.6, made concrete)
```json
"motion": {
  "spring.snappy": { "kind": "spring", "stiffness": 420, "damping": 32, "mass": 1 },
  "tween.200.out": { "kind": "tween", "ms": 200, "ease": "cubic-out" },
  "intro":         { "kind": "timeline", "tracks": [
                     { "target": "#card", "prop": "y", "keys": [[0, 24], [320, 0]], "ease": "expo-out" },
                     { "target": ".row",  "prop": "opacity", "keys": [[0, 0], [240, 1]], "stagger_ms": 40 } ] },
  "breathe":       { "kind": "ambient", "prop": "glow", "wave": "sine", "period_ms": 4200, "amp": 4, "intensity": { "$var": "prefs.ambient" } }
}
```
Every motion is interruptible. A new target retargets from current position and velocity, so
nothing snaps (`PHASEMAP.md` phase 4 exit test).

### 4. Particle emitter element (new element type)
```json
{
  "type": "emitter", "id": "spark",
  "props": {
    "seed": 7,
    "max": 600,
    "rate": { "$var": "net.rx_rate", "map": [0, 5e6, 0, 120] },
    "burst": { "on": "monitor:spike:detect", "count": 80 },
    "lifetime_ms": [600, 1400],
    "shape": { "kind": "outline", "of": "#cpu-bar" },
    "velocity": { "speed": [40, 140], "angle": [-100, -80] },
    "forces": [
      { "kind": "gravity", "y": 220 },
      { "kind": "drag", "k": 0.8 },
      { "kind": "curl_noise", "scale": 0.004, "strength": 60, "speed": 0.3 },
      { "kind": "attractor", "to": { "$var": "input.cursor" }, "strength": 90, "falloff": 160 }
    ],
    "over_life": {
      "size":    [[0, 2], [0.2, 5], [1, 0]],
      "opacity": [[0, 0], [0.1, 1], [1, 0]],
      "color":   { "space": "oklch", "stops": [[0, "#ffe7a0"], [0.5, { "$token": "color.accent" }], [1, "#20004000"]] }
    },
    "sprite": { "kind": "sdf_circle", "softness": 0.6 },
    "blend": "add",
    "space": "layer",
    "intensity": { "$var": "prefs.motion" }
  }
}
```
- Sprites: SDF circle, SDF shape, glyph, or a snapshot of another element.
- Forces: gravity, drag, curl noise, attractor (to a point, element, or variable), vortex,
  bounds collision.
- `seed` makes the simulation deterministic, so replay gives identical pixels (`PHASEMAP.md`
  phase 10 exit test).
- `max` and `intensity` are what the motion budget and governor turn down (phases 6 and 10).

### 5. Components
A reusable schema with typed params, slots, internal variables, and its own styles and
motion. Instances override params. Components are versioned (`name@major.minor`) so a
library update cannot silently change existing scenes.
```json
{ "component": "GlassCard@1.2",
  "params": { "title": "string", "accent": "color", "elevated": "bool" },
  "slots": ["body"],
  "vars": { "hovered": false },
  "root": { "type": "rect", "props": { "...": "..." }, "children": ["..."] } }
```

### 6. Tokens
Named design values (color, radius, spacing, type, motion curves, particle presets) served
from `lg-prefs` (phase 8) as variables, so a theme change reaches every app.

### 7. Op (the unit of change)
```json
{ "op": "prop.set", "target": "el:7f3a", "args": { "prop": "fill", "value": { "$token": "color.accent" } },
  "base_rev": 412, "origin": "user", "txn": "t:9c01" }
```
- `origin` is one of: `user`, `script`, `replay`, `plugin`, `code` (an op parsed back from
  a hand edit in the code view).
- The core computes and stores each op's inverse when it is applied. Undo means applying
  the inverse.
- A transaction groups ops into one undo step (for example, one drag, or one paste).
- Op set: `element.add/remove/move/duplicate`, `prop.set/unset`, `bind.set/clear`,
  `style.add/remove/reorder`, `motion.define/attach/detach`, `layer.add/remove/set`,
  `var.define/remove`, `wire.add/remove` (event → target → action),
  `component.define/instantiate/detach/upgrade`, `token.set`.

---

## SECTION: api

### 1. Editor core (`lg-editor-core`, headless, no rendering)
```
Document::open(path) -> Result<Document, E>
Document::save(path) -> Result<(), E>
doc.apply(Txn) -> Result<Rev, Rejection>        // validates all ops, atomic
doc.preview(Txn) -> Result<Diff, Rejection>     // dry run, nothing committed
doc.undo() / doc.redo() -> Result<Rev, E>
doc.query(Selector) -> Vec<ElementRef>           // "#id", ".tag", "type:emitter", "bound:cpu.*"
doc.validate() -> Vec<Problem>                   // whole-document lint
doc.schema_of(type) -> ElementSchema             // drives generated inspector panels
doc.subscribe(Fn(Change))                        // canvas, panels, and plugins listen here
doc.log(range) -> Vec<Op>                        // audit and history
```
A CLI ships with the core, so it can be tested before any UI exists:
`lg-edit apply scene.json ops.json`, `lg-edit validate scene.json`, `lg-edit undo-check scene.json ops.json`.

### 2. Code generation (`lg-gen`, deterministic)
```
trait Emitter {                                   // one per element type, per target
    fn element_type(&self) -> &str;
    fn target(&self) -> TargetId;
    fn emit(&self, el: &Element, ctx: &EmitCtx) -> Fragment;   // pure function
}
trait Target {                                    // a language or format
    fn id(&self) -> TargetId;
    fn assemble(&self, doc: &Document, frags: &FragmentMap) -> FileSet;  // file layout, imports, tokens
    fn parse(&self, files: &FileSet) -> Result<Vec<MarkedFragment>, ParseError>;
    fn coverage(&self, doc: &Document) -> Coverage;  // which features map, degrade, or drop
}
gen.emit_all(doc, target) -> FileSet
gen.emit_incremental(doc, change, target) -> Patch     // only touched elements
gen.read_back(files, target) -> Result<Txn, Drift>     // code view edits become ops
```

How it works (PROPOSED):
1. **Emit.** Each element's emitter is a pure function of its props, styles, motion, and
   bindings. `EmitCtx` gives only stable inputs (token table, id map, indentation rules), so
   output cannot depend on time, hash order, or machine.
2. **Mark.** Every fragment is wrapped in a marker carrying the element id and type, for
   example `// lg:button id=el:7f3a` ... `// /lg:button` in code targets. In scene JSON the
   id is already present.
3. **Assemble.** The target lays out files (one per scene or component), hoists shared
   tokens and variables, and orders everything by tree order. Formatting is fixed, so diffs
   in version control stay small and readable.
4. **Live.** After every op, `emit_incremental` replaces only the touched fragments. The code
   view (split, or toggled like WordPress's Code editor) updates as you drag.
5. **Read back.** Editing in the code view reparses the marked fragments. A fragment that
   parses into valid props becomes ops (`origin: code`). A fragment its emitter wouldn't
   produce raises `E_CODE_DRIFT`, and you choose **keep as raw** (stored verbatim and
   emitted untouched) or **regenerate**.

Emitter sources (PROPOSED): built-in emitters ship with each element type. Components emit
by composing their children's emitters, so a new component needs no new emitter. Plugin
element types must register an emitter for each target they support; the scene JSON
target is mandatory.

### 3. Additional targets (`lg-export`, gated on E-OQ1)
Each additional target is an emitter pack: one `Target` plus an `Emitter` per element type.
`coverage` runs before writing and lists losses explicitly (for example: particles to CSS
cannot map; particles to canvas can). There is no silent degradation.

### 4. Plugin API
Plugins can register element schemas, custom inspector widgets for a prop type, signal
providers (`SPEC.md` §2.7), emitters, and targets. Plugins run under the phase 9
permission model.

---

## SECTION: events

The editor is an app on the bus (`PHASEMAP.md` phase 5). Events follow `{layer}:{noun}:{verb}`.
The editor runs on a meta-tagged layer. The tag is a convention; the engine does not know
the name.

Emits (PROPOSED):
```
editor:selection:change      editor:doc:apply       editor:doc:reject
editor:txn:undo              editor:txn:redo        editor:doc:save
editor:code:emit             editor:code:readback   editor:code:drift
editor:preview:enter         editor:preview:exit    editor:problem:raise
```
Accepts: `scene:*` change notifications from the runtime, `prefs:*` (theme), and
`runtime:frame:stats` (performance HUD).

Live editing of another app's scene requires a capability to rewrite lower layers. That is
`SPEC.md` OQ3, so **the editor forces OQ3 to be decided** (E-OQ3). Until then the editor
edits its own scene and scenes loaded as documents.

Wiring (`wire.add`) produces the bus primitive **element + target + action** (`SPEC.md`
§2.3). The editor validates each wire against the target layer's contract and refuses
undeclared events at edit time, not run time.

---

## SECTION: integration

### Editor surfaces (all built from Looking Glass elements, phase 11)
| Surface | What it does |
|---|---|
| Canvas | The live scene running in the real renderer, not a mock. Select, drag, resize, re-parent across layers. Toggle between edit and play. |
| Layer stack | Layers by depth, tags, bounds, lifecycle state (active, idle, unloaded), and texture memory. |
| Tree | Scene hierarchy, components, and slots. |
| Inspector | Generated from `schema_of(type)`. Each prop shows literal, token, binding, or style-rule mode. |
| Variables | All variables with live values. Scrub a value to see every bound element react. Shows which provider feeds each one. |
| Style rules | Ordered rule list per element, with live highlighting of the rule that currently matches. |
| Motion | Spring visualizer (drag stiffness and damping, see the curve), easing editor, multi-track timeline, stagger. |
| Particles | Emitter editor with forces drawn as gizmos on the canvas, over-life curve editors, presets, and a live particle count against budget. |
| Wiring | Graph of element → target → action, checked against contracts. |
| Tokens / theme | Edits `lg-prefs` tokens; every open app updates. |
| Library | Versioned components, with upgrade previews shown as diffs. |
| Code view | Generated code for the current target, updated live. Split or toggled. Selecting an element highlights its fragment and the reverse. Editable; edits read back into elements. Drift is flagged inline. |
| History | Op log with origin (user, script, code, plugin), jump to any revision, replay a range. |
| Problems | `validate()` output, accessibility lint (contrast, hit-target size, focus order, reduced-motion respect). |
| Performance HUD | Frame time, active layers, particle count, motion-budget state. |

### Relation to the rest of Looking Glass
- Variables and providers: `lg-vars`, `lg-signals` (phases 2 and 7).
- Tokens and theme: `lg-prefs` (phase 8).
- Replay-based visual tests: `lg-runtime` snapshot and replay (phase 10).
- Permissions: phase 9.

### Relation to anything outside Looking Glass
Only through files on disk: saved scenes and generated code. Nothing else.

---

## SECTION: failure_modes

Every failure is named and typed. Nothing fails silently.

| Code | When | Behavior |
|---|---|---|
| `E_SCHEMA_UNKNOWN_TYPE` | Op or file uses an unregistered element type | Reject; name the type and its source (file or plugin). |
| `E_PROP_TYPE` | Value doesn't match the prop's schema type | Reject; name element, prop, expected and actual types. |
| `E_BIND_UNKNOWN_VAR` | Binding to an undefined variable | Reject at edit time. At load time, mark the element and keep the scene valid (matches phase 7: removing a provider leaves the scene valid). |
| `E_BIND_CYCLE` | Variable graph forms a cycle | Reject; print the cycle path. |
| `E_EXPR_UNSUPPORTED` | Expression outside the allowed set | Reject; list allowed operators. |
| `E_CONTRACT_UNDECLARED` | Wire emits or accepts an event the layer didn't declare | Reject at edit time. |
| `E_PERM_DENIED` | Op needs a capability the editor or plugin lacks | Reject; name the capability. |
| `E_OP_STALE` | `base_rev` is behind and the op conflicts with later changes | Reject; offer rebase onto the current revision. |
| `E_RELOAD_CONFLICT` | Scene file changed on disk during an edit session (hot reload) | Stop; show a three-way diff. Never overwrite either side automatically. |
| `E_EMIT_MISSING` | An element type has no emitter for the current target | Reject the target switch (or export); name the type. Scene JSON emitters are mandatory, so this never blocks saving. |
| `E_EMIT_NONDETERMINISTIC` | Emitting the same element twice gives different output | Fails the emitter's registration test; a plugin emitter that fails is refused at load. |
| `E_CODE_PARSE` | Code view edit breaks a marker or the target's syntax | Keep the last good document; underline the broken span; nothing is applied until it parses. |
| `E_CODE_DRIFT` | A marked fragment differs from what its emitter produces | Flag inline; offer keep-as-raw or regenerate. Never discard either version silently. |
| `E_BUDGET_PARTICLES` | Emitter `max` exceeds the layer's budget | Clamp at run time and raise a problem in the editor. |
| `E_EXPORT_UNSUPPORTED` | Exporter can't represent a feature | Listed in `coverage` before export; export only proceeds if the user accepts the losses. |
| `E_SELF_EDIT_LOCKOUT` | An edit to the editor's own scene makes it unusable (phase 11 risk) | Undo is bound natively, outside the scene. The editor pins a last-known-good copy of its own scene and restores it on a failed frame or a missing required surface. |

---

## SECTION: build_order

Bottom-up. Each step passes its exit test before the next starts (`PHASEMAP.md` rule).

### Track E (PROPOSED), alongside the main phase map
| # | Step | After | Exit test |
|---|---|---|---|
| E0 | Document, ops, transactions, undo, validation, CLI (`lg-editor-core`) | Phase 2 | Every phase 2 scene round-trips byte-identical. A fuzzed op sequence followed by full undo returns the original document byte-identical. |
| E1 | Layer ops; schema-to-inspector descriptors (as data) | Phase 3 | Layer add, move, and remove through ops; descriptors generated for rect, text, button with no per-type code. |
| E2 | Style rules, motion defs, tokens, emitter schema in the document model | Phase 4 + A1 | Style rules switch on a variable and animate. Emitter with a fixed seed renders identical frames on two runs. |
| E3 | Wiring ops with contract validation | Phase 5 | An undeclared wire is rejected at edit time with `E_CONTRACT_UNDECLARED`. |
| E4 | Code generation (`lg-gen`) for the scene JSON target: emitters, markers, incremental emit, read-back, drift | E0 | Every scene emits byte-identical output on repeated runs. Emit then read back gives the same document. A hand edit that matches an emitter becomes ops; one that doesn't raises `E_CODE_DRIFT`. |
| E5 | Editor UI, self-hosted (this **is** PHASEMAP phase 11) | Phases 8, 9; E1–E4 | Phase 11's exit test (edit the editor live, then undo), plus: dragging an element updates the code view live; editing the code view updates the canvas; `E_SELF_EDIT_LOCKOUT` recovery works. |
| E6 | Additional targets (emitter packs) | E-OQ1 decided | Per target: `coverage` matches a fixture of expected losses; exported output renders the conformance scenes; repeated export is byte-identical. |
| E7 | Enterprise layer: component versioning and upgrades, accessibility lint, replay-based visual regression, multi-user (E-OQ5) | E5, phase 10 | A component upgrade shows a diff and is undoable; a recorded session replays to the same pixels in CI. |

E0 and E4 are headless. They can start as soon as phase 2 schemas exist, long before the
renderer can host an editor UI. Both are testable from the CLI (`lg-edit emit`,
`lg-edit readback`).

### Proposed amendments to `PHASEMAP.md` (not applied)
- **A1. Particles in phase 4:** add `crates/lg-render/src/particles.rs` (GPU simulation with
  a CPU fallback) and `crates/lg-motion/src/emitter.rs`. Extend the exit test: an emitter
  with a fixed seed is frame-identical across runs, and at intensity 0 it emits nothing.
- **A2. Style rules in phase 2:** add `styles` to `element.schema.json`, plus the
  comparisons from E-OQ7.
- **A3. Phase 11 points here:** phase 11 becomes E5 and depends on E1–E4.

---

## SECTION: axioms

1. **One source of truth.** The scene document. Editor-only data lives under
   `meta.editor` and is never required to run the scene.
2. **Everything is an op.** Users, scripts, plugins, code-view edits, and replay all change
   the document the same way, through the same gates.
3. **Code comes from elements.** Every line of generated code traces to an element through
   its marker. There is no AI and no model in the editor.
4. **Emitters are pure.** Same element and context in, byte-identical fragment out.
5. **Hand edits are never lost.** Drift is flagged and kept as raw on request, never
   silently overwritten.
6. **Panels come from schemas.** No hand-written per-element inspector code. Plugins may add
   widgets per prop type.
7. **Output runs without the editor.**
8. **Determinism.** Seeded randomness only. Same document plus same event stream gives the
   same pixels.
9. **No hard-coded layer names** (inherited from `SPEC.md` §2.2).
10. **Motion obeys the budget.** Intensity 0 means fully off, for ambient motion and
    particles alike.
11. **Loud, named failures.** Every rejection names its code, target, and cause.

---

## SECTION: tests

- **Op inverse property:** for random valid op sequences, apply then undo-all gives a
  byte-identical document. Fuzzed in CI.
- **Validation fuzz:** random malformed ops are each rejected with a named code, and never
  panic.
- **Round-trip:** every file in `scenes/` loads and saves byte-identical.
- **Particle determinism:** fixed seed and fixed event stream give identical frames twice.
- **Budget:** intensity 0 with nothing else animating gives zero frames rendered (ties to
  phase 6 exit test).
- **Emit determinism:** every scene and component emits byte-identical output across runs
  and machines. Every registered emitter is run twice at registration.
- **Round-trip:** emit then read back gives the original document for every fixture.
- **Incremental equals full:** after any op sequence, the incrementally patched code equals a
  full re-emit.
- **Drift:** fixture hand edits (matching, non-matching, broken markers) each give their
  expected outcome (ops, `E_CODE_DRIFT`, `E_CODE_PARSE`).
- **Contract:** wiring an undeclared event is rejected at edit time.
- **Self-edit lockout:** a fixture edit breaks the editor's own scene; recovery restores the
  last-known-good copy.
- **Visual regression (E7):** recorded sessions replay to the same pixels.
- **Performance:** no targets are claimed yet. E0 sets them after measuring named benchmarks
  (for example: apply latency on a 10,000-element scene; validate time on the same scene).

---

## Open questions

1. **E-OQ1. What does "agnostic" mean for output?** On hold at your request. Options: Looking
   Glass scenes only; plus web exporters (HTML/CSS/JS, framework components); plus native or
   other toolkits. The emitter design works for all of them: each target is an emitter pack.
   Only `lg-export` waits on this.
2. **E-OQ2. Editor before the renderer?** The phase map puts the editor last, and it can't
   self-host until phases 8 and 9. Proposed: build the headless core (E0, E4) early, and no
   temporary web shell, since that would contradict "not Chromium-based." The alternative is
   a throwaway preview shell for earlier hands-on use.
3. **E-OQ3. Permissions (`SPEC.md` OQ3).** Live-editing another app's scene requires the meta
   layer to rewrite lower layers. The editor cannot fully exist without deciding this.
4. **E-OQ4. Is the code view editable?** WordPress lets you edit a page's markup directly.
   Proposed: yes, with read-back and drift handling as specified. The alternative is a
   read-only code view, which removes `E_CODE_DRIFT` and read-back entirely.
5. **E-OQ5. Collaboration:** single user first, then multi-user merge over the op log?
   Proposed: single user; ops already carry `base_rev`, which leaves room for merging later.
6. **E-OQ6. Visual feel (`SPEC.md` OQ9):** decides default tokens, particle presets, and the
   editor's own look.
7. **E-OQ7. Expressions (`SPEC.md` OQ10):** style rules need comparisons (`gt`, `lt`, `eq`,
   `between`) and event recency (`within_ms`). Proposed: add these to phase 2's set, still
   no general scripting.
8. **E-OQ8. Name.**

---

# SPEC.spec

---
# Looking Glass: Working Spec (YAML form of SPEC.md, with the project DAG in the dag section)
format: yaml
title: Looking Glass
version: "0.3"
status: draft
stage: concept stage, nothing built yet
build_plan: PHASEMAP.md
origin:
  source: design conversation
  date: 2026-10-13
  goal: >-
    Invent an alternative to Electron that is its own thing, not a copy of
    Tauri/Wails. It is a UI renderer and app host, nothing more, and it depends
    on nothing outside itself.

legend:
  DECIDED: you said it or agreed to it directly.
  PROPOSED: a suggestion from the conversation that you have not confirmed.
  OPEN: unresolved question.

what_this_is:
  summary: >-
    An app platform, closer to a tiny OS layer for desktop apps than to an
    Electron clone. It is a UI renderer ("HTML, but not HTML") that draws its
    own pixels on the GPU and hosts apps live, with shared styling/preferences
    across all of them.
  goals:
    status: DECIDED
    items:
      - Not Chromium-based.
      - "Not static: apps are loaded live by a host, not frozen into packages with their own copy of everything."
      - Good, shared styling and preferences (theme, fonts, accent, density) that every app inherits.
      - "Cross-app: apps can share state, messaging, and embedding."
      - Borderless, dynamically scaling windows with GPU-accelerated rendering.
      - "No markup language. UI is data, not tags in a file."
      - RAM savings are not the main motivation.
      - "Self-contained: a UI renderer and app host. It needs no external platform or service to run."
      - "Beautiful, animated, alive, dynamic: motion and visual quality are core, and behavior is driven by events and variables."
  non_goals:
    when: for now
    items:
      - Matching the web's feature set.
      - Building the editor, scripting runtime, or multi-language support before the first slice works.

core_ideas:
  ui_is_typed_data:
    id: "2.1"
    status: DECIDED direction, PROPOSED details
    description: >-
      There is no markup source of truth. Every element (button, text,
      rectangle, slider, toast, close button) is defined once by a schema:
      props, states, events, slots. The UI itself is a tree of schema
      instances, which is what an editor manipulates.
    properties:
      - "Deterministic: same data in, same pixels out."
      - Any element can be placed at any layer or depth.
      - Images and HTML are just more element types (HTML would be an optional embed element, later).
      - Schemas are the "deterministic reusable factors" (buttons etc.).

  layers_are_a_runtime_operation:
    id: "2.2"
    status: DECIDED
    rules:
      - The surface starts as one layer. You can add layers dynamically.
      - Adding a layer is an action like any other (an element action).
      - Every layer has a depth coordinate, bounds, and a lifecycle policy.
      - Elements can move between layers by re-parenting in the tree.
      - When a layer empties, it is removed; the system returns to one layer.
      - >-
        The engine must not hard-code layer names. "Meta", "interaction", etc.
        are conventions (tags), not special types. The engine only knows
        depth, bounds, and permissions.
    mental_model:
      status: DECIDED
      text: >-
        A sticker on glass. Each layer is a transparent surface with its own
        owner. Lower layers are plumbing; higher layers are closer to the
        human. The top layer is the meta layer.
    suggested_convention_stack:
      status: PROPOSED
      order: bottom to top
      layers:
        - name: Plumbing
          contains: OS surface, borderless window, input, GPU context.
        - name: Renderer
          contains: scene graph, vector shapes, text, scaling.
        - name: Runtime
          contains: scripting, state, messaging between apps.
        - name: App content
          contains: the actual elements.
        - name: Interaction
          contains: input routing, focus, gestures, command palette.
        - name: Meta
          contains: theming, preferences, cross-app control, inspection.

  isolation_through_event_bus:
    id: "2.3"
    status: DECIDED
    name: interaction contract
    description: >-
      Layers are isolated and talk only through typed messages on an event bus
      (the "interaction contract"). A layer declares what it emits and
      accepts; anything that honors the contract can be stacked on. This is
      what keeps the UI from being hard-coded.
    interaction_primitive:
      status: PROPOSED
      shape: element + target + action
      examples:
        - element: Close button
          behavior: target = own app, action = close.
        - element: Toast
          behavior: spawns an element on a higher layer.
        - element: Pop-up
          behavior: spawns an element one layer above the caller.

  rendering_and_performance:
    id: "2.4"
    status: DECIDED direction, PROPOSED mechanics
    points:
      - GPU-accelerated, resolution-independent vector drawing, so scaling is free.
      - Each layer renders into its own GPU texture; a compositor blends them.
      - >-
        CPU/GPU "ping-pong" = double or triple buffering: a layer draws into a
        back buffer while the compositor reads the front one, then they swap.
      - Threads per layer (or processes, see open_questions).
    memory_control:
      status: DECIDED idea (layers dynamically scale and switch off when not needed)
      points:
        - Textures are sized to the layer's bounds, not full screen.
        - Transparent (not black) means "nothing here" and costs nothing.
        - Occlusion culling: skip rendering beneath fully opaque regions.
        - >-
          Unloading is cheap because layer state is typed data, not pixels;
          the texture is a throwaway cache.
      layer_lifecycle:
        - state: active
          meaning: redrawing
        - state: idle
          meaning: keeps texture, thread sleeps, last frame reused
        - state: unloaded
          meaning: texture freed, only the data tree remains
      layer_policies:
        - always-warm
        - sleep-when-idle
        - unload-when-empty

  any_language_per_layer:
    id: "2.5"
    status: PROPOSED, later
    description: >-
      Because layers only see messages, the language behind a layer does not
      matter. Preferred route: WASM modules (sandboxed, cheap to load/unload).
      Alternative: a process per layer. Keep high-frequency rendering in the
      native core; foreign layers send small, infrequent messages. Do not
      build this until the bus contract is clean.

  variables_bindings_and_motion:
    id: "2.6"
    status: DECIDED goals, PROPOSED mechanics
    variables_are_first_class: >-
      A named, typed value store. Any element prop is a literal or a variable
      reference. Events write variables, animations drive variables, signal
      providers feed variables, and the renderer reads them every frame.
      "Event and variable driven" is the data model, not a feature.
    motion_is_data: >-
      Springs, tweens, easing, timelines, and staggers are declared on
      elements or variables with no animation code. They are interruptible, so
      the UI never feels stuck mid-transition. A frame clock paces frames to
      the display's refresh rate.
    alive: >-
      A time variable and ambient motion (slow breathing, noise drift, light
      that follows the cursor), each with an intensity setting that can be
      turned fully off.
    beauty_on_the_gpu: >-
      Shapes drawn as signed distance fields (crisp at any scale, soft
      shadows, glows), gradients in a perceptual color space, frosted-glass
      blur of whatever sits under a layer (fits the name and layers-as-glass),
      and a custom-shader element. Styling uses shared design tokens (color,
      radius, spacing, motion curves).
    motion_budget: >-
      Continuous motion fights the idle/unload lifecycle (2.4), so a layer
      renders frames only while something animates, ambient motion has an
      intensity cap, and load or power state can turn it down.
    visual_feel: >-
      The overall visual feel (frosted glass, neon/glow, other) is still
      undecided; see open question 9.

  signal_providers:
    id: "2.7"
    status: PROPOSED
    description: >-
      A provider is anything that feeds variables: clock, mouse and keyboard,
      system metrics, file watchers, sockets, HTTP/SSE streams, or a plugin.
      Providers sit behind one trait, so the UI can react to any live source
      without the core knowing what it is.
    example: >-
      A live system monitor drawn as spring-smoothed bars from CPU, memory,
      and network variables.

prior_art:
  note: Not dependencies, just what exists so Looking Glass can differ on purpose.
  items:
    - category: Electron alternatives that still use a webview or Chromium
      examples: [Tauri (system webview + Rust), Wails (Go), Electrobun (Bun), Neutralino]
      note: Looking Glass is not based on a browser engine.
    - category: Non-browser UI toolkits
      examples: [Flutter, Slint, Lynx, Dioxus Blitz]
      note: They draw their own pixels but have no shared host, no layered runtime composition, and no cross-app preference layer.
    - category: Rendering pieces to learn from
      examples: [wgpu, Skia, Vello (GPU vector drawing)]
    - category: Compositor design to learn from
      examples: [Wayland, macOS, Windows DWM]
      note: Each surface renders to its own texture; a compositor blends them.
  differentiators:
    - The layered runtime (layers added and removed live)
    - UI as typed data with variables
    - Motion as data
    - The shared host with cross-app preferences
    - Layers in any language

smallest_slice:
  approach: DECIDED, start with the smallest unit and build up
  smallest_unit: one borderless window that draws one rectangle from a data struct. No layers, no bus, nothing else.
  build_order:
    detail: PHASEMAP.md
    phases:
      - { phase: 0, name: foundations }
      - { phase: 1, name: window + one rectangle from data }
      - { phase: 2, name: text and button, plus variables and bindings }
      - { phase: 3, name: layers as a runtime operation (spawn a toast) }
      - { phase: 4, name: motion and visual effects }
      - { phase: 5, name: event bus }
      - { phase: 6, name: lifecycle and motion budget }
      - { phase: 7, name: signal providers }
      - { phase: 8, name: host/app model and shared preferences }
      - { phase: 9, name: scripting/WASM }
      - { phase: 10, name: snapshot, replay, governor }
      - { phase: 11, name: editor }
      - { phase: 12, name: packaging }
  first_real_target:
    status: PROPOSED
    name: live system monitor
    description: >-
      CPU, memory, and network bars, spring-smoothed, driven by variables from
      a system-metrics provider, with a toast on a spike. It exercises schema,
      variables, motion, layers, and live data with no external service.
  executable_goal:
    status: DECIDED
    description: >-
      It must compile into a single application (exe). Rust, Zig, or C++ fit
      best because they produce a single native binary with static linking and
      no runtime to install.

open_questions:
  - id: 1
    question: Threads or processes per layer?
    detail: Threads are faster with shared memory; processes isolate better but add messaging latency.
    assigned_to: phase 6 (measure)
  - id: 2
    question: What does "PID management" mean here?
    detail: Managing processes and threads, a PID controller (feedback loop that tunes resources automatically), or both?
    assigned_to: phases 0 and 10
  - id: 3
    question: Layer permissions
    detail: >-
      What can a layer read or change in the others? Should the meta layer
      rewrite what is below it live (devtools for everything), or only observe
      and route? Does an element's power change with its depth, or only its
      reach?
    assigned_to: phase 9
  - id: 4
    question: Wake latency policy
    detail: Which layers stay warm (e.g. toasts) versus unload when empty?
    assigned_to: phase 6
  - id: 5
    question: Name for the project.
    resolved: true
    resolution: Looking Glass
  - id: 6
    question: Does the UI editor come before or after scripting?
    detail: Currently placed last (phase 11).
  - id: 7
    question: "Feedback loop: how should layer lifecycle respond to load?"
    detail: A local governor (phase 10) fed by generic signals such as frame time, memory, and CPU.
  - id: 8
    question: Replay format
    detail: Looking Glass's own snapshot/replay format; details at phase 10.
  - id: 9
    question: What is the visual feel?
    detail: Frosted glass (blur, soft light), neon/glow, or something else. Decides phase 4 priorities. Asked, not yet answered.
  - id: 10
    question: Variable expressions
    detail: How much of an expression language before scripting arrives in phase 9?
    proposed: Only map-range, clamp, and mix in phase 2.

risks:
  - name: Scope
    detail: >-
      Renderer, compositor, scripting runtime, and editor are each large. The
      mitigation is the rule above: add a piece only when the previous one
      works.
  - name: Designing in the abstract
    detail: >-
      Designing with no target tends to fold back on itself (self-hosting
      editor editing itself). Keep a concrete target (the system-map panel) in
      view.
  - name: Memory cost of many full-size layers
    detail: Handled by bounds-sized textures and the lifecycle policy.
  - name: Beauty vs idle
    detail: >-
      Continuous animation fights the idle/unload lifecycle; handled by the
      motion budget (2.6).

bundle_contents:
  - SPEC.md (this file)
  - PHASEMAP.md (phased build plan)
  - README.md

# =====================================================================
# DAG: full dependency graph for the whole project (main track, Track E,
# decisions, milestones). Generated from PHASEMAP.md, EDITOR.md and SPEC.md.
# =====================================================================
dag:
  version: "1.0"
  sources: [SPEC.md, PHASEMAP.md, EDITOR.md]
  rule: >-
    No node starts until every node in its depends_on has finished. A phase's
    exit node (kind gate) carries the phase's exit test, and the next phase's
    first tasks depend on that exit node. This encodes the PHASEMAP.md rule
    that a phase must pass its exit test before the next one starts.
  conventions:
    id: group.name, where group is p0..p12 (main phases), e0..e7 (editor Track E), d (decision), m (milestone)
    kinds:
      task: a unit of work taken from a phase's Do list or an editor step
      gate: the exit test of a phase or editor step
      decision: an open question, shown as a node so work can depend on it
      milestone: a named point in the project that depends on gates
    edges:
      depends_on: hard edge; the node cannot start until these finish
      soft_depends_on: informs the node but does not block it (typically an unanswered decision or a lower-priority input)
    flags:
      optional: not required by its gate; listed because the source documents propose it
      status: proposed_amendment (A1/A2 in EDITOR.md, not applied to PHASEMAP.md), on_hold, open, assigned
    sizes: PHASEMAP.md gives relative effort (S, M, L) per phase only, not per task and not time
  stats:
    nodes: 197
    by_kind: {task: 154, gate: 20, decision: 14, milestone: 9}
    hard_edges: 315
    soft_edges: 17
    waves: 41
    longest_chain_nodes: 41
    acyclic: true
  groups:
    - id: p0
      name: "Foundations and decisions"
      track: main
      size: S
      declared_depends_on: []
      derived_extra_depends_on: []
    - id: p1
      name: "Window + one rectangle from data"
      track: main
      size: S
      declared_depends_on: [p0]
      derived_extra_depends_on: []
    - id: p2
      name: "Elements, layout, variables and bindings"
      track: main
      size: M
      declared_depends_on: [p1]
      derived_extra_depends_on: []
    - id: p3
      name: "Layers as a runtime operation"
      track: main
      size: M
      declared_depends_on: [p2]
      derived_extra_depends_on: []
    - id: p4
      name: "Motion and visual effects"
      track: main
      size: L
      declared_depends_on: [p2, p3]
      derived_extra_depends_on: []
    - id: p5
      name: "Event bus / interaction contract"
      track: main
      size: M
      declared_depends_on: [p2, p3]
      derived_extra_depends_on: []
    - id: p6
      name: "Lifecycle, performance, motion budget"
      track: main
      size: L
      declared_depends_on: [p3, p4, p5]
      derived_extra_depends_on: []
    - id: p7
      name: "Signal providers + live demo"
      track: main
      size: M
      declared_depends_on: [p2, p5]
      derived_extra_depends_on: [p3, p4]
    - id: p8
      name: "Host, app model, preferences, cross-app"
      track: main
      size: M
      declared_depends_on: [p3, p5]
      derived_extra_depends_on: []
    - id: p9
      name: "Scripting, permissions, multi-language"
      track: main
      size: L
      declared_depends_on: [p5, p8]
      derived_extra_depends_on: [p3]
    - id: p10
      name: "Snapshot, replay, governor"
      track: main
      size: L
      declared_depends_on: [p6, p7]
      derived_extra_depends_on: []
    - id: p11
      name: "Self-hosted UI editor (= Track E step E5)"
      track: main
      size: L
      declared_depends_on: [p8, p9, e1, e2, e3, e4]
      derived_extra_depends_on: [e0, p6, p7]
    - id: p12
      name: "Packaging and distribution"
      track: main
      size: M
      declared_depends_on: [p8]
      derived_extra_depends_on: []
    - id: e0
      name: "Editor core: document, ops, transactions, undo, validation, CLI"
      track: editor
      declared_depends_on: [p2]
      derived_extra_depends_on: []
    - id: e1
      name: "Layer ops and inspector descriptors"
      track: editor
      declared_depends_on: [p3]
      derived_extra_depends_on: [e0]
    - id: e2
      name: "Style rules, motion defs, tokens, particle emitter schema"
      track: editor
      declared_depends_on: [p4]
      derived_extra_depends_on: [e0, e1]
    - id: e3
      name: "Wiring ops with contract validation"
      track: editor
      declared_depends_on: [p5]
      derived_extra_depends_on: [e0]
    - id: e4
      name: "Deterministic code generation (lg-gen)"
      track: editor
      declared_depends_on: [e0]
      derived_extra_depends_on: []
    - id: e6
      name: "Additional targets (emitter packs), on hold"
      track: editor
      declared_depends_on: [e4]
      derived_extra_depends_on: []
      status: on_hold
    - id: e7
      name: "Enterprise layer"
      track: editor
      declared_depends_on: [p11, p10]
      derived_extra_depends_on: [e4, p9]
  nodes:
    - id: d.oq2
      name: "OQ2: what does PID management mean (process/thread management, a PID controller, or both)"
      kind: decision
      depends_on: [p0.decide_oq1_oq2]
      status: open
      spec_ref: "5.2"
      note: "Decided or deferred in phase 0; consumed by the governor in phase 10."
    - id: d.oq3
      name: "OQ3 / E-OQ3: layer permissions (what a layer may read or change in others; meta layer rewrites live or only observes)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ3]
      spec_ref: "5.3"
      note: "Assigned to phase 9. The editor cannot fully exist without it."
    - id: d.oq9
      name: "OQ9 / E-OQ6: visual feel (frosted glass, neon/glow, other)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ6]
      spec_ref: "5.9"
      note: "Asked, not yet answered. Decides phase 4 priorities, default tokens, particle presets, and the editor's own look."
    - id: d.oq10
      name: "OQ10 / E-OQ7: variable expression set (map-range, clamp, mix only; plus gt, lt, eq, between, within_ms for style rules)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ7]
      spec_ref: "5.10"
      note: "Proposed: add comparisons and event recency to phase 2, still no general scripting."
    - id: d.oq6
      name: "OQ6: does the UI editor come before or after scripting"
      kind: decision
      depends_on: []
      status: assigned
      spec_ref: "5.6"
      note: "Currently placed last (phase 11)."
    - id: d.e_oq1
      name: "E-OQ1: what 'agnostic' means for editor output (scene JSON only, web exporters, native toolkits)"
      kind: decision
      depends_on: []
      status: on_hold
      note: "On hold at the user's request. Only lg-export waits on this."
    - id: d.e_oq2
      name: "E-OQ2: editor before the renderer? (proposed: headless core early, no temporary web shell)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq4
      name: "E-OQ4: is the code view editable (proposed: yes, with read-back and drift handling)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq5
      name: "E-OQ5: collaboration (proposed: single user first; base_rev leaves room for merge)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq8
      name: "E-OQ8: editor name (working name: Looking Glass Editor)"
      kind: decision
      depends_on: []
      status: open
    - id: d.oq1
      name: "OQ1: threads or processes per layer"
      kind: decision
      depends_on: [p6.measure_threads_vs_processes]
      status: assigned
      spec_ref: "5.1"
      note: "Resolved by measurement in phase 6."
    - id: d.oq4
      name: "OQ4: wake latency policy (which layers stay warm vs unload when empty)"
      kind: decision
      depends_on: [p6.measure_wake_latency]
      status: assigned
      spec_ref: "5.4"
      note: "Resolved by measurement in phase 6."
    - id: d.oq7
      name: "OQ7: feedback loop (how layer lifecycle responds to load: a local governor fed by generic signals)"
      kind: decision
      depends_on: [p10.governor_controller]
      status: assigned
      spec_ref: "5.7"
    - id: d.oq8
      name: "OQ8: replay format (Looking Glass's own snapshot/replay format)"
      kind: decision
      depends_on: [p6.exit]
      status: assigned
      spec_ref: "5.8"
      note: "Format details settled at the start of phase 10."
    - id: p0.workspace
      name: "Create the Cargo workspace and an empty lg-shell that builds to one exe"
      kind: task
      depends_on: []
      files: [Cargo.toml, "apps/lg-shell/src/main.rs"]
    - id: p0.decide_stack
      name: "Settle language (Rust), data format (JSON first), platform (Windows first)"
      kind: task
      depends_on: []
      files: ["docs/decisions.md"]
    - id: p0.decide_oq1_oq2
      name: "Decide OQ1 and OQ2, or defer them to phases 6 and 10"
      kind: task
      depends_on: [p0.decide_stack]
    - id: p0.exit
      name: "Phase 0 exit test"
      kind: gate
      depends_on: [p0.workspace, p0.decide_oq1_oq2]
      exit_test: "cargo build --release yields one exe that starts and exits cleanly."
    - id: p1.element_struct
      name: "Element data struct for a rectangle"
      kind: task
      depends_on: [p0.exit]
      files: ["crates/lg-core/src/element.rs"]
    - id: p1.window
      name: "Borderless window via winit with own drag/resize hit-testing and HiDPI scale"
      kind: task
      depends_on: [p0.exit]
      files: ["apps/lg-shell/src/main.rs"]
    - id: p1.gpu_context
      name: "wgpu GPU context bound to the window"
      kind: task
      depends_on: [p1.window]
    - id: p1.scene_loader
      name: "Load the rectangle from scenes/rect.json"
      kind: task
      depends_on: [p1.element_struct]
      files: ["scenes/rect.json"]
    - id: p1.rect_renderer
      name: "Draw one rectangle from data on the GPU"
      kind: task
      depends_on: [p1.gpu_context, p1.scene_loader]
      files: ["crates/lg-render/src/rect.rs"]
    - id: p1.exit
      name: "Phase 1 exit test"
      kind: gate
      depends_on: [p1.rect_renderer, p1.window]
      exit_test: "Editing the JSON and restarting changes the rectangle; resizing keeps it sharp and correctly scaled."
    - id: p2.schema
      name: "Element schema: props, states, events, slots"
      kind: task
      depends_on: [p1.exit]
      spec_ref: "2.1"
      files: ["schemas/element.schema.json", "crates/lg-core/src/schema.rs"]
    - id: p2.tree
      name: "Scene tree of schema instances"
      kind: task
      depends_on: [p2.schema]
      spec_ref: "2.1"
      files: ["crates/lg-core/src/tree.rs"]
    - id: p2.vars
      name: "Variable store: named, typed values"
      kind: task
      depends_on: [p1.exit]
      spec_ref: "2.6"
      files: ["crates/lg-vars/src/lib.rs"]
    - id: p2.bindings
      name: "Props as literal or variable reference; events write variables"
      kind: task
      depends_on: [p2.vars, p2.tree]
      spec_ref: "2.6"
    - id: p2.expr
      name: "Tiny expression set: map-range, clamp, mix"
      kind: task
      depends_on: [p2.vars]
      soft_depends_on: [d.oq10]
      spec_ref: "2.6"
    - id: p2.layout
      name: "Small flexbox-like layout"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-layout/src/lib.rs"]
    - id: p2.text
      name: "Text rendering (cosmic-text or glyphon)"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-render/src/text.rs"]
    - id: p2.shapes
      name: "Shape rendering for rectangle and button"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-render/src/shapes.rs"]
    - id: p2.hit_test
      name: "Hit testing"
      kind: task
      depends_on: [p2.layout]
    - id: p2.button
      name: "Button element with states; click writes a variable"
      kind: task
      depends_on: [p2.hit_test, p2.bindings, p2.shapes, p2.text]
      files: ["scenes/button.json"]
    - id: p2.hot_reload
      name: "Hot reload of scenes/*.json (notify)"
      kind: task
      depends_on: [p2.tree, p2.bindings]
    - id: p2.styles_schema
      name: "Amendment A2: add styles and comparison conditions to element.schema.json"
      kind: task
      depends_on: [p2.schema]
      soft_depends_on: [d.oq10]
      optional: true
      status: proposed_amendment
      note: "PROPOSED in EDITOR.md, not applied to PHASEMAP.md."
    - id: p2.exit
      name: "Phase 2 exit test"
      kind: gate
      depends_on: [p2.button, p2.expr, p2.text, p2.hot_reload]
      exit_test: "A button writes a variable on click and a text element bound to it updates; editing button.json live updates the window."
    - id: p3.layer_model
      name: "Layer model: id, tags, depth, bounds, lifecycle policy, owner (names are conventions only)"
      kind: task
      depends_on: [p2.exit]
      spec_ref: "2.2"
      files: ["schemas/layer.schema.json", "crates/lg-core/src/layer.rs"]
    - id: p3.layer_ops
      name: "Operations layer.add, layer.remove, element.move (re-parent)"
      kind: task
      depends_on: [p3.layer_model]
      spec_ref: "2.2"
    - id: p3.layer_texture
      name: "Per-layer GPU texture sized to the layer's bounds"
      kind: task
      depends_on: [p3.layer_model]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/texture.rs"]
    - id: p3.compositor
      name: "Compositor blends layers by depth"
      kind: task
      depends_on: [p3.layer_texture]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/compositor.rs"]
    - id: p3.auto_remove
      name: "Remove empty layers and return to one layer"
      kind: task
      depends_on: [p3.layer_ops]
      spec_ref: "2.2"
    - id: p3.toast
      name: "Toast spawned on a second layer by a button"
      kind: task
      depends_on: [p3.layer_ops, p3.compositor]
      files: ["scenes/toast.json"]
    - id: p3.exit
      name: "Phase 3 exit test"
      kind: gate
      depends_on: [p3.toast, p3.auto_remove]
      exit_test: "A button spawns a toast on a second layer; dismissing removes the layer; no layer names are hard-coded in the engine."
    - id: p4.frame_clock
      name: "Frame clock with pacing matched to the display's refresh rate"
      kind: task
      depends_on: [p3.exit]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/clock.rs"]
    - id: p4.springs_tweens
      name: "Springs, tweens, and easing as data"
      kind: task
      depends_on: [p4.frame_clock]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/spring.rs", "crates/lg-motion/src/tween.rs"]
    - id: p4.timelines
      name: "Timelines and staggers"
      kind: task
      depends_on: [p4.springs_tweens]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/timeline.rs"]
    - id: p4.interruptible
      name: "Interruptible motion: retarget from current position and velocity"
      kind: task
      depends_on: [p4.springs_tweens]
      spec_ref: "2.6"
    - id: p4.time_variable
      name: "Time variable"
      kind: task
      depends_on: [p4.frame_clock]
      spec_ref: "2.6"
    - id: p4.ambient
      name: "Ambient motion: breathing, noise drift, light following the cursor"
      kind: task
      depends_on: [p4.time_variable, p4.interruptible]
      spec_ref: "2.6"
    - id: p4.intensity_controls
      name: "Intensity setting per ambient effect; 0 is fully off (exposed from the start)"
      kind: task
      depends_on: [p4.ambient]
      spec_ref: "2.6"
    - id: p4.sdf
      name: "SDF rounded shapes"
      kind: task
      depends_on: [p3.exit]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/sdf.rs"]
    - id: p4.shadow_glow
      name: "Soft shadows and glows"
      kind: task
      depends_on: [p4.sdf]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/shadow.rs"]
    - id: p4.gradient
      name: "Gradients in a perceptual color space"
      kind: task
      depends_on: [p4.sdf]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/gradient.rs"]
    - id: p4.blur
      name: "Frosted-glass blur of whatever sits under a layer"
      kind: task
      depends_on: [p4.shadow_glow, p4.gradient, p3.compositor]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/blur.rs"]
      note: "Built after SDF, shadow, and gradient. Needs the phase 3 compositor."
    - id: p4.shader_element
      name: "Custom-shader element"
      kind: task
      depends_on: [p4.sdf]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/shader_element.rs"]
    - id: p4.design_tokens
      name: "Design tokens: color, radius, spacing, motion curves"
      kind: task
      depends_on: [p4.gradient, p4.springs_tweens]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
    - id: p4.particles
      name: "Amendment A1: particle simulation (GPU with CPU fallback), seeded, intensity 0 emits nothing"
      kind: task
      depends_on: [p4.sdf, p4.frame_clock, p4.intensity_controls]
      optional: true
      status: proposed_amendment
      files: ["crates/lg-render/src/particles.rs", "crates/lg-motion/src/emitter.rs"]
      note: "PROPOSED in EDITOR.md, not applied to PHASEMAP.md. Extends the phase 4 exit test."
    - id: p4.exit
      name: "Phase 4 exit test"
      kind: gate
      depends_on: [p4.timelines, p4.interruptible, p4.ambient, p4.intensity_controls, p4.blur, p4.shader_element, p4.design_tokens]
      exit_test: "A button, a toast, and a panel animate smoothly at display refresh rate; interrupting never snaps or stalls; ambient motion can be turned fully off."
    - id: p5.event_types
      name: "Typed events named {layer}:{noun}:{verb}"
      kind: task
      depends_on: [p3.exit]
      spec_ref: "2.3"
      files: ["schemas/event.schema.json", "crates/lg-bus/src/event.rs"]
    - id: p5.event_gates
      name: "One gate per event type; collisions are errors"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
      files: ["crates/lg-bus/src/gate.rs"]
    - id: p5.observers
      name: "Read-only observers"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
      files: ["crates/lg-bus/src/stream.rs"]
    - id: p5.ring_buffer
      name: "Ring buffer with sequence numbers"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
    - id: p5.contracts
      name: "Layer contracts: declare what is emitted and accepted; bus rejects violations"
      kind: task
      depends_on: [p5.event_gates]
      spec_ref: "2.3"
      files: ["schemas/contract.schema.json", "crates/lg-bus/src/contract.rs"]
    - id: p5.interaction_primitive
      name: "element + target + action (close, toast, pop-up) through the bus only"
      kind: task
      depends_on: [p5.contracts, p5.observers]
      spec_ref: "2.3"
    - id: p5.violation_log
      name: "Reject and log undeclared events"
      kind: task
      depends_on: [p5.contracts, p5.ring_buffer]
    - id: p5.exit
      name: "Phase 5 exit test"
      kind: gate
      depends_on: [p5.interaction_primitive, p5.violation_log]
      exit_test: "Close, toast, and pop-up work through the bus only; a layer sending an undeclared event is rejected and logged."
    - id: p6.lifecycle
      name: "Layer lifecycle states: active, idle, unloaded"
      kind: task
      depends_on: [p4.exit, p5.exit]
      spec_ref: "2.4"
      files: ["crates/lg-runtime/src/lifecycle.rs"]
    - id: p6.policies
      name: "Per-layer policy: always-warm, sleep-when-idle, unload-when-empty"
      kind: task
      depends_on: [p6.lifecycle]
      spec_ref: "2.4"
    - id: p6.motion_budget
      name: "Motion budget: frames only while animating; ambient intensity cap; load/power state turns it down"
      kind: task
      depends_on: [p6.lifecycle, p4.intensity_controls]
      spec_ref: "2.6"
      files: ["crates/lg-runtime/src/budget.rs"]
    - id: p6.dirty_regions
      name: "Dirty regions"
      kind: task
      depends_on: [p3.exit]
      files: ["crates/lg-render/src/dirty.rs"]
    - id: p6.occlusion_culling
      name: "Occlusion culling beneath fully opaque regions"
      kind: task
      depends_on: [p6.dirty_regions]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/cull.rs"]
    - id: p6.transparent_free
      name: "Transparent means nothing here and costs nothing"
      kind: task
      depends_on: [p6.dirty_regions]
      spec_ref: "2.4"
    - id: p6.layer_threads
      name: "Per-layer threads"
      kind: task
      depends_on: [p6.lifecycle]
      spec_ref: "2.4"
    - id: p6.buffering
      name: "Double and triple buffering"
      kind: task
      depends_on: [p6.layer_threads]
      spec_ref: "2.4"
      files: ["crates/lg-runtime/src/buffers.rs"]
    - id: p6.scheduler
      name: Scheduler
      kind: task
      depends_on: [p6.layer_threads, p6.policies]
      files: ["crates/lg-runtime/src/scheduler.rs"]
    - id: p6.stress_demo
      name: "Stress demo with many sparse layers"
      kind: task
      depends_on: [p6.scheduler, p6.buffering]
      files: ["apps/lg-demo/src/stress.rs"]
    - id: p6.measure_threads_vs_processes
      name: "Measure threads vs processes per layer"
      kind: task
      depends_on: [p6.stress_demo]
      resolves: OQ1
    - id: p6.measure_wake_latency
      name: "Measure wake latency per lifecycle policy"
      kind: task
      depends_on: [p6.stress_demo, p6.policies]
      resolves: OQ4
    - id: p6.exit
      name: "Phase 6 exit test"
      kind: gate
      depends_on: [p6.motion_budget, p6.occlusion_culling, p6.transparent_free, d.oq1, d.oq4]
      exit_test: "With many sparse layers an idle layer uses effectively no CPU; an unloaded layer frees its texture; with nothing animating the app idles near zero frames; wake latency is measured per policy."
    - id: p7.provider_trait
      name: "Signal provider trait"
      kind: task
      depends_on: [p5.exit]
      spec_ref: "2.7"
      files: ["schemas/signal.schema.json", "crates/lg-signals/src/provider.rs"]
    - id: p7.provider_time
      name: "Clock provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/time.rs"]
    - id: p7.provider_input
      name: "Mouse and keyboard provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/input.rs"]
    - id: p7.provider_metrics
      name: "System metrics provider (sysinfo)"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/metrics.rs"]
    - id: p7.provider_net
      name: "Socket and HTTP/SSE provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/net.rs"]
    - id: p7.provider_files
      name: "File watcher provider (notify)"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
    - id: p7.scene_valid_without_provider
      name: "Removing a provider leaves the scene valid"
      kind: task
      depends_on: [p7.provider_trait]
    - id: p7.monitor_scene
      name: "System monitor scene: spring-smoothed CPU, memory, and network bars bound to variables"
      kind: task
      depends_on: [p7.provider_metrics, p7.provider_net, p4.exit]
      files: ["scenes/monitor.json"]
      note: "Needs phase 4 motion (springs) although the phase map lists phase 7 as depending on 2 and 5 only."
    - id: p7.spike_toast
      name: "Toast on a spike"
      kind: task
      depends_on: [p7.monitor_scene, p3.toast]
    - id: p7.monitor_demo
      name: "Live system monitor demo app"
      kind: task
      depends_on: [p7.monitor_scene, p7.spike_toast]
      files: ["apps/lg-demo/src/monitor.rs"]
    - id: p7.exit
      name: "Phase 7 exit test"
      kind: gate
      depends_on: [p7.monitor_demo, p7.scene_valid_without_provider, p7.provider_time, p7.provider_input, p7.provider_files]
      exit_test: "The monitor updates live from real system data with no network service running; removing a provider leaves the scene valid."
    - id: p8.local_ipc
      name: "Local IPC between host and apps"
      kind: task
      depends_on: [p3.exit, p5.exit]
      files: ["crates/lg-host/src/ipc.rs"]
    - id: p8.app_registry
      name: "App registration; apps declare their contract"
      kind: task
      depends_on: [p8.local_ipc]
      files: ["crates/lg-host/src/registry.rs"]
    - id: p8.live_loading
      name: "Apps load live, not as static packages"
      kind: task
      depends_on: [p8.app_registry]
    - id: p8.session
      name: "Host session model"
      kind: task
      depends_on: [p8.app_registry]
      files: ["crates/lg-host/src/session.rs"]
    - id: p8.prefs_store
      name: "Preferences store in the meta layer: theme, fonts, accent, density, per-app overrides"
      kind: task
      depends_on: [p8.app_registry]
      files: ["schemas/prefs.schema.json", "crates/lg-prefs/src/lib.rs"]
    - id: p8.prefs_as_variables
      name: "Preferences exposed as variables so every app inherits"
      kind: task
      depends_on: [p8.prefs_store]
    - id: p8.shared_state
      name: "Cross-app shared state"
      kind: task
      depends_on: [p8.session]
    - id: p8.cross_app_messaging
      name: "Cross-app messaging over the bus"
      kind: task
      depends_on: [p8.session]
    - id: p8.embedding
      name: "Embed another app's elements"
      kind: task
      depends_on: [p8.cross_app_messaging, p8.shared_state]
    - id: p8.two_apps_demo
      name: "Two separate demo apps in one host"
      kind: task
      depends_on: [p8.embedding, p8.prefs_as_variables, p8.live_loading]
      files: ["apps/lg-demo/src/two_apps.rs"]
    - id: p8.exit
      name: "Phase 8 exit test"
      kind: gate
      depends_on: [p8.two_apps_demo]
      exit_test: "Two separate demo apps run in one host; changing the accent color once updates both; one embeds an element from the other."
    - id: p9.perm_model
      name: "Capability permission model"
      kind: task
      depends_on: [p8.exit, d.oq3]
      resolves: OQ3
      files: ["crates/lg-wasm/src/perms.rs"]
    - id: p9.wasm_host
      name: "WASM layer host (wasmtime)"
      kind: task
      depends_on: [p5.exit, p8.exit]
      spec_ref: "2.5"
      files: ["crates/lg-wasm/src/host.rs"]
    - id: p9.wasm_api
      name: "WASM layer API over the bus"
      kind: task
      depends_on: [p9.wasm_host]
      spec_ref: "2.5"
      files: ["crates/lg-wasm/src/api.rs"]
    - id: p9.wasm_sandbox
      name: "Sandboxed, cheap load and unload; rendering stays in the native core"
      kind: task
      depends_on: [p9.wasm_host]
      soft_depends_on: [p6.exit]
      spec_ref: "2.5"
    - id: p9.embedded_scripting
      name: "Embedded scripting (QuickJS or Lua); expression set may grow here"
      kind: task
      depends_on: [p9.wasm_api]
      optional: true
      note: "Listed as optional in PHASEMAP.md."
    - id: p9.wasm_toast_demo
      name: "WASM toast layer demo"
      kind: task
      depends_on: [p9.wasm_api, p9.perm_model, p3.toast]
      files: ["apps/lg-demo/wasm-toast/"]
    - id: p9.exit
      name: "Phase 9 exit test"
      kind: gate
      depends_on: [p9.wasm_toast_demo, p9.wasm_sandbox]
      exit_test: "A WASM layer draws a toast through the bus; it is denied an action its permissions do not grant."
    - id: p10.snapshot
      name: "Snapshot and restore of a layer's data tree on unload and wake"
      kind: task
      depends_on: [p6.exit, d.oq8]
      files: ["crates/lg-runtime/src/snapshot.rs"]
    - id: p10.event_recorder
      name: "Record the event stream"
      kind: task
      depends_on: [p6.exit, d.oq8]
      files: ["crates/lg-runtime/src/replay.rs"]
    - id: p10.replay
      name: "Deterministic replay"
      kind: task
      depends_on: [p10.event_recorder, p10.snapshot]
      soft_depends_on: [p4.particles]
      note: "Pixel-identical replay of particle scenes relies on seeded emitters (A1)."
    - id: p10.replay_slice
      name: "Replay a bounded slice for debugging"
      kind: task
      depends_on: [p10.replay]
    - id: p10.governor_signals
      name: "Governor inputs: frame time, memory, CPU"
      kind: task
      depends_on: [p6.exit, p7.exit]
    - id: p10.governor_controller
      name: "Governor: simple feedback controller"
      kind: task
      depends_on: [p10.governor_signals, d.oq2]
      files: ["crates/lg-runtime/src/governor.rs"]
    - id: p10.governor_actions
      name: "Throttle or unload layers and trim ambient motion"
      kind: task
      depends_on: [p10.governor_controller, p6.motion_budget]
    - id: p10.load_test
      name: "Simulated load test: idle layers unload and memory drops"
      kind: task
      depends_on: [p10.governor_actions]
    - id: p10.exit
      name: "Phase 10 exit test"
      kind: gate
      depends_on: [p10.replay_slice, p10.load_test, d.oq7]
      exit_test: "Under simulated load, idle layers unload and memory drops; an unloaded layer wakes with identical state; a recorded session replays to the same pixels."
    - id: e0.document_model
      name: "Document model: scene is the source of truth; editor-only data under meta.editor"
      kind: task
      depends_on: [p2.exit]
      soft_depends_on: [d.e_oq2]
      files: ["crates/lg-editor-core/"]
    - id: e0.op_set
      name: "Op set: element, prop, bind, style, motion, layer, var, wire, component, token ops with origin and base_rev"
      kind: task
      depends_on: [e0.document_model]
    - id: e0.txn_undo
      name: "Transactions; inverse computed on apply; undo and redo"
      kind: task
      depends_on: [e0.op_set]
    - id: e0.validation
      name: "Validation gates and doc.validate() with named failure codes"
      kind: task
      depends_on: [e0.op_set]
    - id: e0.preview_dry_run
      name: "doc.preview dry run"
      kind: task
      depends_on: [e0.validation]
    - id: e0.query_subscribe_log
      name: "doc.query selectors, doc.subscribe, doc.log"
      kind: task
      depends_on: [e0.document_model]
    - id: e0.cli
      name: "lg-edit CLI: apply, validate, undo-check"
      kind: task
      depends_on: [e0.txn_undo, e0.validation]
    - id: e0.fuzz_roundtrip
      name: "Round-trip, op-inverse fuzz, and validation fuzz in CI"
      kind: task
      depends_on: [e0.cli]
    - id: e0.benchmarks
      name: "Named benchmarks (apply latency and validate time on a 10,000-element scene) to set performance targets"
      kind: task
      depends_on: [e0.cli]
    - id: e0.exit
      name: "E0 exit test"
      kind: gate
      depends_on: [e0.fuzz_roundtrip, e0.benchmarks, e0.preview_dry_run, e0.query_subscribe_log]
      exit_test: "Every phase 2 scene round-trips byte-identical; a fuzzed op sequence followed by full undo returns the original byte-identical."
    - id: e1.layer_ops
      name: "Layer ops through the op system"
      kind: task
      depends_on: [p3.exit, e0.exit]
      note: "EDITOR.md lists E1 after phase 3 only; ops come from E0."
    - id: e1.inspector_descriptors
      name: "Schema-to-inspector descriptors generated as data"
      kind: task
      depends_on: [p3.exit, e0.exit]
    - id: e1.exit
      name: "E1 exit test"
      kind: gate
      depends_on: [e1.layer_ops, e1.inspector_descriptors]
      exit_test: "Layer add, move, and remove work through ops; descriptors are generated for rect, text, and button with no per-type code."
    - id: e2.style_rules
      name: "Style rules in the document model"
      kind: task
      depends_on: [p4.exit, e1.exit]
      soft_depends_on: [p2.styles_schema, d.oq10]
    - id: e2.motion_defs
      name: "Motion definitions in the document model"
      kind: task
      depends_on: [p4.exit, e0.exit]
    - id: e2.tokens
      name: "Tokens in the document model"
      kind: task
      depends_on: [p4.design_tokens, e0.exit]
    - id: e2.particle_emitter_schema
      name: "Particle emitter element schema in the document model"
      kind: task
      depends_on: [p4.particles, e0.exit]
    - id: e2.exit
      name: "E2 exit test"
      kind: gate
      depends_on: [e2.style_rules, e2.motion_defs, e2.tokens, e2.particle_emitter_schema]
      exit_test: "Style rules switch on a variable and animate; a particle emitter with a fixed seed renders identical frames on two runs."
    - id: e3.wire_ops
      name: "wire.add and wire.remove ops (event, target, action)"
      kind: task
      depends_on: [p5.exit, e0.exit]
    - id: e3.contract_validation
      name: "Validate wires against the target layer's contract at edit time"
      kind: task
      depends_on: [e3.wire_ops]
    - id: e3.exit
      name: "E3 exit test"
      kind: gate
      depends_on: [e3.contract_validation]
      exit_test: "An undeclared wire is rejected at edit time with E_CONTRACT_UNDECLARED."
    - id: e4.emitter_trait
      name: "lg-gen Emitter and Target traits"
      kind: task
      depends_on: [e0.exit]
      files: ["crates/lg-gen/"]
    - id: e4.element_emitters
      name: "Built-in code emitters per element type (scene JSON target mandatory)"
      kind: task
      depends_on: [e4.emitter_trait]
    - id: e4.markers
      name: "Element markers wrapping every fragment"
      kind: task
      depends_on: [e4.emitter_trait]
    - id: e4.assemble
      name: "Target.assemble: file layout, hoisted tokens and variables, tree order, fixed formatting"
      kind: task
      depends_on: [e4.element_emitters, e4.markers]
    - id: e4.incremental
      name: "emit_incremental patches only touched fragments"
      kind: task
      depends_on: [e4.assemble]
    - id: e4.readback
      name: "Read back marked fragments into ops (origin: code)"
      kind: task
      depends_on: [e4.assemble]
      soft_depends_on: [d.e_oq4]
    - id: e4.drift
      name: "Drift and parse handling: E_CODE_DRIFT, E_CODE_PARSE, keep as raw or regenerate"
      kind: task
      depends_on: [e4.readback]
    - id: e4.emit_registration_test
      name: "Registration test: emit twice; nondeterministic emitters are refused (E_EMIT_NONDETERMINISTIC)"
      kind: task
      depends_on: [e4.element_emitters]
    - id: e4.cli_emit_readback
      name: "lg-edit emit and lg-edit readback"
      kind: task
      depends_on: [e4.incremental, e4.readback]
    - id: e4.tests
      name: "Emit determinism, round-trip, incremental equals full, drift fixtures"
      kind: task
      depends_on: [e4.cli_emit_readback, e4.drift, e4.emit_registration_test]
    - id: e4.exit
      name: "E4 exit test"
      kind: gate
      depends_on: [e4.tests]
      soft_depends_on: [e2.exit]
      exit_test: "Every scene emits byte-identical output on repeated runs; emit then read back gives the same document; a matching hand edit becomes ops and a non-matching one raises E_CODE_DRIFT."
      note: "Emitting style, motion, and particle data needs the E2 schema even though EDITOR.md lists E4 after E0 only."
    - id: p11.shell
      name: "Editor app built from Looking Glass elements on a meta-tagged layer"
      kind: task
      depends_on: [p8.exit, p9.exit, e1.exit, e2.exit, e3.exit, e4.exit]
      soft_depends_on: [d.oq6]
      aliases: [E5]
      files: ["crates/lg-editor/", "apps/lg-demo/editor/"]
    - id: p11.native_undo
      name: "Undo bound natively, outside the scene"
      kind: task
      depends_on: [p11.shell, e0.txn_undo]
    - id: p11.lockout_recovery
      name: "Pinned last-known-good copy of the editor's own scene (E_SELF_EDIT_LOCKOUT recovery)"
      kind: task
      depends_on: [p11.shell, p11.native_undo]
    - id: p11.canvas
      name: "Canvas: live scene in the real renderer; select, drag, resize, re-parent across layers; edit/play toggle"
      kind: task
      depends_on: [p11.shell, e1.layer_ops]
    - id: p11.layer_stack
      name: "Layer stack surface: depth, tags, bounds, lifecycle state, texture memory"
      kind: task
      depends_on: [p11.shell, e1.layer_ops, p6.exit]
    - id: p11.tree
      name: "Tree surface: hierarchy, components, slots"
      kind: task
      depends_on: [p11.shell]
    - id: p11.inspector
      name: "Inspector generated from schema_of(type)"
      kind: task
      depends_on: [p11.shell, e1.inspector_descriptors]
    - id: p11.variables_panel
      name: "Variables surface with live values and provider source"
      kind: task
      depends_on: [p11.shell, p7.exit]
    - id: p11.style_rules_panel
      name: "Style rules surface with live match highlighting"
      kind: task
      depends_on: [p11.shell, e2.style_rules]
    - id: p11.motion_panel
      name: "Motion surface: spring visualizer, easing editor, multi-track timeline, stagger"
      kind: task
      depends_on: [p11.shell, e2.motion_defs]
    - id: p11.particles_panel
      name: "Particle editor: force gizmos, over-life curves, presets, live count against budget"
      kind: task
      depends_on: [p11.shell, e2.particle_emitter_schema]
      optional: true
    - id: p11.wiring_panel
      name: "Wiring surface checked against contracts"
      kind: task
      depends_on: [p11.shell, e3.exit]
    - id: p11.tokens_panel
      name: "Tokens and theme surface (edits lg-prefs tokens)"
      kind: task
      depends_on: [p11.shell, e2.tokens, p8.prefs_as_variables]
    - id: p11.library_panel
      name: "Component library surface"
      kind: task
      depends_on: [p11.shell, p11.tree]
    - id: p11.code_view
      name: "Code view: live generated code, selection linking, editable with read-back"
      kind: task
      depends_on: [p11.shell, e4.exit]
      soft_depends_on: [d.e_oq4]
    - id: p11.history_panel
      name: "History surface: op log, jump to revision, replay a range"
      kind: task
      depends_on: [p11.shell, e0.query_subscribe_log]
    - id: p11.problems_panel
      name: "Problems surface fed by validate()"
      kind: task
      depends_on: [p11.shell, e0.validation]
    - id: p11.perf_hud
      name: "Performance HUD: frame time, active layers, particle count, motion-budget state"
      kind: task
      depends_on: [p11.shell, p6.exit]
    - id: p11.exit
      name: "Phase 11 / E5 exit test"
      kind: gate
      depends_on: [p11.lockout_recovery, p11.canvas, p11.layer_stack, p11.tree, p11.inspector, p11.variables_panel, p11.style_rules_panel, p11.motion_panel, p11.wiring_panel, p11.tokens_panel, p11.library_panel, p11.code_view, p11.history_panel, p11.problems_panel, p11.perf_hud]
      exit_test: "Edit an element of the editor itself and see it update live, then undo; dragging updates the code view live; editing the code view updates the canvas; E_SELF_EDIT_LOCKOUT recovery works."
    - id: e6.export_crate
      name: "lg-export crate and Target packs scaffold"
      kind: task
      depends_on: [e4.exit, d.e_oq1]
      optional: true
      status: on_hold
      files: ["crates/lg-export/"]
    - id: e6.coverage
      name: "coverage() listing explicit losses before export"
      kind: task
      depends_on: [e6.export_crate]
      optional: true
      status: on_hold
    - id: e6.emitter_packs
      name: "Emitter pack per additional target"
      kind: task
      depends_on: [e6.coverage]
      optional: true
      status: on_hold
    - id: e6.conformance
      name: "Conformance scenes and byte-identical repeat export per target"
      kind: task
      depends_on: [e6.emitter_packs]
      optional: true
      status: on_hold
    - id: e6.exit
      name: "E6 exit test"
      kind: gate
      depends_on: [e6.conformance]
      optional: true
      status: on_hold
      exit_test: "Per target: coverage matches a fixture of expected losses; exported output renders the conformance scenes; repeated export is byte-identical."
    - id: e7.component_versioning
      name: "Component versioning (name@major.minor) and upgrades with diff preview, undoable"
      kind: task
      depends_on: [p11.exit]
    - id: e7.a11y_lint
      name: "Accessibility lint: contrast, hit-target size, focus order, reduced-motion respect"
      kind: task
      depends_on: [p11.problems_panel]
    - id: e7.visual_regression
      name: "Replay-based visual regression in CI"
      kind: task
      depends_on: [p10.exit, p11.exit]
    - id: e7.plugin_api
      name: "Plugin API: element schemas, inspector widgets, signal providers, emitters, targets under phase 9 permissions"
      kind: task
      depends_on: [p9.exit, e4.exit]
      note: "EDITOR.md describes this API but assigns it to no build_order step; placed in E7 provisionally."
    - id: e7.multiuser
      name: "Multi-user merge over the op log"
      kind: task
      depends_on: [p11.exit]
      soft_depends_on: [d.e_oq5]
      optional: true
    - id: e7.exit
      name: "E7 exit test"
      kind: gate
      depends_on: [e7.component_versioning, e7.a11y_lint, e7.visual_regression, e7.plugin_api]
      exit_test: "A component upgrade shows a diff and is undoable; a recorded session replays to the same pixels in CI."
    - id: p12.release_exe
      name: "Single-file release exe"
      kind: task
      depends_on: [p8.exit]
    - id: p12.installer
      name: Installer
      kind: task
      depends_on: [p12.release_exe]
    - id: p12.code_signing
      name: "Code signing"
      kind: task
      depends_on: [p12.release_exe]
    - id: p12.auto_update
      name: Auto-update
      kind: task
      depends_on: [p12.installer, p12.code_signing]
    - id: p12.port_linux
      name: "Linux port behind the thin platform layer"
      kind: task
      depends_on: [p8.exit]
    - id: p12.port_macos
      name: "macOS port behind the thin platform layer"
      kind: task
      depends_on: [p8.exit]
    - id: p12.release_docs
      name: "Release documentation"
      kind: task
      depends_on: [p12.installer]
      files: ["docs/release.md"]
    - id: p12.exit
      name: "Phase 12 exit test"
      kind: gate
      depends_on: [p12.auto_update, p12.port_linux, p12.port_macos, p12.release_docs]
      exit_test: "A clean machine installs and runs Looking Glass with no other software."
    - id: m.first_slice
      name: "Milestone: first slice (one borderless window drawing one rectangle from data)"
      kind: milestone
      depends_on: [p1.exit]
    - id: m.interactive_ui
      name: "Milestone: interactive UI with layers (button, variables, toast on a second layer)"
      kind: milestone
      depends_on: [p3.exit]
    - id: m.alive_ui
      name: "Milestone: animated, alive UI (motion, SDF look, blur-behind)"
      kind: milestone
      depends_on: [p4.exit]
    - id: m.live_monitor
      name: "Milestone: live system monitor (first real target)"
      kind: milestone
      depends_on: [p7.exit]
    - id: m.efficient_runtime
      name: "Milestone: idle-efficient, replayable runtime"
      kind: milestone
      depends_on: [p6.exit, p10.exit]
    - id: m.multi_app_host
      name: "Milestone: many apps in one host with shared preferences"
      kind: milestone
      depends_on: [p8.exit]
    - id: m.self_hosted_editor
      name: "Milestone: self-hosted editor"
      kind: milestone
      depends_on: [p11.exit]
    - id: m.enterprise_editor
      name: "Milestone: enterprise editor layer"
      kind: milestone
      depends_on: [e7.exit]
    - id: m.release
      name: "Milestone: packaged release"
      kind: milestone
      depends_on: [p12.exit]
  waves:
    description: Topological levels over hard edges. Everything in one wave can run in parallel once the previous wave is done.
    levels:
      - wave: 0
        nodes: [d.oq3, d.oq9, d.oq10, d.oq6, d.e_oq1, d.e_oq2, d.e_oq4, d.e_oq5, d.e_oq8, p0.workspace, p0.decide_stack]
      - wave: 1
        nodes: [p0.decide_oq1_oq2]
      - wave: 2
        nodes: [d.oq2, p0.exit]
      - wave: 3
        nodes: [p1.element_struct, p1.window]
      - wave: 4
        nodes: [p1.gpu_context, p1.scene_loader]
      - wave: 5
        nodes: [p1.rect_renderer]
      - wave: 6
        nodes: [p1.exit]
      - wave: 7
        nodes: [p2.schema, p2.vars, m.first_slice]
      - wave: 8
        nodes: [p2.tree, p2.expr, p2.styles_schema]
      - wave: 9
        nodes: [p2.bindings, p2.layout, p2.text, p2.shapes]
      - wave: 10
        nodes: [p2.hit_test, p2.hot_reload]
      - wave: 11
        nodes: [p2.button]
      - wave: 12
        nodes: [p2.exit]
      - wave: 13
        nodes: [p3.layer_model, e0.document_model]
      - wave: 14
        nodes: [p3.layer_ops, p3.layer_texture, e0.op_set, e0.query_subscribe_log]
      - wave: 15
        nodes: [p3.compositor, p3.auto_remove, e0.txn_undo, e0.validation]
      - wave: 16
        nodes: [p3.toast, e0.preview_dry_run, e0.cli]
      - wave: 17
        nodes: [p3.exit, e0.fuzz_roundtrip, e0.benchmarks]
      - wave: 18
        nodes: [p4.frame_clock, p4.sdf, p5.event_types, p6.dirty_regions, e0.exit, m.interactive_ui]
      - wave: 19
        nodes: [p4.springs_tweens, p4.time_variable, p4.shadow_glow, p4.gradient, p4.shader_element, p5.event_gates, p5.observers, p5.ring_buffer, p6.occlusion_culling, p6.transparent_free, e1.layer_ops, e1.inspector_descriptors, e4.emitter_trait]
      - wave: 20
        nodes: [p4.timelines, p4.interruptible, p4.blur, p4.design_tokens, p5.contracts, e1.exit, e4.element_emitters, e4.markers]
      - wave: 21
        nodes: [p4.ambient, p5.interaction_primitive, p5.violation_log, e2.tokens, e4.assemble, e4.emit_registration_test]
      - wave: 22
        nodes: [p4.intensity_controls, p5.exit, e4.incremental, e4.readback]
      - wave: 23
        nodes: [p4.particles, p4.exit, p7.provider_trait, p8.local_ipc, e3.wire_ops, e4.drift, e4.cli_emit_readback]
      - wave: 24
        nodes: [p6.lifecycle, p7.provider_time, p7.provider_input, p7.provider_metrics, p7.provider_net, p7.provider_files, p7.scene_valid_without_provider, p8.app_registry, e2.style_rules, e2.motion_defs, e2.particle_emitter_schema, e3.contract_validation, e4.tests, m.alive_ui]
      - wave: 25
        nodes: [p6.policies, p6.motion_budget, p6.layer_threads, p7.monitor_scene, p8.live_loading, p8.session, p8.prefs_store, e2.exit, e3.exit, e4.exit]
      - wave: 26
        nodes: [p6.buffering, p6.scheduler, p7.spike_toast, p8.prefs_as_variables, p8.shared_state, p8.cross_app_messaging, e6.export_crate]
      - wave: 27
        nodes: [p6.stress_demo, p7.monitor_demo, p8.embedding, e6.coverage]
      - wave: 28
        nodes: [p6.measure_threads_vs_processes, p6.measure_wake_latency, p7.exit, p8.two_apps_demo, e6.emitter_packs]
      - wave: 29
        nodes: [d.oq1, d.oq4, p8.exit, e6.conformance, m.live_monitor]
      - wave: 30
        nodes: [p6.exit, p9.perm_model, p9.wasm_host, e6.exit, p12.release_exe, p12.port_linux, p12.port_macos, m.multi_app_host]
      - wave: 31
        nodes: [d.oq8, p9.wasm_api, p9.wasm_sandbox, p10.governor_signals, p12.installer, p12.code_signing]
      - wave: 32
        nodes: [p9.embedded_scripting, p9.wasm_toast_demo, p10.snapshot, p10.event_recorder, p10.governor_controller, p12.auto_update, p12.release_docs]
      - wave: 33
        nodes: [d.oq7, p9.exit, p10.replay, p10.governor_actions, p12.exit]
      - wave: 34
        nodes: [p10.replay_slice, p10.load_test, p11.shell, e7.plugin_api, m.release]
      - wave: 35
        nodes: [p10.exit, p11.native_undo, p11.canvas, p11.layer_stack, p11.tree, p11.inspector, p11.variables_panel, p11.style_rules_panel, p11.motion_panel, p11.particles_panel, p11.wiring_panel, p11.tokens_panel, p11.code_view, p11.history_panel, p11.problems_panel, p11.perf_hud]
      - wave: 36
        nodes: [p11.lockout_recovery, p11.library_panel, e7.a11y_lint, m.efficient_runtime]
      - wave: 37
        nodes: [p11.exit]
      - wave: 38
        nodes: [e7.component_versioning, e7.visual_regression, e7.multiuser, m.self_hosted_editor]
      - wave: 39
        nodes: [e7.exit]
      - wave: 40
        nodes: [m.enterprise_editor]
  longest_chain:
    description: Longest dependency chain by node count over hard edges. It runs through the editor track, which makes editor work the long pole.
    length: 41
    path: [p0.decide_stack, p0.decide_oq1_oq2, p0.exit, p1.window, p1.gpu_context, p1.rect_renderer, p1.exit, p2.schema, p2.tree, p2.layout, p2.hit_test, p2.button, p2.exit, p3.layer_model, p3.layer_texture, p3.compositor, p3.toast, p3.exit, p5.event_types, p5.event_gates, p5.contracts, p5.interaction_primitive, p5.exit, p8.local_ipc, p8.app_registry, p8.session, p8.cross_app_messaging, p8.embedding, p8.two_apps_demo, p8.exit, p9.wasm_host, p9.wasm_api, p9.wasm_toast_demo, p9.exit, p11.shell, p11.native_undo, p11.lockout_recovery, p11.exit, e7.component_versioning, e7.exit, m.enterprise_editor]
  phase_critical_path:
    description: >-
      Longest chain over the phase-level graph declared in PHASEMAP.md, weighting
      S=1, M=2, L=3. Illustrative only; PHASEMAP.md gives relative sizes, not time,
      and Track E steps have no sizes.
    weight: 16
    path: [p0, p1, p2, p3, p5, p8, p9, p11]
  index:
    crates:
      lg-core: [p1.element_struct, p2.schema, p2.tree, p3.layer_model]
      lg-render: [p1.rect_renderer, p2.text, p2.shapes, p3.layer_texture, p3.compositor, p4.sdf, p4.shadow_glow, p4.gradient, p4.blur, p4.shader_element, p4.particles, p6.dirty_regions, p6.occlusion_culling]
      lg-vars: [p2.vars]
      lg-layout: [p2.layout]
      lg-motion: [p4.frame_clock, p4.springs_tweens, p4.timelines, p4.particles]
      lg-bus: [p5.event_types, p5.event_gates, p5.observers, p5.contracts]
      lg-runtime: [p6.lifecycle, p6.motion_budget, p6.buffering, p6.scheduler, p10.snapshot, p10.event_recorder, p10.governor_controller]
      lg-signals: [p7.provider_trait, p7.provider_time, p7.provider_input, p7.provider_metrics, p7.provider_net]
      lg-host: [p8.local_ipc, p8.app_registry, p8.session]
      lg-prefs: [p8.prefs_store]
      lg-wasm: [p9.perm_model, p9.wasm_host, p9.wasm_api]
      lg-editor-core: [e0.document_model]
      lg-gen: [e4.emitter_trait]
      lg-editor: [p11.shell]
      lg-export: [e6.export_crate]
    schemas:
      element.schema.json: [p2.schema]
      layer.schema.json: [p3.layer_model]
      event.schema.json: [p5.event_types]
      contract.schema.json: [p5.contracts]
      signal.schema.json: [p7.provider_trait]
      prefs.schema.json: [p8.prefs_store]
    scenes:
      rect.json: [p1.scene_loader]
      button.json: [p2.button]
      toast.json: [p3.toast]
      monitor.json: [p7.monitor_scene]
  findings:
    description: Things the graph shows that the source documents do not state. Each is a proposal to check, not a decision.
    items:
      - kind: implicit_dependency
        nodes: [p7.monitor_scene]
        text: "PHASEMAP.md lists phase 7 as depending on 2 and 5. The monitor demo needs spring-smoothed bars (phase 4) and a toast (phase 3), so the graph gives phase 7 edges to phases 3 and 4."
      - kind: implicit_dependency
        nodes: [e1.layer_ops, e1.inspector_descriptors, e2.style_rules, e3.wire_ops]
        text: "EDITOR.md lists E1, E2, and E3 as following phases 3, 4, and 5. Their work is expressed as ops, so each also depends on E0 (and E2's style rules on E1)."
      - kind: implicit_dependency
        nodes: [e4.exit]
        text: "EDITOR.md lists E4 after E0 only. Emitting styles, motion, and particle emitters needs the E2 schema, so E4's exit has a soft edge to E2's exit."
      - kind: implicit_dependency
        nodes: [p11.shell]
        text: "PHASEMAP.md lists phase 11 as depending on 8 and 9. With amendment A3 it also depends on E1 to E4, and its surfaces pull in phases 6 and 7 (layer stack, HUD, variables panel)."
      - kind: unassigned_work
        nodes: [e7.plugin_api]
        text: "The Plugin API in EDITOR.md has no build_order step. It is placed in E7 provisionally; it depends on phase 9 permissions and on E4 emitters."
      - kind: long_pole
        nodes: [m.enterprise_editor]
        text: "The longest chain runs 0 to 1 to 2 to 3 to 5 to 8 to 9 to 11 to E7. The editor track, not the renderer or lifecycle phases, ends the critical path."
      - kind: unblocked_start
        nodes: [e0.document_model, e4.emitter_trait]
        text: "E0 and E4 are headless and can start right after phase 2, in parallel with phases 3 to 6, matching the EDITOR.md note."
      - kind: decision_gate
        nodes: [d.oq3, p9.perm_model]
        text: "OQ3 (permissions) has no assigned resolver before phase 9 and blocks both the permission model and the editor's live editing of other apps."
      - kind: decision_gate
        nodes: [d.oq9]
        text: "OQ9 (visual feel) is a soft edge into the phase 4 look work and the design tokens; it blocks nothing hard but sets priorities and is still unanswered."
      - kind: decision_gate
        nodes: [d.e_oq1, e6.export_crate]
        text: "E-OQ1 (agnostic output) is on hold, so the whole of E6 is on hold and optional."
      - kind: parallel_opportunity
        nodes: [p4.exit, p5.exit]
        text: "Phases 4 and 5 both start after phase 3 and share no edges, so they run in parallel. Phases 6, 7, and 8 fan out from them."
      - kind: standalone
        nodes: [d.e_oq5, d.e_oq8, p9.embedded_scripting, p11.particles_panel, e7.multiuser]
        text: "These nodes are optional or open questions with no required downstream node, so no gate waits on them."

---

# SPEC-phasemap.spec

spec:
  meta:
    name: SPEC-phasemap
    spec: SPEC.spec
    spec_sha256: 73daa8cba5a955fef6d68bcb750cbb19ca4bcdd14056020743703593ed000009
    block_hashes:
      "format": 2a6b367c68db2f01
      "title": ff7a20e4a453609c
      "stage": 998033a8b52a55a9
      "build_plan": f5fd77d4b4a5aeb1
      "legend": 098beda52687df76
      "what_this_is": 2cd62c96ef4a270d
      "core_ideas": f8a6970081df1c29
      "prior_art": b56c890caad19519
      "smallest_slice": 910ec74b3506412a
      "open_questions": dfe3209a6bcdf210
      "risks": 73d524c6e9506ec2
      "bundle_contents": 02566cc52320cb40
      "dag": 78a284be0b7c1667
    axioms: docs/AXIOMS-v3.1.md §3.1 §3.3 §3.4 §1.1 §1.3 §0.3 §8.6 §12.1 §17.5
    planned_by: idearium/repo/spec-plan.js derivePlan
    planned_at: 2026-10-19T04:43:08.387Z
    reason: "the agent replied without a map"
    note: "One phase per section of the spec, its layer read from the section. Refine any phase, or ask the agent to plan again (replan) — this map is versioned."
  phases:
    SP0_format:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: []
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "format"
      files: [lib/format.js]
      does: >-
        Build what the spec states in §format (line 2) — format: yaml.
      proof: >-
        A test that proves format as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP1_core_ideas:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP0_format]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "core_ideas"
      files: [lib/core_ideas.js]
      does: >-
        Build what the spec states in §core_ideas (line 46) — ui_is_typed_data: id: "2.1" status: DECIDED direction, PROPOSED details description: >- There is no markup source of truth. Every element (button, text, rectangle, slider, toast, close button) is defi.
      proof: >-
        A test that proves core_ideas as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP2_smallest_slice:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP1_core_ideas]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "smallest_slice"
      files: [lib/smallest_slice.js]
      does: >-
        Build what the spec states in §smallest_slice (line 222) — approach: DECIDED, start with the smallest unit and build up smallest_unit: one borderless window that draws one rectangle from a data struct. No layers, no bus, nothing else. build_order: detail: PHA.
      proof: >-
        A test that proves smallest_slice as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP3_open_questions:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP2_smallest_slice]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "open_questions"
      files: [lib/open_questions.js]
      does: >-
        Build what the spec states in §open_questions (line 255) — - id: 1 question: Threads or processes per layer? detail: Threads are faster with shared memory; processes isolate better but add messaging latency. assigned_to: phase 6 (measure) - id: 2 question: Wh.
      proof: >-
        A test that proves open_questions as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP4_dag:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP3_open_questions]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "dag"
      files: [apps/lg-shell/src/main.rs, crates/lg-core/src/element.rs, scenes/rect.json, crates/lg-render/src/rect.rs, schemas/element.schema.json, crates/lg-core/src/schema.rs]
      does: >-
        Build what the spec states in §dag (line 320) — # DAG: full dependency graph for the whole project (main track, Track E, # decisions, milestones). Generated from PHASEMAP.md, EDITOR.md and SPEC.md. # ================================================.
      proof: >-
        A test that proves dag as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP5_title:
      layer: library
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      status_previous: "OPEN"
      status: "IN PROGRESS 2026-10-19."
      depends_on: [SP4_dag]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "title"
      files: [lib/title.js]
      does: >-
        Build what the spec states in §title (line 4).
      proof: >-
        A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP6_stage:
      layer: library
      status: OPEN
      depends_on: [SP5_title]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "stage"
      files: [lib/stage.js]
      does: >-
        Build what the spec states in §stage (line 7).
      proof: >-
        A test that proves stage as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP7_build_plan:
      layer: library
      status: OPEN
      depends_on: [SP6_stage]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "build_plan"
      files: [lib/build_plan.js]
      does: >-
        Build what the spec states in §build_plan (line 8).
      proof: >-
        A test that proves build_plan as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP8_legend:
      layer: library
      status: OPEN
      depends_on: [SP7_build_plan]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "legend"
      files: [lib/legend.js]
      does: >-
        Build what the spec states in §legend (line 17) — DECIDED: you said it or agreed to it directly. PROPOSED: a suggestion from the conversation that you have not confirmed. OPEN: unresolved question..
      proof: >-
        A test that proves legend as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP9_prior_art:
      layer: library
      status: OPEN
      depends_on: [SP8_legend]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "prior_art"
      files: [lib/prior_art.js]
      does: >-
        Build what the spec states in §prior_art (line 201) — note: Not dependencies, just what exists so Looking Glass can differ on purpose. items: - category: Electron alternatives that still use a webview or Chromium examples: [Tauri (system webview + Rust),.
      proof: >-
        A test that proves prior_art as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP10_bundle_contents:
      layer: library
      status: OPEN
      depends_on: [SP9_prior_art]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "bundle_contents"
      files: [lib/bundle_contents.js]
      does: >-
        Build what the spec states in §bundle_contents (line 315) — - SPEC.md (this file) - PHASEMAP.md (phased build plan) - README.md.
      proof: >-
        A test that proves bundle_contents as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP11_what_this_is:
      layer: ui
      status: OPEN
      depends_on: [SP10_bundle_contents]
      axioms: [§3.4, §1.3, §12.1]
      blocks:
        - "what_this_is"
      files: [ui/what_this_is.js]
      does: >-
        Build what the spec states in §what_this_is (line 22) — summary: >- An app platform, closer to a tiny OS layer for desktop apps than to an Electron clone. It is a UI renderer ("HTML, but not HTML") that draws its own pixels on the GPU and hosts apps live, .
      proof: >-
        A test that proves what_this_is as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP12_risks:
      layer: ui
      status: OPEN
      depends_on: [SP11_what_this_is]
      axioms: [§3.4, §1.3, §12.1]
      blocks:
        - "risks"
      files: [ui/risks.js]
      does: >-
        Build what the spec states in §risks (line 297) — - name: Scope detail: >- Renderer, compositor, scripting runtime, and editor are each large. The mitigation is the rule above: add a piece only when the previous one works. - name: Designing in the ab.
      proof: >-
        A test that proves risks as the spec states it, against the real code (no mock): §1.1, §12.1.

---

# spec/SPEC-phasemap.spec

spec:
  meta:
    name: SPEC-phasemap
    version: 0.1.0
    uuid: SPEC-phasemap-v1
    template: genesis
    purpose: >
      A phasemap for building the SPEC.spec in looking-glass-bundle-v0.4.
  axioms:
    AX-001: "A rule it must never break."
  modules:
    - id: SP0_foundation
      description: "Foundation and architecture first."
      path: lib/foundation.js
      exports:
        - "defineArchitecture(architecture: object) → void"
      behavioral_contracts:
        - "Given an architecture, defineArchitecture sets up the foundational components."
      error_paths:
        - "Invalid architecture → throws with a reason."
    - id: SP1_library
      description: "Raw execution before interfaces. Raw code → library."
      path: lib/library.js
      exports:
        - "buildLibrary(library: object) → void"
      behavioral_contracts:
        - "Given a library, buildLibrary compiles it into a reusable library."
      error_paths:
        - "Invalid library → throws with a reason."
    - id: SP2_api
      description: "API → CLI."
      path: lib/api.js
      exports:
        - "buildAPI(api: object) → void"
      behavioral_contracts:
        - "Given an API, buildAPI generates the CLI interface."
      error_paths:
        - "Invalid API → throws with a reason."
    - id: SP3_cli
      description: "CLI → automation."
      path: lib/cli.js
      exports:
        - "buildCLI(cli: object) → void"
      behavioral_contracts:
        - "Given a CLI, buildCLI automates the build process."
      error_paths:
        - "Invalid CLI → throws with a reason."
    - id: SP4_automation
      description: "Automation → UI."
      path: lib/automation.js
      exports:
        - "buildAutomation(automation: object) → void"
      behavioral_contracts:
        - "Given an automation, buildAutomation generates the UI."
      error_paths:
        - "Invalid automation → throws with a reason."
    - id: SP5_ui
      description: "UI."
      path: lib/ui.js
      exports:
        - "buildUI(ui: object) → void"
      behavioral_contracts:
        - "Given a UI, buildUI renders the final product."
      error_paths:
        - "Invalid UI → throws with a reason."
  tests:
    - "SP0_foundation on a valid architecture is successful."
    - "SP1_library on a valid library is successful."
    - "SP2_api on a valid API is successful."
    - "SP3_cli on a valid CLI is successful."
    - "SP4_automation on a valid automation is successful."
    - "SP5_ui on a valid UI is successful."


---

# tests/sp0-format.test.js

const assert = require('node:assert');
const { parseYaml, stringifyYaml } = require('../lib/format.js');

const sampleObject = { format: 'yaml', version: '0.3' };
const sampleString = 'format: yaml\nversion: "0.3"\n';

const serialized = stringifyYaml(sampleObject);
assert.strictEqual(typeof serialized, 'string');
assert.ok(serialized.includes('format: yaml'));

const parsed = parseYaml(sampleString);
assert.strictEqual(typeof parsed, 'object');
assert.strictEqual(parsed.format, 'yaml');

console.log('SP0_format test passed successfully.');

---

# proof/PROOF-REPORT.md

# Proof report — looking-glass-bundle-v0.4 — SP5 · title

Checked 2026-10-19 09:30 UTC.

**READY.** All 1 condition met.

| | What was promised | Result |
|---|---|---|
| ✅ | A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1. — lib/title.js is there | lib/title.js exists. |

## Evidence

- ✅ **A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1. — lib/title.js is there** — lib/title.js exists.

---
_Every line above was checked by running it, not by reading it._


---

# .nexus/proof-runs/2026-10-19T04-51-39-459Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP0 · format",
  "startedAt": 1792385499459,
  "finishedAt": 1792385499578,
  "verdict": "ready",
  "met": 2,
  "total": 2,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "tests-sp0-format-test-js-passes-written-",
      "says": "tests/sp0-format.test.js passes — written before the code, and seen failing first (the planned module is not written yet (lib/format.js))",
      "kind": "tests",
      "met": true,
      "evidence": "`node tests/sp0-format.test.js` → exit 0 in 0.1s.",
      "ms": 117
    },
    {
      "id": "a-test-that-proves-format-as-the-spec-st",
      "says": "A test that proves format as the spec states it, against the real code (no mock): §1.1, §12.1. — lib/format.js is there",
      "kind": "file",
      "met": true,
      "evidence": "lib/format.js exists.",
      "ms": 0
    }
  ],
  "shadow": {
    "id": "8e05e57a-c4db-4dd7-8a60-a8535b719219",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T04-51-39-459Z.json"
  }
}

---

# .nexus/proof-runs/latest.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP5 · title",
  "startedAt": 1792402256271,
  "finishedAt": 1792402256273,
  "verdict": "ready",
  "met": 1,
  "total": 1,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "a-test-that-proves-title-as-the-spec-sta",
      "says": "A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1. — lib/title.js is there",
      "kind": "file",
      "met": true,
      "evidence": "lib/title.js exists.",
      "ms": 0
    }
  ],
  "shadow": {
    "id": "728308b1-8263-4256-9348-43fafb071199",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T09-30-56-271Z.json"
  }
}

---

# lib/format.js

function parseYaml(content) {
  const result = {};
  const lines = content.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const colonIndex = trimmed.indexOf(':');
    if (colonIndex !== -1) {
      const key = trimmed.slice(0, colonIndex).trim();
      let val = trimmed.slice(colonIndex + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      result[key] = val;
    }
  }
  return result;
}

function stringifyYaml(data) {
  let output = '';
  for (const [key, value] of Object.entries(data)) {
    let valStr = value;
    if (typeof value === 'string' && (value === '0.3' || value.includes('.'))) {
      valStr = `"${value}"`;
    }
    output += `${key}: ${valStr}\n`;
  }
  return output;
}

module.exports = { parseYaml, stringifyYaml };


---

# Gemini said

{
  "system": "looking-glass-bundle-v0.4",
  "read": [
    "README.md",
    "PHASEMAP.md",
    "EDITOR.md",
    "SPEC.spec",
    "SPEC-phasemap.spec",
    "lib/format.js"
  ],
  "intent": "Build the core ideas module implementing the foundational principles of Looking Glass.",
  "spec": [
    "§core_ideas",
    "§1.1",
    "§12.1"
  ],
  "files": [
    {
      "path": "lib/core_ideas.js",
      "component": null,
      "new": true,
      "layer": "kernel",
      "purpose": "Implements the core ideas and principles of the Looking Glass spec.",
      "imports": [],
      "exports": [
        {
          "name": "getCoreIdeas",
          "signature": "getCoreIdeas() -> Array<string>",
          "does": "Returns the core ideas list defined in the spec."
        }
      ],
      "steps": [
        "1. Define the core ideas data structure based on the spec.",
        "2. Implement getCoreIdeas to return the core ideas array.",
        "3. Export getCoreIdeas."
      ]
    },
    {
      "path": "tests/sp1-core-ideas.test.js",
      "component": null,
      "new": true,
      "layer": "test",
      "purpose": "Tests the core ideas module against the requirements.",
      "imports": [
        "./lib/core_ideas.js: getCoreIdeas"
      ],
      "exports": [],
      "steps": [
        "1. Import getCoreIdeas.",
        "2. Write a test asserting that core ideas are returned correctly.",
        "3. Verify execution."
      ]
    }
  ],
  "order": [
    "lib/core_ideas.js",
    "tests/sp1-core-ideas.test.js"
  ],
  "conditions": [
    {
      "says": "Core ideas module exports getCoreIdeas",
      "check": {
        "kind": "file",
        "path": "lib/core_ideas.js",
        "contains": "getCoreIdeas"
      }
    },
    {
      "says": "Tests pass successfully",
      "check": {
        "kind": "tests",
        "run": "node --test tests/sp1-core-ideas.test.js"
      }
    }
  ]
}


---

# spec/core_ideas.

spec:
  meta:
    name: core_ideas
    version: 0.1.0
    uuid: core_ideas-v1
    template: genesis
    purpose: >
      Implements the core ideas and foundational principles of Looking Glass.
  axioms:
    AX-001: "Core ideas must reflect the declarative UI specification without external dependencies."
  modules:
    - id: core_ideas
      description: "Returns the core ideas of the Looking Glass specification."
      path: lib/core_ideas.js
      exports:
        - "getCoreIdeas() → Array"
      behavioral_contracts:
        - "Given the core ideas module is invoked, getCoreIdeas returns the defined array of core concepts."
      error_paths:
        - "Missing configuration → returns empty array."
  schemas:
    - id: Array
      fields:
        items: string
  tests:
    - "getCoreIdeas returns a non-empty array of core concepts."


---

# tests/sp1-core-ideas.

const assert = require('node:assert');
const { getCoreIdeas } = require('../lib/core_ideas.js');

const ideas = getCoreIdeas();
assert.ok(Array.isArray(ideas), 'getCoreIdeas should return an array');
assert.ok(ideas.length > 0, 'getCoreIdeas should return non-empty core ideas');
assert.strictEqual(typeof ideas[0], 'string', 'core idea items should be strings');

console.log('SP1_core_ideas test passed successfully.');


---

# tests/sp1-core-ideas.test.js

const assert = require('node:assert');
const { getCoreIdeas } = require('../lib/core_ideas.js');

const ideas = getCoreIdeas();
assert.ok(Array.isArray(ideas), 'getCoreIdeas should return an array');
assert.ok(ideas.length > 0, 'getCoreIdeas should return non-empty core ideas');
assert.strictEqual(typeof ideas[0], 'string', 'core idea items should be strings');

console.log('SP1_core_ideas test passed successfully.');


---

# .nexus/proof-runs/2026-10-19T07-17-12-081Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP1 · core ideas",
  "startedAt": 1792394232081,
  "finishedAt": 1792394232496,
  "verdict": "ready",
  "met": 3,
  "total": 3,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "tests-sp1-core-ideas-test-js-passes-writ",
      "says": "tests/sp1-core-ideas.test.js passes — written before the code, and seen failing first (the planned module is not written yet (lib/core_ideas.js))",
      "kind": "tests",
      "met": true,
      "evidence": "`node tests/sp1-core-ideas.test.js` → exit 0 in 0.2s.",
      "ms": 197
    },
    {
      "id": "core-ideas-module-exports-getcoreideas",
      "says": "Core ideas module exports getCoreIdeas",
      "kind": "file",
      "met": true,
      "evidence": "lib/core_ideas.js exists and contains \"getCoreIdeas\".",
      "ms": 0
    },
    {
      "id": "tests-pass-successfully",
      "says": "Tests pass successfully",
      "kind": "tests",
      "met": true,
      "evidence": "`node --test tests/sp1-core-ideas.test.js` → exit 0 in 0.2s.",
      "ms": 216
    }
  ],
  "shadow": {
    "id": "923d674e-57bc-42e5-b1f6-a26182882f34",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T07-17-12-081Z.json"
  }
}

---

# lib/core_ideas.js

module.exports = {
  getCoreIdeas: function() {
    return [
      "Transparency",
      "Interoperability",
      "Security",
      "Usability",
      "Scalability",
      "Reliability",
      "Efficiency",
      "Adaptability",
      "Collaboration",
      "Privacy",
      "Accessibility",
      "Performance"
    ];
  }
};


---

# spec/smallest_slice.spec

spec:
  meta:
    name: smallest_slice
    version: 0.1.0
    uuid: smallest_slice-v1
    template: genesis
    purpose: >
      Implements the smallest representable unit: one borderless window that draws one rectangle from a data struct.
  axioms:
    AX-001: "The smallest slice must have no layers and no event bus."
  modules:
    - id: smallest_slice
      description: "Renders the borderless window and rectangle from data."
      path: lib/smallest_slice.js
      exports:
        - "renderSmallestSlice(data: Object) → Object"
      behavioral_contracts:
        - "Given rectangle data, renderSmallestSlice returns a structured representation of a borderless window containing the rectangle."
      error_paths:
        - "Invalid data → throws with a reason."
  schemas:
    - id: Object
      fields:
        type: string
        bounds: string
  tests:
    - "renderSmallestSlice successfully produces a valid window and rectangle structure."


---

# tests/sp2-smallest-slice.test.js

const assert = require('node:assert');
const { renderSmallestSlice } = require('../lib/smallest_slice.js');

const rectData = { x: 10, y: 20, width: 100, height: 50, color: '#ff0000' };
const result = renderSmallestSlice(rectData);

assert.strictEqual(typeof result, 'object', 'renderSmallestSlice should return an object');
assert.strictEqual(result.type, 'borderless-window', 'result should be a borderless window');
assert.ok(result.rectangle, 'result should contain a rectangle description');
assert.strictEqual(result.rectangle.width, 100);
assert.strictEqual(result.rectangle.height, 50);

console.log('SP2_smallest_slice test passed successfully.');

---

# spec/lib/smallest_slice.spec

spec:
  meta:
    name: lib/smallest_slice
    version: 0.1.0
    purpose: >
      Implements the smallest slice representation of a borderless window drawing a rectangle from data.
    uuid: lib-smallest_slice-v1
    template: genesis
  modules:
    - id: renderSmallestSlice
      description: "Renders the smallest slice unit given rectangle data."
      path: lib/smallest_slice.js
      exports:
        - "renderSmallestSlice(data: Object) → Object"
      behavioral_contracts:
        - "Given a data object containing rectangle coordinates and dimensions, renderSmallestSlice returns an object representing a borderless window with a rectangle."
      error_paths:
        - "Invalid data format → throws an error."


---

# lib/smallest_slice.

function renderSmallestSlice(data) {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data provided to renderSmallestSlice');
  }
  return {
    type: 'borderless-window',
    rectangle: {
      x: data.x,
      y: data.y,
      width: data.width,
      height: data.height,
      color: data.color
    }
  };
}

module.exports = { renderSmallestSlice };


---

# .nexus/proof-runs/2026-10-19T07-26-15-692Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP2 · smallest slice",
  "startedAt": 1792394775692,
  "finishedAt": 1792394776348,
  "verdict": "ready",
  "met": 3,
  "total": 3,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "tests-sp2-smallest-slice-test-js-passes-",
      "says": "tests/sp2-smallest-slice.test.js passes — written before the code, and seen failing first (the planned module is not written yet (lib/smallest_slice.js))",
      "kind": "tests",
      "met": true,
      "evidence": "`node tests/sp2-smallest-slice.test.js` → exit 0 in 0.4s.",
      "ms": 389
    },
    {
      "id": "smallest-slice-module-exports-rendersmal",
      "says": "Smallest slice module exports renderSmallestSlice",
      "kind": "file",
      "met": true,
      "evidence": "lib/smallest_slice.js exists and contains \"renderSmallestSlice\".",
      "ms": 1
    },
    {
      "id": "tests-pass-successfully",
      "says": "Tests pass successfully",
      "kind": "tests",
      "met": true,
      "evidence": "`node --test tests/sp2-smallest-slice.test.js` → exit 0 in 0.3s.",
      "ms": 265
    }
  ],
  "shadow": {
    "id": "3b3787b4-ba2f-45e2-8df4-d47a5a9718d4",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T07-26-15-692Z.json"
  }
}

---

# tests/sp3-open-questions.test.js

const assert = require('node:assert');
const { getOpenQuestions } = require('../lib/open_questions.js');

const questions = getOpenQuestions();
assert.ok(Array.isArray(questions), 'getOpenQuestions should return an array');
assert.ok(questions.length > 0, 'getOpenQuestions should return non-empty open questions');
assert.strictEqual(typeof questions[0].id, 'number', 'question id should be a number');
assert.strictEqual(typeof questions[0].question, 'string', 'question text should be a string');

console.log('SP3_open_questions test passed successfully.');

---

# tests/sp3-open-questions.

const assert = require('node:assert');
const { getOpenQuestions } = require('../lib/open_questions.js');

const questions = getOpenQuestions();
assert.ok(Array.isArray(questions), 'getOpenQuestions should return an array');
assert.ok(questions.length > 0, 'getOpenQuestions should return non-empty open questions');
assert.strictEqual(typeof questions[0].id, 'number', 'question id should be a number');
assert.strictEqual(typeof questions[0].question, 'string', 'question text should be a string');

console.log('SP3_open_questions test passed successfully.');


---

# spec/open_questions.spec

spec:
  meta:
    name: open_questions
    version: 0.1.0
    uuid: open_questions-v1
    template: genesis
    purpose: >
      Implements retrieval and management of open design questions for Looking Glass.
  axioms:
    AX-001: "Open questions must accurately reflect the architectural trade-offs defined in the spec."
  modules:
    - id: open_questions
      description: "Returns the open design questions from the specification."
      path: lib/open_questions.js
      exports:
        - "getOpenQuestions() → Array"
      behavioral_contracts:
        - "Given the open questions module is invoked, getOpenQuestions returns an array of design questions."
      error_paths:
        - "Unavailable source → returns empty array."
  schemas:
    - id: Array
      fields:
        id: number
        question: string
  tests:
    - "getOpenQuestions returns a non-empty array of architectural questions."


---

# lib/smallest_slice.js

function renderSmallestSlice(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new TypeError(
      'data must be an object containing rectangle coordinates and dimensions'
    );
  }

  const { x, y, width, height } = data;
  const coordinates = { x, y, width, height };

  for (const [key, value] of Object.entries(coordinates)) {
    if (typeof value !== 'number' || !Number.isFinite(value)) {
      throw new TypeError(`rectangle ${key} must be a finite number`);
    }
  }

  if (width < 0 || height < 0) {
    throw new RangeError('rectangle width and height must be non-negative');
  }

  const rectangle = { x, y, width, height };

  if (Object.prototype.hasOwnProperty.call(data, 'color')) {
    rectangle.color = data.color;
  }

  return {
    type: 'borderless-window',
    border: false,
    rectangle
  };
}

module.exports = { renderSmallestSlice };


---

# spec/lib/open_questions.spec

spec:
  meta:
    name: lib/open_questions
    version: 0.1.0
    uuid: lib-open-questions-v1
    template: genesis
    purpose: >
      Implements retrieval and management of open design questions for Looking Glass.
  modules:
    - id: getOpenQuestions
      description: "Retrieves the list of open design questions defined in the specification."
      path: lib/open_questions.js
      exports:
        - "getOpenQuestions() → Array<Object>"
      behavioral_contracts:
        - "Given no input, getOpenQuestions returns an array of open design questions."
      error_paths:
        - "No questions available → returns an empty array."


---

# lib/open_questions.

function getOpenQuestions() {
  return [
    {
      id: 1,
      question: 'Threads or processes per layer?',
      detail: 'Threads are faster with shared memory; processes isolate better but add messaging latency.'
    }
  ];
}

module.exports = { getOpenQuestions };


---

# .nexus/proof-runs/2026-10-19T07-36-26-001Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP3 · open questions",
  "startedAt": 1792395386001,
  "finishedAt": 1792395386291,
  "verdict": "ready",
  "met": 3,
  "total": 3,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "tests-sp3-open-questions-test-js-passes-",
      "says": "tests/sp3-open-questions.test.js passes — written before the code, and seen failing first (the planned module is not written yet (lib/open_questions.js))",
      "kind": "tests",
      "met": true,
      "evidence": "`node tests/sp3-open-questions.test.js` → exit 0 in 0.1s.",
      "ms": 131
    },
    {
      "id": "open-questions-module-exports-getopenque",
      "says": "Open questions module exports getOpenQuestions",
      "kind": "file",
      "met": true,
      "evidence": "lib/open_questions.js exists and contains \"getOpenQuestions\".",
      "ms": 0
    },
    {
      "id": "tests-pass-successfully",
      "says": "Tests pass successfully",
      "kind": "tests",
      "met": true,
      "evidence": "`node --test tests/sp3-open-questions.test.js` → exit 0 in 0.2s.",
      "ms": 158
    }
  ],
  "shadow": {
    "id": "ba649c21-d52a-414e-9ed7-50854ea4fa45",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T07-36-26-001Z.json"
  }
}

---

# .nexus/proof-runs/2026-10-19T07-59-30-371Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP4 · dag",
  "startedAt": 1792396770371,
  "finishedAt": 1792396770634,
  "verdict": "ready",
  "met": 2,
  "total": 2,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "tests-sp4-dag-test-js-passes-written-bef",
      "says": "tests/sp4-dag.test.js passes — written before the code, and seen failing first (AssertionError [ERR_ASSERTION]: schemas/element.schema.json should exist)",
      "kind": "tests",
      "met": true,
      "evidence": "`node tests/sp4-dag.test.js` → exit 0 in 0.3s.",
      "ms": 262
    },
    {
      "id": "all-dag-files-are-successfully-created",
      "says": "All DAG files are successfully created",
      "kind": "file",
      "met": true,
      "evidence": "schemas/element.schema.json exists.",
      "ms": 0
    }
  ],
  "shadow": {
    "id": "24ad1470-13e8-401d-a925-7cedf9521583",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T07-59-30-371Z.json"
  }
}

---

# lib/open_questions.js

const openQuestions = [
  {
    id: 1,
    question: 'Threads or processes per layer?',
    detail:
      'Threads are faster with shared memory; processes isolate better but add messaging latency.',
    assigned_to: 'phase 6 (measure)'
  },
  {
    id: 2,
    question: 'What does "PID management" mean here?',
    detail:
      'Managing processes and threads, a PID controller (feedback loop that tunes resources automatically), or both?',
    assigned_to: 'phases 0 and 10'
  },
  {
    id: 3,
    question: 'Layer permissions',
    detail:
      "What can a layer read or change in the others? Should the meta layer rewrite what is below it live (devtools for everything), or only observe and route? Does an element's power change with its depth, or only its reach?",
    assigned_to: 'phase 9'
  },
  {
    id: 4,
    question: 'Wake latency policy',
    detail:
      'Which layers stay warm (e.g. toasts) versus unload when empty?',
    assigned_to: 'phase 6'
  },
  {
    id: 5,
    question: 'Name for the project.',
    resolved: true,
    resolution: 'Looking Glass'
  },
  {
    id: 6,
    question: 'Does the UI editor come before or after scripting?',
    detail: 'Currently placed last (phase 11).'
  },
  {
    id: 7,
    question: 'Feedback loop: how should layer lifecycle respond to load?',
    detail:
      'A local governor (phase 10) fed by generic signals such as frame time, memory, and CPU.'
  },
  {
    id: 8,
    question: 'Replay format',
    detail:
      "Looking Glass's own snapshot/replay format; details at phase 10."
  },
  {
    id: 9,
    question: 'What is the visual feel?',
    detail:
      'Frosted glass (blur, soft light), neon/glow, or something else. Decides phase 4 priorities. Asked, not yet answered.'
  },
  {
    id: 10,
    question: 'Variable expressions',
    detail:
      'How much of an expression language before scripting arrives in phase 9?',
    proposed: 'Only map-range, clamp, and mix in phase 2.'
  }
];

function getOpenQuestions() {
  return openQuestions.map(question => ({ ...question }));
}

module.exports = { getOpenQuestions };


---

# spec/dag.spec

spec:
  meta:
    name: dag
    version: 0.1.0
    uuid: dag-v1
    template: genesis
    purpose: >
      Implements the full dependency graph and core structural files for Looking Glass.
  axioms:
    AX-001: "The project DAG and its modules must maintain strict structural integrity."
  modules:
    - id: dag_module
      description: "Core structural modules for Looking Glass."
      path: crates/lg-core/src/element.rs
      exports:
        - "create_element(name: &str) → String"
      behavioral_contracts:
        - "Given an element name, create_element returns a string representation."
      error_paths:
        - "Empty name → returns default element."
  schemas:
    - id: Element
      fields:
        type: string
        id: string
  tests:
    - "create_element successfully builds an element."


---

# tests/sp4-dag.test.js

const assert = require('node:assert');
const fs = require('node:fs');

// Check that the core DAG files and schema exist and are valid JSON/structure
const schemaPath = 'schemas/element.schema.json';
const rectPath = 'scenes/rect.json';

assert.ok(fs.existsSync(schemaPath), 'schemas/element.schema.json should exist');
assert.ok(fs.existsSync(rectPath), 'scenes/rect.json should exist');

const schemaContent = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
assert.strictEqual(typeof schemaContent, 'object', 'schema should be a valid JSON object');

const rectContent = JSON.parse(fs.readFileSync(rectPath, 'utf8'));
assert.strictEqual(typeof rectContent, 'object', 'rect scene should be a valid JSON object');

console.log('SP4_dag test passed successfully.');

---

# apps/lg-shell/src/main.rs

//! Looking Glass shell — main application entry point.

fn main() {
    println!("Looking Glass shell");
}


---

# crates/lg-render/src/rect.rs

//! Rectangle rendering logic for Looking Glass.

/// Renders a rectangle of the given width and height as a string description.
pub fn render_rect(w: u32, h: u32) -> String {
    format!("rect {}x{}", w, h)
}


---

# crates/lg-core/src/schema.rs

pub fn validate_schema(input: &str) -> bool {
    let input = input.trim();

    if input.is_empty() {
        return false;
    }

    let bytes = input.as_bytes();
    if bytes.first() != Some(&b'{') || bytes.last() != Some(&b'}') {
        return false;
    }

    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;

    for &byte in bytes {
        if in_string {
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if byte == b'"' {
                in_string = false;
            }
            continue;
        }

        match byte {
            b'"' => in_string = true,
            b'{' => depth += 1,
            b'}' => {
                if depth == 0 {
                    return false;
                }
                depth -= 1;
                if depth == 0 && byte != *bytes.last().unwrap() {
                    return false;
                }
            }
            _ => {}
        }
    }

    !in_string && !escaped && depth == 0
}


---

# crates/lg-core/src/element.rs

pub struct Element {
    name: String,
}

impl Element {
    pub fn create_element(name: &str) -> String {
        format!("Element: {}", name)
    }
}


---

# spec/schema.spec

spec:
  meta:
    name: schema
    version: 0.1.0
    uuid: schema-v1
    template: genesis
    purpose: >
      Implements core schema validation structures in Rust.
  modules:
    - id: schema
      description: "Implements core schema validation structures in Rust."
      path: crates/lg-core/src/schema.rs
      exports:
        - "validate_schema(input: &str) → bool"
      behavioral_contracts:
        - "Given a valid schema input string, validate_schema returns true."
        - "Given an invalid schema input string, validate_schema returns false."


---

# scenes/rect.json

{
  "position": {
    "x": 0,
    "y": 0
  },
  "dimensions": {
    "width": 100,
    "height": 50
  }
}


---

# schemas/element.schema.json

{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Element Schema",
  "description": "Defines the JSON schema for elements in Looking Glass.",
  "type": "object",
  "properties": {
    "id": {
      "type": "string",
      "description": "Unique identifier for the element."
    },
    "type": {
      "type": "string",
      "description": "Type of the element (e.g., 'button', 'text', 'container')."
    },
    "label": {
      "type": "string",
      "description": "Label or text associated with the element."
    },
    "position": {
      "type": "object",
      "properties": {
        "x": {
          "type": "number",
          "description": "X coordinate of the element."
        },
        "y": {
          "type": "number",
          "description": "Y coordinate of the element."
        }
      },
      "required": ["x", "y"]
    },
    "size": {
      "type": "object",
      "properties": {
        "width": {
          "type": "number",
          "description": "Width of the element."
        },
        "height": {
          "type": "number",
          "description": "Height of the element."
        }
      },
      "required": ["width", "height"]
    },
    "children": {
      "type": "array",
      "items": {
        "$ref": "#"
      },
      "description": "Array of child elements."
    },
    "style": {
      "type": "object",
      "properties": {
        "backgroundColor": {
          "type": "string",
          "description": "Background color of the element."
        },
        "fontColor": {
          "type": "string",
          "description": "Font color of the element."
        },
        "fontSize": {
          "type": "number",
          "description": "Font size of the element."
        }
      },
      "description": "Style properties of the element."
    }
  },
  "required": ["id", "type", "label", "position", "size"]
}


---

# .nexus/proof-runs/2026-10-19T09-30-56-271Z.json

{
  "module": "nexus-idearium-repo-proof-run-v1-0000-2026-1002-jamesbrooks-001",
  "subject": "looking-glass-bundle-v0.4 — SP5 · title",
  "startedAt": 1792402256271,
  "finishedAt": 1792402256273,
  "verdict": "ready",
  "met": 1,
  "total": 1,
  "conditionErrors": [],
  "app": null,
  "results": [
    {
      "id": "a-test-that-proves-title-as-the-spec-sta",
      "says": "A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1. — lib/title.js is there",
      "kind": "file",
      "met": true,
      "evidence": "lib/title.js exists.",
      "ms": 0
    }
  ],
  "shadow": {
    "id": "728308b1-8263-4256-9348-43fafb071199",
    "absent": {
      "files": [],
      "events": [],
      "fields": []
    },
    "gaps": []
  },
  "modes": {},
  "files": {
    "report": "proof/PROOF-REPORT.md",
    "run": ".nexus/proof-runs/2026-10-19T09-30-56-271Z.json"
  }
}

---

# lib/title.js

export function title(input) {
  if (typeof input !== "string") {
    throw new Error("Input must be a string");
  }
  return input.trim();
}


---

# tests/sp5-title.test.js

import assert from 'node:assert';
import { title } from '../lib/title.js';

assert.strictEqual(typeof title, 'function', 'title should be a function');
assert.strictEqual(title('  Looking Glass  '), 'Looking Glass');
assert.strictEqual(title('Project Title'), 'Project Title');

assert.throws(() => {
  title(null);
}, /Input must be a string/);

console.log('SP5 title test passed.');


---

# Gemini said tests/sp5-title.test.js

import assert from 'node:assert';
import { title } from '../lib/title.js';

assert.strictEqual(typeof title, 'function', 'title should be a function');
assert.strictEqual(title('  Looking Glass  '), 'Looking Glass');
assert.strictEqual(title('Project Title'), 'Project Title');

assert.throws(() => {
  title(null);
}, /Input must be a string/);

console.log('SP5 title test passed.');
