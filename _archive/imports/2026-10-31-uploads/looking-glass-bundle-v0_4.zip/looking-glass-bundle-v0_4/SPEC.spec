---
# Looking Glass: Working Spec (YAML form of SPEC.md, with the project DAG in the dag section)
format: yaml
title: Looking Glass
version: "0.3"
status: draft
stage: concept stage, nothing built yet
build_plan: PHASEMAP.md
origin:
  source: design conversation
  date: 2026-10-13
  goal: >-
    Invent an alternative to Electron that is its own thing, not a copy of
    Tauri/Wails. It is a UI renderer and app host, nothing more, and it depends
    on nothing outside itself.

legend:
  DECIDED: you said it or agreed to it directly.
  PROPOSED: a suggestion from the conversation that you have not confirmed.
  OPEN: unresolved question.

what_this_is:
  summary: >-
    An app platform, closer to a tiny OS layer for desktop apps than to an
    Electron clone. It is a UI renderer ("HTML, but not HTML") that draws its
    own pixels on the GPU and hosts apps live, with shared styling/preferences
    across all of them.
  goals:
    status: DECIDED
    items:
      - Not Chromium-based.
      - "Not static: apps are loaded live by a host, not frozen into packages with their own copy of everything."
      - Good, shared styling and preferences (theme, fonts, accent, density) that every app inherits.
      - "Cross-app: apps can share state, messaging, and embedding."
      - Borderless, dynamically scaling windows with GPU-accelerated rendering.
      - "No markup language. UI is data, not tags in a file."
      - RAM savings are not the main motivation.
      - "Self-contained: a UI renderer and app host. It needs no external platform or service to run."
      - "Beautiful, animated, alive, dynamic: motion and visual quality are core, and behavior is driven by events and variables."
  non_goals:
    when: for now
    items:
      - Matching the web's feature set.
      - Building the editor, scripting runtime, or multi-language support before the first slice works.

core_ideas:
  ui_is_typed_data:
    id: "2.1"
    status: DECIDED direction, PROPOSED details
    description: >-
      There is no markup source of truth. Every element (button, text,
      rectangle, slider, toast, close button) is defined once by a schema:
      props, states, events, slots. The UI itself is a tree of schema
      instances, which is what an editor manipulates.
    properties:
      - "Deterministic: same data in, same pixels out."
      - Any element can be placed at any layer or depth.
      - Images and HTML are just more element types (HTML would be an optional embed element, later).
      - Schemas are the "deterministic reusable factors" (buttons etc.).

  layers_are_a_runtime_operation:
    id: "2.2"
    status: DECIDED
    rules:
      - The surface starts as one layer. You can add layers dynamically.
      - Adding a layer is an action like any other (an element action).
      - Every layer has a depth coordinate, bounds, and a lifecycle policy.
      - Elements can move between layers by re-parenting in the tree.
      - When a layer empties, it is removed; the system returns to one layer.
      - >-
        The engine must not hard-code layer names. "Meta", "interaction", etc.
        are conventions (tags), not special types. The engine only knows
        depth, bounds, and permissions.
    mental_model:
      status: DECIDED
      text: >-
        A sticker on glass. Each layer is a transparent surface with its own
        owner. Lower layers are plumbing; higher layers are closer to the
        human. The top layer is the meta layer.
    suggested_convention_stack:
      status: PROPOSED
      order: bottom to top
      layers:
        - name: Plumbing
          contains: OS surface, borderless window, input, GPU context.
        - name: Renderer
          contains: scene graph, vector shapes, text, scaling.
        - name: Runtime
          contains: scripting, state, messaging between apps.
        - name: App content
          contains: the actual elements.
        - name: Interaction
          contains: input routing, focus, gestures, command palette.
        - name: Meta
          contains: theming, preferences, cross-app control, inspection.

  isolation_through_event_bus:
    id: "2.3"
    status: DECIDED
    name: interaction contract
    description: >-
      Layers are isolated and talk only through typed messages on an event bus
      (the "interaction contract"). A layer declares what it emits and
      accepts; anything that honors the contract can be stacked on. This is
      what keeps the UI from being hard-coded.
    interaction_primitive:
      status: PROPOSED
      shape: element + target + action
      examples:
        - element: Close button
          behavior: target = own app, action = close.
        - element: Toast
          behavior: spawns an element on a higher layer.
        - element: Pop-up
          behavior: spawns an element one layer above the caller.

  rendering_and_performance:
    id: "2.4"
    status: DECIDED direction, PROPOSED mechanics
    points:
      - GPU-accelerated, resolution-independent vector drawing, so scaling is free.
      - Each layer renders into its own GPU texture; a compositor blends them.
      - >-
        CPU/GPU "ping-pong" = double or triple buffering: a layer draws into a
        back buffer while the compositor reads the front one, then they swap.
      - Threads per layer (or processes, see open_questions).
    memory_control:
      status: DECIDED idea (layers dynamically scale and switch off when not needed)
      points:
        - Textures are sized to the layer's bounds, not full screen.
        - Transparent (not black) means "nothing here" and costs nothing.
        - Occlusion culling: skip rendering beneath fully opaque regions.
        - >-
          Unloading is cheap because layer state is typed data, not pixels;
          the texture is a throwaway cache.
      layer_lifecycle:
        - state: active
          meaning: redrawing
        - state: idle
          meaning: keeps texture, thread sleeps, last frame reused
        - state: unloaded
          meaning: texture freed, only the data tree remains
      layer_policies:
        - always-warm
        - sleep-when-idle
        - unload-when-empty

  any_language_per_layer:
    id: "2.5"
    status: PROPOSED, later
    description: >-
      Because layers only see messages, the language behind a layer does not
      matter. Preferred route: WASM modules (sandboxed, cheap to load/unload).
      Alternative: a process per layer. Keep high-frequency rendering in the
      native core; foreign layers send small, infrequent messages. Do not
      build this until the bus contract is clean.

  variables_bindings_and_motion:
    id: "2.6"
    status: DECIDED goals, PROPOSED mechanics
    variables_are_first_class: >-
      A named, typed value store. Any element prop is a literal or a variable
      reference. Events write variables, animations drive variables, signal
      providers feed variables, and the renderer reads them every frame.
      "Event and variable driven" is the data model, not a feature.
    motion_is_data: >-
      Springs, tweens, easing, timelines, and staggers are declared on
      elements or variables with no animation code. They are interruptible, so
      the UI never feels stuck mid-transition. A frame clock paces frames to
      the display's refresh rate.
    alive: >-
      A time variable and ambient motion (slow breathing, noise drift, light
      that follows the cursor), each with an intensity setting that can be
      turned fully off.
    beauty_on_the_gpu: >-
      Shapes drawn as signed distance fields (crisp at any scale, soft
      shadows, glows), gradients in a perceptual color space, frosted-glass
      blur of whatever sits under a layer (fits the name and layers-as-glass),
      and a custom-shader element. Styling uses shared design tokens (color,
      radius, spacing, motion curves).
    motion_budget: >-
      Continuous motion fights the idle/unload lifecycle (2.4), so a layer
      renders frames only while something animates, ambient motion has an
      intensity cap, and load or power state can turn it down.
    visual_feel: >-
      The overall visual feel (frosted glass, neon/glow, other) is still
      undecided; see open question 9.

  signal_providers:
    id: "2.7"
    status: PROPOSED
    description: >-
      A provider is anything that feeds variables: clock, mouse and keyboard,
      system metrics, file watchers, sockets, HTTP/SSE streams, or a plugin.
      Providers sit behind one trait, so the UI can react to any live source
      without the core knowing what it is.
    example: >-
      A live system monitor drawn as spring-smoothed bars from CPU, memory,
      and network variables.

prior_art:
  note: Not dependencies, just what exists so Looking Glass can differ on purpose.
  items:
    - category: Electron alternatives that still use a webview or Chromium
      examples: [Tauri (system webview + Rust), Wails (Go), Electrobun (Bun), Neutralino]
      note: Looking Glass is not based on a browser engine.
    - category: Non-browser UI toolkits
      examples: [Flutter, Slint, Lynx, Dioxus Blitz]
      note: They draw their own pixels but have no shared host, no layered runtime composition, and no cross-app preference layer.
    - category: Rendering pieces to learn from
      examples: [wgpu, Skia, Vello (GPU vector drawing)]
    - category: Compositor design to learn from
      examples: [Wayland, macOS, Windows DWM]
      note: Each surface renders to its own texture; a compositor blends them.
  differentiators:
    - The layered runtime (layers added and removed live)
    - UI as typed data with variables
    - Motion as data
    - The shared host with cross-app preferences
    - Layers in any language

smallest_slice:
  approach: DECIDED, start with the smallest unit and build up
  smallest_unit: one borderless window that draws one rectangle from a data struct. No layers, no bus, nothing else.
  build_order:
    detail: PHASEMAP.md
    phases:
      - { phase: 0, name: foundations }
      - { phase: 1, name: window + one rectangle from data }
      - { phase: 2, name: text and button, plus variables and bindings }
      - { phase: 3, name: layers as a runtime operation (spawn a toast) }
      - { phase: 4, name: motion and visual effects }
      - { phase: 5, name: event bus }
      - { phase: 6, name: lifecycle and motion budget }
      - { phase: 7, name: signal providers }
      - { phase: 8, name: host/app model and shared preferences }
      - { phase: 9, name: scripting/WASM }
      - { phase: 10, name: snapshot, replay, governor }
      - { phase: 11, name: editor }
      - { phase: 12, name: packaging }
  first_real_target:
    status: PROPOSED
    name: live system monitor
    description: >-
      CPU, memory, and network bars, spring-smoothed, driven by variables from
      a system-metrics provider, with a toast on a spike. It exercises schema,
      variables, motion, layers, and live data with no external service.
  executable_goal:
    status: DECIDED
    description: >-
      It must compile into a single application (exe). Rust, Zig, or C++ fit
      best because they produce a single native binary with static linking and
      no runtime to install.

open_questions:
  - id: 1
    question: Threads or processes per layer?
    detail: Threads are faster with shared memory; processes isolate better but add messaging latency.
    assigned_to: phase 6 (measure)
  - id: 2
    question: What does "PID management" mean here?
    detail: Managing processes and threads, a PID controller (feedback loop that tunes resources automatically), or both?
    assigned_to: phases 0 and 10
  - id: 3
    question: Layer permissions
    detail: >-
      What can a layer read or change in the others? Should the meta layer
      rewrite what is below it live (devtools for everything), or only observe
      and route? Does an element's power change with its depth, or only its
      reach?
    assigned_to: phase 9
  - id: 4
    question: Wake latency policy
    detail: Which layers stay warm (e.g. toasts) versus unload when empty?
    assigned_to: phase 6
  - id: 5
    question: Name for the project.
    resolved: true
    resolution: Looking Glass
  - id: 6
    question: Does the UI editor come before or after scripting?
    detail: Currently placed last (phase 11).
  - id: 7
    question: "Feedback loop: how should layer lifecycle respond to load?"
    detail: A local governor (phase 10) fed by generic signals such as frame time, memory, and CPU.
  - id: 8
    question: Replay format
    detail: Looking Glass's own snapshot/replay format; details at phase 10.
  - id: 9
    question: What is the visual feel?
    detail: Frosted glass (blur, soft light), neon/glow, or something else. Decides phase 4 priorities. Asked, not yet answered.
  - id: 10
    question: Variable expressions
    detail: How much of an expression language before scripting arrives in phase 9?
    proposed: Only map-range, clamp, and mix in phase 2.

risks:
  - name: Scope
    detail: >-
      Renderer, compositor, scripting runtime, and editor are each large. The
      mitigation is the rule above: add a piece only when the previous one
      works.
  - name: Designing in the abstract
    detail: >-
      Designing with no target tends to fold back on itself (self-hosting
      editor editing itself). Keep a concrete target (the system-map panel) in
      view.
  - name: Memory cost of many full-size layers
    detail: Handled by bounds-sized textures and the lifecycle policy.
  - name: Beauty vs idle
    detail: >-
      Continuous animation fights the idle/unload lifecycle; handled by the
      motion budget (2.6).

bundle_contents:
  - SPEC.md (this file)
  - PHASEMAP.md (phased build plan)
  - README.md

# =====================================================================
# DAG: full dependency graph for the whole project (main track, Track E,
# decisions, milestones). Generated from PHASEMAP.md, EDITOR.md and SPEC.md.
# =====================================================================
dag:
  version: "1.0"
  sources: [SPEC.md, PHASEMAP.md, EDITOR.md]
  rule: >-
    No node starts until every node in its depends_on has finished. A phase's
    exit node (kind gate) carries the phase's exit test, and the next phase's
    first tasks depend on that exit node. This encodes the PHASEMAP.md rule
    that a phase must pass its exit test before the next one starts.
  conventions:
    id: group.name, where group is p0..p12 (main phases), e0..e7 (editor Track E), d (decision), m (milestone)
    kinds:
      task: a unit of work taken from a phase's Do list or an editor step
      gate: the exit test of a phase or editor step
      decision: an open question, shown as a node so work can depend on it
      milestone: a named point in the project that depends on gates
    edges:
      depends_on: hard edge; the node cannot start until these finish
      soft_depends_on: informs the node but does not block it (typically an unanswered decision or a lower-priority input)
    flags:
      optional: not required by its gate; listed because the source documents propose it
      status: proposed_amendment (A1/A2 in EDITOR.md, not applied to PHASEMAP.md), on_hold, open, assigned
    sizes: PHASEMAP.md gives relative effort (S, M, L) per phase only, not per task and not time
  stats:
    nodes: 197
    by_kind: {task: 154, gate: 20, decision: 14, milestone: 9}
    hard_edges: 315
    soft_edges: 17
    waves: 41
    longest_chain_nodes: 41
    acyclic: true
  groups:
    - id: p0
      name: "Foundations and decisions"
      track: main
      size: S
      declared_depends_on: []
      derived_extra_depends_on: []
    - id: p1
      name: "Window + one rectangle from data"
      track: main
      size: S
      declared_depends_on: [p0]
      derived_extra_depends_on: []
    - id: p2
      name: "Elements, layout, variables and bindings"
      track: main
      size: M
      declared_depends_on: [p1]
      derived_extra_depends_on: []
    - id: p3
      name: "Layers as a runtime operation"
      track: main
      size: M
      declared_depends_on: [p2]
      derived_extra_depends_on: []
    - id: p4
      name: "Motion and visual effects"
      track: main
      size: L
      declared_depends_on: [p2, p3]
      derived_extra_depends_on: []
    - id: p5
      name: "Event bus / interaction contract"
      track: main
      size: M
      declared_depends_on: [p2, p3]
      derived_extra_depends_on: []
    - id: p6
      name: "Lifecycle, performance, motion budget"
      track: main
      size: L
      declared_depends_on: [p3, p4, p5]
      derived_extra_depends_on: []
    - id: p7
      name: "Signal providers + live demo"
      track: main
      size: M
      declared_depends_on: [p2, p5]
      derived_extra_depends_on: [p3, p4]
    - id: p8
      name: "Host, app model, preferences, cross-app"
      track: main
      size: M
      declared_depends_on: [p3, p5]
      derived_extra_depends_on: []
    - id: p9
      name: "Scripting, permissions, multi-language"
      track: main
      size: L
      declared_depends_on: [p5, p8]
      derived_extra_depends_on: [p3]
    - id: p10
      name: "Snapshot, replay, governor"
      track: main
      size: L
      declared_depends_on: [p6, p7]
      derived_extra_depends_on: []
    - id: p11
      name: "Self-hosted UI editor (= Track E step E5)"
      track: main
      size: L
      declared_depends_on: [p8, p9, e1, e2, e3, e4]
      derived_extra_depends_on: [e0, p6, p7]
    - id: p12
      name: "Packaging and distribution"
      track: main
      size: M
      declared_depends_on: [p8]
      derived_extra_depends_on: []
    - id: e0
      name: "Editor core: document, ops, transactions, undo, validation, CLI"
      track: editor
      declared_depends_on: [p2]
      derived_extra_depends_on: []
    - id: e1
      name: "Layer ops and inspector descriptors"
      track: editor
      declared_depends_on: [p3]
      derived_extra_depends_on: [e0]
    - id: e2
      name: "Style rules, motion defs, tokens, particle emitter schema"
      track: editor
      declared_depends_on: [p4]
      derived_extra_depends_on: [e0, e1]
    - id: e3
      name: "Wiring ops with contract validation"
      track: editor
      declared_depends_on: [p5]
      derived_extra_depends_on: [e0]
    - id: e4
      name: "Deterministic code generation (lg-gen)"
      track: editor
      declared_depends_on: [e0]
      derived_extra_depends_on: []
    - id: e6
      name: "Additional targets (emitter packs), on hold"
      track: editor
      declared_depends_on: [e4]
      derived_extra_depends_on: []
      status: on_hold
    - id: e7
      name: "Enterprise layer"
      track: editor
      declared_depends_on: [p11, p10]
      derived_extra_depends_on: [e4, p9]
  nodes:
    - id: d.oq2
      name: "OQ2: what does PID management mean (process/thread management, a PID controller, or both)"
      kind: decision
      depends_on: [p0.decide_oq1_oq2]
      status: open
      spec_ref: "5.2"
      note: "Decided or deferred in phase 0; consumed by the governor in phase 10."
    - id: d.oq3
      name: "OQ3 / E-OQ3: layer permissions (what a layer may read or change in others; meta layer rewrites live or only observes)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ3]
      spec_ref: "5.3"
      note: "Assigned to phase 9. The editor cannot fully exist without it."
    - id: d.oq9
      name: "OQ9 / E-OQ6: visual feel (frosted glass, neon/glow, other)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ6]
      spec_ref: "5.9"
      note: "Asked, not yet answered. Decides phase 4 priorities, default tokens, particle presets, and the editor's own look."
    - id: d.oq10
      name: "OQ10 / E-OQ7: variable expression set (map-range, clamp, mix only; plus gt, lt, eq, between, within_ms for style rules)"
      kind: decision
      depends_on: []
      status: open
      aliases: [E-OQ7]
      spec_ref: "5.10"
      note: "Proposed: add comparisons and event recency to phase 2, still no general scripting."
    - id: d.oq6
      name: "OQ6: does the UI editor come before or after scripting"
      kind: decision
      depends_on: []
      status: assigned
      spec_ref: "5.6"
      note: "Currently placed last (phase 11)."
    - id: d.e_oq1
      name: "E-OQ1: what 'agnostic' means for editor output (scene JSON only, web exporters, native toolkits)"
      kind: decision
      depends_on: []
      status: on_hold
      note: "On hold at the user's request. Only lg-export waits on this."
    - id: d.e_oq2
      name: "E-OQ2: editor before the renderer? (proposed: headless core early, no temporary web shell)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq4
      name: "E-OQ4: is the code view editable (proposed: yes, with read-back and drift handling)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq5
      name: "E-OQ5: collaboration (proposed: single user first; base_rev leaves room for merge)"
      kind: decision
      depends_on: []
      status: open
    - id: d.e_oq8
      name: "E-OQ8: editor name (working name: Looking Glass Editor)"
      kind: decision
      depends_on: []
      status: open
    - id: d.oq1
      name: "OQ1: threads or processes per layer"
      kind: decision
      depends_on: [p6.measure_threads_vs_processes]
      status: assigned
      spec_ref: "5.1"
      note: "Resolved by measurement in phase 6."
    - id: d.oq4
      name: "OQ4: wake latency policy (which layers stay warm vs unload when empty)"
      kind: decision
      depends_on: [p6.measure_wake_latency]
      status: assigned
      spec_ref: "5.4"
      note: "Resolved by measurement in phase 6."
    - id: d.oq7
      name: "OQ7: feedback loop (how layer lifecycle responds to load: a local governor fed by generic signals)"
      kind: decision
      depends_on: [p10.governor_controller]
      status: assigned
      spec_ref: "5.7"
    - id: d.oq8
      name: "OQ8: replay format (Looking Glass's own snapshot/replay format)"
      kind: decision
      depends_on: [p6.exit]
      status: assigned
      spec_ref: "5.8"
      note: "Format details settled at the start of phase 10."
    - id: p0.workspace
      name: "Create the Cargo workspace and an empty lg-shell that builds to one exe"
      kind: task
      depends_on: []
      files: [Cargo.toml, "apps/lg-shell/src/main.rs"]
    - id: p0.decide_stack
      name: "Settle language (Rust), data format (JSON first), platform (Windows first)"
      kind: task
      depends_on: []
      files: ["docs/decisions.md"]
    - id: p0.decide_oq1_oq2
      name: "Decide OQ1 and OQ2, or defer them to phases 6 and 10"
      kind: task
      depends_on: [p0.decide_stack]
    - id: p0.exit
      name: "Phase 0 exit test"
      kind: gate
      depends_on: [p0.workspace, p0.decide_oq1_oq2]
      exit_test: "cargo build --release yields one exe that starts and exits cleanly."
    - id: p1.element_struct
      name: "Element data struct for a rectangle"
      kind: task
      depends_on: [p0.exit]
      files: ["crates/lg-core/src/element.rs"]
    - id: p1.window
      name: "Borderless window via winit with own drag/resize hit-testing and HiDPI scale"
      kind: task
      depends_on: [p0.exit]
      files: ["apps/lg-shell/src/main.rs"]
    - id: p1.gpu_context
      name: "wgpu GPU context bound to the window"
      kind: task
      depends_on: [p1.window]
    - id: p1.scene_loader
      name: "Load the rectangle from scenes/rect.json"
      kind: task
      depends_on: [p1.element_struct]
      files: ["scenes/rect.json"]
    - id: p1.rect_renderer
      name: "Draw one rectangle from data on the GPU"
      kind: task
      depends_on: [p1.gpu_context, p1.scene_loader]
      files: ["crates/lg-render/src/rect.rs"]
    - id: p1.exit
      name: "Phase 1 exit test"
      kind: gate
      depends_on: [p1.rect_renderer, p1.window]
      exit_test: "Editing the JSON and restarting changes the rectangle; resizing keeps it sharp and correctly scaled."
    - id: p2.schema
      name: "Element schema: props, states, events, slots"
      kind: task
      depends_on: [p1.exit]
      spec_ref: "2.1"
      files: ["schemas/element.schema.json", "crates/lg-core/src/schema.rs"]
    - id: p2.tree
      name: "Scene tree of schema instances"
      kind: task
      depends_on: [p2.schema]
      spec_ref: "2.1"
      files: ["crates/lg-core/src/tree.rs"]
    - id: p2.vars
      name: "Variable store: named, typed values"
      kind: task
      depends_on: [p1.exit]
      spec_ref: "2.6"
      files: ["crates/lg-vars/src/lib.rs"]
    - id: p2.bindings
      name: "Props as literal or variable reference; events write variables"
      kind: task
      depends_on: [p2.vars, p2.tree]
      spec_ref: "2.6"
    - id: p2.expr
      name: "Tiny expression set: map-range, clamp, mix"
      kind: task
      depends_on: [p2.vars]
      soft_depends_on: [d.oq10]
      spec_ref: "2.6"
    - id: p2.layout
      name: "Small flexbox-like layout"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-layout/src/lib.rs"]
    - id: p2.text
      name: "Text rendering (cosmic-text or glyphon)"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-render/src/text.rs"]
    - id: p2.shapes
      name: "Shape rendering for rectangle and button"
      kind: task
      depends_on: [p2.tree]
      files: ["crates/lg-render/src/shapes.rs"]
    - id: p2.hit_test
      name: "Hit testing"
      kind: task
      depends_on: [p2.layout]
    - id: p2.button
      name: "Button element with states; click writes a variable"
      kind: task
      depends_on: [p2.hit_test, p2.bindings, p2.shapes, p2.text]
      files: ["scenes/button.json"]
    - id: p2.hot_reload
      name: "Hot reload of scenes/*.json (notify)"
      kind: task
      depends_on: [p2.tree, p2.bindings]
    - id: p2.styles_schema
      name: "Amendment A2: add styles and comparison conditions to element.schema.json"
      kind: task
      depends_on: [p2.schema]
      soft_depends_on: [d.oq10]
      optional: true
      status: proposed_amendment
      note: "PROPOSED in EDITOR.md, not applied to PHASEMAP.md."
    - id: p2.exit
      name: "Phase 2 exit test"
      kind: gate
      depends_on: [p2.button, p2.expr, p2.text, p2.hot_reload]
      exit_test: "A button writes a variable on click and a text element bound to it updates; editing button.json live updates the window."
    - id: p3.layer_model
      name: "Layer model: id, tags, depth, bounds, lifecycle policy, owner (names are conventions only)"
      kind: task
      depends_on: [p2.exit]
      spec_ref: "2.2"
      files: ["schemas/layer.schema.json", "crates/lg-core/src/layer.rs"]
    - id: p3.layer_ops
      name: "Operations layer.add, layer.remove, element.move (re-parent)"
      kind: task
      depends_on: [p3.layer_model]
      spec_ref: "2.2"
    - id: p3.layer_texture
      name: "Per-layer GPU texture sized to the layer's bounds"
      kind: task
      depends_on: [p3.layer_model]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/texture.rs"]
    - id: p3.compositor
      name: "Compositor blends layers by depth"
      kind: task
      depends_on: [p3.layer_texture]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/compositor.rs"]
    - id: p3.auto_remove
      name: "Remove empty layers and return to one layer"
      kind: task
      depends_on: [p3.layer_ops]
      spec_ref: "2.2"
    - id: p3.toast
      name: "Toast spawned on a second layer by a button"
      kind: task
      depends_on: [p3.layer_ops, p3.compositor]
      files: ["scenes/toast.json"]
    - id: p3.exit
      name: "Phase 3 exit test"
      kind: gate
      depends_on: [p3.toast, p3.auto_remove]
      exit_test: "A button spawns a toast on a second layer; dismissing removes the layer; no layer names are hard-coded in the engine."
    - id: p4.frame_clock
      name: "Frame clock with pacing matched to the display's refresh rate"
      kind: task
      depends_on: [p3.exit]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/clock.rs"]
    - id: p4.springs_tweens
      name: "Springs, tweens, and easing as data"
      kind: task
      depends_on: [p4.frame_clock]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/spring.rs", "crates/lg-motion/src/tween.rs"]
    - id: p4.timelines
      name: "Timelines and staggers"
      kind: task
      depends_on: [p4.springs_tweens]
      spec_ref: "2.6"
      files: ["crates/lg-motion/src/timeline.rs"]
    - id: p4.interruptible
      name: "Interruptible motion: retarget from current position and velocity"
      kind: task
      depends_on: [p4.springs_tweens]
      spec_ref: "2.6"
    - id: p4.time_variable
      name: "Time variable"
      kind: task
      depends_on: [p4.frame_clock]
      spec_ref: "2.6"
    - id: p4.ambient
      name: "Ambient motion: breathing, noise drift, light following the cursor"
      kind: task
      depends_on: [p4.time_variable, p4.interruptible]
      spec_ref: "2.6"
    - id: p4.intensity_controls
      name: "Intensity setting per ambient effect; 0 is fully off (exposed from the start)"
      kind: task
      depends_on: [p4.ambient]
      spec_ref: "2.6"
    - id: p4.sdf
      name: "SDF rounded shapes"
      kind: task
      depends_on: [p3.exit]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/sdf.rs"]
    - id: p4.shadow_glow
      name: "Soft shadows and glows"
      kind: task
      depends_on: [p4.sdf]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/shadow.rs"]
    - id: p4.gradient
      name: "Gradients in a perceptual color space"
      kind: task
      depends_on: [p4.sdf]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/gradient.rs"]
    - id: p4.blur
      name: "Frosted-glass blur of whatever sits under a layer"
      kind: task
      depends_on: [p4.shadow_glow, p4.gradient, p3.compositor]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/blur.rs"]
      note: "Built after SDF, shadow, and gradient. Needs the phase 3 compositor."
    - id: p4.shader_element
      name: "Custom-shader element"
      kind: task
      depends_on: [p4.sdf]
      spec_ref: "2.6"
      files: ["crates/lg-render/src/shader_element.rs"]
    - id: p4.design_tokens
      name: "Design tokens: color, radius, spacing, motion curves"
      kind: task
      depends_on: [p4.gradient, p4.springs_tweens]
      soft_depends_on: [d.oq9]
      spec_ref: "2.6"
    - id: p4.particles
      name: "Amendment A1: particle simulation (GPU with CPU fallback), seeded, intensity 0 emits nothing"
      kind: task
      depends_on: [p4.sdf, p4.frame_clock, p4.intensity_controls]
      optional: true
      status: proposed_amendment
      files: ["crates/lg-render/src/particles.rs", "crates/lg-motion/src/emitter.rs"]
      note: "PROPOSED in EDITOR.md, not applied to PHASEMAP.md. Extends the phase 4 exit test."
    - id: p4.exit
      name: "Phase 4 exit test"
      kind: gate
      depends_on: [p4.timelines, p4.interruptible, p4.ambient, p4.intensity_controls, p4.blur, p4.shader_element, p4.design_tokens]
      exit_test: "A button, a toast, and a panel animate smoothly at display refresh rate; interrupting never snaps or stalls; ambient motion can be turned fully off."
    - id: p5.event_types
      name: "Typed events named {layer}:{noun}:{verb}"
      kind: task
      depends_on: [p3.exit]
      spec_ref: "2.3"
      files: ["schemas/event.schema.json", "crates/lg-bus/src/event.rs"]
    - id: p5.event_gates
      name: "One gate per event type; collisions are errors"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
      files: ["crates/lg-bus/src/gate.rs"]
    - id: p5.observers
      name: "Read-only observers"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
      files: ["crates/lg-bus/src/stream.rs"]
    - id: p5.ring_buffer
      name: "Ring buffer with sequence numbers"
      kind: task
      depends_on: [p5.event_types]
      spec_ref: "2.3"
    - id: p5.contracts
      name: "Layer contracts: declare what is emitted and accepted; bus rejects violations"
      kind: task
      depends_on: [p5.event_gates]
      spec_ref: "2.3"
      files: ["schemas/contract.schema.json", "crates/lg-bus/src/contract.rs"]
    - id: p5.interaction_primitive
      name: "element + target + action (close, toast, pop-up) through the bus only"
      kind: task
      depends_on: [p5.contracts, p5.observers]
      spec_ref: "2.3"
    - id: p5.violation_log
      name: "Reject and log undeclared events"
      kind: task
      depends_on: [p5.contracts, p5.ring_buffer]
    - id: p5.exit
      name: "Phase 5 exit test"
      kind: gate
      depends_on: [p5.interaction_primitive, p5.violation_log]
      exit_test: "Close, toast, and pop-up work through the bus only; a layer sending an undeclared event is rejected and logged."
    - id: p6.lifecycle
      name: "Layer lifecycle states: active, idle, unloaded"
      kind: task
      depends_on: [p4.exit, p5.exit]
      spec_ref: "2.4"
      files: ["crates/lg-runtime/src/lifecycle.rs"]
    - id: p6.policies
      name: "Per-layer policy: always-warm, sleep-when-idle, unload-when-empty"
      kind: task
      depends_on: [p6.lifecycle]
      spec_ref: "2.4"
    - id: p6.motion_budget
      name: "Motion budget: frames only while animating; ambient intensity cap; load/power state turns it down"
      kind: task
      depends_on: [p6.lifecycle, p4.intensity_controls]
      spec_ref: "2.6"
      files: ["crates/lg-runtime/src/budget.rs"]
    - id: p6.dirty_regions
      name: "Dirty regions"
      kind: task
      depends_on: [p3.exit]
      files: ["crates/lg-render/src/dirty.rs"]
    - id: p6.occlusion_culling
      name: "Occlusion culling beneath fully opaque regions"
      kind: task
      depends_on: [p6.dirty_regions]
      spec_ref: "2.4"
      files: ["crates/lg-render/src/cull.rs"]
    - id: p6.transparent_free
      name: "Transparent means nothing here and costs nothing"
      kind: task
      depends_on: [p6.dirty_regions]
      spec_ref: "2.4"
    - id: p6.layer_threads
      name: "Per-layer threads"
      kind: task
      depends_on: [p6.lifecycle]
      spec_ref: "2.4"
    - id: p6.buffering
      name: "Double and triple buffering"
      kind: task
      depends_on: [p6.layer_threads]
      spec_ref: "2.4"
      files: ["crates/lg-runtime/src/buffers.rs"]
    - id: p6.scheduler
      name: Scheduler
      kind: task
      depends_on: [p6.layer_threads, p6.policies]
      files: ["crates/lg-runtime/src/scheduler.rs"]
    - id: p6.stress_demo
      name: "Stress demo with many sparse layers"
      kind: task
      depends_on: [p6.scheduler, p6.buffering]
      files: ["apps/lg-demo/src/stress.rs"]
    - id: p6.measure_threads_vs_processes
      name: "Measure threads vs processes per layer"
      kind: task
      depends_on: [p6.stress_demo]
      resolves: OQ1
    - id: p6.measure_wake_latency
      name: "Measure wake latency per lifecycle policy"
      kind: task
      depends_on: [p6.stress_demo, p6.policies]
      resolves: OQ4
    - id: p6.exit
      name: "Phase 6 exit test"
      kind: gate
      depends_on: [p6.motion_budget, p6.occlusion_culling, p6.transparent_free, d.oq1, d.oq4]
      exit_test: "With many sparse layers an idle layer uses effectively no CPU; an unloaded layer frees its texture; with nothing animating the app idles near zero frames; wake latency is measured per policy."
    - id: p7.provider_trait
      name: "Signal provider trait"
      kind: task
      depends_on: [p5.exit]
      spec_ref: "2.7"
      files: ["schemas/signal.schema.json", "crates/lg-signals/src/provider.rs"]
    - id: p7.provider_time
      name: "Clock provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/time.rs"]
    - id: p7.provider_input
      name: "Mouse and keyboard provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/input.rs"]
    - id: p7.provider_metrics
      name: "System metrics provider (sysinfo)"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/metrics.rs"]
    - id: p7.provider_net
      name: "Socket and HTTP/SSE provider"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
      files: ["crates/lg-signals/src/net.rs"]
    - id: p7.provider_files
      name: "File watcher provider (notify)"
      kind: task
      depends_on: [p7.provider_trait]
      spec_ref: "2.7"
    - id: p7.scene_valid_without_provider
      name: "Removing a provider leaves the scene valid"
      kind: task
      depends_on: [p7.provider_trait]
    - id: p7.monitor_scene
      name: "System monitor scene: spring-smoothed CPU, memory, and network bars bound to variables"
      kind: task
      depends_on: [p7.provider_metrics, p7.provider_net, p4.exit]
      files: ["scenes/monitor.json"]
      note: "Needs phase 4 motion (springs) although the phase map lists phase 7 as depending on 2 and 5 only."
    - id: p7.spike_toast
      name: "Toast on a spike"
      kind: task
      depends_on: [p7.monitor_scene, p3.toast]
    - id: p7.monitor_demo
      name: "Live system monitor demo app"
      kind: task
      depends_on: [p7.monitor_scene, p7.spike_toast]
      files: ["apps/lg-demo/src/monitor.rs"]
    - id: p7.exit
      name: "Phase 7 exit test"
      kind: gate
      depends_on: [p7.monitor_demo, p7.scene_valid_without_provider, p7.provider_time, p7.provider_input, p7.provider_files]
      exit_test: "The monitor updates live from real system data with no network service running; removing a provider leaves the scene valid."
    - id: p8.local_ipc
      name: "Local IPC between host and apps"
      kind: task
      depends_on: [p3.exit, p5.exit]
      files: ["crates/lg-host/src/ipc.rs"]
    - id: p8.app_registry
      name: "App registration; apps declare their contract"
      kind: task
      depends_on: [p8.local_ipc]
      files: ["crates/lg-host/src/registry.rs"]
    - id: p8.live_loading
      name: "Apps load live, not as static packages"
      kind: task
      depends_on: [p8.app_registry]
    - id: p8.session
      name: "Host session model"
      kind: task
      depends_on: [p8.app_registry]
      files: ["crates/lg-host/src/session.rs"]
    - id: p8.prefs_store
      name: "Preferences store in the meta layer: theme, fonts, accent, density, per-app overrides"
      kind: task
      depends_on: [p8.app_registry]
      files: ["schemas/prefs.schema.json", "crates/lg-prefs/src/lib.rs"]
    - id: p8.prefs_as_variables
      name: "Preferences exposed as variables so every app inherits"
      kind: task
      depends_on: [p8.prefs_store]
    - id: p8.shared_state
      name: "Cross-app shared state"
      kind: task
      depends_on: [p8.session]
    - id: p8.cross_app_messaging
      name: "Cross-app messaging over the bus"
      kind: task
      depends_on: [p8.session]
    - id: p8.embedding
      name: "Embed another app's elements"
      kind: task
      depends_on: [p8.cross_app_messaging, p8.shared_state]
    - id: p8.two_apps_demo
      name: "Two separate demo apps in one host"
      kind: task
      depends_on: [p8.embedding, p8.prefs_as_variables, p8.live_loading]
      files: ["apps/lg-demo/src/two_apps.rs"]
    - id: p8.exit
      name: "Phase 8 exit test"
      kind: gate
      depends_on: [p8.two_apps_demo]
      exit_test: "Two separate demo apps run in one host; changing the accent color once updates both; one embeds an element from the other."
    - id: p9.perm_model
      name: "Capability permission model"
      kind: task
      depends_on: [p8.exit, d.oq3]
      resolves: OQ3
      files: ["crates/lg-wasm/src/perms.rs"]
    - id: p9.wasm_host
      name: "WASM layer host (wasmtime)"
      kind: task
      depends_on: [p5.exit, p8.exit]
      spec_ref: "2.5"
      files: ["crates/lg-wasm/src/host.rs"]
    - id: p9.wasm_api
      name: "WASM layer API over the bus"
      kind: task
      depends_on: [p9.wasm_host]
      spec_ref: "2.5"
      files: ["crates/lg-wasm/src/api.rs"]
    - id: p9.wasm_sandbox
      name: "Sandboxed, cheap load and unload; rendering stays in the native core"
      kind: task
      depends_on: [p9.wasm_host]
      soft_depends_on: [p6.exit]
      spec_ref: "2.5"
    - id: p9.embedded_scripting
      name: "Embedded scripting (QuickJS or Lua); expression set may grow here"
      kind: task
      depends_on: [p9.wasm_api]
      optional: true
      note: "Listed as optional in PHASEMAP.md."
    - id: p9.wasm_toast_demo
      name: "WASM toast layer demo"
      kind: task
      depends_on: [p9.wasm_api, p9.perm_model, p3.toast]
      files: ["apps/lg-demo/wasm-toast/"]
    - id: p9.exit
      name: "Phase 9 exit test"
      kind: gate
      depends_on: [p9.wasm_toast_demo, p9.wasm_sandbox]
      exit_test: "A WASM layer draws a toast through the bus; it is denied an action its permissions do not grant."
    - id: p10.snapshot
      name: "Snapshot and restore of a layer's data tree on unload and wake"
      kind: task
      depends_on: [p6.exit, d.oq8]
      files: ["crates/lg-runtime/src/snapshot.rs"]
    - id: p10.event_recorder
      name: "Record the event stream"
      kind: task
      depends_on: [p6.exit, d.oq8]
      files: ["crates/lg-runtime/src/replay.rs"]
    - id: p10.replay
      name: "Deterministic replay"
      kind: task
      depends_on: [p10.event_recorder, p10.snapshot]
      soft_depends_on: [p4.particles]
      note: "Pixel-identical replay of particle scenes relies on seeded emitters (A1)."
    - id: p10.replay_slice
      name: "Replay a bounded slice for debugging"
      kind: task
      depends_on: [p10.replay]
    - id: p10.governor_signals
      name: "Governor inputs: frame time, memory, CPU"
      kind: task
      depends_on: [p6.exit, p7.exit]
    - id: p10.governor_controller
      name: "Governor: simple feedback controller"
      kind: task
      depends_on: [p10.governor_signals, d.oq2]
      files: ["crates/lg-runtime/src/governor.rs"]
    - id: p10.governor_actions
      name: "Throttle or unload layers and trim ambient motion"
      kind: task
      depends_on: [p10.governor_controller, p6.motion_budget]
    - id: p10.load_test
      name: "Simulated load test: idle layers unload and memory drops"
      kind: task
      depends_on: [p10.governor_actions]
    - id: p10.exit
      name: "Phase 10 exit test"
      kind: gate
      depends_on: [p10.replay_slice, p10.load_test, d.oq7]
      exit_test: "Under simulated load, idle layers unload and memory drops; an unloaded layer wakes with identical state; a recorded session replays to the same pixels."
    - id: e0.document_model
      name: "Document model: scene is the source of truth; editor-only data under meta.editor"
      kind: task
      depends_on: [p2.exit]
      soft_depends_on: [d.e_oq2]
      files: ["crates/lg-editor-core/"]
    - id: e0.op_set
      name: "Op set: element, prop, bind, style, motion, layer, var, wire, component, token ops with origin and base_rev"
      kind: task
      depends_on: [e0.document_model]
    - id: e0.txn_undo
      name: "Transactions; inverse computed on apply; undo and redo"
      kind: task
      depends_on: [e0.op_set]
    - id: e0.validation
      name: "Validation gates and doc.validate() with named failure codes"
      kind: task
      depends_on: [e0.op_set]
    - id: e0.preview_dry_run
      name: "doc.preview dry run"
      kind: task
      depends_on: [e0.validation]
    - id: e0.query_subscribe_log
      name: "doc.query selectors, doc.subscribe, doc.log"
      kind: task
      depends_on: [e0.document_model]
    - id: e0.cli
      name: "lg-edit CLI: apply, validate, undo-check"
      kind: task
      depends_on: [e0.txn_undo, e0.validation]
    - id: e0.fuzz_roundtrip
      name: "Round-trip, op-inverse fuzz, and validation fuzz in CI"
      kind: task
      depends_on: [e0.cli]
    - id: e0.benchmarks
      name: "Named benchmarks (apply latency and validate time on a 10,000-element scene) to set performance targets"
      kind: task
      depends_on: [e0.cli]
    - id: e0.exit
      name: "E0 exit test"
      kind: gate
      depends_on: [e0.fuzz_roundtrip, e0.benchmarks, e0.preview_dry_run, e0.query_subscribe_log]
      exit_test: "Every phase 2 scene round-trips byte-identical; a fuzzed op sequence followed by full undo returns the original byte-identical."
    - id: e1.layer_ops
      name: "Layer ops through the op system"
      kind: task
      depends_on: [p3.exit, e0.exit]
      note: "EDITOR.md lists E1 after phase 3 only; ops come from E0."
    - id: e1.inspector_descriptors
      name: "Schema-to-inspector descriptors generated as data"
      kind: task
      depends_on: [p3.exit, e0.exit]
    - id: e1.exit
      name: "E1 exit test"
      kind: gate
      depends_on: [e1.layer_ops, e1.inspector_descriptors]
      exit_test: "Layer add, move, and remove work through ops; descriptors are generated for rect, text, and button with no per-type code."
    - id: e2.style_rules
      name: "Style rules in the document model"
      kind: task
      depends_on: [p4.exit, e1.exit]
      soft_depends_on: [p2.styles_schema, d.oq10]
    - id: e2.motion_defs
      name: "Motion definitions in the document model"
      kind: task
      depends_on: [p4.exit, e0.exit]
    - id: e2.tokens
      name: "Tokens in the document model"
      kind: task
      depends_on: [p4.design_tokens, e0.exit]
    - id: e2.particle_emitter_schema
      name: "Particle emitter element schema in the document model"
      kind: task
      depends_on: [p4.particles, e0.exit]
    - id: e2.exit
      name: "E2 exit test"
      kind: gate
      depends_on: [e2.style_rules, e2.motion_defs, e2.tokens, e2.particle_emitter_schema]
      exit_test: "Style rules switch on a variable and animate; a particle emitter with a fixed seed renders identical frames on two runs."
    - id: e3.wire_ops
      name: "wire.add and wire.remove ops (event, target, action)"
      kind: task
      depends_on: [p5.exit, e0.exit]
    - id: e3.contract_validation
      name: "Validate wires against the target layer's contract at edit time"
      kind: task
      depends_on: [e3.wire_ops]
    - id: e3.exit
      name: "E3 exit test"
      kind: gate
      depends_on: [e3.contract_validation]
      exit_test: "An undeclared wire is rejected at edit time with E_CONTRACT_UNDECLARED."
    - id: e4.emitter_trait
      name: "lg-gen Emitter and Target traits"
      kind: task
      depends_on: [e0.exit]
      files: ["crates/lg-gen/"]
    - id: e4.element_emitters
      name: "Built-in code emitters per element type (scene JSON target mandatory)"
      kind: task
      depends_on: [e4.emitter_trait]
    - id: e4.markers
      name: "Element markers wrapping every fragment"
      kind: task
      depends_on: [e4.emitter_trait]
    - id: e4.assemble
      name: "Target.assemble: file layout, hoisted tokens and variables, tree order, fixed formatting"
      kind: task
      depends_on: [e4.element_emitters, e4.markers]
    - id: e4.incremental
      name: "emit_incremental patches only touched fragments"
      kind: task
      depends_on: [e4.assemble]
    - id: e4.readback
      name: "Read back marked fragments into ops (origin: code)"
      kind: task
      depends_on: [e4.assemble]
      soft_depends_on: [d.e_oq4]
    - id: e4.drift
      name: "Drift and parse handling: E_CODE_DRIFT, E_CODE_PARSE, keep as raw or regenerate"
      kind: task
      depends_on: [e4.readback]
    - id: e4.emit_registration_test
      name: "Registration test: emit twice; nondeterministic emitters are refused (E_EMIT_NONDETERMINISTIC)"
      kind: task
      depends_on: [e4.element_emitters]
    - id: e4.cli_emit_readback
      name: "lg-edit emit and lg-edit readback"
      kind: task
      depends_on: [e4.incremental, e4.readback]
    - id: e4.tests
      name: "Emit determinism, round-trip, incremental equals full, drift fixtures"
      kind: task
      depends_on: [e4.cli_emit_readback, e4.drift, e4.emit_registration_test]
    - id: e4.exit
      name: "E4 exit test"
      kind: gate
      depends_on: [e4.tests]
      soft_depends_on: [e2.exit]
      exit_test: "Every scene emits byte-identical output on repeated runs; emit then read back gives the same document; a matching hand edit becomes ops and a non-matching one raises E_CODE_DRIFT."
      note: "Emitting style, motion, and particle data needs the E2 schema even though EDITOR.md lists E4 after E0 only."
    - id: p11.shell
      name: "Editor app built from Looking Glass elements on a meta-tagged layer"
      kind: task
      depends_on: [p8.exit, p9.exit, e1.exit, e2.exit, e3.exit, e4.exit]
      soft_depends_on: [d.oq6]
      aliases: [E5]
      files: ["crates/lg-editor/", "apps/lg-demo/editor/"]
    - id: p11.native_undo
      name: "Undo bound natively, outside the scene"
      kind: task
      depends_on: [p11.shell, e0.txn_undo]
    - id: p11.lockout_recovery
      name: "Pinned last-known-good copy of the editor's own scene (E_SELF_EDIT_LOCKOUT recovery)"
      kind: task
      depends_on: [p11.shell, p11.native_undo]
    - id: p11.canvas
      name: "Canvas: live scene in the real renderer; select, drag, resize, re-parent across layers; edit/play toggle"
      kind: task
      depends_on: [p11.shell, e1.layer_ops]
    - id: p11.layer_stack
      name: "Layer stack surface: depth, tags, bounds, lifecycle state, texture memory"
      kind: task
      depends_on: [p11.shell, e1.layer_ops, p6.exit]
    - id: p11.tree
      name: "Tree surface: hierarchy, components, slots"
      kind: task
      depends_on: [p11.shell]
    - id: p11.inspector
      name: "Inspector generated from schema_of(type)"
      kind: task
      depends_on: [p11.shell, e1.inspector_descriptors]
    - id: p11.variables_panel
      name: "Variables surface with live values and provider source"
      kind: task
      depends_on: [p11.shell, p7.exit]
    - id: p11.style_rules_panel
      name: "Style rules surface with live match highlighting"
      kind: task
      depends_on: [p11.shell, e2.style_rules]
    - id: p11.motion_panel
      name: "Motion surface: spring visualizer, easing editor, multi-track timeline, stagger"
      kind: task
      depends_on: [p11.shell, e2.motion_defs]
    - id: p11.particles_panel
      name: "Particle editor: force gizmos, over-life curves, presets, live count against budget"
      kind: task
      depends_on: [p11.shell, e2.particle_emitter_schema]
      optional: true
    - id: p11.wiring_panel
      name: "Wiring surface checked against contracts"
      kind: task
      depends_on: [p11.shell, e3.exit]
    - id: p11.tokens_panel
      name: "Tokens and theme surface (edits lg-prefs tokens)"
      kind: task
      depends_on: [p11.shell, e2.tokens, p8.prefs_as_variables]
    - id: p11.library_panel
      name: "Component library surface"
      kind: task
      depends_on: [p11.shell, p11.tree]
    - id: p11.code_view
      name: "Code view: live generated code, selection linking, editable with read-back"
      kind: task
      depends_on: [p11.shell, e4.exit]
      soft_depends_on: [d.e_oq4]
    - id: p11.history_panel
      name: "History surface: op log, jump to revision, replay a range"
      kind: task
      depends_on: [p11.shell, e0.query_subscribe_log]
    - id: p11.problems_panel
      name: "Problems surface fed by validate()"
      kind: task
      depends_on: [p11.shell, e0.validation]
    - id: p11.perf_hud
      name: "Performance HUD: frame time, active layers, particle count, motion-budget state"
      kind: task
      depends_on: [p11.shell, p6.exit]
    - id: p11.exit
      name: "Phase 11 / E5 exit test"
      kind: gate
      depends_on: [p11.lockout_recovery, p11.canvas, p11.layer_stack, p11.tree, p11.inspector, p11.variables_panel, p11.style_rules_panel, p11.motion_panel, p11.wiring_panel, p11.tokens_panel, p11.library_panel, p11.code_view, p11.history_panel, p11.problems_panel, p11.perf_hud]
      exit_test: "Edit an element of the editor itself and see it update live, then undo; dragging updates the code view live; editing the code view updates the canvas; E_SELF_EDIT_LOCKOUT recovery works."
    - id: e6.export_crate
      name: "lg-export crate and Target packs scaffold"
      kind: task
      depends_on: [e4.exit, d.e_oq1]
      optional: true
      status: on_hold
      files: ["crates/lg-export/"]
    - id: e6.coverage
      name: "coverage() listing explicit losses before export"
      kind: task
      depends_on: [e6.export_crate]
      optional: true
      status: on_hold
    - id: e6.emitter_packs
      name: "Emitter pack per additional target"
      kind: task
      depends_on: [e6.coverage]
      optional: true
      status: on_hold
    - id: e6.conformance
      name: "Conformance scenes and byte-identical repeat export per target"
      kind: task
      depends_on: [e6.emitter_packs]
      optional: true
      status: on_hold
    - id: e6.exit
      name: "E6 exit test"
      kind: gate
      depends_on: [e6.conformance]
      optional: true
      status: on_hold
      exit_test: "Per target: coverage matches a fixture of expected losses; exported output renders the conformance scenes; repeated export is byte-identical."
    - id: e7.component_versioning
      name: "Component versioning (name@major.minor) and upgrades with diff preview, undoable"
      kind: task
      depends_on: [p11.exit]
    - id: e7.a11y_lint
      name: "Accessibility lint: contrast, hit-target size, focus order, reduced-motion respect"
      kind: task
      depends_on: [p11.problems_panel]
    - id: e7.visual_regression
      name: "Replay-based visual regression in CI"
      kind: task
      depends_on: [p10.exit, p11.exit]
    - id: e7.plugin_api
      name: "Plugin API: element schemas, inspector widgets, signal providers, emitters, targets under phase 9 permissions"
      kind: task
      depends_on: [p9.exit, e4.exit]
      note: "EDITOR.md describes this API but assigns it to no build_order step; placed in E7 provisionally."
    - id: e7.multiuser
      name: "Multi-user merge over the op log"
      kind: task
      depends_on: [p11.exit]
      soft_depends_on: [d.e_oq5]
      optional: true
    - id: e7.exit
      name: "E7 exit test"
      kind: gate
      depends_on: [e7.component_versioning, e7.a11y_lint, e7.visual_regression, e7.plugin_api]
      exit_test: "A component upgrade shows a diff and is undoable; a recorded session replays to the same pixels in CI."
    - id: p12.release_exe
      name: "Single-file release exe"
      kind: task
      depends_on: [p8.exit]
    - id: p12.installer
      name: Installer
      kind: task
      depends_on: [p12.release_exe]
    - id: p12.code_signing
      name: "Code signing"
      kind: task
      depends_on: [p12.release_exe]
    - id: p12.auto_update
      name: Auto-update
      kind: task
      depends_on: [p12.installer, p12.code_signing]
    - id: p12.port_linux
      name: "Linux port behind the thin platform layer"
      kind: task
      depends_on: [p8.exit]
    - id: p12.port_macos
      name: "macOS port behind the thin platform layer"
      kind: task
      depends_on: [p8.exit]
    - id: p12.release_docs
      name: "Release documentation"
      kind: task
      depends_on: [p12.installer]
      files: ["docs/release.md"]
    - id: p12.exit
      name: "Phase 12 exit test"
      kind: gate
      depends_on: [p12.auto_update, p12.port_linux, p12.port_macos, p12.release_docs]
      exit_test: "A clean machine installs and runs Looking Glass with no other software."
    - id: m.first_slice
      name: "Milestone: first slice (one borderless window drawing one rectangle from data)"
      kind: milestone
      depends_on: [p1.exit]
    - id: m.interactive_ui
      name: "Milestone: interactive UI with layers (button, variables, toast on a second layer)"
      kind: milestone
      depends_on: [p3.exit]
    - id: m.alive_ui
      name: "Milestone: animated, alive UI (motion, SDF look, blur-behind)"
      kind: milestone
      depends_on: [p4.exit]
    - id: m.live_monitor
      name: "Milestone: live system monitor (first real target)"
      kind: milestone
      depends_on: [p7.exit]
    - id: m.efficient_runtime
      name: "Milestone: idle-efficient, replayable runtime"
      kind: milestone
      depends_on: [p6.exit, p10.exit]
    - id: m.multi_app_host
      name: "Milestone: many apps in one host with shared preferences"
      kind: milestone
      depends_on: [p8.exit]
    - id: m.self_hosted_editor
      name: "Milestone: self-hosted editor"
      kind: milestone
      depends_on: [p11.exit]
    - id: m.enterprise_editor
      name: "Milestone: enterprise editor layer"
      kind: milestone
      depends_on: [e7.exit]
    - id: m.release
      name: "Milestone: packaged release"
      kind: milestone
      depends_on: [p12.exit]
  waves:
    description: Topological levels over hard edges. Everything in one wave can run in parallel once the previous wave is done.
    levels:
      - wave: 0
        nodes: [d.oq3, d.oq9, d.oq10, d.oq6, d.e_oq1, d.e_oq2, d.e_oq4, d.e_oq5, d.e_oq8, p0.workspace, p0.decide_stack]
      - wave: 1
        nodes: [p0.decide_oq1_oq2]
      - wave: 2
        nodes: [d.oq2, p0.exit]
      - wave: 3
        nodes: [p1.element_struct, p1.window]
      - wave: 4
        nodes: [p1.gpu_context, p1.scene_loader]
      - wave: 5
        nodes: [p1.rect_renderer]
      - wave: 6
        nodes: [p1.exit]
      - wave: 7
        nodes: [p2.schema, p2.vars, m.first_slice]
      - wave: 8
        nodes: [p2.tree, p2.expr, p2.styles_schema]
      - wave: 9
        nodes: [p2.bindings, p2.layout, p2.text, p2.shapes]
      - wave: 10
        nodes: [p2.hit_test, p2.hot_reload]
      - wave: 11
        nodes: [p2.button]
      - wave: 12
        nodes: [p2.exit]
      - wave: 13
        nodes: [p3.layer_model, e0.document_model]
      - wave: 14
        nodes: [p3.layer_ops, p3.layer_texture, e0.op_set, e0.query_subscribe_log]
      - wave: 15
        nodes: [p3.compositor, p3.auto_remove, e0.txn_undo, e0.validation]
      - wave: 16
        nodes: [p3.toast, e0.preview_dry_run, e0.cli]
      - wave: 17
        nodes: [p3.exit, e0.fuzz_roundtrip, e0.benchmarks]
      - wave: 18
        nodes: [p4.frame_clock, p4.sdf, p5.event_types, p6.dirty_regions, e0.exit, m.interactive_ui]
      - wave: 19
        nodes: [p4.springs_tweens, p4.time_variable, p4.shadow_glow, p4.gradient, p4.shader_element, p5.event_gates, p5.observers, p5.ring_buffer, p6.occlusion_culling, p6.transparent_free, e1.layer_ops, e1.inspector_descriptors, e4.emitter_trait]
      - wave: 20
        nodes: [p4.timelines, p4.interruptible, p4.blur, p4.design_tokens, p5.contracts, e1.exit, e4.element_emitters, e4.markers]
      - wave: 21
        nodes: [p4.ambient, p5.interaction_primitive, p5.violation_log, e2.tokens, e4.assemble, e4.emit_registration_test]
      - wave: 22
        nodes: [p4.intensity_controls, p5.exit, e4.incremental, e4.readback]
      - wave: 23
        nodes: [p4.particles, p4.exit, p7.provider_trait, p8.local_ipc, e3.wire_ops, e4.drift, e4.cli_emit_readback]
      - wave: 24
        nodes: [p6.lifecycle, p7.provider_time, p7.provider_input, p7.provider_metrics, p7.provider_net, p7.provider_files, p7.scene_valid_without_provider, p8.app_registry, e2.style_rules, e2.motion_defs, e2.particle_emitter_schema, e3.contract_validation, e4.tests, m.alive_ui]
      - wave: 25
        nodes: [p6.policies, p6.motion_budget, p6.layer_threads, p7.monitor_scene, p8.live_loading, p8.session, p8.prefs_store, e2.exit, e3.exit, e4.exit]
      - wave: 26
        nodes: [p6.buffering, p6.scheduler, p7.spike_toast, p8.prefs_as_variables, p8.shared_state, p8.cross_app_messaging, e6.export_crate]
      - wave: 27
        nodes: [p6.stress_demo, p7.monitor_demo, p8.embedding, e6.coverage]
      - wave: 28
        nodes: [p6.measure_threads_vs_processes, p6.measure_wake_latency, p7.exit, p8.two_apps_demo, e6.emitter_packs]
      - wave: 29
        nodes: [d.oq1, d.oq4, p8.exit, e6.conformance, m.live_monitor]
      - wave: 30
        nodes: [p6.exit, p9.perm_model, p9.wasm_host, e6.exit, p12.release_exe, p12.port_linux, p12.port_macos, m.multi_app_host]
      - wave: 31
        nodes: [d.oq8, p9.wasm_api, p9.wasm_sandbox, p10.governor_signals, p12.installer, p12.code_signing]
      - wave: 32
        nodes: [p9.embedded_scripting, p9.wasm_toast_demo, p10.snapshot, p10.event_recorder, p10.governor_controller, p12.auto_update, p12.release_docs]
      - wave: 33
        nodes: [d.oq7, p9.exit, p10.replay, p10.governor_actions, p12.exit]
      - wave: 34
        nodes: [p10.replay_slice, p10.load_test, p11.shell, e7.plugin_api, m.release]
      - wave: 35
        nodes: [p10.exit, p11.native_undo, p11.canvas, p11.layer_stack, p11.tree, p11.inspector, p11.variables_panel, p11.style_rules_panel, p11.motion_panel, p11.particles_panel, p11.wiring_panel, p11.tokens_panel, p11.code_view, p11.history_panel, p11.problems_panel, p11.perf_hud]
      - wave: 36
        nodes: [p11.lockout_recovery, p11.library_panel, e7.a11y_lint, m.efficient_runtime]
      - wave: 37
        nodes: [p11.exit]
      - wave: 38
        nodes: [e7.component_versioning, e7.visual_regression, e7.multiuser, m.self_hosted_editor]
      - wave: 39
        nodes: [e7.exit]
      - wave: 40
        nodes: [m.enterprise_editor]
  longest_chain:
    description: Longest dependency chain by node count over hard edges. It runs through the editor track, which makes editor work the long pole.
    length: 41
    path: [p0.decide_stack, p0.decide_oq1_oq2, p0.exit, p1.window, p1.gpu_context, p1.rect_renderer, p1.exit, p2.schema, p2.tree, p2.layout, p2.hit_test, p2.button, p2.exit, p3.layer_model, p3.layer_texture, p3.compositor, p3.toast, p3.exit, p5.event_types, p5.event_gates, p5.contracts, p5.interaction_primitive, p5.exit, p8.local_ipc, p8.app_registry, p8.session, p8.cross_app_messaging, p8.embedding, p8.two_apps_demo, p8.exit, p9.wasm_host, p9.wasm_api, p9.wasm_toast_demo, p9.exit, p11.shell, p11.native_undo, p11.lockout_recovery, p11.exit, e7.component_versioning, e7.exit, m.enterprise_editor]
  phase_critical_path:
    description: >-
      Longest chain over the phase-level graph declared in PHASEMAP.md, weighting
      S=1, M=2, L=3. Illustrative only; PHASEMAP.md gives relative sizes, not time,
      and Track E steps have no sizes.
    weight: 16
    path: [p0, p1, p2, p3, p5, p8, p9, p11]
  index:
    crates:
      lg-core: [p1.element_struct, p2.schema, p2.tree, p3.layer_model]
      lg-render: [p1.rect_renderer, p2.text, p2.shapes, p3.layer_texture, p3.compositor, p4.sdf, p4.shadow_glow, p4.gradient, p4.blur, p4.shader_element, p4.particles, p6.dirty_regions, p6.occlusion_culling]
      lg-vars: [p2.vars]
      lg-layout: [p2.layout]
      lg-motion: [p4.frame_clock, p4.springs_tweens, p4.timelines, p4.particles]
      lg-bus: [p5.event_types, p5.event_gates, p5.observers, p5.contracts]
      lg-runtime: [p6.lifecycle, p6.motion_budget, p6.buffering, p6.scheduler, p10.snapshot, p10.event_recorder, p10.governor_controller]
      lg-signals: [p7.provider_trait, p7.provider_time, p7.provider_input, p7.provider_metrics, p7.provider_net]
      lg-host: [p8.local_ipc, p8.app_registry, p8.session]
      lg-prefs: [p8.prefs_store]
      lg-wasm: [p9.perm_model, p9.wasm_host, p9.wasm_api]
      lg-editor-core: [e0.document_model]
      lg-gen: [e4.emitter_trait]
      lg-editor: [p11.shell]
      lg-export: [e6.export_crate]
    schemas:
      element.schema.json: [p2.schema]
      layer.schema.json: [p3.layer_model]
      event.schema.json: [p5.event_types]
      contract.schema.json: [p5.contracts]
      signal.schema.json: [p7.provider_trait]
      prefs.schema.json: [p8.prefs_store]
    scenes:
      rect.json: [p1.scene_loader]
      button.json: [p2.button]
      toast.json: [p3.toast]
      monitor.json: [p7.monitor_scene]
  findings:
    description: Things the graph shows that the source documents do not state. Each is a proposal to check, not a decision.
    items:
      - kind: implicit_dependency
        nodes: [p7.monitor_scene]
        text: "PHASEMAP.md lists phase 7 as depending on 2 and 5. The monitor demo needs spring-smoothed bars (phase 4) and a toast (phase 3), so the graph gives phase 7 edges to phases 3 and 4."
      - kind: implicit_dependency
        nodes: [e1.layer_ops, e1.inspector_descriptors, e2.style_rules, e3.wire_ops]
        text: "EDITOR.md lists E1, E2, and E3 as following phases 3, 4, and 5. Their work is expressed as ops, so each also depends on E0 (and E2's style rules on E1)."
      - kind: implicit_dependency
        nodes: [e4.exit]
        text: "EDITOR.md lists E4 after E0 only. Emitting styles, motion, and particle emitters needs the E2 schema, so E4's exit has a soft edge to E2's exit."
      - kind: implicit_dependency
        nodes: [p11.shell]
        text: "PHASEMAP.md lists phase 11 as depending on 8 and 9. With amendment A3 it also depends on E1 to E4, and its surfaces pull in phases 6 and 7 (layer stack, HUD, variables panel)."
      - kind: unassigned_work
        nodes: [e7.plugin_api]
        text: "The Plugin API in EDITOR.md has no build_order step. It is placed in E7 provisionally; it depends on phase 9 permissions and on E4 emitters."
      - kind: long_pole
        nodes: [m.enterprise_editor]
        text: "The longest chain runs 0 to 1 to 2 to 3 to 5 to 8 to 9 to 11 to E7. The editor track, not the renderer or lifecycle phases, ends the critical path."
      - kind: unblocked_start
        nodes: [e0.document_model, e4.emitter_trait]
        text: "E0 and E4 are headless and can start right after phase 2, in parallel with phases 3 to 6, matching the EDITOR.md note."
      - kind: decision_gate
        nodes: [d.oq3, p9.perm_model]
        text: "OQ3 (permissions) has no assigned resolver before phase 9 and blocks both the permission model and the editor's live editing of other apps."
      - kind: decision_gate
        nodes: [d.oq9]
        text: "OQ9 (visual feel) is a soft edge into the phase 4 look work and the design tokens; it blocks nothing hard but sets priorities and is still unanswered."
      - kind: decision_gate
        nodes: [d.e_oq1, e6.export_crate]
        text: "E-OQ1 (agnostic output) is on hold, so the whole of E6 is on hold and optional."
      - kind: parallel_opportunity
        nodes: [p4.exit, p5.exit]
        text: "Phases 4 and 5 both start after phase 3 and share no edges, so they run in parallel. Phases 6, 7, and 8 fan out from them."
      - kind: standalone
        nodes: [d.e_oq5, d.e_oq8, p9.embedded_scripting, p11.particles_panel, e7.multiuser]
        text: "These nodes are optional or open questions with no required downstream node, so no gate waits on them."