const assert = require('node:assert');
const { parseYaml, stringifyYaml } = require('../lib/format.js');

const sampleObject = { format: 'yaml', version: '0.3' };
const sampleString = 'format: yaml\nversion: "0.3"\n';

const serialized = stringifyYaml(sampleObject);
assert.strictEqual(typeof serialized, 'string');
assert.ok(serialized.includes('format: yaml'));

const parsed = parseYaml(sampleString);
assert.strictEqual(typeof parsed, 'object');
assert.strictEqual(parsed.format, 'yaml');

console.log('SP0_format test passed successfully.');