const assert = require('node:assert');
const { getCoreIdeas } = require('../lib/core_ideas.js');

const ideas = getCoreIdeas();
assert.ok(Array.isArray(ideas), 'getCoreIdeas should return an array');
assert.ok(ideas.length > 0, 'getCoreIdeas should return non-empty core ideas');
assert.strictEqual(typeof ideas[0], 'string', 'core idea items should be strings');

console.log('SP1_core_ideas test passed successfully.');
