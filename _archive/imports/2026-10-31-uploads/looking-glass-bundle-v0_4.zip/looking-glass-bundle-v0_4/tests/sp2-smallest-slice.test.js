const assert = require('node:assert');
const { renderSmallestSlice } = require('../lib/smallest_slice.js');

const rectData = { x: 10, y: 20, width: 100, height: 50, color: '#ff0000' };
const result = renderSmallestSlice(rectData);

assert.strictEqual(typeof result, 'object', 'renderSmallestSlice should return an object');
assert.strictEqual(result.type, 'borderless-window', 'result should be a borderless window');
assert.ok(result.rectangle, 'result should contain a rectangle description');
assert.strictEqual(result.rectangle.width, 100);
assert.strictEqual(result.rectangle.height, 50);

console.log('SP2_smallest_slice test passed successfully.');