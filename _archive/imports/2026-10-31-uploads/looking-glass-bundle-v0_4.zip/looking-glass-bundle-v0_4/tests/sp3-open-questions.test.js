const assert = require('node:assert');
const { getOpenQuestions } = require('../lib/open_questions.js');

const questions = getOpenQuestions();
assert.ok(Array.isArray(questions), 'getOpenQuestions should return an array');
assert.ok(questions.length > 0, 'getOpenQuestions should return non-empty open questions');
assert.strictEqual(typeof questions[0].id, 'number', 'question id should be a number');
assert.strictEqual(typeof questions[0].question, 'string', 'question text should be a string');

console.log('SP3_open_questions test passed successfully.');