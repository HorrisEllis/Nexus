const assert = require('node:assert');
const fs = require('node:fs');

// Check that the core DAG files and schema exist and are valid JSON/structure
const schemaPath = 'schemas/element.schema.json';
const rectPath = 'scenes/rect.json';

assert.ok(fs.existsSync(schemaPath), 'schemas/element.schema.json should exist');
assert.ok(fs.existsSync(rectPath), 'scenes/rect.json should exist');

const schemaContent = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
assert.strictEqual(typeof schemaContent, 'object', 'schema should be a valid JSON object');

const rectContent = JSON.parse(fs.readFileSync(rectPath, 'utf8'));
assert.strictEqual(typeof rectContent, 'object', 'rect scene should be a valid JSON object');

console.log('SP4_dag test passed successfully.');