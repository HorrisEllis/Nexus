spec:
  meta:
    name: SPEC-phasemap
    version: 0.1.0
    uuid: SPEC-phasemap-v1
    template: genesis
    purpose: >
      A phasemap for building the SPEC.spec in looking-glass-bundle-v0.4.
  axioms:
    AX-001: "A rule it must never break."
  modules:
    - id: SP0_foundation
      description: "Foundation and architecture first."
      path: lib/foundation.js
      exports:
        - "defineArchitecture(architecture: object) → void"
      behavioral_contracts:
        - "Given an architecture, defineArchitecture sets up the foundational components."
      error_paths:
        - "Invalid architecture → throws with a reason."
    - id: SP1_library
      description: "Raw execution before interfaces. Raw code → library."
      path: lib/library.js
      exports:
        - "buildLibrary(library: object) → void"
      behavioral_contracts:
        - "Given a library, buildLibrary compiles it into a reusable library."
      error_paths:
        - "Invalid library → throws with a reason."
    - id: SP2_api
      description: "API → CLI."
      path: lib/api.js
      exports:
        - "buildAPI(api: object) → void"
      behavioral_contracts:
        - "Given an API, buildAPI generates the CLI interface."
      error_paths:
        - "Invalid API → throws with a reason."
    - id: SP3_cli
      description: "CLI → automation."
      path: lib/cli.js
      exports:
        - "buildCLI(cli: object) → void"
      behavioral_contracts:
        - "Given a CLI, buildCLI automates the build process."
      error_paths:
        - "Invalid CLI → throws with a reason."
    - id: SP4_automation
      description: "Automation → UI."
      path: lib/automation.js
      exports:
        - "buildAutomation(automation: object) → void"
      behavioral_contracts:
        - "Given an automation, buildAutomation generates the UI."
      error_paths:
        - "Invalid automation → throws with a reason."
    - id: SP5_ui
      description: "UI."
      path: lib/ui.js
      exports:
        - "buildUI(ui: object) → void"
      behavioral_contracts:
        - "Given a UI, buildUI renders the final product."
      error_paths:
        - "Invalid UI → throws with a reason."
  tests:
    - "SP0_foundation on a valid architecture is successful."
    - "SP1_library on a valid library is successful."
    - "SP2_api on a valid API is successful."
    - "SP3_cli on a valid CLI is successful."
    - "SP4_automation on a valid automation is successful."
    - "SP5_ui on a valid UI is successful."
