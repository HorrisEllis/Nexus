spec:
  meta:
    name: schema
    version: 0.1.0
    uuid: schema-v1
    template: genesis
    purpose: >
      Implements core schema validation structures in Rust.
  modules:
    - id: schema
      description: "Implements core schema validation structures in Rust."
      path: crates/lg-core/src/schema.rs
      exports:
        - "validate_schema(input: &str) → bool"
      behavioral_contracts:
        - "Given a valid schema input string, validate_schema returns true."
        - "Given an invalid schema input string, validate_schema returns false."
