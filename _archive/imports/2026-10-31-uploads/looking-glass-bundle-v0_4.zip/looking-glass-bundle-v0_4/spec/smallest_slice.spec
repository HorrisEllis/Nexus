spec:
  meta:
    name: smallest_slice
    version: 0.1.0
    uuid: smallest_slice-v1
    template: genesis
    purpose: >
      Implements the smallest representable unit: one borderless window that draws one rectangle from a data struct.
  axioms:
    AX-001: "The smallest slice must have no layers and no event bus."
  modules:
    - id: smallest_slice
      description: "Renders the borderless window and rectangle from data."
      path: lib/smallest_slice.js
      exports:
        - "renderSmallestSlice(data: Object) → Object"
      behavioral_contracts:
        - "Given rectangle data, renderSmallestSlice returns a structured representation of a borderless window containing the rectangle."
      error_paths:
        - "Invalid data → throws with a reason."
  schemas:
    - id: Object
      fields:
        type: string
        bounds: string
  tests:
    - "renderSmallestSlice successfully produces a valid window and rectangle structure."
