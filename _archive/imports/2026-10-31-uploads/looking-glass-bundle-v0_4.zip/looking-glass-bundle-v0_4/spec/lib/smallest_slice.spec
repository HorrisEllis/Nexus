spec:
  meta:
    name: lib/smallest_slice
    version: 0.1.0
    purpose: >
      Implements the smallest slice representation of a borderless window drawing a rectangle from data.
    uuid: lib-smallest_slice-v1
    template: genesis
  modules:
    - id: renderSmallestSlice
      description: "Renders the smallest slice unit given rectangle data."
      path: lib/smallest_slice.js
      exports:
        - "renderSmallestSlice(data: Object) → Object"
      behavioral_contracts:
        - "Given a data object containing rectangle coordinates and dimensions, renderSmallestSlice returns an object representing a borderless window with a rectangle."
      error_paths:
        - "Invalid data format → throws an error."
