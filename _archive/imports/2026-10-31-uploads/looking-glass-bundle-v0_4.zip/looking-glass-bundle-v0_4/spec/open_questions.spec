spec:
  meta:
    name: open_questions
    version: 0.1.0
    uuid: open_questions-v1
    template: genesis
    purpose: >
      Implements retrieval and management of open design questions for Looking Glass.
  axioms:
    AX-001: "Open questions must accurately reflect the architectural trade-offs defined in the spec."
  modules:
    - id: open_questions
      description: "Returns the open design questions from the specification."
      path: lib/open_questions.js
      exports:
        - "getOpenQuestions() → Array"
      behavioral_contracts:
        - "Given the open questions module is invoked, getOpenQuestions returns an array of design questions."
      error_paths:
        - "Unavailable source → returns empty array."
  schemas:
    - id: Array
      fields:
        id: number
        question: string
  tests:
    - "getOpenQuestions returns a non-empty array of architectural questions."
