pub fn validate_schema(input: &str) -> bool {
    let input = input.trim();

    if input.is_empty() {
        return false;
    }

    let bytes = input.as_bytes();
    if bytes.first() != Some(&b'{') || bytes.last() != Some(&b'}') {
        return false;
    }

    let mut depth = 0usize;
    let mut in_string = false;
    let mut escaped = false;

    for &byte in bytes {
        if in_string {
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if byte == b'"' {
                in_string = false;
            }
            continue;
        }

        match byte {
            b'"' => in_string = true,
            b'{' => depth += 1,
            b'}' => {
                if depth == 0 {
                    return false;
                }
                depth -= 1;
                if depth == 0 && byte != *bytes.last().unwrap() {
                    return false;
                }
            }
            _ => {}
        }
    }

    !in_string && !escaped && depth == 0
}
