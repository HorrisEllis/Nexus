pub struct Element {
    name: String,
}

impl Element {
    pub fn create_element(name: &str) -> String {
        format!("Element: {}", name)
    }
}
