//! Rectangle rendering logic for Looking Glass.

/// Renders a rectangle of the given width and height as a string description.
pub fn render_rect(w: u32, h: u32) -> String {
    format!("rect {}x{}", w, h)
}
