spec:
  meta:
    name: SPEC-phasemap
    spec: SPEC.spec
    spec_sha256: 73daa8cba5a955fef6d68bcb750cbb19ca4bcdd14056020743703593ed000009
    block_hashes:
      "format": 2a6b367c68db2f01
      "title": ff7a20e4a453609c
      "stage": 998033a8b52a55a9
      "build_plan": f5fd77d4b4a5aeb1
      "legend": 098beda52687df76
      "what_this_is": 2cd62c96ef4a270d
      "core_ideas": f8a6970081df1c29
      "prior_art": b56c890caad19519
      "smallest_slice": 910ec74b3506412a
      "open_questions": dfe3209a6bcdf210
      "risks": 73d524c6e9506ec2
      "bundle_contents": 02566cc52320cb40
      "dag": 78a284be0b7c1667
    axioms: docs/AXIOMS-v3.1.md §3.1 §3.3 §3.4 §1.1 §1.3 §0.3 §8.6 §12.1 §17.5
    planned_by: idearium/repo/spec-plan.js derivePlan
    planned_at: 2026-10-19T04:43:08.387Z
    reason: "the agent replied without a map"
    note: "One phase per section of the spec, its layer read from the section. Refine any phase, or ask the agent to plan again (replan) — this map is versioned."
  phases:
    SP0_format:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: []
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "format"
      files: [lib/format.js]
      does: >-
        Build what the spec states in §format (line 2) — format: yaml.
      proof: >-
        A test that proves format as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP1_core_ideas:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP0_format]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "core_ideas"
      files: [lib/core_ideas.js]
      does: >-
        Build what the spec states in §core_ideas (line 46) — ui_is_typed_data: id: "2.1" status: DECIDED direction, PROPOSED details description: >- There is no markup source of truth. Every element (button, text, rectangle, slider, toast, close button) is defi.
      proof: >-
        A test that proves core_ideas as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP2_smallest_slice:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP1_core_ideas]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "smallest_slice"
      files: [lib/smallest_slice.js]
      does: >-
        Build what the spec states in §smallest_slice (line 222) — approach: DECIDED, start with the smallest unit and build up smallest_unit: one borderless window that draws one rectangle from a data struct. No layers, no bus, nothing else. build_order: detail: PHA.
      proof: >-
        A test that proves smallest_slice as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP3_open_questions:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP2_smallest_slice]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "open_questions"
      files: [lib/open_questions.js]
      does: >-
        Build what the spec states in §open_questions (line 255) — - id: 1 question: Threads or processes per layer? detail: Threads are faster with shared memory; processes isolate better but add messaging latency. assigned_to: phase 6 (measure) - id: 2 question: Wh.
      proof: >-
        A test that proves open_questions as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP4_dag:
      layer: foundation
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      # roadmap edit 2026-10-19: IN PROGRESS 2026-10-19. -> DONE 2026-10-19.
      status_previous: "IN PROGRESS 2026-10-19."
      status: "DONE 2026-10-19."
      depends_on: [SP3_open_questions]
      axioms: [§3.1, §1.1, §1.3, §0.3]
      blocks:
        - "dag"
      files: [apps/lg-shell/src/main.rs, crates/lg-core/src/element.rs, scenes/rect.json, crates/lg-render/src/rect.rs, schemas/element.schema.json, crates/lg-core/src/schema.rs]
      does: >-
        Build what the spec states in §dag (line 320) — # DAG: full dependency graph for the whole project (main track, Track E, # decisions, milestones). Generated from PHASEMAP.md, EDITOR.md and SPEC.md. # ================================================.
      proof: >-
        A test that proves dag as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP5_title:
      layer: library
      # roadmap edit 2026-10-19: OPEN -> IN PROGRESS 2026-10-19.
      status_previous: "OPEN"
      status: "IN PROGRESS 2026-10-19."
      depends_on: [SP4_dag]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "title"
      files: [lib/title.js]
      does: >-
        Build what the spec states in §title (line 4).
      proof: >-
        A test that proves title as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP6_stage:
      layer: library
      status: OPEN
      depends_on: [SP5_title]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "stage"
      files: [lib/stage.js]
      does: >-
        Build what the spec states in §stage (line 7).
      proof: >-
        A test that proves stage as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP7_build_plan:
      layer: library
      status: OPEN
      depends_on: [SP6_stage]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "build_plan"
      files: [lib/build_plan.js]
      does: >-
        Build what the spec states in §build_plan (line 8).
      proof: >-
        A test that proves build_plan as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP8_legend:
      layer: library
      status: OPEN
      depends_on: [SP7_build_plan]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "legend"
      files: [lib/legend.js]
      does: >-
        Build what the spec states in §legend (line 17) — DECIDED: you said it or agreed to it directly. PROPOSED: a suggestion from the conversation that you have not confirmed. OPEN: unresolved question..
      proof: >-
        A test that proves legend as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP9_prior_art:
      layer: library
      status: OPEN
      depends_on: [SP8_legend]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "prior_art"
      files: [lib/prior_art.js]
      does: >-
        Build what the spec states in §prior_art (line 201) — note: Not dependencies, just what exists so Looking Glass can differ on purpose. items: - category: Electron alternatives that still use a webview or Chromium examples: [Tauri (system webview + Rust),.
      proof: >-
        A test that proves prior_art as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP10_bundle_contents:
      layer: library
      status: OPEN
      depends_on: [SP9_prior_art]
      axioms: [§3.1, §8.6, §1.3, §12.1]
      blocks:
        - "bundle_contents"
      files: [lib/bundle_contents.js]
      does: >-
        Build what the spec states in §bundle_contents (line 315) — - SPEC.md (this file) - PHASEMAP.md (phased build plan) - README.md.
      proof: >-
        A test that proves bundle_contents as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP11_what_this_is:
      layer: ui
      status: OPEN
      depends_on: [SP10_bundle_contents]
      axioms: [§3.4, §1.3, §12.1]
      blocks:
        - "what_this_is"
      files: [ui/what_this_is.js]
      does: >-
        Build what the spec states in §what_this_is (line 22) — summary: >- An app platform, closer to a tiny OS layer for desktop apps than to an Electron clone. It is a UI renderer ("HTML, but not HTML") that draws its own pixels on the GPU and hosts apps live, .
      proof: >-
        A test that proves what_this_is as the spec states it, against the real code (no mock): §1.1, §12.1.

    SP12_risks:
      layer: ui
      status: OPEN
      depends_on: [SP11_what_this_is]
      axioms: [§3.4, §1.3, §12.1]
      blocks:
        - "risks"
      files: [ui/risks.js]
      does: >-
        Build what the spec states in §risks (line 297) — - name: Scope detail: >- Renderer, compositor, scripting runtime, and editor are each large. The mitigation is the rule above: add a piece only when the previous one works. - name: Designing in the ab.
      proof: >-
        A test that proves risks as the spec states it, against the real code (no mock): §1.1, §12.1.