import assert from 'node:assert';
import { title } from '../lib/title.js';

assert.strictEqual(typeof title, 'function', 'title should be a function');
assert.strictEqual(title('  Looking Glass  '), 'Looking Glass');
assert.strictEqual(title('Project Title'), 'Project Title');

assert.throws(() => {
  title(null);
}, /Input must be a string/);

console.log('SP5 title test passed.');
