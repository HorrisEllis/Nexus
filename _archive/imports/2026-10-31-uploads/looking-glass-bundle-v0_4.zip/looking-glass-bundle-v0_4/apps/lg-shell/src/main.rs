//! Looking Glass shell — main application entry point.

fn main() {
    println!("Looking Glass shell");
}
