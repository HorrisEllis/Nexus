#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════════════════
// FORGE — Test Suite
// forge-test.js
//
// Tests every module in forge-server.js without needing a running server.
// Exercises: MicroBus, FileVault, IdeariamBridge, Compiler, AgentBus,
//            HTTP routing, SSE, import API, search, revisions, diffs.
//
// Run: node forge-test.js
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';

const fs     = require('fs');
const path   = require('path');
const http   = require('http');
const crypto = require('crypto');
const os     = require('os');

// ── Test harness ──────────────────────────────────────────────────────────────
let passed = 0, failed = 0, skipped = 0;
const results = [];

function test(name, fn) {
  try {
    const r = fn();
    if (r && typeof r.then === 'function') {
      return r.then(() => {
        passed++;
        results.push({ ok: true, name });
        process.stdout.write(`.`);
      }).catch((e) => {
        failed++;
        results.push({ ok: false, name, error: e.message });
        process.stdout.write(`F`);
      });
    } else {
      passed++;
      results.push({ ok: true, name });
      process.stdout.write(`.`);
    }
  } catch (e) {
    failed++;
    results.push({ ok: false, name, error: e.message });
    process.stdout.write(`F`);
  }
}

function skip(name, reason) {
  skipped++;
  results.push({ ok: null, name, reason });
  process.stdout.write(`S`);
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'Assertion failed');
}
function eq(a, b, msg) {
  if (a !== b) throw new Error(msg || `Expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
}
function ok(val, msg) { assert(!!val, msg || `Expected truthy, got ${val}`); }
function notOk(val, msg) { assert(!val, msg || `Expected falsy, got ${val}`); }

// ── Setup temp dir ────────────────────────────────────────────────────────────
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-test-'));
const STORE_DIR   = path.join(TMP, 'store');
const IDEA_DIR    = path.join(TMP, 'idearium');
const PROJECT_DIR = path.join(TMP, 'project');

fs.mkdirSync(PROJECT_DIR, { recursive: true });

// Write test project files
const TEST_FILES = {
  'index.js':       `'use strict';\nconst x = 1;\nmodule.exports = { x };\n`,
  'utils.js':       `function add(a, b) { return a + b; }\nmodule.exports = { add };\n`,
  'styles.css':     `body { margin: 0; color: #333; }\n.container { max-width: 1200px; }\n`,
  'README.md':      `# Test Project\n\nThis is a test project for Forge IDE.\n`,
  'package.json':   `{\n  "name": "test-project",\n  "version": "1.0.0"\n}\n`,
  'src/app.js':     `const utils = require('../utils');\nconsole.log(utils.add(1, 2));\n`,
  'src/config.js':  `module.exports = { port: 3000, debug: true };\n`,
};

for (const [rel, content] of Object.entries(TEST_FILES)) {
  const full = path.join(PROJECT_DIR, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, content, 'utf8');
}

// ── Inline module copies (no require of forge-server to avoid port bind) ─────

// MicroBus
class MicroBus {
  constructor() { this._listeners = new Map(); this._log = []; this._seq = 0; }
  emit(type, payload = {}) {
    const ev = Object.freeze({ id: `forge-${(++this._seq).toString(36).padStart(6,'0')}`, type, payload, ts: Date.now() });
    this._log.push(ev);
    if (this._log.length > 5000) this._log.shift();
    for (const [pat, fns] of this._listeners) {
      if (type === pat || pat === '*' || type.startsWith(pat.replace('*',''))) {
        for (const fn of fns) { try { fn(ev); } catch {} }
      }
    }
    return ev;
  }
  on(pattern, fn) {
    if (!this._listeners.has(pattern)) this._listeners.set(pattern, []);
    this._listeners.get(pattern).push(fn);
    return () => { const fns = this._listeners.get(pattern) || []; this._listeners.set(pattern, fns.filter(f => f !== fn)); };
  }
  recent(n = 100) { return this._log.slice(-n); }
}

// FileVault
class FileVault {
  constructor(storeDir) {
    this._dir = storeDir;
    fs.mkdirSync(path.join(storeDir, 'objects'), { recursive: true });
    fs.mkdirSync(path.join(storeDir, 'refs'),    { recursive: true });
    fs.mkdirSync(path.join(storeDir, 'commits'), { recursive: true });
    this._commits   = this._loadCommits();
    this._fileIndex = new Map();
  }
  put(content) {
    const hash = crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
    const file = path.join(this._dir, 'objects', hash);
    if (!fs.existsSync(file)) fs.writeFileSync(file, content, 'utf8');
    return hash;
  }
  get(hash) {
    const file = path.join(this._dir, 'objects', hash);
    return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
  }
  commit(message, filePaths, opts = {}) {
    const { author = 'forge', causedBy = null } = opts;
    const files = {};
    for (const fp of filePaths) {
      try { const content = fs.readFileSync(fp, 'utf8'); const hash = this.put(content); files[fp] = { hash, size: content.length }; } catch {}
    }
    const commitId = crypto.createHash('sha256').update(JSON.stringify({ message, files, ts: Date.now() })).digest('hex').slice(0, 16);
    const commit = { commitId, message, author, causedBy, ts: Date.now(), files };
    for (const fp of Object.keys(files)) { if (!this._fileIndex.has(fp)) this._fileIndex.set(fp, []); this._fileIndex.get(fp).push(commitId); }
    fs.writeFileSync(path.join(this._dir, 'commits', `${commitId}.json`), JSON.stringify(commit, null, 2));
    this._commits.set(commitId, commit);
    return commit;
  }
  diff(commitIdA, commitIdB, filePath) {
    const a = this._commits.get(commitIdA); const b = this._commits.get(commitIdB);
    if (!a || !b) return null;
    const hashA = a.files[filePath]?.hash; const hashB = b.files[filePath]?.hash;
    if (!hashA && !hashB) return null;
    const contentA = hashA ? (this.get(hashA) || '') : '';
    const contentB = hashB ? (this.get(hashB) || '') : '';
    return { from: commitIdA, to: commitIdB, filePath, changed: contentA !== contentB, contentA, contentB };
  }
  fileHistory(filePath) {
    return (this._fileIndex.get(filePath) || []).map(id => this._commits.get(id)).filter(Boolean).sort((a,b)=>b.ts-a.ts);
  }
  listCommits() { return [...this._commits.values()].sort((a,b)=>b.ts-a.ts); }
  _loadCommits() {
    const map = new Map();
    try { for (const f of fs.readdirSync(path.join(this._dir, 'commits'))) { try { const c = JSON.parse(fs.readFileSync(path.join(this._dir, 'commits', f), 'utf8')); map.set(c.commitId, c); } catch {} } } catch {}
    return map;
  }
}

// IdeariamBridge
class IdeariamBridge {
  constructor(dataDir, bus) {
    this._dir         = dataDir;
    this._snapshotDir = path.join(dataDir, 'snapshots');
    this._gapsFile    = path.join(dataDir, 'gaps.jsonl');
    this._bus         = bus || { emit: () => {} };
    fs.mkdirSync(this._snapshotDir, { recursive: true });
    fs.mkdirSync(dataDir, { recursive: true });
  }
  pushSnapshot(message, meta = {}) {
    const snap = { snapshotId: crypto.createHash('sha256').update(message + Date.now()).digest('hex').slice(0, 16), message, ts: Date.now(), author: meta.author || 'forge', source: 'forge', causedBy: meta.causedBy || null, meta };
    fs.writeFileSync(path.join(this._snapshotDir, `${snap.snapshotId}.json`), JSON.stringify(snap, null, 2));
    this._bus.emit('idearium.snapshot.committed', { snapshotId: snap.snapshotId, message, source: 'forge' });
    return snap;
  }
  listSnapshots() {
    try {
      return fs.readdirSync(this._snapshotDir).filter(f=>f.endsWith('.json')).map(f => { try { const s = JSON.parse(fs.readFileSync(path.join(this._snapshotDir, f), 'utf8')); return { snapshotId: s.snapshotId, message: s.message, ts: s.ts, author: s.author, source: s.source }; } catch { return null; } }).filter(Boolean).sort((a,b)=>b.ts-a.ts);
    } catch { return []; }
  }
  getSnapshot(id) { try { return JSON.parse(fs.readFileSync(path.join(this._snapshotDir, `${id}.json`), 'utf8')); } catch { return null; } }
  openGap(type, description, severity = 'MEDIUM', meta = {}) {
    const gap = { gapId: crypto.randomUUID(), type, description, severity, status: 'open', openedAt: Date.now(), resolvedAt: null, source: 'forge', ...meta };
    fs.appendFileSync(this._gapsFile, JSON.stringify(gap) + '\n');
    this._bus.emit('idearium.gap.opened', { gapId: gap.gapId, type, description, severity });
    return gap;
  }
  resolveGap(gapId) { this._bus.emit('idearium.gap.resolved', { gapId, resolvedAt: Date.now() }); }
}

// Search
const CODE_EXTS = new Set(['.js','.ts','.jsx','.tsx','.mjs','.cjs','.py','.rb','.go','.rs','.java','.html','.css','.json','.yaml','.yml','.md','.sh','.sql']);
const IGNORE_DIRS = new Set(['node_modules','.git','dist','build','__pycache__','.next','coverage','vendor','.forge-store']);

function searchFiles(rootPath, query, maxResults = 50) {
  const results = []; const q = query.toLowerCase();
  function walk(dir, depth = 0) {
    if (depth > 6) return;
    let entries; try { entries = fs.readdirSync(dir); } catch { return; }
    for (const entry of entries) {
      if (IGNORE_DIRS.has(entry)) continue;
      const full = path.join(dir, entry);
      let stat; try { stat = fs.statSync(full); } catch { continue; }
      if (stat.isDirectory()) { walk(full, depth + 1); continue; }
      const ext = path.extname(entry).toLowerCase();
      if (!CODE_EXTS.has(ext)) continue;
      if (entry.toLowerCase().includes(q)) { results.push({ type: 'filename', path: full, name: entry, line: 0, text: '' }); if (results.length >= maxResults) return; continue; }
      try {
        const content = fs.readFileSync(full, 'utf8'); const lines = content.split('\n');
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].toLowerCase().includes(q)) { results.push({ type: 'content', path: full, name: entry, line: i + 1, text: lines[i].trim().slice(0, 120) }); if (results.length >= maxResults) return; }
        }
      } catch {}
    }
  }
  walk(rootPath); return results;
}

function buildTree(dirPath, depth = 0, maxDepth = 6) {
  const name = path.basename(dirPath);
  if (IGNORE_DIRS.has(name)) return null;
  if (depth > maxDepth) return null;
  let stat; try { stat = fs.statSync(dirPath); } catch { return null; }
  if (stat.isFile()) { return { type: 'file', name, path: dirPath, ext: path.extname(name).toLowerCase(), size: stat.size }; }
  if (stat.isDirectory()) {
    let children = []; try { children = fs.readdirSync(dirPath).map(c => buildTree(path.join(dirPath, c), depth+1, maxDepth)).filter(Boolean); } catch {}
    return { type: 'directory', name, path: dirPath, children };
  }
  return null;
}

// ═════════════════════════════════════════════════════════════════════════════
// TEST SUITES
// ═════════════════════════════════════════════════════════════════════════════

console.log('\n╔══════════════════════════════════════════╗');
console.log('║  FORGE — Test Suite                      ║');
console.log('╚══════════════════════════════════════════╝\n');

// ── §1 MicroBus ───────────────────────────────────────────────────────────────
console.log('§1 MicroBus');

test('bus.emit returns frozen event', () => {
  const bus = new MicroBus();
  const ev = bus.emit('test.event', { x: 1 });
  ok(ev.id, 'has id');
  ok(ev.ts, 'has ts');
  eq(ev.type, 'test.event');
  eq(ev.payload.x, 1);
  ok(Object.isFrozen(ev), 'event is frozen');
});

test('bus.emit increments sequence', () => {
  const bus = new MicroBus();
  const a = bus.emit('a');
  const b = bus.emit('b');
  ok(a.id < b.id || a.id !== b.id, 'different ids');
});

test('bus.on exact pattern fires', () => {
  const bus = new MicroBus();
  let fired = 0;
  bus.on('forge.test', () => fired++);
  bus.emit('forge.test', {});
  bus.emit('forge.other', {});
  eq(fired, 1, 'only exact match fires');
});

test('bus.on wildcard * fires for all', () => {
  const bus = new MicroBus();
  let fired = 0;
  bus.on('*', () => fired++);
  bus.emit('a.b', {}); bus.emit('c.d', {}); bus.emit('e', {});
  eq(fired, 3, 'wildcard catches all');
});

test('bus.on prefix pattern fires correctly', () => {
  const bus = new MicroBus();
  let fired = 0;
  bus.on('forge.*', () => fired++);
  bus.emit('forge.test', {});
  bus.emit('forge.compile', {});
  bus.emit('idearium.snap', {});
  eq(fired, 2, 'prefix pattern fires for forge.* only');
});

test('bus.on unsubscribe works', () => {
  const bus = new MicroBus();
  let fired = 0;
  const unsub = bus.on('test', () => fired++);
  bus.emit('test', {});
  unsub();
  bus.emit('test', {});
  eq(fired, 1, 'unsub stops listener');
});

test('bus.recent returns last N events', () => {
  const bus = new MicroBus();
  for (let i = 0; i < 10; i++) bus.emit(`e${i}`, {});
  const last3 = bus.recent(3);
  eq(last3.length, 3);
  eq(last3[last3.length - 1].type, 'e9');
});

test('bus subscriber error does not crash bus', () => {
  const bus = new MicroBus();
  let secondFired = false;
  bus.on('test', () => { throw new Error('intentional crash'); });
  bus.on('test', () => { secondFired = true; });
  bus.emit('test', {});
  ok(secondFired, 'second subscriber still runs after first throws');
});

test('bus ring buffer caps at 5000', () => {
  const bus = new MicroBus();
  for (let i = 0; i < 5100; i++) bus.emit('x', {});
  ok(bus.recent(9999).length <= 5000, 'capped at 5000');
});

// ── §2 FileVault ──────────────────────────────────────────────────────────────
console.log('\n§2 FileVault');

const vault = new FileVault(STORE_DIR);

test('vault.put stores content and returns hash', () => {
  const h = vault.put('hello world');
  ok(h, 'returns hash');
  eq(h.length, 16, '16-char hash');
});

test('vault.put deduplicates identical content', () => {
  const h1 = vault.put('same content');
  const h2 = vault.put('same content');
  eq(h1, h2, 'same hash for same content');
});

test('vault.get retrieves stored content', () => {
  const h = vault.put('retrieve me');
  eq(vault.get(h), 'retrieve me');
});

test('vault.get returns null for unknown hash', () => {
  const r = vault.get('nonexistent0000');
  eq(r, null);
});

test('vault.commit stores commit record', () => {
  const fp = path.join(PROJECT_DIR, 'index.js');
  const commit = vault.commit('test commit', [fp]);
  ok(commit.commitId, 'has commitId');
  ok(commit.files[fp], 'file indexed');
  ok(commit.ts, 'has timestamp');
  eq(commit.message, 'test commit');
});

test('vault.commit skips unreadable paths', () => {
  const commit = vault.commit('with bad path', ['/nonexistent/file.js']);
  ok(commit.commitId, 'commit still created');
  eq(Object.keys(commit.files).length, 0, 'no files from bad path');
});

test('vault.fileHistory returns ordered history', () => {
  const fp = path.join(PROJECT_DIR, 'utils.js');
  vault.commit('first', [fp]);
  vault.commit('second', [fp]);
  const hist = vault.fileHistory(fp);
  ok(hist.length >= 2, 'at least 2 entries');
  ok(hist[0].ts >= hist[1].ts, 'newest first');
});

test('vault.diff detects changed content', () => {
  const fp = path.join(PROJECT_DIR, 'index.js');
  const c1 = vault.commit('before', [fp]);
  // Modify in memory
  const original = fs.readFileSync(fp, 'utf8');
  fs.writeFileSync(fp, original + '\n// modified\n');
  const c2 = vault.commit('after', [fp]);
  fs.writeFileSync(fp, original); // restore

  const diff = vault.diff(c1.commitId, c2.commitId, fp);
  ok(diff, 'diff returned');
  ok(diff.changed, 'detects change');
  ok(diff.contentA !== diff.contentB, 'content differs');
});

test('vault.diff returns null for missing commits', () => {
  const d = vault.diff('deadbeef0000', 'cafebabe0000', '/any/path');
  eq(d, null);
});

test('vault.listCommits returns newest first', () => {
  const commits = vault.listCommits();
  ok(commits.length > 0, 'has commits');
  if (commits.length > 1) ok(commits[0].ts >= commits[1].ts, 'sorted newest first');
});

test('vault persists commits across instances', () => {
  const fp = path.join(PROJECT_DIR, 'README.md');
  const c  = vault.commit('persist test', [fp]);
  const vault2 = new FileVault(STORE_DIR);
  ok(vault2._commits.has(c.commitId), 'commit persisted and reloaded');
});

// ── §3 IdeariamBridge ────────────────────────────────────────────────────────
console.log('\n§3 IdeariamBridge');

const bus = new MicroBus();
const idearium = new IdeariamBridge(IDEA_DIR, bus);

test('idearium.pushSnapshot creates snapshot file', () => {
  const s = idearium.pushSnapshot('test snapshot', { author: 'tester' });
  ok(s.snapshotId, 'has snapshotId');
  eq(s.message, 'test snapshot');
  eq(s.source, 'forge');
  ok(fs.existsSync(path.join(IDEA_DIR, 'snapshots', `${s.snapshotId}.json`)), 'file exists');
});

test('idearium.pushSnapshot emits bus event', () => {
  let fired = false;
  const unsub = bus.on('idearium.snapshot.committed', () => { fired = true; });
  idearium.pushSnapshot('event test');
  unsub();
  ok(fired, 'bus event emitted');
});

test('idearium.listSnapshots returns newest first', () => {
  idearium.pushSnapshot('snap A');
  idearium.pushSnapshot('snap B');
  const snaps = idearium.listSnapshots();
  ok(snaps.length >= 2, 'at least 2 snapshots');
  ok(snaps[0].ts >= snaps[1].ts, 'newest first');
});

test('idearium.getSnapshot retrieves by id', () => {
  const s = idearium.pushSnapshot('retrieve test');
  const r = idearium.getSnapshot(s.snapshotId);
  ok(r, 'found');
  eq(r.snapshotId, s.snapshotId);
  eq(r.message, 'retrieve test');
});

test('idearium.getSnapshot returns null for unknown id', () => {
  const r = idearium.getSnapshot('nonexistent123');
  eq(r, null);
});

test('idearium.openGap creates gap and emits event', () => {
  let gapEvent = null;
  const unsub = bus.on('idearium.gap.opened', (ev) => { gapEvent = ev; });
  const gap = idearium.openGap('compile_error', 'Build failed: missing dep', 'HIGH');
  unsub();
  ok(gap.gapId, 'has gapId');
  eq(gap.type, 'compile_error');
  eq(gap.severity, 'HIGH');
  eq(gap.status, 'open');
  ok(gapEvent, 'bus event emitted');
  eq(gapEvent.payload.severity, 'HIGH');
});

test('idearium.openGap appends to gaps.jsonl', () => {
  idearium.openGap('file_friction', 'Test gap');
  const content = fs.readFileSync(path.join(IDEA_DIR, 'gaps.jsonl'), 'utf8');
  ok(content.length > 0, 'gaps file has content');
  const lines = content.trim().split('\n').filter(Boolean);
  ok(lines.length > 0, 'at least one gap line');
  const last = JSON.parse(lines[lines.length - 1]);
  ok(last.gapId, 'valid JSON');
});

test('idearium.resolveGap emits resolved event', () => {
  let resolved = false;
  const unsub = bus.on('idearium.gap.resolved', () => { resolved = true; });
  idearium.resolveGap('some-gap-id');
  unsub();
  ok(resolved, 'resolved event fired');
});

test('idearium snapshots survive restart (persist to disk)', () => {
  const s = idearium.pushSnapshot('persist check');
  const i2 = new IdeariamBridge(IDEA_DIR, bus);
  const loaded = i2.getSnapshot(s.snapshotId);
  ok(loaded, 'snapshot survived restart');
  eq(loaded.message, 'persist check');
});

// ── §4 File Search ────────────────────────────────────────────────────────────
console.log('\n§4 File Search');

test('searchFiles finds by filename', () => {
  const results = searchFiles(PROJECT_DIR, 'utils');
  ok(results.length > 0, 'found results');
  ok(results.some(r => r.name === 'utils.js'), 'found utils.js');
});

test('searchFiles finds by content', () => {
  const results = searchFiles(PROJECT_DIR, 'module.exports');
  ok(results.length > 0, 'found content matches');
  ok(results.every(r => r.type === 'filename' || r.line > 0), 'all have line numbers');
});

test('searchFiles respects maxResults', () => {
  const results = searchFiles(PROJECT_DIR, 'e', 3);
  ok(results.length <= 3, 'respects maxResults');
});

test('searchFiles skips ignored dirs', () => {
  const nmDir = path.join(PROJECT_DIR, 'node_modules', 'pkg');
  fs.mkdirSync(nmDir, { recursive: true });
  fs.writeFileSync(path.join(nmDir, 'index.js'), 'const secret_token = 1;');
  const results = searchFiles(PROJECT_DIR, 'secret_token');
  ok(results.length === 0, 'node_modules skipped');
});

test('searchFiles returns empty for no matches', () => {
  const results = searchFiles(PROJECT_DIR, 'xyzzy_not_found_ever');
  eq(results.length, 0);
});

test('searchFiles returns file + line + text for content match', () => {
  const results = searchFiles(PROJECT_DIR, 'max-width');
  const hit = results.find(r => r.name === 'styles.css');
  ok(hit, 'found in styles.css');
  eq(hit.type, 'content');
  ok(hit.line > 0, 'has line number');
  ok(hit.text.includes('max-width'), 'has matching text');
});

// ── §5 File Tree ──────────────────────────────────────────────────────────────
console.log('\n§5 File Tree');

test('buildTree returns directory node', () => {
  const tree = buildTree(PROJECT_DIR);
  ok(tree, 'tree returned');
  eq(tree.type, 'directory');
  ok(Array.isArray(tree.children), 'has children array');
});

test('buildTree includes project files', () => {
  const tree = buildTree(PROJECT_DIR);
  const names = tree.children.map(c => c.name);
  ok(names.includes('index.js'), 'has index.js');
  ok(names.includes('utils.js'), 'has utils.js');
});

test('buildTree returns file nodes with ext', () => {
  const tree = buildTree(PROJECT_DIR);
  const jsFile = tree.children.find(c => c.name === 'index.js');
  ok(jsFile, 'found index.js');
  eq(jsFile.type, 'file');
  eq(jsFile.ext, '.js');
  ok(jsFile.size > 0, 'has size');
});

test('buildTree ignores node_modules', () => {
  const tree = buildTree(PROJECT_DIR);
  const names = tree.children.map(c => c.name);
  notOk(names.includes('node_modules'), 'node_modules excluded');
});

test('buildTree recurses into src/', () => {
  const tree = buildTree(PROJECT_DIR);
  const src = tree.children.find(c => c.name === 'src');
  ok(src, 'found src directory');
  eq(src.type, 'directory');
  ok(src.children.length > 0, 'src has children');
});

test('buildTree returns null for nonexistent path', () => {
  const r = buildTree('/nonexistent/path/xyz');
  eq(r, null);
});

// ── §6 MicroBus Integration ───────────────────────────────────────────────────
console.log('\n§6 Bus Integration');

test('vault.commit triggers bus via composition', () => {
  const bus2 = new MicroBus();
  let events = [];
  bus2.on('*', (ev) => events.push(ev));

  // Simulate compile pipeline
  bus2.emit('forge.compile.started', { runId: 'r1', command: 'npm test' });
  bus2.emit('forge.compile.done', { runId: 'r1', code: 0, duration: 500 });

  eq(events.length, 2);
  eq(events[0].type, 'forge.compile.started');
  eq(events[1].type, 'forge.compile.done');
  eq(events[1].payload.code, 0);
});

test('idearium gap opens after compile failure', () => {
  const bus3 = new MicroBus();
  const idea = new IdeariamBridge(path.join(TMP, 'idea2'), bus3);
  let gapFired = false;

  bus3.on('idearium.gap.opened', () => { gapFired = true; });

  // Simulate compile failure → gap
  bus3.on('forge.compile.done', (ev) => {
    if (ev.payload.code !== 0) {
      idea.openGap('compile_error', `exit ${ev.payload.code}`, 'HIGH');
    }
  });

  bus3.emit('forge.compile.done', { runId: 'r2', code: 1, duration: 200 });
  ok(gapFired, 'gap opened on compile failure');
});

test('snapshot auto-triggered after successful compile', () => {
  const bus4 = new MicroBus();
  const idea = new IdeariamBridge(path.join(TMP, 'idea3'), bus4);
  let snapFired = false;

  bus4.on('idearium.snapshot.committed', () => { snapFired = true; });

  bus4.on('forge.compile.done', (ev) => {
    if (ev.payload.code === 0) {
      idea.pushSnapshot(`Compile: npm build`, { causedBy: ev.payload.runId });
    }
  });

  bus4.emit('forge.compile.done', { runId: 'r3', code: 0, duration: 100 });
  ok(snapFired, 'snapshot triggered after successful compile');
});

test('file write pipeline: write → vault → snapshot', () => {
  const bus5 = new MicroBus();
  const vault2 = new FileVault(path.join(TMP, 'store2'));
  const idea2 = new IdeariamBridge(path.join(TMP, 'idea4'), bus5);

  let writeEvents = [], snapEvents = [];
  bus5.on('forge.fs.write', ev => writeEvents.push(ev));
  bus5.on('idearium.snapshot.committed', ev => snapEvents.push(ev));

  // Simulate a file write
  const fp = path.join(PROJECT_DIR, 'index.js');
  const content = fs.readFileSync(fp, 'utf8');
  vault2.put(content);
  const snap = idea2.pushSnapshot('Save: index.js', { files: [fp] });
  bus5.emit('forge.fs.write', { path: fp, size: content.length, snapshotId: snap.snapshotId });

  eq(writeEvents.length, 1);
  eq(snapEvents.length, 1);
  eq(writeEvents[0].payload.snapshotId, snap.snapshotId);
});

// ── §7 Event routing ──────────────────────────────────────────────────────────
console.log('\n§7 Event Routing');

test('forge.agents.status routes to pill update', () => {
  const bus6 = new MicroBus();
  let ollamaStatus = null, nexusStatus = null;

  bus6.on('forge.agents.status', (ev) => {
    ollamaStatus = ev.payload.ollama;
    nexusStatus  = ev.payload.nexus;
  });

  bus6.emit('forge.agents.status', { ollama: true, nexus: false });
  eq(ollamaStatus, true, 'ollama online');
  eq(nexusStatus, false, 'nexus offline');
});

test('idearium and forge events coexist on same bus', () => {
  const bus7 = new MicroBus();
  let forgeCount = 0, ideaCount = 0;
  bus7.on('forge.*', () => forgeCount++);
  bus7.on('idearium.*', () => ideaCount++);

  bus7.emit('forge.compile.started', {});
  bus7.emit('forge.fs.write', {});
  bus7.emit('idearium.snapshot.committed', {});
  bus7.emit('idearium.gap.opened', {});

  eq(forgeCount, 2, '2 forge events');
  eq(ideaCount, 2, '2 idearium events');
});

test('event causality chain preserved in payload', () => {
  const bus8 = new MicroBus();
  const events = [];
  bus8.on('*', ev => events.push(ev));

  const e1 = bus8.emit('forge.compile.started', { runId: 'r1' });
  const e2 = bus8.emit('forge.compile.done', { runId: 'r1', causedBy: e1.id, code: 0 });

  eq(e2.payload.causedBy, e1.id, 'causedBy chain preserved');
  eq(events[0].id, e1.id);
  eq(events[1].id, e2.id);
});

// ── §8 API Contract (HTTP surface — format only, no live server) ──────────────
console.log('\n§8 API Contract');

test('api route /api/health returns expected shape', () => {
  // We test the shape contract without a live server
  const mock = { status: 'ok', version: '1.0.0', port: 4242, uptime: 12, agents: { ollama: true, nexus: false }, running: [], clients: 0, ts: Date.now() };
  ok(mock.status === 'ok', 'has status');
  ok(typeof mock.version === 'string', 'has version string');
  ok(Array.isArray(mock.running), 'running is array');
  ok(typeof mock.agents === 'object', 'agents is object');
});

test('api /api/fs/tree response shape is valid', () => {
  const tree = buildTree(PROJECT_DIR);
  const mock = { tree, root: PROJECT_DIR };
  ok(mock.tree, 'has tree');
  ok(mock.root, 'has root');
  eq(mock.tree.type, 'directory');
});

test('api /api/fs/read response shape is valid', () => {
  const fp = path.join(PROJECT_DIR, 'index.js');
  const content = fs.readFileSync(fp, 'utf8');
  const mock = { path: fp, content, ext: '.js', size: content.length, mtime: Date.now() };
  ok(mock.path, 'has path');
  ok(mock.content, 'has content');
  eq(mock.ext, '.js', 'correct ext');
  ok(mock.size > 0, 'has size');
});

test('api /api/idearium/log response shape is valid', () => {
  const snaps = idearium.listSnapshots();
  const mock = { snapshots: snaps, count: snaps.length };
  ok(Array.isArray(mock.snapshots), 'snapshots is array');
  eq(mock.count, snaps.length);
});

test('api /api/revisions response shape is valid', () => {
  const fp = path.join(PROJECT_DIR, 'index.js');
  const hist = vault.fileHistory(fp);
  const mock = { path: fp, history: hist };
  ok(mock.path, 'has path');
  ok(Array.isArray(mock.history), 'history is array');
});

test('api /api/fs/search response shape is valid', () => {
  const results = searchFiles(PROJECT_DIR, 'module');
  const mock = { query: 'module', root: PROJECT_DIR, results, count: results.length };
  ok(mock.query, 'has query');
  ok(Array.isArray(mock.results), 'results is array');
  eq(mock.count, results.length);
});

// ── §9 CLI args parser ────────────────────────────────────────────────────────
console.log('\n§9 CLI Arg Parser');

function parseArgs(argv) {
  const args = [], flags = {}; let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a.startsWith('--')) { const key = a.slice(2); const next = argv[i+1]; if (next && !next.startsWith('--')) { flags[key] = next; i+=2; } else { flags[key] = true; i++; } }
    else { args.push(a); i++; }
  }
  return { args, flags };
}

test('parseArgs separates args and flags', () => {
  const { args, flags } = parseArgs(['import', '/some/path', '--message', 'hello', '--verbose']);
  eq(args[0], 'import');
  eq(args[1], '/some/path');
  eq(flags.message, 'hello');
  eq(flags.verbose, true);
});

test('parseArgs handles no flags', () => {
  const { args, flags } = parseArgs(['status']);
  eq(args[0], 'status');
  eq(Object.keys(flags).length, 0);
});

test('parseArgs handles only flags', () => {
  const { args, flags } = parseArgs(['--port', '4242', '--dev']);
  eq(args.length, 0);
  eq(flags.port, '4242');
  eq(flags.dev, true);
});

// ── §10 Content hash consistency ──────────────────────────────────────────────
console.log('\n§10 Content Addressing');

test('same content always produces same hash', () => {
  const content = 'deterministic content for hashing';
  const h1 = crypto.createHash('sha256').update(content).digest('hex').slice(0,16);
  const h2 = crypto.createHash('sha256').update(content).digest('hex').slice(0,16);
  eq(h1, h2, 'hashes are deterministic');
});

test('different content produces different hashes', () => {
  const h1 = crypto.createHash('sha256').update('content A').digest('hex').slice(0,16);
  const h2 = crypto.createHash('sha256').update('content B').digest('hex').slice(0,16);
  ok(h1 !== h2, 'different content → different hash');
});

test('vault dedup saves disk space', () => {
  const content = 'duplicate content for dedup test';
  vault.put(content); vault.put(content); vault.put(content);
  const objDir = path.join(STORE_DIR, 'objects');
  const hash = crypto.createHash('sha256').update(content).digest('hex').slice(0,16);
  const count = fs.readdirSync(objDir).filter(f => f === hash).length;
  eq(count, 1, 'only one file written for duplicate content');
});

// ── Results ───────────────────────────────────────────────────────────────────
async function main() {
  // Wait for any async tests
  await new Promise(r => setTimeout(r, 100));

  console.log('\n\n╔══════════════════════════════════════════╗');
  console.log('║  RESULTS                                 ║');
  console.log('╠══════════════════════════════════════════╣');

  const failures = results.filter(r => r.ok === false);
  const skips    = results.filter(r => r.ok === null);

  if (failures.length) {
    console.log('║  FAILURES:                               ║');
    for (const f of failures) {
      console.log(`╟  ✗ ${f.name.slice(0, 40).padEnd(40)}`);
      console.log(`║    ${(f.error||'').slice(0,42).padEnd(42)}║`);
    }
    console.log('╠══════════════════════════════════════════╣');
  }

  console.log(`║  Passed:  ${String(passed).padEnd(4)}  Failed: ${String(failed).padEnd(4)}  Skipped: ${String(skipped).padEnd(4)}║`);
  console.log('╚══════════════════════════════════════════╝\n');

  // Cleanup
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}

  if (failed > 0) {
    process.exit(1);
  } else {
    console.log(`✓ All ${passed} tests passed.\n`);
    process.exit(0);
  }
}

main();
