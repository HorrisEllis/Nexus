#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════════════════
// FORGE CLI
// forge-cli.js
//
// Sovereign CLI for the Forge IDE server.
// Connects to forge-server.js API at localhost:4242.
// Bridges to Nexus CLI commands via /api/emit.
//
// Usage:
//   forge status
//   forge import <path> [--message "msg"]
//   forge open <file>
//   forge compile <command>
//   forge snapshot <message>
//   forge rewind <snapshotId>
//   forge agent <prompt> [--agent ollama|nexus|chatgpt|claude|gemini]
//   forge emit <event.type> [--payload '{"key":"val"}']
//   forge events [--n 20]
//   forge health
//   forge serve [--port 4242]
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';

const http  = require('http');
const https = require('https');
const path  = require('path');
const fs    = require('fs');

const FORGE_PORT = parseInt(process.env.FORGE_PORT) || 4242;
const BASE       = `http://localhost:${FORGE_PORT}`;

// ── ANSI ──────────────────────────────────────────────────────────────────────
const C = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  dim:    '\x1b[2m',
  red:    '\x1b[31m',
  green:  '\x1b[32m',
  yellow: '\x1b[33m',
  blue:   '\x1b[34m',
  cyan:   '\x1b[36m',
  magenta:'\x1b[35m',
  gray:   '\x1b[90m',
  white:  '\x1b[97m',
};

function c(col, text) { return `${C[col]||''}${text}${C.reset}`; }
function info(s)  { console.log(c('cyan', '  ◆ ') + s); }
function ok(s)    { console.log(c('green', '  ✓ ') + s); }
function warn(s)  { console.log(c('yellow', '  ⚠ ') + s); }
function err(s)   { console.error(c('red', '  ✗ ') + s); }
function head(s)  { console.log('\n' + c('bold', c('blue', s))); }
function hr()     { console.log(c('gray', '─'.repeat(54))); }

// ── HTTP helpers ──────────────────────────────────────────────────────────────
function api(method, endpoint, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'localhost',
      port:     FORGE_PORT,
      path:     endpoint,
      method,
      headers: {
        'Content-Type':   'application/json',
        'Content-Length': data ? Buffer.byteLength(data) : 0,
      },
    };
    const req = http.request(opts, (res) => {
      let buf = '';
      res.on('data', chunk => buf += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(buf)); }
        catch { resolve(buf); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// ── Arg parser ────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args  = [];
  const flags = {};
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) { flags[key] = next; i += 2; }
      else { flags[key] = true; i++; }
    } else {
      args.push(a); i++;
    }
  }
  return { args, flags };
}

// ── Commands ──────────────────────────────────────────────────────────────────
const COMMANDS = {

  async status() {
    head('FORGE STATUS');
    try {
      const d = await api('GET', '/api/health');
      ok(`Forge IDE v${d.version} running on :${d.port}`);
      info(`Uptime: ${Math.round(d.uptime)}s`);
      info(`SSE clients: ${d.clients}`);
      info(`Active compiles: ${d.running?.length || 0}`);
      hr();
      head('AGENTS');
      for (const [name, alive] of Object.entries(d.agents || {})) {
        (alive ? ok : err)(`${name}: ${alive ? 'online' : 'offline'}`);
      }
    } catch (e) {
      err(`Forge server not reachable on :${FORGE_PORT}`);
      err(`Start with: node forge-server.js`);
      process.exit(1);
    }
  },

  async health() { return COMMANDS.status(); },

  async import(args, flags) {
    const target = args[0] || process.cwd();
    const msg    = flags.message || flags.m || `Import: ${path.basename(target)}`;
    head('IMPORT');
    info(`Target: ${target}`);

    const isDir = fs.existsSync(target) && fs.statSync(target).isDirectory();
    const body  = isDir
      ? { root: path.resolve(target), message: msg }
      : { paths: [path.resolve(target)], message: msg };

    try {
      const d = await api('POST', '/api/fs/import', body);
      ok(`Imported ${d.imported?.length || 0} items`);
      ok(`Commit: ${d.commitId}`);
      ok(`Snapshot: ${d.snapshotId}`);
    } catch (e) { err(e.message); }
  },

  async open(args) {
    const filePath = path.resolve(args[0] || '.');
    head('OPEN');
    try {
      const d = await api('GET', `/api/fs/read?path=${encodeURIComponent(filePath)}`);
      info(`${filePath} (${d.size} bytes)`);
      console.log(d.content.slice(0, 500) + (d.content.length > 500 ? '\n…' : ''));
    } catch (e) { err(e.message); }
  },

  async compile(args, flags) {
    const command = args.join(' ');
    if (!command) { err('Usage: forge compile <command>'); return; }
    head('COMPILE');
    info(`Command: ${command}`);

    try {
      const d = await api('POST', '/api/compile', {
        command,
        cwd: flags.cwd || process.cwd(),
      });
      ok(`Run started: ${d.runId}`);
      info(`Watch output at: http://localhost:${FORGE_PORT}/api/compile/stream`);

      // Stream output via SSE
      const req = http.get(`${BASE}/api/compile/stream`, (res) => {
        res.on('data', (chunk) => {
          const lines = chunk.toString().split('\n');
          for (const line of lines) {
            if (!line.startsWith('data:')) continue;
            try {
              const ev = JSON.parse(line.slice(5));
              if (ev.type === 'compile.output') {
                process[ev.stream === 'stderr' ? 'stderr' : 'stdout'].write(ev.text);
              }
              if (ev.type === 'compile.done') {
                const ok2 = ev.code === 0;
                (ok2 ? ok : err)(`Done (exit ${ev.code}) in ${ev.duration}ms`);
                req.destroy();
                process.exit(ok2 ? 0 : 1);
              }
            } catch {}
          }
        });
      });
      req.on('error', () => {});
    } catch (e) { err(e.message); }
  },

  async snapshot(args, flags) {
    const msg = args.join(' ') || flags.message || 'CLI snapshot';
    head('SNAPSHOT');
    try {
      const d = await api('POST', '/api/idearium/snapshot', { message: msg });
      ok(`Snapshot committed: ${d.snapshot.snapshotId}`);
      info(`Message: ${msg}`);
      info(`Time: ${new Date(d.snapshot.ts).toISOString()}`);
    } catch (e) { err(e.message); }
  },

  async rewind(args) {
    const id = args[0];
    if (!id) { err('Usage: forge rewind <snapshotId>'); return; }
    head('REWIND');
    try {
      const d = await api('POST', '/api/idearium/rewind', { snapshotId: id });
      ok(`Rewound to: ${d.snapshot.snapshotId}`);
      info(`Message: ${d.snapshot.message}`);
    } catch (e) { err(e.message); }
  },

  async log(args, flags) {
    head('IDEARIUM LOG');
    try {
      const d = await api('GET', '/api/idearium/log');
      const n = parseInt(flags.n || '10');
      for (const s of d.snapshots.slice(0, n)) {
        console.log(`  ${c('cyan', s.snapshotId)}  ${c('white', s.message)}`);
        console.log(`  ${c('gray', `${s.source || 'forge'} · ${new Date(s.ts).toLocaleString()}`)}`);
        console.log('');
      }
    } catch (e) { err(e.message); }
  },

  async agent(args, flags) {
    const prompt = args.join(' ');
    if (!prompt) { err('Usage: forge agent <prompt> [--agent ollama]'); return; }
    const ag = flags.agent || flags.a || 'auto';
    head('AGENT');
    info(`Agent: ${ag}`);
    info(`Prompt: ${prompt.slice(0,80)}…`);

    try {
      const d = await api('POST', '/api/agent/complete', { prompt, agent: ag });
      hr();
      console.log(c('green', `[${d.agent}] (${d.latency}ms)\n`));
      console.log(d.content);
    } catch (e) { err(e.message); }
  },

  async emit(args, flags) {
    const type = args[0];
    if (!type) { err('Usage: forge emit <event.type> [--payload \'{"k":"v"}\']'); return; }
    let payload = {};
    try { if (flags.payload) payload = JSON.parse(flags.payload); } catch {}
    try {
      const d = await api('POST', '/api/emit', { type, payload });
      ok(`Emitted: ${type} → ${d.eventId}`);
    } catch (e) { err(e.message); }
  },

  async events(args, flags) {
    head('EVENT LOG');
    const n = parseInt(flags.n || flags.n || '20');
    try {
      const d = await api('GET', `/api/events?n=${n}`);
      for (const ev of d.events.slice(-n)) {
        const ts = new Date(ev.ts).toLocaleTimeString();
        console.log(`${c('gray', ts)}  ${c('cyan', ev.type.padEnd(36))}  ${c('gray', JSON.stringify(ev.payload).slice(0,60))}`);
      }
    } catch (e) { err(e.message); }
  },

  async search(args, flags) {
    const q    = args[0];
    const root = flags.root || process.cwd();
    if (!q) { err('Usage: forge search <query> [--root /path]'); return; }
    head('SEARCH');
    try {
      const d = await api('GET', `/api/fs/search?q=${encodeURIComponent(q)}&root=${encodeURIComponent(root)}`);
      info(`${d.count} results for "${q}" in ${root}`);
      hr();
      for (const r of d.results.slice(0, 30)) {
        console.log(`  ${c('cyan', r.name)}  ${c('gray', r.path)}`);
        if (r.line) console.log(`    ${c('yellow', `L${r.line}`)}  ${c('gray', r.text)}`);
      }
    } catch (e) { err(e.message); }
  },

  async serve(args, flags) {
    const port = flags.port || FORGE_PORT;
    process.env.FORGE_PORT = port;
    head(`FORGE SERVER`);
    info(`Starting on port ${port}…`);
    require('./forge-server.js');
  },

  help() {
    head('FORGE IDE CLI');
    hr();
    const cmds = [
      ['status',   'Show server health and agent status'],
      ['import',   '<path> [--message]  Import project or files'],
      ['open',     '<file>              Read file contents'],
      ['compile',  '<command>           Run build command, stream output'],
      ['snapshot', '<message>           Push Idearium snapshot'],
      ['rewind',   '<snapshotId>        Restore a snapshot'],
      ['log',      '[--n 10]            Show Idearium snapshot log'],
      ['agent',    '<prompt> [--agent]  Query Ollama/Nexus/cloud agent'],
      ['emit',     '<type> [--payload]  Emit event to Forge/Nexus bus'],
      ['events',   '[--n 20]            Show recent bus events'],
      ['search',   '<q> [--root]        Code-aware full-text search'],
      ['serve',    '[--port 4242]       Start the Forge server'],
    ];
    for (const [cmd, desc] of cmds) {
      console.log(`  ${c('cyan', ('forge ' + cmd).padEnd(20))}  ${c('gray', desc)}`);
    }
    hr();
    info('Forge UI: http://localhost:4242');
    info('Nexus:    http://localhost:3748/admin');
  },
};

// ── Main ──────────────────────────────────────────────────────────────────────
async function main() {
  const argv = process.argv.slice(2);
  const { args, flags } = parseArgs(argv);
  const cmd = args[0] || 'help';
  const rest = args.slice(1);

  const fn = COMMANDS[cmd];
  if (!fn) {
    err(`Unknown command: ${cmd}`);
    COMMANDS.help();
    process.exit(1);
  }

  try {
    await fn(rest, flags);
  } catch (e) {
    err(e.message);
    process.exit(1);
  }
}

main();
