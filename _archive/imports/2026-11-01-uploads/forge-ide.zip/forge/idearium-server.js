#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════════════════
// IDEARIUM SERVER
// idearium-server.js
//
// Sovereign Idearium HTTP server.
// Exposes the full Idearium data pipeline over HTTP + SSE.
// Connects to: Forge (port 4242) · Nexus (port 3748)
//
// This is the living memory layer — every idea, gap, snapshot, tension score,
// compartment, and pendulum signal flows through here.
//
// PORT: 5151
//
// API ROUTES:
//   GET  /api/stream             — SSE event stream (live idearium bus)
//   GET  /api/health             — health + stats
//
//   IDEAS:
//   POST /api/ideas              — create idea { name, intent, body, tags, compartment, coreFiles }
//   GET  /api/ideas              — list ideas [?tension&tag&status&compartment]
//   GET  /api/ideas/:uuid        — get idea by uuid
//   PUT  /api/ideas/:uuid        — update idea fields
//   POST /api/ideas/:uuid/link   — link two ideas { targetUuid, type: resonance|tension }
//   POST /api/ideas/:uuid/observe— pendulum observation { value, source }
//
//   SNAPSHOTS:
//   POST /api/snapshots          — commit snapshot { message, author }
//   GET  /api/snapshots          — list snapshots [?n=20]
//   GET  /api/snapshots/:id      — get full snapshot
//   POST /api/snapshots/:id/restore — restore state from snapshot
//   GET  /api/snapshots/diff     — diff two snapshots ?from=&to=
//
//   GAPS:
//   POST /api/gaps               — open gap { type, description, severity, between }
//   GET  /api/gaps               — list gaps [?status=open|resolved]
//   POST /api/gaps/:id/resolve   — resolve gap
//
//   COMPARTMENTS:
//   POST /api/compartments       — create compartment { name, intent, coreFiles }
//   GET  /api/compartments       — list compartments
//   POST /api/compartments/:uuid/assign — assign idea to compartment { ideaUuid }
//   POST /api/compartments/scan  — scan for boundary gaps
//
//   TENSION:
//   GET  /api/tension            — get tension scores for all ideas (ranked)
//   GET  /api/tension/:uuid      — tension score for specific idea
//
//   EMIT:
//   POST /api/emit               — inject event into bus (Nexus/Forge bridge)
//   GET  /api/events             — recent bus events [?n=100]
//
// CLI PIPE PROTOCOL:
//   Forge → POST /api/emit with forge.* events
//   Nexus → POST /api/emit with nexus.* events
//   Idearium → forwards relevant events to Nexus at :3748
//
// §I1  Every idea is a node. Every node has a rhythm.
// §I2  Friction is information. High tension rises.
// §I3  The gap between compartments is first-class.
// §I4  Append-only. Never overwrite. Only accumulate.
// §I5  Cause precedes effect. Always.
// §F1  All state changes emit before returning.
// §F2  SSE streams all events in real time.
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';

const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

const PORT         = parseInt(process.env.IDEARIUM_PORT)  || 5151;
const NEXUS_URL    = process.env.NEXUS_URL                || 'http://localhost:3748';
const FORGE_URL    = process.env.FORGE_URL                || 'http://localhost:4242';
const DATA_DIR     = process.env.IDEARIUM_DATA            || path.join(process.cwd(), '.idearium');
const VERSION      = '1.0.0';
const MAX_SSE      = 64;

// ── Ensure data dirs ──────────────────────────────────────────────────────────
const SNAPSHOT_DIR = path.join(DATA_DIR, 'snapshots');
const IDEAS_FILE   = path.join(DATA_DIR, 'ideas.jsonl');
const GAPS_FILE    = path.join(DATA_DIR, 'gaps.jsonl');
const PEND_FILE    = path.join(DATA_DIR, 'pendulum-data.json');
const COMP_FILE    = path.join(DATA_DIR, 'compartments.json');

for (const d of [DATA_DIR, SNAPSHOT_DIR]) fs.mkdirSync(d, { recursive: true });

// ── MicroBus ──────────────────────────────────────────────────────────────────
class MicroBus {
  constructor() { this._listeners = new Map(); this._log = []; this._seq = 0; }
  emit(type, payload = {}) {
    const ev = Object.freeze({ id: `idr-${(++this._seq).toString(36).padStart(6,'0')}`, type, payload, ts: Date.now() });
    this._log.push(ev); if (this._log.length > 8000) this._log.shift();
    for (const [pat, fns] of this._listeners) {
      if (type === pat || pat === '*' || (pat.endsWith('*') && type.startsWith(pat.slice(0,-1)))) {
        for (const fn of fns) { try { fn(ev); } catch (e) { console.error('[idearium-bus]', e.message); } }
      }
    }
    return ev;
  }
  on(pattern, fn) {
    if (!this._listeners.has(pattern)) this._listeners.set(pattern, []);
    this._listeners.get(pattern).push(fn);
    return () => { const fns = this._listeners.get(pattern)||[]; this._listeners.set(pattern, fns.filter(f=>f!==fn)); };
  }
  recent(n = 100) { return this._log.slice(-n); }
}

const bus = new MicroBus();

// ── SSE ───────────────────────────────────────────────────────────────────────
const sseClients = new Set();

function sseSetup(res) {
  if (sseClients.size >= MAX_SSE) { res.writeHead(503); res.end('Too many clients'); return false; }
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'Access-Control-Allow-Origin': '*' });
  res.flushHeaders?.();
  sseClients.add(res);
  res.on('close', () => sseClients.delete(res));
  for (const ev of bus.recent(20)) res.write(`data: ${JSON.stringify(ev)}\n\n`);
  return true;
}

bus.on('*', (ev) => {
  const payload = `data: ${JSON.stringify(ev)}\n\n`;
  for (const res of sseClients) { try { res.write(payload); } catch {} }
});

setInterval(() => {
  const ping = `data: ${JSON.stringify({ type: 'idearium.ping', ts: Date.now() })}\n\n`;
  for (const res of sseClients) { try { res.write(ping); } catch {} }
}, 15_000);

// ── Pendulum (lightweight rhythm tracker) ─────────────────────────────────────
class PendulumTracker {
  constructor() {
    this._signals = this._load();
  }
  observe(signalId, value, source) {
    if (!this._signals[signalId]) {
      this._signals[signalId] = { signalId, observations: [], phase: 'seed', tensionScore: 0, lastObserved: null };
    }
    const sig = this._signals[signalId];
    sig.observations.push({ value, source, ts: Date.now() });
    if (sig.observations.length > 100) sig.observations.shift();
    sig.lastObserved = Date.now();
    sig.tensionScore = this._computeTension(sig);
    sig.phase = this._computePhase(sig);
    this._save();
    bus.emit('idearium.pendulum.observed', { signalId, value, source, phase: sig.phase, tensionScore: sig.tensionScore });
    return sig;
  }
  profile(signalId) {
    const sig = this._signals[signalId];
    if (!sig) return null;
    return { signalId, phase: sig.phase, tensionScore: sig.tensionScore, lastObserved: sig.lastObserved, observations: sig.observations.slice(-5) };
  }
  snapshot() { return { ...this._signals }; }
  _computeTension(sig) {
    const n = sig.observations.length;
    if (n < 2) return 0;
    const recent = sig.observations.slice(-5).map(o => o.value);
    const variance = this._variance(recent);
    const freq = n > 10 ? Math.min(n / 20, 1) : n / 10;
    return Math.min(Math.round((variance * 0.6 + freq * 0.4) * 100) / 100, 1.0);
  }
  _computePhase(sig) {
    const n = sig.observations.length;
    if (n < 3) return 'rising';
    const recent = sig.observations.slice(-3).map(o => o.value);
    const delta1 = recent[1] - recent[0];
    const delta2 = recent[2] - recent[1];
    if (delta1 > 0 && delta2 > 0) return 'rising';
    if (delta1 < 0 && delta2 < 0) return 'falling';
    if (delta2 > delta1) return 'peak';
    return 'trough';
  }
  _variance(arr) {
    if (!arr.length) return 0;
    const mean = arr.reduce((a,b) => a+b, 0) / arr.length;
    return arr.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / arr.length;
  }
  _load() {
    try { return JSON.parse(fs.readFileSync(PEND_FILE, 'utf8')); } catch { return {}; }
  }
  _save() { try { fs.writeFileSync(PEND_FILE, JSON.stringify(this._signals, null, 2)); } catch {} }
}

const pendulum = new PendulumTracker();

// ── Ideas store ───────────────────────────────────────────────────────────────
class IdeaStore {
  constructor() {
    this._ideas = this._load();
  }
  create({ name, intent, body = '', tags = [], coreFiles = [], compartment = null, resonanceWith = [], tensionWith = [], causalAncestry = [] }) {
    const uuid = crypto.randomUUID();
    const idea = {
      uuid, slug: this._slug(name), intent, body, status: 'seed',
      tags, coreFiles, resonanceWith, tensionWith, compartment,
      causalAncestry, createdAt: Date.now(), updatedAt: Date.now(),
    };
    this._ideas.set(uuid, idea);
    this._append(idea);
    bus.emit('idearium.idea.created', { uuid, slug: idea.slug, intent, compartment });
    return idea;
  }
  update(uuid, patch) {
    const idea = this._ideas.get(uuid);
    if (!idea) return null;
    const prev = { ...idea };
    for (const [k, v] of Object.entries(patch)) {
      if (k === 'uuid' || k === 'createdAt') continue;
      if (idea[k] !== v) {
        bus.emit('idearium.idea.updated', { uuid, slug: idea.slug, field: k, from: idea[k], to: v });
        idea[k] = v;
      }
    }
    idea.updatedAt = Date.now();
    this._ideas.set(uuid, idea);
    if (prev.status !== idea.status) {
      bus.emit('idearium.idea.status.changed', { uuid, slug: idea.slug, from: prev.status, to: idea.status });
    }
    return idea;
  }
  link(uuidA, uuidB, type = 'resonance') {
    const a = this._ideas.get(uuidA);
    const b = this._ideas.get(uuidB);
    if (!a || !b) return null;
    const field = type === 'tension' ? 'tensionWith' : 'resonanceWith';
    if (!(a[field] || []).includes(uuidB)) {
      a[field] = [...(a[field] || []), uuidB];
      a.updatedAt = Date.now();
    }
    if (!(b[field] || []).includes(uuidA)) {
      b[field] = [...(b[field] || []), uuidA];
      b.updatedAt = Date.now();
    }
    bus.emit('idearium.idea.linked', { uuidA, uuidB, type });
    return { a, b };
  }
  get(uuid) { return this._ideas.get(uuid) || null; }
  all() { return [...this._ideas.values()]; }
  query({ status, tag, compartment } = {}) {
    let ideas = [...this._ideas.values()];
    if (status)      ideas = ideas.filter(i => i.status === status);
    if (tag)         ideas = ideas.filter(i => (i.tags||[]).includes(tag));
    if (compartment) ideas = ideas.filter(i => i.compartment === compartment);
    return ideas;
  }
  _slug(name) {
    return name.toLowerCase().replace(/[^a-z0-9\s-]/g,'').replace(/\s+/g,'-').slice(0,48);
  }
  _append(idea) {
    fs.appendFileSync(IDEAS_FILE, JSON.stringify(idea) + '\n');
  }
  _load() {
    const map = new Map();
    try {
      const lines = fs.readFileSync(IDEAS_FILE, 'utf8').trim().split('\n').filter(Boolean);
      for (const line of lines) {
        try { const i = JSON.parse(line); map.set(i.uuid, i); } catch {}
      }
    } catch {}
    return map;
  }
}

const ideas = new IdeaStore();

// ── Gap store ─────────────────────────────────────────────────────────────────
class GapStore {
  constructor() { this._gaps = this._load(); }
  open({ type, description, severity = 'MEDIUM', between = [], causedBy = null, source = 'idearium' }) {
    const gap = { gapId: crypto.randomUUID(), type, description, severity, status: 'open', between, causedBy, source, openedAt: Date.now(), resolvedAt: null, resolvedBy: null };
    this._gaps.set(gap.gapId, gap);
    fs.appendFileSync(GAPS_FILE, JSON.stringify(gap) + '\n');
    bus.emit('idearium.gap.opened', { gapId: gap.gapId, type, between, severity });
    return gap;
  }
  resolve(gapId, resolvedBy = null) {
    const gap = this._gaps.get(gapId);
    if (!gap) return null;
    gap.status = 'resolved'; gap.resolvedAt = Date.now(); gap.resolvedBy = resolvedBy;
    bus.emit('idearium.gap.resolved', { gapId, resolvedBy });
    return gap;
  }
  query({ status } = {}) {
    let list = [...this._gaps.values()];
    if (status) list = list.filter(g => g.status === status);
    return list;
  }
  get(gapId) { return this._gaps.get(gapId) || null; }
  open_list() { return [...this._gaps.values()].filter(g => g.status === 'open'); }
  _load() {
    const map = new Map();
    try {
      const lines = fs.readFileSync(GAPS_FILE, 'utf8').trim().split('\n').filter(Boolean);
      for (const line of lines) { try { const g = JSON.parse(line); map.set(g.gapId, g); } catch {} }
    } catch {}
    return map;
  }
}

const gapStore = new GapStore();

// ── Tension scorer ────────────────────────────────────────────────────────────
function tensionScore(idea) {
  let t = 0;
  const openGaps = gapStore.open_list();

  // Gap density
  const myGaps = openGaps.filter(g => g.between.includes(idea.uuid));
  t += Math.min(myGaps.length * 0.15, 0.45);

  // Pendulum tension
  const prof = pendulum.profile(idea.uuid);
  if (prof?.tensionScore) t += prof.tensionScore * 0.25;

  // Contradiction load
  const contradictions = (idea.tensionWith || []).filter(uid => {
    const other = ideas.get(uid);
    return other && other.status !== 'dissolved';
  });
  t += Math.min(contradictions.length * 0.1, 0.2);

  // Age vs activity — stale seeds
  const staleDays = (Date.now() - idea.updatedAt) / (1000 * 60 * 60 * 24);
  if (staleDays > 7 && idea.status === 'seed') t += 0.1;

  // File friction
  const fileFriction = openGaps.filter(g =>
    g.type === 'file_friction' && g.between.some(b => (idea.coreFiles || []).includes(b))
  );
  t += Math.min(fileFriction.length * 0.1, 0.2);

  return Math.min(Math.round(t * 100) / 100, 1.0);
}

// ── Compartments ──────────────────────────────────────────────────────────────
class CompartmentStore {
  constructor() { this._comps = this._load(); }
  create({ name, intent, coreFiles = [] }) {
    const uuid = crypto.randomUUID();
    const comp = { uuid, name, intent, coreFiles, ideas: [], createdAt: Date.now() };
    this._comps.set(uuid, comp); this._save();
    bus.emit('idearium.compartment.born', { uuid, name, intent });
    return comp;
  }
  assign(ideaUuid, compUuid) {
    const comp = this._comps.get(compUuid);
    if (!comp) throw new Error(`Unknown compartment: ${compUuid}`);
    if (!comp.ideas.includes(ideaUuid)) comp.ideas.push(ideaUuid);
    this._save();
    bus.emit('idearium.compartment.idea.assigned', { ideaUuid, compUuid });
    return comp;
  }
  scanBoundaryGaps() {
    const found = [];
    const allIdeas = ideas.all();
    for (const [, comp] of this._comps) {
      for (const [, other] of this._comps) {
        if (comp.uuid === other.uuid) continue;
        // Intent overlap
        const overlap = _intentSim(comp.intent, other.intent);
        if (overlap > 0.7) found.push({ type: 'boundary_gap', subtype: 'intent_overlap', between: [comp.uuid, other.uuid], description: `"${comp.name}" and "${other.name}" have overlapping intent`, severity: 'MEDIUM' });
        // Unlinked resonance across boundary
        const compIdeas  = allIdeas.filter(i => i.compartment === comp.uuid);
        const otherIdeas = allIdeas.filter(i => i.compartment === other.uuid);
        for (const a of compIdeas) {
          for (const b of otherIdeas) {
            const linked = (a.resonanceWith||[]).includes(b.uuid) || (b.resonanceWith||[]).includes(a.uuid);
            const shared = (a.tags||[]).filter(t => (b.tags||[]).includes(t));
            if (!linked && shared.length >= 2) found.push({ type: 'boundary_gap', subtype: 'unlinked_resonance', between: [a.uuid, b.uuid], description: `"${a.slug}" and "${b.slug}" share [${shared.join(',')}] across boundary`, severity: 'LOW' });
          }
        }
      }
    }
    return found;
  }
  list() { return [...this._comps.values()]; }
  get(uuid) { return this._comps.get(uuid) || null; }
  _load() {
    try { const d = JSON.parse(fs.readFileSync(COMP_FILE, 'utf8')); return new Map(Object.entries(d)); } catch { return new Map(); }
  }
  _save() { try { fs.writeFileSync(COMP_FILE, JSON.stringify(Object.fromEntries(this._comps), null, 2)); } catch {} }
}

function _intentSim(a = '', b = '') {
  const stop = new Set(['a','an','the','is','are','to','for','with','and','or','of','in','that','this','by']);
  const tok = s => s.toLowerCase().split(/\W+/).filter(w => w.length > 3 && !stop.has(w));
  const tA = tok(a), tB = tok(b);
  const shared = tA.filter(w => tB.includes(w));
  return (shared.length * 2) / (tA.length + tB.length + 0.001);
}

const compartments = new CompartmentStore();

// ── Snapshot engine ───────────────────────────────────────────────────────────
class SnapshotEngine {
  commit(message, opts = {}) {
    const { author = 'idearium', causedBy = null } = opts;
    const ideaList = ideas.all();
    const gapList  = gapStore.open_list();
    const pendSnap = pendulum.snapshot();
    const scores   = {};
    for (const idea of ideaList) scores[idea.uuid] = tensionScore(idea);

    const payload = { message, causedBy, author, ts: Date.now(), ideas: ideaList, gaps: gapList, pendulum: pendSnap, tension: scores };
    const hash = crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex').slice(0, 16);
    const snap = { snapshotId: hash, ...payload };
    fs.writeFileSync(path.join(SNAPSHOT_DIR, `${hash}.json`), JSON.stringify(snap, null, 2));
    bus.emit('idearium.snapshot.committed', { snapshotId: hash, message, ts: snap.ts, author });
    return snap;
  }

  list(n = 50) {
    try {
      return fs.readdirSync(SNAPSHOT_DIR).filter(f => f.endsWith('.json'))
        .map(f => { try { const s = JSON.parse(fs.readFileSync(path.join(SNAPSHOT_DIR, f), 'utf8')); return { snapshotId: s.snapshotId, message: s.message, ts: s.ts, author: s.author }; } catch { return null; } })
        .filter(Boolean).sort((a,b) => b.ts - a.ts).slice(0, n);
    } catch { return []; }
  }

  get(id) {
    try { return JSON.parse(fs.readFileSync(path.join(SNAPSHOT_DIR, `${id}.json`), 'utf8')); } catch { return null; }
  }

  diff(hashA, hashB) {
    const a = this.get(hashA); const b = this.get(hashB);
    if (!a || !b) return null;
    const mapA = new Map((a.ideas||[]).map(i => [i.uuid, i]));
    const mapB = new Map((b.ideas||[]).map(i => [i.uuid, i]));
    const added   = [...mapB.values()].filter(i => !mapA.has(i.uuid));
    const removed = [...mapA.values()].filter(i => !mapB.has(i.uuid));
    const changed = [...mapB.values()].filter(i => { const prev = mapA.get(i.uuid); return prev && prev.updatedAt !== i.updatedAt; });
    const tensionDelta = {};
    for (const [uuid, scoreB] of Object.entries(b.tension || {})) {
      const scoreA = a.tension?.[uuid] ?? 0;
      if (Math.abs(scoreB - scoreA) > 0.05) tensionDelta[uuid] = { from: scoreA, to: scoreB, delta: scoreB - scoreA };
    }
    return { from: hashA, to: hashB, added, removed, changed, tensionDelta, gapDelta: { opened: (b.gaps||[]).filter(g => !(a.gaps||[]).find(ag => ag.gapId === g.gapId)), resolved: (a.gaps||[]).filter(g => !(b.gaps||[]).find(bg => bg.gapId === g.gapId)) } };
  }

  restore(id) {
    const snap = this.get(id);
    if (!snap) return null;
    bus.emit('idearium.snapshot.restored', { snapshotId: id, message: snap.message, ts: snap.ts });
    return snap;
  }
}

const snapshots = new SnapshotEngine();

// ── HTTP ──────────────────────────────────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 5_000_000) reject(new Error('Too large')); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}

function json(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

function err(res, message, status = 400) { json(res, { error: message }, status); }

function cors(res) { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }); res.end(); }

const server = http.createServer(async (req, res) => {
  const url    = new URL(req.url, `http://localhost:${PORT}`);
  const method = req.method.toUpperCase();
  const p      = url.pathname;

  if (method === 'OPTIONS') { cors(res); return; }
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    // SSE
    if (p === '/api/stream' && method === 'GET') { sseSetup(res); return; }

    // Health
    if (p === '/api/health' && method === 'GET') {
      json(res, { status: 'ok', version: VERSION, port: PORT, uptime: process.uptime(), ideas: ideas.all().length, gaps: gapStore.open_list().length, snapshots: snapshots.list(3).length, clients: sseClients.size, ts: Date.now() });
      return;
    }

    // ── Ideas ──────────────────────────────────────────────────────────────
    if (p === '/api/ideas' && method === 'POST') {
      const body = await readBody(req);
      if (!body.name || !body.intent) { err(res, 'name and intent required'); return; }
      const idea = ideas.create(body);
      json(res, { ok: true, idea }, 201);
      return;
    }

    if (p === '/api/ideas' && method === 'GET') {
      const status   = url.searchParams.get('status');
      const tag      = url.searchParams.get('tag');
      const comp     = url.searchParams.get('compartment');
      const byTension = url.searchParams.get('tension') === '1';
      let list = ideas.query({ status, tag, compartment: comp });
      if (byTension) {
        list = list.map(i => ({ ...i, _tension: tensionScore(i) })).sort((a,b) => b._tension - a._tension);
      }
      json(res, { ideas: list, count: list.length });
      return;
    }

    const ideaMatch = p.match(/^\/api\/ideas\/([^/]+)$/);
    if (ideaMatch) {
      const uuid = ideaMatch[1];
      if (method === 'GET') {
        const idea = ideas.get(uuid);
        if (!idea) { err(res, 'Not found', 404); return; }
        const score = tensionScore(idea);
        const prof  = pendulum.profile(uuid);
        json(res, { idea, tension: score, pendulum: prof });
        return;
      }
      if (method === 'PUT') {
        const body = await readBody(req);
        const updated = ideas.update(uuid, body);
        if (!updated) { err(res, 'Not found', 404); return; }
        json(res, { ok: true, idea: updated });
        return;
      }
    }

    const linkMatch = p.match(/^\/api\/ideas\/([^/]+)\/link$/);
    if (linkMatch && method === 'POST') {
      const body = await readBody(req);
      const result = ideas.link(linkMatch[1], body.targetUuid, body.type || 'resonance');
      if (!result) { err(res, 'One or both ideas not found', 404); return; }
      json(res, { ok: true });
      return;
    }

    const observeMatch = p.match(/^\/api\/ideas\/([^/]+)\/observe$/);
    if (observeMatch && method === 'POST') {
      const body = await readBody(req);
      const sig = pendulum.observe(observeMatch[1], body.value, body.source || 'api');
      json(res, { ok: true, signal: sig });
      return;
    }

    // ── Snapshots ──────────────────────────────────────────────────────────
    if (p === '/api/snapshots' && method === 'POST') {
      const body = await readBody(req);
      const snap = snapshots.commit(body.message || 'Manual snapshot', { author: body.author });
      json(res, { ok: true, snapshot: { snapshotId: snap.snapshotId, message: snap.message, ts: snap.ts } }, 201);
      return;
    }

    if (p === '/api/snapshots' && method === 'GET') {
      const n = parseInt(url.searchParams.get('n') || '50');
      json(res, { snapshots: snapshots.list(n) });
      return;
    }

    if (p === '/api/snapshots/diff' && method === 'GET') {
      const from = url.searchParams.get('from');
      const to   = url.searchParams.get('to');
      if (!from || !to) { err(res, 'from and to required'); return; }
      const diff = snapshots.diff(from, to);
      if (!diff) { err(res, 'Could not compute diff', 404); return; }
      json(res, { diff });
      return;
    }

    const snapMatch = p.match(/^\/api\/snapshots\/([^/]+)$/);
    if (snapMatch) {
      if (method === 'GET') {
        const snap = snapshots.get(snapMatch[1]);
        if (!snap) { err(res, 'Not found', 404); return; }
        json(res, { snapshot: snap });
        return;
      }
    }

    const restoreMatch = p.match(/^\/api\/snapshots\/([^/]+)\/restore$/);
    if (restoreMatch && method === 'POST') {
      const snap = snapshots.restore(restoreMatch[1]);
      if (!snap) { err(res, 'Not found', 404); return; }
      json(res, { ok: true, snapshot: { snapshotId: snap.snapshotId, message: snap.message, ts: snap.ts } });
      return;
    }

    // ── Gaps ──────────────────────────────────────────────────────────────
    if (p === '/api/gaps' && method === 'POST') {
      const body = await readBody(req);
      const gap = gapStore.open(body);
      json(res, { ok: true, gap }, 201);
      return;
    }

    if (p === '/api/gaps' && method === 'GET') {
      const status = url.searchParams.get('status');
      json(res, { gaps: gapStore.query({ status: status || undefined }) });
      return;
    }

    const resolveMatch = p.match(/^\/api\/gaps\/([^/]+)\/resolve$/);
    if (resolveMatch && method === 'POST') {
      const body = await readBody(req);
      const gap = gapStore.resolve(resolveMatch[1], body.resolvedBy);
      if (!gap) { err(res, 'Not found', 404); return; }
      json(res, { ok: true, gap });
      return;
    }

    // ── Compartments ───────────────────────────────────────────────────────
    if (p === '/api/compartments' && method === 'POST') {
      const body = await readBody(req);
      if (!body.name || !body.intent) { err(res, 'name and intent required'); return; }
      const comp = compartments.create(body);
      json(res, { ok: true, compartment: comp }, 201);
      return;
    }

    if (p === '/api/compartments' && method === 'GET') {
      json(res, { compartments: compartments.list() });
      return;
    }

    if (p === '/api/compartments/scan' && method === 'POST') {
      const found = compartments.scanBoundaryGaps();
      // Auto-open gaps for critical boundary issues
      for (const f of found.filter(g => g.severity === 'MEDIUM')) {
        gapStore.open({ type: f.type, description: f.description, severity: f.severity, between: f.between, source: 'compartment-scan' });
      }
      json(res, { found, opened: found.filter(g => g.severity === 'MEDIUM').length });
      return;
    }

    const assignMatch = p.match(/^\/api\/compartments\/([^/]+)\/assign$/);
    if (assignMatch && method === 'POST') {
      const body = await readBody(req);
      const comp = compartments.assign(body.ideaUuid, assignMatch[1]);
      if (!comp) { err(res, 'Not found', 404); return; }
      json(res, { ok: true });
      return;
    }

    // ── Tension ────────────────────────────────────────────────────────────
    if (p === '/api/tension' && method === 'GET') {
      const list = ideas.all().map(i => ({ uuid: i.uuid, slug: i.slug, intent: i.intent, status: i.status, tension: tensionScore(i) })).sort((a,b) => b.tension - a.tension);
      bus.emit('idearium.tension.recalculated', { count: list.length, top: list.slice(0,3).map(i=>({ uuid: i.uuid, tension: i.tension })) });
      json(res, { ideas: list });
      return;
    }

    const tensionMatch = p.match(/^\/api\/tension\/([^/]+)$/);
    if (tensionMatch && method === 'GET') {
      const idea = ideas.get(tensionMatch[1]);
      if (!idea) { err(res, 'Not found', 404); return; }
      const score = tensionScore(idea);
      json(res, { uuid: idea.uuid, slug: idea.slug, tension: score, pendulum: pendulum.profile(idea.uuid) });
      return;
    }

    // ── Event bus ──────────────────────────────────────────────────────────
    if (p === '/api/emit' && method === 'POST') {
      const body = await readBody(req);
      const ev = bus.emit(body.type || 'idearium.external', body.payload || {});
      // Forward to Nexus
      try {
        fetch(`${NEXUS_URL}/api/emit`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: body.type, payload: body.payload }), signal: AbortSignal.timeout(1000) }).catch(() => {});
      } catch {}
      json(res, { ok: true, eventId: ev.id });
      return;
    }

    if (p === '/api/events' && method === 'GET') {
      const n = parseInt(url.searchParams.get('n') || '100');
      json(res, { events: bus.recent(n) });
      return;
    }

    res.writeHead(404); res.end('Not found');

  } catch (e) {
    console.error('[idearium-server]', e.message);
    err(res, e.message, 500);
  }
});

// ── Forge SSE bridge: forward relevant events from Forge bus ──────────────────
async function forgeBridge() {
  try {
    const res = await fetch(`${FORGE_URL}/api/stream`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error('non-200');
    // Pipe forge events into idearium bus
    let buf = '';
    for await (const chunk of res.body) {
      buf += chunk.toString();
      const lines = buf.split('\n\n');
      buf = lines.pop();
      for (const block of lines) {
        const dataLine = block.split('\n').find(l => l.startsWith('data:'));
        if (!dataLine) continue;
        try {
          const ev = JSON.parse(dataLine.slice(5));
          if (ev.type?.startsWith('forge.')) {
            bus.emit(ev.type, { ...ev.payload, _bridged: 'forge' });
          }
        } catch {}
      }
    }
  } catch {
    setTimeout(forgeBridge, 30_000);
  }
}

// ── Nexus emit bridge ─────────────────────────────────────────────────────────
bus.on('idearium.*', async (ev) => {
  try {
    await fetch(`${NEXUS_URL}/api/emit`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: ev.type, payload: ev.payload }),
      signal: AbortSignal.timeout(1000),
    });
  } catch {}
});

// ── Boot ──────────────────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  bus.emit('idearium.server.booted', { port: PORT, version: VERSION, dataDir: DATA_DIR, ideas: ideas.all().length });

  console.log(`\n╔═══════════════════════════════════════════╗`);
  console.log(`║  IDEARIUM SERVER  v${VERSION}              ║`);
  console.log(`╠═══════════════════════════════════════════╣`);
  console.log(`║  API  → http://localhost:${PORT}            ║`);
  console.log(`║  SSE  → http://localhost:${PORT}/api/stream ║`);
  console.log(`║  Data → ${DATA_DIR.slice(0,36).padEnd(36)} ║`);
  console.log(`║  Nexus→ ${NEXUS_URL.padEnd(36)} ║`);
  console.log(`║  Forge→ ${FORGE_URL.padEnd(36)} ║`);
  console.log(`╚═══════════════════════════════════════════╝\n`);

  console.log(`[idearium] ${ideas.all().length} ideas · ${gapStore.open_list().length} open gaps · ${snapshots.list(1).length} snapshots`);

  // Try Forge bridge
  setTimeout(() => forgeBridge().catch(() => {}), 3000);
});

server.on('error', (e) => { console.error('[idearium-server] Error:', e.message); process.exit(1); });

module.exports = { server, bus, ideas, gapStore, snapshots, compartments, pendulum };
