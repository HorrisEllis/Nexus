#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════════════════
// FORGE — Sovereign IDE Server
// forge-server.js
//
// A sovereign, event-driven IDE backend.
// Connects: Nexus (orchestration) · Idearium (idea/revision tracking)
//           Ollama (local LLM) · Guardian (cloud agents)
//
// ARCHITECTURE:
//   Port 4242  — Forge HTTP API + SSE event stream + static file server
//   MicroBus   — internal event bus (SISO-compatible with Nexus kernel)
//   FileVault  — sovereign file store (reads/writes real project files)
//   Versionium — revision history (hooks into Idearium snapshots)
//   Compiler   — run arbitrary build commands, stream output via SSE
//   AgentBus   — fan-out to Ollama/Nexus/Guardian
//
// API ROUTES:
//   GET  /api/stream              — SSE event stream (live bus events)
//   GET  /api/health              — health + uptime
//   GET  /api/fs/tree?root=<path> — directory tree
//   GET  /api/fs/read?path=<path> — file content
//   POST /api/fs/write            — { path, content } write file
//   POST /api/fs/import           — { paths: [...] } import project/files
//   GET  /api/fs/search?q=<query>&root=<path> — code-aware search
//   POST /api/compile             — { command, cwd } run build command
//   GET  /api/compile/stream      — SSE for compiler output
//   POST /api/agent/complete      — { prompt, agent } → Ollama/Nexus/Guardian
//   POST /api/idearium/snapshot   — { message } push idearium snapshot
//   GET  /api/idearium/log        — recent snapshots
//   POST /api/idearium/rewind     — { snapshotId } restore snapshot
//   GET  /api/revisions?path=<path> — file revision history (versionium)
//   POST /api/revisions/commit    — { paths, message } commit revision
//   POST /api/revisions/diff      — { hashA, hashB } diff two revisions
//   POST /api/emit                — forward event to Nexus kernel
//
// CLI COMMANDS (pipe to Nexus):
//   forge status
//   forge import <path>
//   forge compile <command>
//   forge snapshot <message>
//   forge rewind <id>
//
// §F1  Every file operation emits a bus event before returning.
// §F2  Compiler output streams — never buffers a full run.
// §F3  All revisions stored content-addressed (SHA256).
// §F4  Idearium hooks on every write + snapshot.
// §F5  Nexus SSE bridge: forward relevant events to Nexus admin channel.
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';

const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');
const { spawn, exec } = require('child_process');

const FORGE_PORT     = parseInt(process.env.FORGE_PORT)     || 4242;
const NEXUS_URL      = process.env.NEXUS_URL                || 'http://localhost:3748';
const OLLAMA_URL     = process.env.OLLAMA_URL               || 'http://localhost:11434';
const OLLAMA_MODEL   = process.env.OLLAMA_MODEL             || 'deepseek-coder-v2:16b-lite-instruct-q4_K_M';
const IDEARIUM_DATA  = process.env.IDEARIUM_DATA            || path.join(process.cwd(), '.idearium');
const FORGE_STATIC   = path.join(__dirname, 'public');
const MAX_SSE        = 64;
const VERSION        = '1.0.0';

// ── MIME ──────────────────────────────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.ico':  'image/x-icon',
  '.woff2':'font/woff2',
  '.ts':   'text/typescript',
  '.md':   'text/markdown',
};

const CODE_EXTS = new Set([
  '.js','.ts','.jsx','.tsx','.mjs','.cjs',
  '.py','.rb','.go','.rs','.java','.kt','.swift',
  '.c','.cpp','.h','.hpp','.cs','.php',
  '.html','.css','.scss','.sass','.less',
  '.json','.yaml','.yml','.toml','.env',
  '.sh','.bash','.zsh','.ps1',
  '.md','.txt','.gitignore','.dockerfile',
  '.sql','.graphql','.proto',
]);

const IGNORE_DIRS = new Set([
  'node_modules','.git','.svn','dist','build',
  '__pycache__','.next','.nuxt','.cache',
  'coverage','.nyc_output','vendor','.venv','venv',
  'target','out','bin','obj','.forge-store',
]);

// ── MicroBus ──────────────────────────────────────────────────────────────────
class MicroBus {
  constructor() {
    this._listeners = new Map();
    this._log = [];
    this._seq = 0;
  }

  emit(type, payload = {}) {
    const ev = Object.freeze({
      id:   `forge-${(++this._seq).toString(36).padStart(6,'0')}`,
      type,
      payload,
      ts:   Date.now(),
    });
    this._log.push(ev);
    if (this._log.length > 5000) this._log.shift();

    for (const [pat, fns] of this._listeners) {
      if (type === pat || pat === '*' || type.startsWith(pat.replace('*',''))) {
        for (const fn of fns) {
          try { fn(ev); } catch (e) { console.error('[bus]', e.message); }
        }
      }
    }
    return ev;
  }

  on(pattern, fn) {
    if (!this._listeners.has(pattern)) this._listeners.set(pattern, []);
    this._listeners.get(pattern).push(fn);
    return () => {
      const fns = this._listeners.get(pattern) || [];
      this._listeners.set(pattern, fns.filter(f => f !== fn));
    };
  }

  recent(n = 100) { return this._log.slice(-n); }
}

const bus = new MicroBus();

// ── FileVault ─────────────────────────────────────────────────────────────────
// Sovereign content-addressed store for revision tracking.
// Actual project files read/written at their real paths.

class FileVault {
  constructor(storeDir) {
    this._dir = storeDir;
    fs.mkdirSync(path.join(storeDir, 'objects'), { recursive: true });
    fs.mkdirSync(path.join(storeDir, 'refs'),    { recursive: true });
    fs.mkdirSync(path.join(storeDir, 'commits'), { recursive: true });
    this._commits = this._loadCommits();
    this._fileIndex = new Map(); // filePath → commitId[]
  }

  // Store content-addressed object
  put(content) {
    const hash = crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
    const file = path.join(this._dir, 'objects', hash);
    if (!fs.existsSync(file)) fs.writeFileSync(file, content, 'utf8');
    return hash;
  }

  get(hash) {
    const file = path.join(this._dir, 'objects', hash);
    return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
  }

  // Commit — snapshot a set of files
  commit(message, filePaths, opts = {}) {
    const { author = 'forge', causedBy = null } = opts;
    const files = {};
    for (const fp of filePaths) {
      try {
        const content = fs.readFileSync(fp, 'utf8');
        const hash = this.put(content);
        files[fp] = { hash, size: content.length };
        if (!this._fileIndex.has(fp)) this._fileIndex.set(fp, []);
      } catch { /* skip unreadable */ }
    }

    const commitId = crypto.createHash('sha256')
      .update(JSON.stringify({ message, files, ts: Date.now() }))
      .digest('hex').slice(0, 16);

    const commit = {
      commitId, message, author, causedBy,
      ts:    Date.now(),
      files,
    };

    // Update file index
    for (const fp of Object.keys(files)) {
      if (!this._fileIndex.has(fp)) this._fileIndex.set(fp, []);
      this._fileIndex.get(fp).push(commitId);
    }

    const commitFile = path.join(this._dir, 'commits', `${commitId}.json`);
    fs.writeFileSync(commitFile, JSON.stringify(commit, null, 2));
    this._commits.set(commitId, commit);

    bus.emit('forge.revision.committed', { commitId, message, files: Object.keys(files), author });
    return commit;
  }

  // Diff two commits for a specific file
  diff(commitIdA, commitIdB, filePath) {
    const a = this._commits.get(commitIdA);
    const b = this._commits.get(commitIdB);
    if (!a || !b) return null;

    const hashA = a.files[filePath]?.hash;
    const hashB = b.files[filePath]?.hash;
    if (!hashA && !hashB) return null;

    const contentA = hashA ? (this.get(hashA) || '') : '';
    const contentB = hashB ? (this.get(hashB) || '') : '';

    return {
      from: commitIdA, to: commitIdB, filePath,
      linesA: contentA.split('\n').length,
      linesB: contentB.split('\n').length,
      changed: contentA !== contentB,
      contentA, contentB,
    };
  }

  fileHistory(filePath) {
    return (this._fileIndex.get(filePath) || [])
      .map(id => this._commits.get(id))
      .filter(Boolean)
      .sort((a, b) => b.ts - a.ts);
  }

  listCommits() {
    return [...this._commits.values()].sort((a, b) => b.ts - a.ts);
  }

  _loadCommits() {
    const map = new Map();
    const dir = path.join(this._dir, 'commits');
    try {
      for (const f of fs.readdirSync(dir)) {
        if (!f.endsWith('.json')) continue;
        try {
          const c = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
          map.set(c.commitId, c);
          for (const fp of Object.keys(c.files || {})) {
            if (!this._fileIndex) this._fileIndex = new Map();
            // preload index
          }
        } catch {}
      }
    } catch {}
    return map;
  }
}

const vault = new FileVault(path.join(process.cwd(), '.forge-store'));

// ── Idearium Bridge ───────────────────────────────────────────────────────────
// Pushes snapshots to .idearium store via Idearium core directly.

class IdeariamBridge {
  constructor(dataDir) {
    this._dir  = dataDir;
    this._snapshotDir = path.join(dataDir, 'snapshots');
    this._gapsFile    = path.join(dataDir, 'gaps.jsonl');
    this._ideasFile   = path.join(dataDir, 'ideas.jsonl');
    fs.mkdirSync(this._snapshotDir, { recursive: true });
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Push a Forge revision snapshot into Idearium
  pushSnapshot(message, meta = {}) {
    const snap = {
      snapshotId: crypto.createHash('sha256')
        .update(message + Date.now())
        .digest('hex').slice(0, 16),
      message,
      ts:     Date.now(),
      author: meta.author || 'forge',
      source: 'forge',
      causedBy: meta.causedBy || null,
      meta,
    };

    const file = path.join(this._snapshotDir, `${snap.snapshotId}.json`);
    fs.writeFileSync(file, JSON.stringify(snap, null, 2));

    bus.emit('idearium.snapshot.committed', { snapshotId: snap.snapshotId, message, source: 'forge' });
    return snap;
  }

  listSnapshots() {
    try {
      return fs.readdirSync(this._snapshotDir)
        .filter(f => f.endsWith('.json'))
        .map(f => {
          try {
            const s = JSON.parse(fs.readFileSync(path.join(this._snapshotDir, f), 'utf8'));
            return { snapshotId: s.snapshotId, message: s.message, ts: s.ts, author: s.author, source: s.source };
          } catch { return null; }
        })
        .filter(Boolean)
        .sort((a, b) => b.ts - a.ts)
        .slice(0, 50);
    } catch { return []; }
  }

  getSnapshot(id) {
    try {
      return JSON.parse(fs.readFileSync(path.join(this._snapshotDir, `${id}.json`), 'utf8'));
    } catch { return null; }
  }

  // Register a gap (e.g. compile error, missing dep)
  openGap(type, description, severity = 'MEDIUM', meta = {}) {
    const gap = {
      gapId:       crypto.randomUUID(),
      type,
      description,
      severity,
      status:      'open',
      openedAt:    Date.now(),
      resolvedAt:  null,
      source:      'forge',
      ...meta,
    };
    fs.appendFileSync(this._gapsFile, JSON.stringify(gap) + '\n');
    bus.emit('idearium.gap.opened', { gapId: gap.gapId, type, description, severity });
    return gap;
  }

  resolveGap(gapId) {
    bus.emit('idearium.gap.resolved', { gapId, resolvedAt: Date.now() });
  }
}

const idearium = new IdeariamBridge(IDEARIUM_DATA);

// ── Compiler ──────────────────────────────────────────────────────────────────
// Runs build commands; streams output over SSE.

class Compiler {
  constructor() {
    this._running = new Map();  // runId → child process
    this._history = [];
    this._sseClients = new Set();
  }

  addSseClient(res) {
    this._sseClients.add(res);
    res.on('close', () => this._sseClients.delete(res));
  }

  _broadcast(type, data) {
    const payload = `data: ${JSON.stringify({ type, ...data })}\n\n`;
    for (const res of this._sseClients) {
      try { res.write(payload); } catch {}
    }
  }

  run(command, cwd = process.cwd(), env = {}) {
    const runId = crypto.randomUUID().slice(0, 8);
    const started = Date.now();
    const output = [];

    bus.emit('forge.compile.started', { runId, command, cwd });
    this._broadcast('compile.started', { runId, command, cwd, ts: started });

    const child = spawn(command, {
      shell:   true,
      cwd:     fs.existsSync(cwd) ? cwd : process.cwd(),
      env:     { ...process.env, ...env },
    });

    this._running.set(runId, child);

    child.stdout.on('data', (chunk) => {
      const line = chunk.toString();
      output.push({ stream: 'stdout', text: line, ts: Date.now() });
      this._broadcast('compile.output', { runId, stream: 'stdout', text: line });
    });

    child.stderr.on('data', (chunk) => {
      const line = chunk.toString();
      output.push({ stream: 'stderr', text: line, ts: Date.now() });
      this._broadcast('compile.output', { runId, stream: 'stderr', text: line });
    });

    child.on('close', (code) => {
      this._running.delete(runId);
      const duration = Date.now() - started;
      const entry = { runId, command, cwd, code, duration, output, ts: started };
      this._history.unshift(entry);
      if (this._history.length > 50) this._history.pop();

      bus.emit('forge.compile.done', { runId, command, code, duration });
      this._broadcast('compile.done', { runId, code, duration });

      if (code !== 0) {
        const errText = output.filter(o => o.stream === 'stderr').map(o => o.text).join('').slice(0, 500);
        idearium.openGap('compile_error', `${command} exited ${code}: ${errText}`, 'HIGH', { runId });
      } else {
        // Auto-snapshot on successful compile
        idearium.pushSnapshot(`Compile: ${command}`, { causedBy: runId });
      }
    });

    child.on('error', (e) => {
      this._running.delete(runId);
      bus.emit('forge.compile.error', { runId, command, error: e.message });
      this._broadcast('compile.error', { runId, error: e.message });
    });

    return runId;
  }

  kill(runId) {
    const child = this._running.get(runId);
    if (child) { child.kill('SIGTERM'); this._running.delete(runId); }
  }

  history() { return this._history.slice(0, 20); }
  running() { return [...this._running.keys()]; }
}

const compiler = new Compiler();

// ── AgentBus ──────────────────────────────────────────────────────────────────
// Fan-out: Ollama primary (Law I), Nexus fallback, Guardian cloud last.

class AgentBus {
  async complete(prompt, opts = {}) {
    const { agent = 'auto', signal } = opts;
    const startTs = Date.now();

    // Law I — Ollama first
    if (agent === 'auto' || agent === 'ollama') {
      try {
        const result = await this._ollama(prompt, opts);
        bus.emit('forge.agent.response', { agent: 'ollama', latency: Date.now() - startTs });
        return { agent: 'ollama', content: result, latency: Date.now() - startTs };
      } catch (e) {
        bus.emit('forge.agent.failed', { agent: 'ollama', error: e.message });
        if (agent === 'ollama') throw e;
      }
    }

    // Nexus gateway (routes to Guardian → cloud agents)
    if (agent === 'auto' || agent === 'nexus') {
      try {
        const result = await this._nexus(prompt, opts);
        bus.emit('forge.agent.response', { agent: 'nexus', latency: Date.now() - startTs });
        return { agent: 'nexus', content: result, latency: Date.now() - startTs };
      } catch (e) {
        bus.emit('forge.agent.failed', { agent: 'nexus', error: e.message });
        if (agent === 'nexus') throw e;
      }
    }

    // Direct Guardian for specific cloud agents
    if (['chatgpt','claude','gemini'].includes(agent)) {
      const result = await this._guardian(agent, prompt, opts);
      return { agent, content: result, latency: Date.now() - startTs };
    }

    throw new Error('All agents failed or unavailable');
  }

  async _ollama(prompt, opts = {}) {
    const res = await fetch(`${OLLAMA_URL}/api/generate`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model:   opts.model || OLLAMA_MODEL,
        prompt,
        stream:  false,
        options: {
          temperature:    opts.temperature ?? 0.15,
          num_ctx:        opts.maxTokens   ?? 4096,
          num_thread:     7,
          repeat_penalty: 1.1,
        },
      }),
      signal: opts.signal || AbortSignal.timeout(120_000),
    });
    if (!res.ok) throw new Error(`Ollama ${res.status}`);
    const data = await res.json();
    return data.response || '';
  }

  async _nexus(prompt, opts = {}) {
    const res = await fetch(`${NEXUS_URL}/api/complete`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service: 'nexus', prompt, ...opts }),
      signal:  opts.signal || AbortSignal.timeout(60_000),
    });
    if (!res.ok) throw new Error(`Nexus ${res.status}`);
    const data = await res.json();
    return data.content || data.response || '';
  }

  async _guardian(service, prompt, opts = {}) {
    const res = await fetch(`${NEXUS_URL}/api/complete`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ service, prompt, ...opts }),
      signal:  opts.signal || AbortSignal.timeout(60_000),
    });
    if (!res.ok) throw new Error(`Guardian/${service} ${res.status}`);
    const data = await res.json();
    return data.content || data.response || '';
  }

  async ping() {
    const results = {};
    // Ping Ollama
    try {
      const r = await fetch(`${OLLAMA_URL}/api/tags`, { signal: AbortSignal.timeout(2000) });
      results.ollama = r.ok;
    } catch { results.ollama = false; }
    // Ping Nexus
    try {
      const r = await fetch(`${NEXUS_URL}/health`, { signal: AbortSignal.timeout(2000) });
      results.nexus = r.ok;
    } catch { results.nexus = false; }

    return results;
  }
}

const agents = new AgentBus();

// ── File System ───────────────────────────────────────────────────────────────

function buildTree(dirPath, depth = 0, maxDepth = 6) {
  const name = path.basename(dirPath);
  if (IGNORE_DIRS.has(name)) return null;
  if (depth > maxDepth) return null;

  let stat;
  try { stat = fs.statSync(dirPath); } catch { return null; }

  if (stat.isFile()) {
    const ext = path.extname(name).toLowerCase();
    return {
      type:     'file',
      name,
      path:     dirPath,
      ext,
      isCode:   CODE_EXTS.has(ext),
      size:     stat.size,
      mtime:    stat.mtimeMs,
    };
  }

  if (stat.isDirectory()) {
    let children = [];
    try {
      children = fs.readdirSync(dirPath)
        .map(child => buildTree(path.join(dirPath, child), depth + 1, maxDepth))
        .filter(Boolean)
        .sort((a, b) => {
          if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
    } catch {}

    return { type: 'directory', name, path: dirPath, children };
  }

  return null;
}

function searchFiles(rootPath, query, maxResults = 50) {
  const results = [];
  const q = query.toLowerCase();

  function walk(dir, depth = 0) {
    if (depth > 6) return;
    let entries;
    try { entries = fs.readdirSync(dir); } catch { return; }

    for (const entry of entries) {
      if (IGNORE_DIRS.has(entry)) continue;
      const full = path.join(dir, entry);
      let stat;
      try { stat = fs.statSync(full); } catch { continue; }

      if (stat.isDirectory()) { walk(full, depth + 1); continue; }

      const ext = path.extname(entry).toLowerCase();
      if (!CODE_EXTS.has(ext)) continue;

      // Filename match
      if (entry.toLowerCase().includes(q)) {
        results.push({ type: 'filename', path: full, name: entry, line: 0, text: '' });
        if (results.length >= maxResults) return;
        continue;
      }

      // Content match
      try {
        const content = fs.readFileSync(full, 'utf8');
        const lines = content.split('\n');
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].toLowerCase().includes(q)) {
            results.push({
              type: 'content',
              path: full,
              name: entry,
              line: i + 1,
              text: lines[i].trim().slice(0, 120),
            });
            if (results.length >= maxResults) return;
          }
        }
      } catch {}
    }
  }

  walk(rootPath);
  return results;
}

// ── SSE ───────────────────────────────────────────────────────────────────────

const sseClients = new Set();

function sseSetup(res) {
  if (sseClients.size >= MAX_SSE) { res.writeHead(503); res.end('Too many clients'); return false; }
  res.writeHead(200, {
    'Content-Type':  'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection':    'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });
  res.flushHeaders?.();
  sseClients.add(res);
  res.on('close', () => sseClients.delete(res));

  // Send recent history on connect
  const recent = bus.recent(30);
  for (const ev of recent) {
    res.write(`data: ${JSON.stringify(ev)}\n\n`);
  }
  return true;
}

// Forward all bus events to SSE clients
bus.on('*', (ev) => {
  const payload = `data: ${JSON.stringify(ev)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch {}
  }
});

// SSE keepalive
setInterval(() => {
  const ping = `data: ${JSON.stringify({ type: 'forge.ping', ts: Date.now() })}\n\n`;
  for (const res of sseClients) { try { res.write(ping); } catch {} }
}, 15_000);

// ── HTTP API ──────────────────────────────────────────────────────────────────

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 10_000_000) reject(new Error('Too large')); });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function json(res, data, status = 200) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(data));
}

function err(res, message, status = 400) {
  json(res, { error: message }, status);
}

function cors(res) {
  res.writeHead(204, {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  });
  res.end();
}

const server = http.createServer(async (req, res) => {
  const url    = new URL(req.url, `http://localhost:${FORGE_PORT}`);
  const method = req.method.toUpperCase();
  const p      = url.pathname;

  if (method === 'OPTIONS') { cors(res); return; }

  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    // ── GET /api/stream ──────────────────────────────
    if (p === '/api/stream' && method === 'GET') {
      sseSetup(res);
      return;
    }

    // ── GET /api/compile/stream ──────────────────────
    if (p === '/api/compile/stream' && method === 'GET') {
      if (!sseSetup(res)) return;
      compiler.addSseClient(res);
      return;
    }

    // ── GET /api/health ──────────────────────────────
    if (p === '/api/health' && method === 'GET') {
      const agentStatus = await agents.ping().catch(() => ({}));
      json(res, {
        status:    'ok',
        version:   VERSION,
        port:      FORGE_PORT,
        uptime:    process.uptime(),
        agents:    agentStatus,
        running:   compiler.running(),
        clients:   sseClients.size,
        ts:        Date.now(),
      });
      return;
    }

    // ── GET /api/fs/tree ─────────────────────────────
    if (p === '/api/fs/tree' && method === 'GET') {
      const root = url.searchParams.get('root') || process.cwd();
      if (!fs.existsSync(root)) { err(res, `Path not found: ${root}`, 404); return; }
      const tree = buildTree(path.resolve(root));
      bus.emit('forge.fs.tree', { root, ts: Date.now() });
      json(res, { tree, root });
      return;
    }

    // ── GET /api/fs/read ─────────────────────────────
    if (p === '/api/fs/read' && method === 'GET') {
      const filePath = url.searchParams.get('path');
      if (!filePath) { err(res, 'path required'); return; }
      if (!fs.existsSync(filePath)) { err(res, 'File not found', 404); return; }
      const content = fs.readFileSync(filePath, 'utf8');
      const ext = path.extname(filePath).toLowerCase();
      bus.emit('forge.fs.read', { path: filePath, size: content.length });
      json(res, { path: filePath, content, ext, size: content.length, mtime: fs.statSync(filePath).mtimeMs });
      return;
    }

    // ── POST /api/fs/write ───────────────────────────
    if (p === '/api/fs/write' && method === 'POST') {
      const body = await readBody(req);
      const { path: filePath, content, message } = body;
      if (!filePath || content == null) { err(res, 'path and content required'); return; }

      // Backup in vault before overwrite
      if (fs.existsSync(filePath)) vault.put(fs.readFileSync(filePath, 'utf8'));

      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      fs.writeFileSync(filePath, content, 'utf8');

      // Idearium auto-snapshot on write
      const snap = idearium.pushSnapshot(message || `Edit: ${path.basename(filePath)}`, { files: [filePath] });

      bus.emit('forge.fs.write', { path: filePath, size: content.length, snapshotId: snap.snapshotId });
      json(res, { ok: true, path: filePath, size: content.length, snapshotId: snap.snapshotId });
      return;
    }

    // ── POST /api/fs/import ──────────────────────────
    if (p === '/api/fs/import' && method === 'POST') {
      const body = await readBody(req);
      const { paths = [], root, message = 'Import project' } = body;

      const targets = paths.length ? paths : (root ? [root] : []);
      if (!targets.length) { err(res, 'paths or root required'); return; }

      const imported = [];
      for (const t of targets) {
        if (!fs.existsSync(t)) continue;
        const stat = fs.statSync(t);
        if (stat.isFile()) {
          imported.push({ path: t, type: 'file', size: stat.size });
        } else if (stat.isDirectory()) {
          // Walk and index the directory
          const tree = buildTree(t);
          imported.push({ path: t, type: 'directory', tree });
        }
      }

      const commit = vault.commit(message, paths.filter(p => fs.existsSync(p) && fs.statSync(p).isFile()));
      const snap   = idearium.pushSnapshot(message, { commit: commit.commitId, imported: imported.length });

      bus.emit('forge.project.imported', { targets, count: imported.length, commitId: commit.commitId });
      json(res, { ok: true, imported, commitId: commit.commitId, snapshotId: snap.snapshotId });
      return;
    }

    // ── GET /api/fs/search ───────────────────────────
    if (p === '/api/fs/search' && method === 'GET') {
      const q    = url.searchParams.get('q') || '';
      const root = url.searchParams.get('root') || process.cwd();
      if (!q) { err(res, 'q required'); return; }
      const results = searchFiles(root, q);
      json(res, { query: q, root, results, count: results.length });
      return;
    }

    // ── POST /api/compile ────────────────────────────
    if (p === '/api/compile' && method === 'POST') {
      const body = await readBody(req);
      const { command, cwd, env } = body;
      if (!command) { err(res, 'command required'); return; }
      const runId = compiler.run(command, cwd || process.cwd(), env || {});
      json(res, { ok: true, runId });
      return;
    }

    // ── POST /api/compile/kill ───────────────────────
    if (p === '/api/compile/kill' && method === 'POST') {
      const body = await readBody(req);
      compiler.kill(body.runId);
      json(res, { ok: true });
      return;
    }

    // ── GET /api/compile/history ─────────────────────
    if (p === '/api/compile/history' && method === 'GET') {
      json(res, { history: compiler.history() });
      return;
    }

    // ── POST /api/agent/complete ─────────────────────
    if (p === '/api/agent/complete' && method === 'POST') {
      const body = await readBody(req);
      const { prompt, agent = 'auto', temperature, maxTokens, model } = body;
      if (!prompt) { err(res, 'prompt required'); return; }
      try {
        const result = await agents.complete(prompt, { agent, temperature, maxTokens, model });
        json(res, result);
      } catch (e) {
        err(res, e.message, 503);
      }
      return;
    }

    // ── POST /api/idearium/snapshot ──────────────────
    if (p === '/api/idearium/snapshot' && method === 'POST') {
      const body = await readBody(req);
      const snap = idearium.pushSnapshot(body.message || 'Manual snapshot', body.meta || {});
      json(res, { ok: true, snapshot: snap });
      return;
    }

    // ── GET /api/idearium/log ────────────────────────
    if (p === '/api/idearium/log' && method === 'GET') {
      const snaps = idearium.listSnapshots();
      json(res, { snapshots: snaps, count: snaps.length });
      return;
    }

    // ── POST /api/idearium/rewind ────────────────────
    if (p === '/api/idearium/rewind' && method === 'POST') {
      const body = await readBody(req);
      const snap = idearium.getSnapshot(body.snapshotId);
      if (!snap) { err(res, 'Snapshot not found', 404); return; }
      bus.emit('idearium.snapshot.restored', { snapshotId: snap.snapshotId, message: snap.message });
      json(res, { ok: true, snapshot: snap });
      return;
    }

    // ── GET /api/revisions ───────────────────────────
    if (p === '/api/revisions' && method === 'GET') {
      const filePath = url.searchParams.get('path');
      if (filePath) {
        json(res, { path: filePath, history: vault.fileHistory(filePath) });
      } else {
        json(res, { commits: vault.listCommits().slice(0, 30) });
      }
      return;
    }

    // ── POST /api/revisions/commit ───────────────────
    if (p === '/api/revisions/commit' && method === 'POST') {
      const body = await readBody(req);
      const commit = vault.commit(body.message || 'Manual commit', body.paths || [], { author: body.author });
      json(res, { ok: true, commit });
      return;
    }

    // ── POST /api/revisions/diff ─────────────────────
    if (p === '/api/revisions/diff' && method === 'POST') {
      const body = await readBody(req);
      const diff = vault.diff(body.hashA, body.hashB, body.path);
      if (!diff) { err(res, 'Could not compute diff', 404); return; }
      json(res, { diff });
      return;
    }

    // ── POST /api/emit ────────────────────────────────
    if (p === '/api/emit' && method === 'POST') {
      const body = await readBody(req);
      const ev = bus.emit(body.type || 'forge.external', body.payload || {});
      // Also forward to Nexus
      try {
        fetch(`${NEXUS_URL}/api/emit`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: body.type, payload: body.payload }),
          signal: AbortSignal.timeout(2000),
        }).catch(() => {});
      } catch {}
      json(res, { ok: true, eventId: ev.id });
      return;
    }

    // ── GET /api/events ──────────────────────────────
    if (p === '/api/events' && method === 'GET') {
      const n = parseInt(url.searchParams.get('n') || '100');
      json(res, { events: bus.recent(n) });
      return;
    }

    // ── Static file serving ──────────────────────────
    if (method === 'GET') {
      let filePath = p === '/' ? '/index.html' : p;
      filePath = path.join(FORGE_STATIC, filePath);
      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        const ext = path.extname(filePath).toLowerCase();
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
        fs.createReadStream(filePath).pipe(res);
        return;
      }
      // SPA fallback — serve index.html for unknown paths
      const index = path.join(FORGE_STATIC, 'index.html');
      if (fs.existsSync(index)) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        fs.createReadStream(index).pipe(res);
        return;
      }
      res.writeHead(404);
      res.end('Not found');
      return;
    }

    res.writeHead(404);
    res.end('Not found');

  } catch (e) {
    console.error('[FORGE] Request error:', e.message);
    bus.emit('forge.request.error', { path: p, error: e.message });
    err(res, e.message, 500);
  }
});

// ── Nexus SSE Bridge ──────────────────────────────────────────────────────────
// Forward relevant Forge events to Nexus admin SSE channel.

async function nexusBridge() {
  try {
    const res = await fetch(`${NEXUS_URL}/api/stream`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return;

    // Forward Forge events to Nexus kernel
    bus.on('forge.*', async (ev) => {
      try {
        await fetch(`${NEXUS_URL}/api/emit`, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ type: `forge.${ev.type}`, payload: ev.payload }),
          signal:  AbortSignal.timeout(1000),
        });
      } catch {}
    });
  } catch {
    // Nexus offline — retry in 30s
    setTimeout(nexusBridge, 30_000);
  }
}

// ── Boot ──────────────────────────────────────────────────────────────────────

server.listen(FORGE_PORT, '0.0.0.0', () => {
  bus.emit('forge.booted', {
    port:       FORGE_PORT,
    version:    VERSION,
    nexus:      NEXUS_URL,
    ollama:     OLLAMA_URL,
    idearium:   IDEARIUM_DATA,
  });

  console.log(`\n╔═══════════════════════════════════════════╗`);
  console.log(`║  FORGE IDE Server  v${VERSION}                 ║`);
  console.log(`╠═══════════════════════════════════════════╣`);
  console.log(`║  UI    → http://localhost:${FORGE_PORT}           ║`);
  console.log(`║  API   → http://localhost:${FORGE_PORT}/api       ║`);
  console.log(`║  SSE   → http://localhost:${FORGE_PORT}/api/stream║`);
  console.log(`║  Nexus → ${NEXUS_URL}         ║`);
  console.log(`║  Ollama→ ${OLLAMA_URL}  ║`);
  console.log(`╚═══════════════════════════════════════════╝\n`);

  // Try to connect to Nexus
  nexusBridge().catch(() => {});

  // Initial agent ping
  agents.ping().then(results => {
    bus.emit('forge.agents.status', results);
    console.log('[FORGE] Agents:', JSON.stringify(results));
  });
});

server.on('error', (e) => {
  console.error('[FORGE] Server error:', e.message);
  process.exit(1);
});

// Export for programmatic use
module.exports = { server, bus, vault, idearium, compiler, agents };
