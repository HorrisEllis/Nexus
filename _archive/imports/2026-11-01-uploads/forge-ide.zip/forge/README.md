# FORGE — Sovereign IDE

> Compiler · Editor · File Manager · Live Preview · Rewind  
> Connected to: **Nexus** (orchestration) · **Idearium** (idea memory) · **Ollama** (local LLM) · **Guardian** (cloud agents)

---

## What This Is

Three sovereign servers that form a complete local-first development environment:

| Server | Port | Role |
|---|---|---|
| `forge-server.js` | **4242** | IDE backend — file I/O, compiler, agent fan-out, SSE event stream |
| `idearium-server.js` | **5151** | Living memory — ideas, gaps, tension scores, snapshots, compartments |
| Nexus (`boot.js`) | **3748** | Orchestration — RAID routing, LLM pipeline, Guardian bridge |

All three are event-driven. All state changes emit on a bus before returning. Everything is stored.

---

## Start

```bash
# 1. Start Nexus (from your Nexus-Cobalt directory)
node boot.js

# 2. Start Idearium server
node idearium-server.js

# 3. Start Forge IDE server
node forge-server.js

# 4. Open the IDE
open http://localhost:4242
```

Or use the CLI:
```bash
node forge-cli.js serve
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     FORGE UI  :4242                      │
│  File Tree │ Code Editor │ Split Preview │ Agent Panel   │
│  Tab Bar   │ Syntax HL  │ Live Preview  │ Compile Out   │
│  Rewind    │ Revisions  │ Idearium Log  │ Event Stream  │
└──────────────────────┬──────────────────────────────────┘
                       │ HTTP + SSE
┌──────────────────────▼──────────────────────────────────┐
│              FORGE SERVER  :4242                         │
│                                                          │
│  MicroBus ──────────────────────────────────────────┐   │
│  FileVault (SHA256 content-addressed revisions)     │   │
│  Compiler (spawn + SSE stream)                      │   │
│  AgentBus ─── Ollama :11434 (LAW I: always first)  │   │
│             └─ Nexus  :3748 (fallback)              │   │
│             └─ Guardian (chatgpt/claude/gemini)     │   │
│  IdeariamBridge ── auto-snapshot on save/compile    │   │
│  REST API + SSE stream                              │   │
└──────────────────────┬──────────────────────────────┘   │
                       │ events / HTTP                     │
         ┌─────────────┴──────────────┐                    │
         ▼                            ▼                    │
┌────────────────┐          ┌─────────────────────┐        │
│ IDEARIUM :5151 │          │   NEXUS       :3748 │        │
│                │          │                     │        │
│ IdeaStore      │◄────────►│ ALKKernel (SISO bus)│        │
│ GapStore       │  events  │ RAID engine         │        │
│ SnapshotEngine │          │ Guardian bridge     │        │
│ Pendulum       │          │ Admin panel         │        │
│ Compartments   │          │ CrystalBall         │        │
│ TensionScorer  │          │ Versionium          │        │
└────────────────┘          └─────────────────────┘        │
```

---

## Import API

Import a project or individual files into the IDE:

```bash
# Via CLI
node forge-cli.js import /path/to/project --message "Import: my-project"

# Via HTTP
curl -X POST http://localhost:4242/api/fs/import \
  -H 'Content-Type: application/json' \
  -d '{"root": "/path/to/project", "message": "Import project"}'

# Specific files
curl -X POST http://localhost:4242/api/fs/import \
  -H 'Content-Type: application/json' \
  -d '{"paths": ["/path/to/file.js", "/path/to/other.ts"], "message": "Import files"}'
```

Response:
```json
{
  "ok": true,
  "imported": [{ "path": "/path/to/project", "type": "directory" }],
  "commitId": "a3f8bc12",
  "snapshotId": "d4e9ab01"
}
```

---

## Data Pipeline

Every action flows through the event bus:

```
User saves file
  → forge.fs.write emitted
  → FileVault.put() → content-addressed backup
  → IdeariamBridge.pushSnapshot() → .idearium/snapshots/<hash>.json
  → idearium.snapshot.committed emitted
  → Nexus /api/emit (forwarded)
  → SSE broadcast to all connected clients

User runs compile
  → forge.compile.started emitted
  → spawn(command) → stdout/stderr streamed via SSE
  → On exit 0: auto-snapshot + idearium.snapshot.committed
  → On exit ≠ 0: idearium.gap.opened (type: compile_error)

Agent query
  → AgentBus.complete(prompt, { agent: 'auto' })
  → Tries Ollama first (Law I: LOCAL_FIRST)
  → Falls back to Nexus → Guardian → cloud
  → forge.agent.response emitted with latency
```

---

## Rewind / Revision History

Every file write creates a content-addressed snapshot in `.forge-store/`. Every save/compile creates an Idearium snapshot in `.idearium/snapshots/`.

```bash
# List snapshots
node forge-cli.js log --n 20

# Rewind to a snapshot
node forge-cli.js rewind <snapshotId>

# View file history
curl http://localhost:4242/api/revisions?path=/path/to/file.js

# Diff two revisions
curl -X POST http://localhost:4242/api/revisions/diff \
  -d '{"hashA": "a3f8bc12", "hashB": "d4e9ab01", "path": "/path/to/file.js"}'
```

---

## Idearium Server API

```bash
# Create an idea
curl -X POST http://localhost:5151/api/ideas \
  -d '{"name": "auth module", "intent": "JWT auth with refresh tokens", "tags": ["auth","security"], "coreFiles": ["src/auth.js"]}'

# Query by tension (highest friction first)
curl http://localhost:5151/api/ideas?tension=1

# Open a gap
curl -X POST http://localhost:5151/api/gaps \
  -d '{"type": "file_friction", "description": "auth.js missing refresh token logic", "severity": "HIGH", "between": ["<ideaUuid>"]}'

# Commit snapshot
curl -X POST http://localhost:5151/api/snapshots \
  -d '{"message": "Before auth refactor"}'

# Diff two snapshots
curl http://localhost:5151/api/snapshots/diff?from=<hashA>&to=<hashB>

# Get tension ranking
curl http://localhost:5151/api/tension
```

---

## CLI Reference

```
forge status                         Health + agent status
forge import <path> [--message]      Import project or files
forge open <file>                    Read file
forge compile <command>              Run build, stream output
forge snapshot <message>             Push Idearium snapshot
forge rewind <snapshotId>            Restore snapshot
forge log [--n 10]                   Show snapshot log
forge agent <prompt> [--agent]       Query agent (auto|ollama|nexus|chatgpt|claude|gemini)
forge emit <type> [--payload]        Emit event to bus
forge events [--n 20]               Show recent events
forge search <q> [--root]           Code-aware search
forge serve [--port 4242]           Start server
```

---

## Environment Variables

```bash
FORGE_PORT=4242          # Forge server port
IDEARIUM_PORT=5151       # Idearium server port
NEXUS_URL=http://localhost:3748   # Nexus admin server
OLLAMA_URL=http://localhost:11434 # Ollama
OLLAMA_MODEL=deepseek-coder-v2:16b-lite-instruct-q4_K_M
IDEARIUM_DATA=.idearium  # Idearium data directory
```

---

## Tests

```bash
node forge-test.js
# 60 tests · 0 failures
# §1 MicroBus (9) · §2 FileVault (11) · §3 IdeariamBridge (9)
# §4 File Search (6) · §5 File Tree (6) · §6 Bus Integration (4)
# §7 Event Routing (3) · §8 API Contract (6) · §9 CLI Parser (3)
# §10 Content Addressing (3)
```

---

## Constitutional Laws (inherited from Nexus)

| Law | Enforcement |
|---|---|
| **I LOCAL_FIRST** | Ollama evaluated before any cloud agent. RAID routes cloud only on failure. |
| **II EVENT_AUTHORITY** | No direct state mutations. All state via bus.emit(). |
| **III LAYER_SOVEREIGNTY** | No direct cross-server calls. All I/O via event bus + HTTP API. |
| **IV SCHEMA_OVER_CODE** | Every idea, gap, snapshot schema-validated at write. |
| **§F1** | Every file operation emits a bus event before returning. |
| **§F2** | Compiler output streams — never buffers a full run. |
| **§F3** | All revisions stored content-addressed (SHA256). |
| **§F4** | Idearium hooks on every write + snapshot. |
| **§F5** | Nexus SSE bridge: relevant events forwarded to Nexus admin channel. |

---

## File Layout

```
forge/
  forge-server.js      ← IDE backend (port 4242)
  idearium-server.js   ← Idearium HTTP server (port 5151)
  forge-cli.js         ← CLI (connects to forge-server API)
  forge-test.js        ← Test suite (60 tests, 0 deps)
  package.json
  public/
    index.html         ← Full IDE UI (single file, no build step)

Runtime data (auto-created):
  .forge-store/
    objects/           ← SHA256 content-addressed file objects
    commits/           ← Commit records (JSON)
    refs/              ← Named pointers
  .idearium/
    snapshots/         ← Idearium snapshots (JSON)
    ideas.jsonl        ← Append-only idea ledger
    gaps.jsonl         ← Gap log
    compartments.json  ← Compartment registry
    pendulum-data.json ← Pendulum signal state
```
