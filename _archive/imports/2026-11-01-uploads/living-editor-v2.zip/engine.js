// ═══════════════════════════════════════════════════════════════════
// LIVING EDITOR — engine.js  v1.0.0
// Pure computation. No DOM. No storage.
// Exports: SyntaxEngine, BehavioralEngine, HashChain
// ═══════════════════════════════════════════════════════════════════

// ── SYNTAX ENGINE ─────────────────────────────────────────────────

var SyntaxEngine = (function() {

  var KW = {
    js: ['const','let','var','function','return','if','else','for','while','do',
         'class','extends','import','export','default','new','this','typeof',
         'instanceof','async','await','try','catch','finally','throw','switch',
         'case','break','continue','null','undefined','true','false','in','of',
         'delete','void','yield','static','super','from','as'],
    python: ['def','class','return','if','elif','else','for','while','import',
             'from','as','try','except','finally','raise','with','pass','break',
             'continue','and','or','not','in','is','lambda','yield','global',
             'nonlocal','True','False','None','async','await']
  };

  var TYPES = {
    js: ['Array','Object','String','Number','Boolean','Promise','Map','Set',
         'Error','Date','Math','JSON','console','window','document','module','require'],
    python: ['int','str','float','bool','list','dict','tuple','set','type',
             'object','Exception','print','len','range']
  };

  var OPS = ['=>','===','!==','==','!=','<=','>=','&&','||','??','**','++','--','+=','-='];

  function _tokenizeLine(line, lang) {
    var kw = KW[lang] || [], types = TYPES[lang] || [], tokens = [], i = 0;
    while (i < line.length) {
      var ch = line[i];
      // Comments
      if ((lang === 'python' && ch === '#') || (lang === 'js' && ch === '/' && line[i+1] === '/')) {
        tokens.push({ t:'comment', v:line.slice(i) }); return tokens;
      }
      if (lang === 'js' && ch === '/' && line[i+1] === '*') {
        var j = i+2;
        while (j < line.length-1 && !(line[j]==='*' && line[j+1]==='/')) j++;
        tokens.push({ t:'comment', v:line.slice(i, j+2) }); i = j+2; continue;
      }
      // Strings
      if (ch==='"' || ch==="'" || ch==='`') {
        var q=ch, j=i+1, s=ch;
        while (j < line.length) {
          if (line[j]==='\\') { s+=line[j]+line[j+1]; j+=2; continue; }
          s+=line[j]; if (line[j]===q) { j++; break; } j++;
        }
        tokens.push({ t:'string', v:s }); i=j; continue;
      }
      // Numbers
      if (/[0-9]/.test(ch)) {
        var j=i; while (j<line.length && /[0-9._]/.test(line[j])) j++;
        tokens.push({ t:'number', v:line.slice(i,j) }); i=j; continue;
      }
      // Python decorators
      if (lang==='python' && ch==='@') {
        var j=i+1; while (j<line.length && /[a-zA-Z0-9_]/.test(line[j])) j++;
        tokens.push({ t:'at', v:line.slice(i,j) }); i=j; continue;
      }
      // Identifiers / keywords
      if (/[a-zA-Z_$]/.test(ch)) {
        var j=i; while (j<line.length && /[a-zA-Z0-9_$]/.test(line[j])) j++;
        var w=line.slice(i,j), after=line.slice(j).trimLeft(), isCall=after[0]==='(';
        var type='ident';
        if (kw.indexOf(w)>-1) type='keyword';
        else if (types.indexOf(w)>-1) type='type';
        else if (isCall) type='fn';
        tokens.push({ t:type, v:w }); i=j; continue;
      }
      // Punctuation
      if (/[{}()\[\];,]/.test(ch)) { tokens.push({ t:'punct', v:ch }); i++; continue; }
      // Operators (multi-char first)
      if (/[+\-*\/=<>!&|^~%?:.]/.test(ch)) {
        var found=false;
        for (var oi=0; oi<OPS.length; oi++) {
          if (line.slice(i, i+OPS[oi].length)===OPS[oi]) {
            tokens.push({ t:'op', v:OPS[oi] }); i+=OPS[oi].length; found=true; break;
          }
        }
        if (!found) { tokens.push({ t:'op', v:ch }); i++; }
        continue;
      }
      tokens.push({ t:'space', v:ch }); i++;
    }
    return tokens;
  }

  function _tokenizeHTML(line) {
    var tokens=[], i=0;
    while (i < line.length) {
      if (line[i]==='<') {
        var j=i+1, isClose=line[j]==='/';
        if (isClose) { tokens.push({ t:'punct', v:'</' }); j++; }
        else tokens.push({ t:'punct', v:'<' });
        var s=j; while (j<line.length && /[a-zA-Z0-9]/.test(line[j])) j++;
        if (j>s) tokens.push({ t:'tag', v:line.slice(s,j) });
        while (j<line.length && line[j]!=='>') {
          if (line[j]==='"' || line[j]==="'") {
            var q=line[j], s2=q, k=j+1;
            while (k<line.length && line[k]!==q) { s2+=line[k]; k++; }
            s2+=q; tokens.push({ t:'string', v:s2 }); j=k+1; continue;
          }
          if (/[a-zA-Z\-]/.test(line[j])) {
            var s3=j; while (j<line.length && /[a-zA-Z0-9\-]/.test(line[j])) j++;
            tokens.push({ t:'attr', v:line.slice(s3,j) }); continue;
          }
          tokens.push({ t:'op', v:line[j] }); j++;
        }
        if (j<line.length) { tokens.push({ t:'punct', v:'>' }); j++; }
        i=j; continue;
      }
      var j=i; while (j<line.length && line[j]!=='<') j++;
      if (j>i) tokens.push({ t:'ident', v:line.slice(i,j) });
      i=j;
    }
    return tokens;
  }

  function _tokenizeCSS(line) {
    var tokens=[], i=0;
    while (i<line.length) {
      var ch=line[i];
      if (ch==='/' && line[i+1]==='*') { tokens.push({ t:'comment', v:line.slice(i) }); return tokens; }
      if (ch==='"' || ch==="'") {
        var q=ch, s=ch, j=i+1;
        while (j<line.length && line[j]!==q) { s+=line[j]; j++; }
        s+=q; tokens.push({ t:'string', v:s }); i=j+1; continue;
      }
      if (ch==='#' && /[0-9a-fA-F]/.test(line[i+1]||'')) {
        var j=i+1; while (j<line.length && /[0-9a-fA-F]/.test(line[j])) j++;
        tokens.push({ t:'number', v:line.slice(i,j) }); i=j; continue;
      }
      if (ch==='@') {
        var j=i+1; while (j<line.length && /[a-zA-Z\-]/.test(line[j])) j++;
        tokens.push({ t:'at', v:line.slice(i,j) }); i=j; continue;
      }
      if (/[0-9]/.test(ch)) {
        var j=i; while (j<line.length && /[0-9.%a-zA-Z]/.test(line[j])) j++;
        tokens.push({ t:'number', v:line.slice(i,j) }); i=j; continue;
      }
      if (/[a-zA-Z\-_]/.test(ch)) {
        var j=i; while (j<line.length && /[a-zA-Z0-9\-_]/.test(line[j])) j++;
        var w=line.slice(i,j), hasBrace=line.indexOf('{')>-1;
        var isSelector=hasBrace && line.indexOf(w)<line.indexOf('{');
        var isProp=line.indexOf(':')>-1 && !isSelector;
        tokens.push({ t:isProp?'prop':isSelector?'selector':'ident', v:w }); i=j; continue;
      }
      if (/[{};:,()]/.test(ch)) { tokens.push({ t:'punct', v:ch }); i++; continue; }
      tokens.push({ t:'space', v:ch }); i++;
    }
    return tokens;
  }

  function _tokensToHTML(lines) {
    return lines.map(function(toks) {
      return toks.map(function(tok) {
        var v = tok.v.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        return '<span class="tk-'+tok.t+'">'+v+'</span>';
      }).join('');
    }).join('\n');
  }

  var pub = {};

  pub.highlight = function(code, lang) {
    var lines = code.split('\n');
    var tokenized = lines.map(function(line) {
      if (lang==='html') return _tokenizeHTML(line);
      if (lang==='css')  return _tokenizeCSS(line);
      return _tokenizeLine(line, lang);
    });
    return _tokensToHTML(tokenized);
  };

  // Auto-detect language from code content
  pub.detectLang = function(code, current) {
    if (!code || code.trim().length < 8) return current || 'js';
    if (/<[a-zA-Z][^>]*>/.test(code)) return 'html';
    if (/[{};]/.test(code) && /:\s*[^{]/.test(code) && !/{/.test(code.slice(0,20))) return 'css';
    if (/^[\s\S]*\{[\s\S]*:/.test(code) && !/function|const|var|let/.test(code)) return 'css';
    if (/^(def |class |import |from |elif |print\()/.test(code.trim())) return 'python';
    if (/def\s+\w+\s*\(/.test(code)) return 'python';
    if (/^\s{4}\w/.test(code) && !/\{/.test(code)) return 'python';
    return 'js';
  };

  return pub;
})();


// ── BEHAVIORAL ENGINE ─────────────────────────────────────────────
// Tracks keystroke gaps → derives cognitive state signal.
// No DOM access. Returns state objects — caller handles UI.

var BehavioralEngine = (function() {

  var pub = {};

  // Classify a gap history array into a signal state
  pub.classify = function(gapHistory) {
    if (!gapHistory || gapHistory.length === 0) return 'idle';
    var avg = gapHistory.reduce(function(a,b){ return a+b; }, 0) / gapHistory.length;
    if (avg < 200)  return 'flow';
    if (avg < 900)  return 'thinking';
    return 'stuck';
  };

  // Process a new keystroke event. Returns { gap, signal, changed }
  pub.record = function(now, lastKey, gapHistory) {
    var gap = now - lastKey;
    var updated = gapHistory.slice();
    if (gap > 50 && gap < 30000) {
      updated.push(gap);
      if (updated.length > 30) updated.shift();
    }
    var signal = pub.classify(updated);
    var prev = pub.classify(gapHistory);
    return { gap: gap, signal: signal, changed: signal !== prev, gapHistory: updated };
  };

  // Compute a summary of deltas stored on a doc
  pub.summary = function(deltas) {
    if (!deltas || deltas.length === 0) return null;
    var signals = { flow:0, thinking:0, stuck:0, idle:0 };
    deltas.forEach(function(d) { signals[d.signal] = (signals[d.signal]||0)+1; });
    var total = deltas.length;
    var dominant = Object.keys(signals).reduce(function(a,b){ return signals[a]>signals[b]?a:b; });
    var gaps = deltas.map(function(d){ return d.gap; }).filter(function(g){ return g>0; });
    var avgGap = gaps.length ? gaps.reduce(function(a,b){ return a+b; },0)/gaps.length : 0;
    return { dominant: dominant, signals: signals, total: total, avgGap: Math.round(avgGap) };
  };

  return pub;
})();


// ── HASH CHAIN ────────────────────────────────────────────────────
// Immutable snapshot chain. Each entry hashes content + previous hash.
// Tamper-evident: any edit to a prior entry breaks all subsequent hashes.

var HashChain = (function() {

  var pub = {};

  function _sha256(str) {
    // Use SubtleCrypto if available (returns Promise), else fast djb2 fallback
    if (typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.digest) {
      try {
        var buf = new TextEncoder().encode(str);
        return crypto.subtle.digest('SHA-256', buf).then(function(hash) {
          return Array.from(new Uint8Array(hash))
            .map(function(b){ return b.toString(16).padStart(2,'0'); }).join('');
        });
      } catch(e) {}
    }
    // Fallback: djb2
    var h = 5381;
    for (var i=0; i<str.length; i++) { h = ((h << 5) + h) + str.charCodeAt(i); h = h & h; }
    return Promise.resolve(Math.abs(h).toString(16).padStart(16,'0'));
  }

  // Create a new snapshot entry. Returns Promise<{hash, prev, ts, wc, preview}>.
  pub.create = function(chain, contentStr, wordCount, previewText) {
    var prev = chain && chain.length > 0 ? chain[chain.length-1].hash : '0000000000000000';
    var payload = JSON.stringify({
      content: contentStr, wc: wordCount, prev: prev, ts: Date.now()
    });
    return _sha256(payload).then(function(hash) {
      return {
        hash:    hash,
        prev:    prev,
        ts:      Date.now(),
        wc:      wordCount,
        preview: (previewText || contentStr).slice(0, 120)
      };
    });
  };

  // Verify the full chain integrity. Returns { valid, failedAt } (failedAt = null if valid).
  pub.verify = function(chain) {
    if (!chain || chain.length === 0) return Promise.resolve({ valid: true, failedAt: null });
    var checks = chain.map(function(entry, i) {
      if (i === 0) return Promise.resolve(true);
      return Promise.resolve(entry.prev === chain[i-1].hash);
    });
    return Promise.all(checks).then(function(results) {
      var failedAt = null;
      for (var i=0; i<results.length; i++) {
        if (!results[i]) { failedAt = i; break; }
      }
      return { valid: failedAt === null, failedAt: failedAt };
    });
  };

  return pub;
})();
