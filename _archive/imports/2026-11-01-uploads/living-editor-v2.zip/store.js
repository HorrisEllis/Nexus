// ═══════════════════════════════════════════════════════════════════
// LIVING EDITOR — store.js  v1.0.0
// State + persistence. No DOM. No rendering.
// Depends on: engine.js (HashChain)
// ═══════════════════════════════════════════════════════════════════

var Store = (function() {

  var SK = 'living-editor-v2';
  var _state = { docs: {}, lastId: null };
  var pub = {};

  // ── uid ───────────────────────────────────────────────────────
  pub.uid = function() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2,6);
  };

  // ── persist ───────────────────────────────────────────────────
  pub.save = function() {
    try {
      var payload = JSON.stringify(_state);
      if (window.storage) {
        try {
          var r = window.storage.set(SK, payload);
          if (r && typeof r.catch === 'function') r.catch(function(e){ console.warn('[store] set failed:', e); });
        } catch(e) { console.warn('[store] set threw:', e); }
        return;
      }
      localStorage.setItem(SK, payload);
    } catch(e) { console.warn('[store] save failed:', e); }
  };

  pub.load = function(cb) {
    function parse(raw) {
      if (!raw) { if (cb) cb(); return; }
      try { _state = JSON.parse(raw); } catch(e) { console.warn('[store] parse failed:', e); }
      if (cb) cb();
    }

    if (window.storage) {
      try {
        var r = window.storage.get(SK);
        if (r && typeof r.then === 'function') {
          r.then(function(res){ parse(res && res.value ? res.value : null); })
           .catch(function(){ if (cb) cb(); });
        } else { parse(r && r.value ? r.value : null); }
      } catch(e) { if (cb) cb(); }
      return;
    }
    try { parse(localStorage.getItem(SK)); } catch(e) { if (cb) cb(); }
  };

  // ── state accessors ───────────────────────────────────────────
  pub.getState  = function() { return _state; };
  pub.getDocs   = function() { return _state.docs; };
  pub.getLastId = function() { return _state.lastId; };

  pub.getDoc = function(id) {
    return _state.docs[id] || null;
  };

  pub.setDoc = function(doc) {
    _state.docs[doc.id] = doc;
    _state.lastId = doc.id;
    pub.save();
  };

  pub.deleteDoc = function(id) {
    delete _state.docs[id];
    if (_state.lastId === id) {
      var ids = Object.keys(_state.docs);
      _state.lastId = ids.length > 0 ? ids[ids.length-1] : null;
    }
    pub.save();
  };

  // ── doc factory ───────────────────────────────────────────────
  pub.newDoc = function(tpl) {
    var id = pub.uid();
    var doc = {
      id:           id,
      title:        '',
      template:     tpl.id,
      templateName: tpl.name,
      type:         tpl.type,
      lang:         tpl.lang || null,
      blocks:       tpl.type === 'prose'
        ? tpl.blocks.map(function(b){
            return { id:pub.uid(), type:b.type, content:b.content||'', meta:{} };
          })
        : null,
      content:      tpl.type === 'code' ? (tpl.content||'') : null,
      chain:        [],
      deltas:       [],
      wordCount:    0,
      createdAt:    Date.now(),
      updatedAt:    Date.now()
    };
    pub.setDoc(doc);
    return doc;
  };

  // ── doc snapshot (immutable chain entry) ──────────────────────
  pub.snapshot = function(doc, contentStr, wordCount, previewText) {
    return HashChain.create(doc.chain, contentStr, wordCount, previewText)
      .then(function(entry) {
        if (!doc.chain) doc.chain = [];
        doc.chain.push(entry);
        doc.updatedAt = Date.now();
        pub.setDoc(doc);
        return entry;
      });
  };

  // ── doc content helpers ───────────────────────────────────────
  pub.getContent = function(doc) {
    if (!doc) return '';
    if (doc.type === 'code') return doc.content || '';
    return (doc.blocks || []).map(function(b){ return b.content; }).join('\n');
  };

  pub.getWordCount = function(doc) {
    var t = pub.getContent(doc);
    return t.trim() ? t.trim().split(/\s+/).length : 0;
  };

  // ── sorted doc list ───────────────────────────────────────────
  pub.sortedDocs = function(sortBy) {
    var docs = Object.values(_state.docs);
    var fns = {
      updated:  function(a,b){ return (b.updatedAt||0)-(a.updatedAt||0); },
      created:  function(a,b){ return (b.createdAt||0)-(a.createdAt||0); },
      name:     function(a,b){ return (a.title||'').localeCompare(b.title||''); },
      type:     function(a,b){ return (a.templateName||'').localeCompare(b.templateName||''); },
      words:    function(a,b){ return (b.wordCount||0)-(a.wordCount||0); }
    };
    return docs.sort(fns[sortBy] || fns.updated);
  };

  // ── delta recording ───────────────────────────────────────────
  pub.recordDelta = function(doc, gap, signal) {
    if (!doc.deltas) doc.deltas = [];
    doc.deltas.push({ ts: Date.now(), gap: gap, signal: signal });
    if (doc.deltas.length > 500) doc.deltas.shift();
    // Don't save on every keystroke — caller decides when to flush
  };

  return pub;
})();
