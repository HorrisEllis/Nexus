'use strict';
// Minimal WARP-shaped event bus: Event { id, type, payload, ts } published
// to any number of Gate subscribers. Every mutation in this project should
// emit through here rather than being called directly — §5.1.

const { uuid, now } = require('./models');
const store = require('./store');

const listeners = new Map(); // type -> Set<fn>
const streamLog = []; // in-memory StreamLog, capped

const MAX_STREAM_LOG = 500;

function on(type, fn) {
  if (!listeners.has(type)) listeners.set(type, new Set());
  listeners.get(type).add(fn);
  return () => listeners.get(type).delete(fn); // unsubscribe
}

function emit(type, payload) {
  const event = { id: uuid(), type, payload, ts: now() };
  streamLog.push(event);
  if (streamLog.length > MAX_STREAM_LOG) streamLog.shift();

  const subs = listeners.get(type);
  if (subs) {
    for (const fn of subs) {
      try {
        fn(event);
      } catch (e) {
        // §1.2 nothing silently fails — a bad subscriber must not kill the bus
        // or other subscribers. Log loudly, keep going.
        console.error(`[bus] listener for "${type}" threw:`, e);
      }
    }
  }
  return event;
}

function recent(n = 50) {
  return streamLog.slice(-n);
}

module.exports = { on, emit, recent };
