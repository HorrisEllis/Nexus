'use strict';
const store = require('./store');
const bus = require('./bus');
const { makeLoop, makeExposureTier, now } = require('./models');
const { extractConcepts } = require('./concepts');

function captureLoop(text, opts = {}) {
  const concepts = extractConcepts(text);
  const loop = makeLoop({ text, concepts, ...opts });
  store.insert('loops', loop);
  bus.emit('loop.captured', { loop_id: loop.id });
  return loop;
}

function classifyLoop(loopId, solvability) {
  if (!['desk', 'outside', 'unclassified'].includes(solvability)) {
    throw new Error(`[loops] invalid solvability "${solvability}"`);
  }
  const loop = store.update('loops', loopId, { solvability });
  bus.emit('loop.classified', { loop_id: loopId, solvability });
  return loop;
}

function dischargeLoop(loopId, { mode, note = null } = {}) {
  if (!['desk', 'outside'].includes(mode)) {
    throw new Error(`[loops] discharge mode must be 'desk' or 'outside'`);
  }
  const status = mode === 'outside' ? 'outside_closed' : 'desk_closed';
  const loop = store.update('loops', loopId, { status });
  const { uuid } = require('./models');
  const dischargeEvent = { id: uuid(), loop_id: loopId, quest_id: null, ts: now(), mode, note };
  store.insert('discharge_events', dischargeEvent); // §0.3 — was previously bus-only and lost on restart
  bus.emit('loop.discharged', { loop_id: loopId, mode, discharge_event: dischargeEvent });
  return loop;
}

// Explicit user action only — never called from anywhere but a direct
// user-triggered handler. §1/§5 rule: tiers never auto-advance.
function setActiveTier(tierId) {
  const all = store.readAll('tiers');
  const updated = all.map(t => ({ ...t, active: t.id === tierId }));
  store.writeAll('tiers', updated);
  bus.emit('tier.changed', { tier_id: tierId });
  return updated.find(t => t.id === tierId);
}

function createTier(fields) {
  const tier = makeExposureTier(fields);
  store.insert('tiers', tier);
  return tier;
}

// Long-untouched (not declined) quests move to dormant quietly — no nag,
// no re-surfacing. §9 step 7.
function sweepDormant(dormancyWindowMs = 14 * 24 * 60 * 60 * 1000) {
  const cutoff = now() - dormancyWindowMs;
  const loops = store.readAll('loops');
  let swept = 0;
  for (const loop of loops) {
    if (loop.status === 'open' && loop.created_at < cutoff) {
      store.update('loops', loop.id, { status: 'dormant' });
      swept++;
    }
  }
  return swept;
}

module.exports = { captureLoop, classifyLoop, dischargeLoop, setActiveTier, createTier, sweepDormant };
