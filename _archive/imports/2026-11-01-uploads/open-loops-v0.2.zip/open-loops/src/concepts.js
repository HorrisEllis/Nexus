'use strict';
// Same extractor as the Claude/DM bridge userscripts. Kept as one canonical
// copy here; the userscripts have their own inline copies since they can't
// import across the network boundary — if this logic changes, update both.

const STOP = new Set(['i','a','an','the','is','it','in','of','to','and','or','but','for','with','on','at','by','from','as','up','be','was','are','were','have','has','had','do','did','does','not','no','so','if','my','your','their','we','he','she','they','this','that','these','those','can','will','would','could','should','just','need','want','think','know','get','go','make','its','me','him','her','us','them','what','how','when','where','why','who','been','all','any','some','more','than','then','about','into','through','very','also','only','both','even','back','still','same','way','here','there']);

function extractConcepts(text, max = 6) {
  if (!text || text.length < 4) return [];
  const lower = text.toLowerCase().replace(/[^\w\s'-]/g, ' ');
  const words = lower.split(/\s+/).filter(w => w.length > 2 && !STOP.has(w));
  const raw = lower.split(/\s+/);
  const bigs = [];
  for (let i = 0; i < raw.length - 1; i++) {
    const a = raw[i].replace(/[^\w]/g, ''), b = raw[i + 1].replace(/[^\w]/g, '');
    if (a.length > 2 && b.length > 2 && !STOP.has(a) && !STOP.has(b)) bigs.push(a + ' ' + b);
  }
  const seen = new Set(), res = [];
  for (const bg of bigs) { if (!seen.has(bg)) { res.push(bg); seen.add(bg); } }
  for (const w of words) { if (!res.some(r => r.includes(w)) && !seen.has(w)) { res.push(w); seen.add(w); } }
  return res.slice(0, max);
}

module.exports = { extractConcepts };
