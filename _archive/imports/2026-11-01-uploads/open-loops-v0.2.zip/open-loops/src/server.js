'use strict';
// Same KERNEL_URL (127.0.0.1:7820) and X-Auth-Token convention as the
// existing Claude bridge and DM listener userscripts — this kernel is a
// drop-in target for both without touching those scripts.

const http = require('http');
const { URL } = require('url');

const store = require('./store');
const bus = require('./bus');
const loops = require('./loops');
const baitEngine = require('./baitEngine');
const commitments = require('./commitments');
const widgets = require('./widgets');
const rewind = require('./rewind');
const { extractConcepts } = require('./concepts');

const PORT = 7820;
const TOKEN = 'adhd-local-token';

rewind.attachAutoSnapshot();
widgets.ensureSeeded();

function send(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => (data += chunk));
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

// ── generic /event dispatcher — this is what the userscripts POST to ──
async function handleEvent(payload) {
  const { type, src, content, concepts, meta } = payload;

  if (type === 'bridge_ready') {
    console.log(`[kernel] bridge ready: ${src}`);
    return { ok: true };
  }

  if (type === 'ai_response' || type === 'inject_ack') {
    // Claude bridge traffic — captured for potential loop-linking later,
    // not auto-turned into a Loop (that would be noisy; most AI turns
    // aren't open loops).
    bus.emit('bridge.' + type, { src, content, concepts, meta });
    return { ok: true };
  }

  if (type === 'dm_received') {
    // §12: DM convergence — auto-create a Loop, desk-solvable by default.
    const loop = loops.captureLoop(content, { concepts: concepts || extractConcepts(content), solvability: 'desk' });
    bus.emit('dm.converged', { src, loop_id: loop.id, meta });
    return { ok: true, loop_id: loop.id };
  }

  // Unknown event type — log, don't fail the request. §1.2 nothing
  // silently fails, but an unrecognized event type from a bridge script
  // shouldn't 500 and break the caller's queue-drain logic.
  console.warn(`[kernel] unhandled event type "${type}"`);
  return { ok: true, unhandled: true };
}

const server = http.createServer(async (req, res) => {
  const token = req.headers['x-auth-token'];
  if (token !== TOKEN) return send(res, 401, { error: 'bad token' });

  const url = new URL(req.url, `http://localhost:${PORT}`);
  const parts = url.pathname.split('/').filter(Boolean);

  try {
    // POST /event — generic bridge intake
    if (req.method === 'POST' && parts[0] === 'event') {
      const payload = await readBody(req);
      const result = await handleEvent(payload);
      return send(res, 200, result);
    }

    // ── loops ──
    if (req.method === 'GET' && parts[0] === 'loops') {
      return send(res, 200, store.readAll('loops'));
    }
    if (req.method === 'POST' && parts[0] === 'loops' && !parts[1]) {
      const { text } = await readBody(req);
      return send(res, 200, loops.captureLoop(text));
    }
    if (req.method === 'POST' && parts[0] === 'loops' && parts[2] === 'classify') {
      const { solvability } = await readBody(req);
      return send(res, 200, loops.classifyLoop(parts[1], solvability));
    }
    if (req.method === 'POST' && parts[0] === 'loops' && parts[2] === 'discharge') {
      const body = await readBody(req);
      return send(res, 200, loops.dischargeLoop(parts[1], body));
    }

    // ── quests ──
    if (req.method === 'GET' && parts[0] === 'quests') {
      return send(res, 200, store.readAll('quests'));
    }
    if (req.method === 'POST' && parts[0] === 'quests' && parts[1] === 'offer') {
      const { loop_id, tier_required } = await readBody(req);
      const loop = store.findOne('loops', loop_id);
      if (!loop) return send(res, 404, { error: 'loop not found' });
      const quest = baitEngine.offerQuest(loop, { tier_required });
      return send(res, 200, quest || { offered: false, reason: 'no generator had a real gap/match' });
    }
    if (req.method === 'POST' && parts[0] === 'quests' && parts[2] === 'respond') {
      const { response } = await readBody(req);
      return send(res, 200, baitEngine.respondToQuest(parts[1], response));
    }

    // ── tiers ──
    if (req.method === 'GET' && parts[0] === 'tiers') {
      return send(res, 200, store.readAll('tiers'));
    }
    if (req.method === 'POST' && parts[0] === 'tiers' && !parts[1]) {
      return send(res, 200, loops.createTier(await readBody(req)));
    }
    if (req.method === 'POST' && parts[0] === 'tiers' && parts[2] === 'activate') {
      return send(res, 200, loops.setActiveTier(parts[1]));
    }

    // ── patternsets ──
    if (req.method === 'GET' && parts[0] === 'patternsets') {
      return send(res, 200, store.readAll('patternsets'));
    }
    if (req.method === 'POST' && parts[0] === 'patternsets' && !parts[1]) {
      const { makePatternSet } = require('./models');
      const ps = makePatternSet(await readBody(req));
      return send(res, 200, store.insert('patternsets', ps));
    }

    // ── commitments ──
    if (req.method === 'GET' && parts[0] === 'commitments' && parts[1] === 'upcoming') {
      const hrs = Number(url.searchParams.get('withinHours') || 24);
      return send(res, 200, commitments.upcoming(hrs));
    }
    if (req.method === 'GET' && parts[0] === 'commitments') {
      return send(res, 200, store.readAll('commitments'));
    }
    if (req.method === 'POST' && parts[0] === 'commitments') {
      return send(res, 200, commitments.create(await readBody(req)));
    }

    // ── widgets ──
    if (req.method === 'GET' && parts[0] === 'widgets') {
      return send(res, 200, widgets.list());
    }
    if (req.method === 'POST' && parts[0] === 'widgets' && parts[2] === 'toggle') {
      const { enabled } = await readBody(req);
      return send(res, 200, widgets.setEnabled(parts[1], enabled));
    }

    // ── rewind ──
    if (req.method === 'GET' && parts[0] === 'rewind') {
      return send(res, 200, rewind.list());
    }
    if (req.method === 'POST' && parts[0] === 'rewind' && parts[1] === 'snapshot') {
      return send(res, 200, rewind.takeSnapshot('manual'));
    }
    if (req.method === 'POST' && parts[0] === 'rewind' && parts[2] === 'restore') {
      const { field } = await readBody(req);
      return send(res, 200, rewind.restore(parts[1], field || null));
    }
    if (req.method === 'POST' && parts[0] === 'rewind' && parts[1] === 'clear') {
      rewind.clear();
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: 'not found' });
  } catch (e) {
    console.error('[kernel] error handling request:', e);
    return send(res, 500, { error: e.message });
  }
});

// Poll for commitments due an alert — the one place a real, non-dismissible
// push is correct per §17.
setInterval(() => {
  for (const c of commitments.dueForAlert()) {
    console.log(`[ALERT] ${c.title} at ${new Date(c.when).toLocaleString()}`);
    bus.emit('commitment.alert', { commitment_id: c.id, title: c.title, when: c.when });
    commitments.markAlerted(c.id);
  }
}, 60 * 1000);

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[kernel] Open Loops listening on http://127.0.0.1:${PORT}`);
});

module.exports = server;
