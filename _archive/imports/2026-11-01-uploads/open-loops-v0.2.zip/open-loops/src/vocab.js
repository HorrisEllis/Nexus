'use strict';
const fs = require('fs');
const path = require('path');

const VOCAB_PATH = path.join(__dirname, '..', 'data', 'vocab.json');

function loadVocab() {
  if (!fs.existsSync(VOCAB_PATH)) return {};
  const raw = JSON.parse(fs.readFileSync(VOCAB_PATH, 'utf8'));
  const { _comment, ...categories } = raw;
  return categories; // { categoryName: string[] }
}

// Best-effort match of loop concepts against vocab categories.
// Returns [{ category, phrases }] sorted by relevance (concept overlap first).
function matchCategories(concepts) {
  const vocab = loadVocab();
  const matches = Object.entries(vocab).map(([category, phrases]) => {
    const overlap = concepts.filter(c =>
      category.includes(c) || phrases.some(p => p.toLowerCase().includes(c))
    ).length;
    return { category, phrases, overlap };
  });
  matches.sort((a, b) => b.overlap - a.overlap);
  return matches;
}

module.exports = { loadVocab, matchCategories, VOCAB_PATH };
