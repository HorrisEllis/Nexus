'use strict';
// §16: widgets are a view layer, not a storage layer. Disabling one never
// deletes or stops writing underlying data — it just stops rendering it.

const store = require('./store');
const { makeWidget } = require('./models');

const DEFAULT_WIDGETS = [
  { id: 'loop_inbox', enabled: true, slot: 'horizon_planner' },        // only mandatory-by-default widget
  { id: 'quest_card', enabled: true, slot: 'horizon_planner' },
  { id: 'tier_ladder', enabled: true, slot: 'horizon_planner' },
  { id: 'constellation_view', enabled: true, slot: 'brain_map' },
  { id: 'toast_layer', enabled: true, slot: 'floating', config: { duration_ms: 8000 } },
];

function ensureSeeded() {
  const existing = store.readAll('widgets');
  if (existing.length > 0) return existing;
  const seeded = DEFAULT_WIDGETS.map(w => makeWidget(w));
  store.writeAll('widgets', seeded);
  return seeded;
}

function list() {
  return ensureSeeded();
}

// No framing, no confirmation dialog — a checkbox, not a decision (§16).
function setEnabled(id, enabled) {
  const all = ensureSeeded();
  if (!all.some(w => w.id === id)) throw new Error(`[widgets] unknown widget "${id}"`);
  return store.update('widgets', id, { enabled });
}

function isEnabled(id) {
  const w = ensureSeeded().find(x => x.id === id);
  return w ? w.enabled : false;
}

module.exports = { list, setEnabled, isEnabled, ensureSeeded, DEFAULT_WIDGETS };
