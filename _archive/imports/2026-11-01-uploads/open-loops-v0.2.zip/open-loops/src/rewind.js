'use strict';
// §15: lighter-weight sibling of ClearGlass's RewindEngine, scoped to Open
// Loops state (loops/patternsets/tiers) instead of browser session state.
// Restore carries zero framing — it's a neutral state change, same register
// as any tier change in §1.

const store = require('./store');
const bus = require('./bus');
const { uuid, now } = require('./models');

const MAX_SNAPSHOTS = 100;
const SNAPSHOT_TRIGGERS = ['loop.discharged', 'tier.changed']; // + quest.responded:yes, handled separately

function takeSnapshot(reason) {
  const snapshot = {
    id: uuid(),
    ts: now(),
    reason,
    loops: store.readAll('loops'),
    patternSets: store.readAll('patternsets'),
    tiers: store.readAll('tiers'),
    activeTierId: (store.readAll('tiers').find(t => t.active) || {}).id || null,
  };
  const all = store.readAll('rewind_snapshots');
  all.push(snapshot);
  if (all.length > MAX_SNAPSHOTS) all.shift();
  store.writeAll('rewind_snapshots', all);
  bus.emit('rewind.snapshot', { snapshot_id: snapshot.id, reason });
  return snapshot;
}

function list() {
  return store.readAll('rewind_snapshots').map(s => ({ id: s.id, ts: s.ts, reason: s.reason }));
}

// field: null = restore everything, or 'tiers' | 'loops' | 'patternSets' to
// restore just one slice (§15's v1.1 field-level nicety, built in from the
// start since it's cheap here).
function restore(snapshotId, field = null) {
  const snap = store.readAll('rewind_snapshots').find(s => s.id === snapshotId);
  if (!snap) throw new Error(`[rewind] no snapshot ${snapshotId}`);

  const targets = field ? [field] : ['loops', 'patternSets', 'tiers'];
  const collectionMap = { loops: 'loops', patternSets: 'patternsets', tiers: 'tiers' };

  for (const t of targets) {
    store.writeAll(collectionMap[t], snap[t]);
  }
  bus.emit('rewind.restored', { snapshot_id: snapshotId, field: field || 'all' });
  return { restored: field || 'all', snapshot_id: snapshotId };
}

function clear() {
  store.writeAll('rewind_snapshots', []);
  bus.emit('rewind.cleared', {});
}

// Wire auto-snapshot triggers to the bus. Call once at startup.
function attachAutoSnapshot() {
  for (const type of SNAPSHOT_TRIGGERS) {
    bus.on(type, event => takeSnapshot(type));
  }
  // quest.responded only snapshots on 'yes' — not_now/reframe are no-ops,
  // shouldn't bloat history per §15.
  bus.on('quest.responded', event => {
    if (event.payload.response === 'yes') takeSnapshot('quest.responded:yes');
  });
}

module.exports = { takeSnapshot, list, restore, clear, attachAutoSnapshot, MAX_SNAPSHOTS };
