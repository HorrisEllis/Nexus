'use strict';
// §2.1 persistence is the golden rule — flat-file JSON, same convention as Hub.
// One file per collection. Every write is atomic (write temp, rename) so a
// crash mid-write can never corrupt state — §1.2 nothing silently fails.

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const COLLECTIONS = ['loops', 'quests', 'tiers', 'patternsets', 'commitments', 'widgets', 'rewind_snapshots', 'discharge_events'];

function filePath(collection) {
  if (!COLLECTIONS.includes(collection)) {
    throw new Error(`[store] unknown collection "${collection}"`);
  }
  return path.join(DATA_DIR, `${collection}.json`);
}

function readAll(collection) {
  const fp = filePath(collection);
  if (!fs.existsSync(fp)) return [];
  try {
    const raw = fs.readFileSync(fp, 'utf8');
    return raw.trim() ? JSON.parse(raw) : [];
  } catch (e) {
    // §0.3 information must never be lost — never overwrite a file we can't
    // parse. Back it up and surface the failure instead of silently resetting.
    const backup = fp + `.corrupt-${Date.now()}`;
    fs.copyFileSync(fp, backup);
    throw new Error(`[store] ${collection}.json failed to parse — backed up to ${backup}: ${e.message}`);
  }
}

function writeAll(collection, records) {
  const fp = filePath(collection);
  const tmp = fp + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(records, null, 2));
  fs.renameSync(tmp, fp); // atomic on same filesystem
  return records;
}

function insert(collection, record) {
  const all = readAll(collection);
  all.push(record);
  writeAll(collection, all);
  return record;
}

function update(collection, id, patch) {
  const all = readAll(collection);
  const idx = all.findIndex(r => r.id === id);
  if (idx === -1) throw new Error(`[store] ${collection}: no record with id ${id}`);
  all[idx] = { ...all[idx], ...patch };
  writeAll(collection, all);
  return all[idx];
}

function find(collection, predicate) {
  return readAll(collection).filter(predicate);
}

function findOne(collection, id) {
  return readAll(collection).find(r => r.id === id) || null;
}

module.exports = { readAll, writeAll, insert, update, find, findOne, DATA_DIR, COLLECTIONS };
