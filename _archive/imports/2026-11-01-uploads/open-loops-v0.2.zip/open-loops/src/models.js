'use strict';
const crypto = require('crypto');

const uuid = () => crypto.randomUUID();
const now = () => Date.now();

// §1.2 nothing silently fails — every factory validates required fields
// and throws rather than returning a half-built object.
function required(obj, fields, ctx) {
  for (const f of fields) {
    if (obj[f] === undefined || obj[f] === null) {
      throw new Error(`[models] ${ctx}: missing required field "${f}"`);
    }
  }
}

function makeLoop({ text, concepts = [], solvability = 'unclassified', linked_node_id = null }) {
  required({ text }, ['text'], 'Loop');
  return {
    id: uuid(),
    text,
    concepts,
    created_at: now(),
    status: 'open', // 'open' | 'desk_closed' | 'outside_closed' | 'dormant'
    solvability,     // 'desk' | 'outside' | 'unclassified'
    linked_node_id,
  };
}

function makeMicroQuest({ loop_id, prompt, bait_mode, tier_required = null, location_hint = null }) {
  required({ loop_id, prompt, bait_mode }, ['loop_id', 'prompt', 'bait_mode'], 'MicroQuest');
  if (!['curiosity', 'provocation', 'pattern'].includes(bait_mode)) {
    throw new Error(`[models] MicroQuest: invalid bait_mode "${bait_mode}"`);
  }
  return {
    id: uuid(),
    loop_id,
    prompt,
    bait_mode,
    tier_required,
    location_hint,
    offered_at: [],
    response_log: [], // { ts, response: 'yes'|'not_now'|'reframe' }
  };
}

function makeExposureTier({ label, order, quest_flavor_notes = '', active = false }) {
  required({ label, order }, ['label', 'order'], 'ExposureTier');
  return { id: uuid(), label, order, active, quest_flavor_notes };
}

function makePatternSet({ label, members = [], expected_size = null, linked_node_id = null }) {
  required({ label }, ['label'], 'PatternSet');
  return { id: uuid(), label, members, expected_size, linked_node_id };
}

function makeCommitment({ title, when, location = null, source = 'manual', linked_loop_id = null, reminder_lead_minutes = 30 }) {
  required({ title, when }, ['title', 'when'], 'Commitment');
  return { id: uuid(), title, when, location, source, linked_loop_id, reminder_lead_minutes, created_at: now() };
}

function makeWidget({ id, enabled = true, slot = null, config = {} }) {
  required({ id }, ['id'], 'Widget');
  return { id, enabled, slot, config };
}

module.exports = {
  uuid, now,
  makeLoop, makeMicroQuest, makeExposureTier, makePatternSet, makeCommitment, makeWidget,
};
