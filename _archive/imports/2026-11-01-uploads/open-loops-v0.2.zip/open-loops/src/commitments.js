'use strict';
// §17: commitments are NOT loops. Real external obligations get plain,
// reliable alerts — this module deliberately does not route through the
// toast/widget/dismiss-for-free machinery in §14/§16. That's the point.

const store = require('./store');
const bus = require('./bus');
const { makeCommitment, now } = require('./models');

function create(fields) {
  const commitment = makeCommitment(fields);
  store.insert('commitments', commitment);
  bus.emit('commitment.created', { commitment_id: commitment.id, when: commitment.when });
  return commitment;
}

function upcoming(withinHours = 24) {
  const cutoff = now() + withinHours * 60 * 60 * 1000;
  return store.find('commitments', c => c.when <= cutoff && c.when >= now());
}

// Should be polled by a scheduler (cron / setInterval in server.js) —
// fires a real alert event, not a dismissible toast. This is the one
// event type in the whole project explicitly exempt from §14's rules.
function dueForAlert() {
  const now_ = now();
  return store.find('commitments', c => {
    const leadMs = c.reminder_lead_minutes * 60 * 1000;
    return c.when - leadMs <= now_ && c.when > now_ && !c._alerted;
  });
}

function markAlerted(id) {
  return store.update('commitments', id, { _alerted: true });
}

module.exports = { create, upcoming, dueForAlert, markAlerted };
