'use strict';
const { matchCategories } = require('../vocab');

const TEMPLATES = [
  c => `Is there ${c} near you right now?`,
  c => `What would you find if you went looking for ${c} nearby?`,
  c => `Does the ${c} near you look different than you remember?`,
];

function generate(loop) {
  const matches = matchCategories(loop.concepts);
  const best = matches.find(m => m.overlap > 0) || matches[0];
  if (!best) return null;

  const subject = best.phrases[0] || best.category;
  const template = TEMPLATES[Math.floor(Math.random() * TEMPLATES.length)];
  return {
    prompt: template(subject),
    location_hint: null,
  };
}

module.exports = { generate };
