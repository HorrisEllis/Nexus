'use strict';
// §10 intent lock: v1 default bait_mode is 'pattern'. Curiosity/provocation
// remain available as explicit manual switches — never auto-inferred from
// mood/behavior, per §6b/§6c mode-selection rule.

const store = require('../store');
const bus = require('../bus');
const { makeMicroQuest, now } = require('../models');

const generators = {
  pattern: require('./pattern'),
  curiosity: require('./curiosity'),
  provocation: require('./provocation'),
};

// Fixed rotation order for reframe cycling — a plain object's key order
// happens to match this today, but pinning it explicitly means reframe
// behavior can't silently break if generators are ever reordered/added.
const MODE_ROTATION = ['pattern', 'curiosity', 'provocation'];

const DEFAULT_MODE = 'pattern';

// Reads the loop's own preferred mode if set, else the global default.
// Global default is itself just a config value the user can flip — never
// computed from anything like recent response history.
function resolveMode(loop, globalDefault = DEFAULT_MODE) {
  return loop.bait_mode_override || globalDefault;
}

// Generates a MicroQuest for a loop. Tries the resolved mode first; if that
// generator declines (returns null — e.g. pattern mode found no real gap),
// falls through to pattern -> curiosity -> provocation in that order rather
// than forcing a bad-fit bait. A loop with genuinely nothing to offer just
// doesn't get a quest yet, which is correct behavior, not a failure state.
function offerQuest(loop, opts = {}) {
  const mode = resolveMode(loop, opts.globalDefault);
  const order = [mode, ...Object.keys(generators).filter(m => m !== mode)];

  for (const m of order) {
    const result = generators[m].generate(loop);
    if (result) {
      const quest = makeMicroQuest({
        loop_id: loop.id,
        prompt: result.prompt,
        bait_mode: m,
        tier_required: opts.tier_required || null,
        location_hint: result.location_hint,
      });
      quest.offered_at.push(now());
      store.insert('quests', quest);
      bus.emit('quest.offered', { quest_id: quest.id, loop_id: loop.id, bait_mode: m });
      return quest;
    }
  }
  return null; // nothing to offer — not an error
}

// §1: exactly three responses, all zero-cost except 'yes'.
function respondToQuest(questId, response) {
  if (!['yes', 'not_now', 'reframe'].includes(response)) {
    throw new Error(`[baitEngine] invalid response "${response}"`);
  }
  const quest = store.findOne('quests', questId);
  if (!quest) throw new Error(`[baitEngine] no quest ${questId}`);

  quest.response_log.push({ ts: now(), response });
  store.update('quests', questId, { response_log: quest.response_log });
  bus.emit('quest.responded', { quest_id: questId, loop_id: quest.loop_id, response });

  if (response === 'reframe') {
    const loop = store.findOne('loops', quest.loop_id);
    if (loop) {
      // Full rotation through all three modes, not just the first different
      // one — previously this ping-ponged between two modes and could never
      // reach the third. §1's "reframe always available" means genuinely
      // available, not available-except-one-mode.
      const idx = MODE_ROTATION.indexOf(quest.bait_mode);
      const nextMode = MODE_ROTATION[(idx + 1) % MODE_ROTATION.length];
      return offerQuest({ ...loop, bait_mode_override: nextMode });
    }
  }
  return quest;
}

module.exports = { offerQuest, respondToQuest, resolveMode, DEFAULT_MODE, generators };
