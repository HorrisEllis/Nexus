'use strict';
// §6b, absolute rule: doubt the WORLD, never the PERSON. These templates are
// deliberately hardcoded (not generated) precisely so that rule can't drift —
// every string here has been written to target an outcome, not a character trait.

const { matchCategories } = require('../vocab');

const TEMPLATES = [
  c => `Bet the ${c} isn't actually there anymore.`,
  c => `You probably won't find anything interesting about the ${c} nearby.`,
  c => `Doubt the ${c} near you is worth the walk.`,
  c => `Probably closed / gone / not what you remember — the ${c} near you.`,
];

// Guardrail: reject any generated string containing self-referential /
// character-judgment language, even though templates are hardcoded above.
// Belt-and-suspenders in case templates are ever extended later.
const BANNED_PATTERNS = [/\byou (never|always|can't|won't)\b.*\b(follow|finish|stick|try)\b/i, /\byou're\s+(lazy|bad|failing)\b/i];

function isSafe(str) {
  return !BANNED_PATTERNS.some(re => re.test(str));
}

function generate(loop) {
  const matches = matchCategories(loop.concepts);
  const best = matches.find(m => m.overlap > 0) || matches[0];
  if (!best) return null;

  const subject = best.phrases[0] || best.category;
  const template = TEMPLATES[Math.floor(Math.random() * TEMPLATES.length)];
  const prompt = template(subject);

  if (!isSafe(prompt)) {
    console.error('[provocation] generated string failed self-worth guardrail, discarding:', prompt);
    return null;
  }
  return { prompt, location_hint: null };
}

module.exports = { generate, isSafe };
