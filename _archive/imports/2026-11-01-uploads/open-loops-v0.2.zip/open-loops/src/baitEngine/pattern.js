'use strict';
// §6c — the gap must be real. This module only ever reads gaps off actual
// PatternSet state (members.length vs expected_size) or off vocab categories
// with zero entries. It never invents a target count to create false tension.

const store = require('../store');

function findGapInPatternSets(loop) {
  const sets = store.find('patternsets', ps => ps.members.includes(loop.id));
  for (const ps of sets) {
    if (ps.expected_size != null && ps.members.length < ps.expected_size) {
      const remaining = ps.expected_size - ps.members.length;
      return {
        prompt: `"${ps.label}": ${ps.members.length} of ${ps.expected_size} confirmed. ${remaining} unconfirmed — this loop is one of them.`,
        location_hint: null,
      };
    }
  }
  return null;
}

function findGapInVocab() {
  const { loadVocab } = require('../vocab');
  const vocab = loadVocab();
  const empty = Object.entries(vocab).filter(([, phrases]) => phrases.length === 0);
  if (empty.length === 0) return null;
  const [category] = empty[0];
  return {
    prompt: `Your outside-vocabulary table has a category with zero entries: "${category}". Every other category has at least one.`,
    location_hint: null,
  };
}

// Returns { prompt, location_hint } or null if no real gap exists.
// Per §6c: returning null (declining to generate bait) is correct behavior
// when nothing is actually incomplete — never fabricate a gap to force output.
function generate(loop) {
  return findGapInPatternSets(loop) || findGapInVocab(loop) || null;
}

module.exports = { generate };
