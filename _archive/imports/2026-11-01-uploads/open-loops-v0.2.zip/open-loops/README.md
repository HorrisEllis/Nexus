# Open Loops — v0.2

Sovereign project. Not owned by MASTERMIND or NEXUS — integrates with both as an equal, replaceable party (see spec header). ClearGlass/Guardian is a documented future dependency (§13), not wired into v1.

## v0.2 — hostile review against real code (§7, run for real this time)

§7 in the spec was written against the design, not the code — running it against what actually shipped found two real bugs:

1. **`DischargeEvent` was constructed but never persisted** — only lived in the bus payload (in-memory, capped at 500, gone on restart). Violated §0.3 (information must never be lost). Fixed: now written to a `discharge_events` collection on disk.
2. **Reframe only ever reached two of three bait modes** — `Object.keys(generators).find(m => m !== tried)` ping-ponged between whichever two keys happened to come first, never rotating to the third. For a contract that promises "reframe always available," available-except-one-mode isn't actually that. Fixed: explicit `MODE_ROTATION` array, proper cyclic rotation.

Both have regression tests now (`discharge events are actually persisted`, `reframe rotates through all three bait modes`). 12/12 passing.

## Phase
FORGE-SKILL: 4 = Build. Version 0.1 per phase-increment convention.

## What's built (v1, deterministic, zero external dependencies)

- `src/models.js` — Loop, MicroQuest, ExposureTier, PatternSet, Commitment, Widget factories. All validate required fields and throw rather than silently building a bad object.
- `src/store.js` — flat-file JSON persistence, atomic writes (temp + rename), same convention as Hub. Corrupt files get backed up, never silently overwritten.
- `src/bus.js` — WARP-shaped Event/Gate pub-sub. Every mutation in this project emits through here.
- `src/concepts.js` — same concept extractor as the Claude/DM bridge userscripts (kept in sync manually, can't share code across the network boundary).
- `src/vocab.js` + `data/vocab.json` — user-seeded outside-vocabulary table. Seed your own categories; empty categories are valid input for pattern-completion bait, not bugs.
- `src/baitEngine/` — three deterministic generators (`pattern.js` default, `curiosity.js`, `provocation.js`) plus `index.js` for mode resolution and the `yes`/`not_now`/`reframe` response contract. Provocation has a hardcoded self-worth guardrail (`isSafe()`) that any future template addition must pass.
- `src/loops.js` — capture/classify/discharge lifecycle, tier changes (explicit-only, never auto-advanced), dormancy sweep.
- `src/commitments.js` — hard obligations, deliberately exempt from the zero-pressure delivery rules (§17). The one place a real, non-dismissible alert is correct.
- `src/widgets.js` — modular UI registry. View layer only — disabling a widget never touches underlying data.
- `src/rewind.js` — auto-snapshot on `loop.discharged` / `tier.changed` / `quest.responded:yes`, bounded history, field-level restore, zero framing on restore.
- `src/server.js` — HTTP kernel on `127.0.0.1:7820`, same token (`adhd-local-token`) and `/event` convention as the existing Claude bridge and DM listener userscripts. Drop-in target for both, unmodified.
- `test/run.js` — 10 real assertions covering capture, classify, bait generation + fallback, response-cost neutrality, the provocation guardrail, discharge, rewind snapshot/restore, widget isolation, and commitment alert timing. All passing.

## What's deferred (documented, not built)

- §13 AI-assistance via ClearGlass Guardian — v2, not wired in.
- §15's "v1.1 nicety" — field-level restore is actually already in (turned out cheap), so this shipped early.
- DM listener platform selectors (Discord/Instagram/X) — placeholders, unverified against live DOM, same maintenance model as the Claude bridge's `KNOWN_SELECTORS`.

## Running it

```
npm start        # boots kernel on 127.0.0.1:7820
npm test         # resets data/, runs the real test suite
```

## Next session should ask (per FORGE-SKILL)

- Phase: still 4 (Build) — UI phase (6) not started, this is backend/kernel only.
- Bugs: none known as of this build; all 10 tests green.
- Intent for next pass: wire a Horizon Planner / Brain Map consumer against this kernel's REST surface, or keep iterating backend (commitment alert delivery channel, dormancy sweep scheduling, PatternSet-from-Cortex-gaps decision from §13 if that gets un-deferred).
