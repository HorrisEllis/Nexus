'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
// Reset data dir for a clean test run.
for (const f of fs.existsSync(DATA_DIR) ? fs.readdirSync(DATA_DIR) : []) {
  if (f.endsWith('.json')) fs.unlinkSync(path.join(DATA_DIR, f));
}
// re-seed vocab (was deleted above)
fs.writeFileSync(path.join(DATA_DIR, 'vocab.json'), JSON.stringify({
  plants: ['silver-veined leaves'],
  sound: [],
}, null, 2));

const store = require('../src/store');
const bus = require('../src/bus');
const loops = require('../src/loops');
const baitEngine = require('../src/baitEngine');
const commitments = require('../src/commitments');
const widgets = require('../src/widgets');
const rewind = require('../src/rewind');
const { makePatternSet } = require('../src/models');
const provocation = require('../src/baitEngine/provocation');

// server.js normally wires this at startup — tests import modules directly
// without booting the server, so wire it explicitly here.
rewind.attachAutoSnapshot();

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  ok - ${name}`); }
  catch (e) { failed++; console.error(`  FAIL - ${name}\n    ${e.message}`); }
}

console.log('models + store + bus');
test('capture creates an open loop with extracted concepts', () => {
  const loop = loops.captureLoop('wondering about silver-veined leaves near the river');
  assert.strictEqual(loop.status, 'open');
  assert.strictEqual(loop.solvability, 'unclassified');
  assert.ok(loop.concepts.length > 0);
});

test('classify updates solvability and emits event', () => {
  const loop = loops.captureLoop('need to check the plant');
  let fired = false;
  bus.on('loop.classified', () => (fired = true));
  const updated = loops.classifyLoop(loop.id, 'outside');
  assert.strictEqual(updated.solvability, 'outside');
  assert.ok(fired);
});

console.log('bait engine — mode defaults + fallback');
test('pattern mode is default and falls through when no gap exists', () => {
  const loop = loops.captureLoop('a loop with no matching pattern set at all zzqx');
  const quest = baitEngine.offerQuest(loop);
  // no PatternSet exists yet and vocab has an empty 'sound' category,
  // so pattern.js should find the vocab gap and win.
  assert.ok(quest, 'expected a quest to be generated via vocab gap fallback');
  assert.strictEqual(quest.bait_mode, 'pattern');
});

test('pattern mode surfaces a real, non-fabricated PatternSet gap', () => {
  const loop = loops.captureLoop('checking on the silver-veined plant list');
  const ps = makePatternSet({ label: 'silver-veined plants', members: [loop.id], expected_size: 5 });
  store.insert('patternsets', ps);
  const quest = baitEngine.offerQuest(loop);
  assert.ok(quest.prompt.includes('4') || quest.prompt.includes('of 5'));
});

test('not_now and reframe cost nothing (no status change on loop)', () => {
  const loop = loops.captureLoop('reframe test loop');
  const quest = baitEngine.offerQuest(loop);
  assert.ok(quest);
  const before = store.findOne('loops', loop.id).status;
  baitEngine.respondToQuest(quest.id, 'not_now');
  const after = store.findOne('loops', loop.id).status;
  assert.strictEqual(before, after);
});

console.log('provocation guardrail');
test('provocation templates never target self-worth/character', () => {
  const unsafe = "You never follow through on anything, do you?";
  assert.strictEqual(provocation.isSafe(unsafe), false);
  const safe = "Bet the shop near you isn't actually there anymore.";
  assert.strictEqual(provocation.isSafe(safe), true);
});

console.log('discharge + rewind');
test('discharge marks loop closed and triggers auto-snapshot', () => {
  const loop = loops.captureLoop('discharge test loop');
  loops.dischargeLoop(loop.id, { mode: 'outside', note: 'found it' });
  const updated = store.findOne('loops', loop.id);
  assert.strictEqual(updated.status, 'outside_closed');
  const snaps = rewind.list();
  assert.ok(snaps.length > 0);
});

test('rewind restore brings back prior tier state without framing/side effects', () => {
  const tier = loops.createTier({ label: 'porch', order: 0 });
  loops.setActiveTier(tier.id);
  const snap = rewind.takeSnapshot('manual-test');
  loops.createTier({ label: 'driveway', order: 1 });
  const restoreResult = rewind.restore(snap.id, 'tiers');
  assert.strictEqual(restoreResult.restored, 'tiers');
  const tiersNow = store.readAll('tiers');
  assert.strictEqual(tiersNow.length, 1); // driveway rolled back
});

console.log('widgets');
test('loop_inbox defaults enabled, disabling never touches loop data', () => {
  const list = widgets.list();
  assert.ok(list.find(w => w.id === 'loop_inbox').enabled);
  const loopCountBefore = store.readAll('loops').length;
  widgets.setEnabled('toast_layer', false);
  assert.strictEqual(store.readAll('loops').length, loopCountBefore);
});

console.log('commitments — separate rules from loops');
test('commitment due-for-alert logic fires within lead window, not before', () => {
  const soon = commitments.create({ title: 'dentist', when: Date.now() + 10 * 60 * 1000, reminder_lead_minutes: 30 });
  const far = commitments.create({ title: 'far off thing', when: Date.now() + 5 * 60 * 60 * 1000, reminder_lead_minutes: 30 });
  const due = commitments.dueForAlert();
  assert.ok(due.some(c => c.id === soon.id));
  assert.ok(!due.some(c => c.id === far.id));
});

console.log('hostile-review regression tests');
test('discharge events are actually persisted, not just bus-emitted', () => {
  const loop = loops.captureLoop('persistence regression test loop');
  loops.dischargeLoop(loop.id, { mode: 'outside', note: 'persisted?' });
  const events = store.readAll('discharge_events');
  assert.ok(events.some(e => e.loop_id === loop.id && e.note === 'persisted?'));
});

test('reframe rotates through all three bait modes, not just two', () => {
  const loop = loops.captureLoop('reframe rotation test near river with plants');
  const q1 = baitEngine.offerQuest(loop, {}); // likely 'pattern' via vocab gap
  const modesSeen = new Set([q1.bait_mode]);
  let current = q1;
  for (let i = 0; i < 4; i++) {
    const next = baitEngine.respondToQuest(current.id, 'reframe');
    if (next) { modesSeen.add(next.bait_mode); current = next; }
  }
  assert.strictEqual(modesSeen.size, 3, `expected all 3 modes reachable via reframe, saw: ${[...modesSeen]}`);
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
