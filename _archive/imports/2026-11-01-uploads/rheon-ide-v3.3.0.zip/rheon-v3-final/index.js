/**
 * RHEON IDE — index.js
 * @uuid        aa000006-0000-4000-8000-000000000006
 * @version     3.0.0
 *
 * ROOT ENTRY POINT — run with: node index.js
 *
 * What this does:
 *   Starts the IDE server on http://localhost:7800
 *   Starts the WS bridge on ws://localhost:7800/ws
 *   Boots all modules in phase order
 *   Opens Jaa store
 *   Starts spec engine
 *   Watches modules/ for drag+drop hot-reload
 *
 * §1.2: Every failure is loud, specific, and traceable.
 *       Nothing exits silently.
 */

// Re-export core surfaces (for consumers who import from root)
export { bus, SISOBus, SISOEvent, StreamLog, Gate, Stream, SISO_VERSION } from './siso.js';
export { jaa, ALL_TABLES, uid, JAA_VERSION }                              from './jaa.js';
export { validateManifest, UI_SLOT, UI_COMPONENT, BOOT_PHASES }           from './plugins/plugin-schema.js';
export { bootAll, loadModule, unloadModule, watchModules, getRegistry, getHooks } from './plugins/plugin-loader.js';
export { init as initSpec, watchFiles }                                    from './spec/spec-engine.js';

// ── Entry point ───────────────────────────────────────────────────────────────
// Only runs when this file is the entry point (node index.js)
// import.meta.url check is the ESM equivalent of require.main === module

import { fileURLToPath } from 'url';
import { boot as serverBoot } from './server/index.js';

const isMain = process.argv[1] &&
  fileURLToPath(import.meta.url).replace(/\\/g, '/') ===
  process.argv[1].replace(/\\/g, '/');

if (isMain) {
  serverBoot().catch(err => {
    console.error('\n  [FATAL] Boot failed:', err.message);
    console.error('  Stack:', err.stack);
    process.exit(1);
  });
}

export const CORE_VERSION = '3.0.0';
export const CORE_UUID    = 'aa000006-0000-4000-8000-000000000006';
