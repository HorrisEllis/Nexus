/**
 * RHEON CORE — siso.js
 * @uuid        aa000001-0000-4000-8000-000000000001
 * @version     3.0.0
 * @layer       0 — ROOT (immutable after v1.0.0, §5.7)
 * @axioms      §3.1 §5.1 §5.6 §5.7 §8.3
 *
 * THE IMMUTABLE CORE.
 * This file and core/jaa.js are the only files in root/core/.
 * Every other system is a module in modules/.
 * Nothing in this file changes without a major version bump.
 *
 * Exports: SISOEvent, StreamLog, Gate, Stream, SISOBus, bus
 * The singleton `bus` is the only shared surface between all modules.
 */

'use strict';

// ── Logical clock (§3.2) ──────────────────────────────────────────────────────
// eventTs is the ONLY ordering axis. wall is display metadata only.
let _tick = 0;
let _seq  = 0;

export function _resetClock() { _tick = 0; _seq = 0; } // test-only

// ── SISOEvent ─────────────────────────────────────────────────────────────────
export class SISOEvent {
  constructor(type, payload = {}, opts = {}) {
    if (typeof type !== 'string' || !type) throw new Error('[SISOEvent] type must be non-empty string');
    this.id             = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}-${_seq++}`;
    this.type           = type;
    this.tick           = ++_tick;
    this.wall           = Date.now();
    this.causedBy       = opts.causedBy    || null;
    this.relatedTo      = Object.freeze(opts.relatedTo || []);
    this.payload        = Object.freeze({ ...(payload || {}) });
    this.streamId       = opts.streamId    || 1;
    this.parentStreamId = opts.parentStreamId || null;
    Object.freeze(this);
  }
}

// ── StreamLog ─────────────────────────────────────────────────────────────────
export class StreamLog {
  constructor(maxSize = 50000) {
    this._entries = [];
    this._idx     = new Map();
    this._maxSize = maxSize;
  }
  push(ev) {
    this._entries.push(ev);
    this._idx.set(ev.id, ev);
    if (this._entries.length > this._maxSize) {
      this._idx.delete(this._entries.shift().id);
    }
  }
  get entries() { return this._entries; }
  get size()    { return this._entries.length; }
  byId(id)      { return this._idx.get(id) || null; }
  byType(t)     { return this._entries.filter(e => e.type === t); }
  upTo(tick)    { return this._entries.filter(e => e.tick <= tick); }
  causalChain(id, max = 20) {
    const chain = []; let cur = this._idx.get(id); let d = 0;
    while (cur && d++ < max) { chain.push(cur); cur = cur.causedBy ? this._idx.get(cur.causedBy) : null; }
    return chain;
  }
  forkAt(tick)  { const f = new StreamLog(this._maxSize); this.upTo(tick).forEach(e => f.push(e)); return f; }
  stats()       { return { size: this._entries.length, max: this._maxSize }; }
}

// ── Gate ──────────────────────────────────────────────────────────────────────
export class Gate {
  constructor(name) {
    if (!name) throw new Error('[Gate] name required');
    this.name = name;
    this._processed = new WeakMap();
  }
  matches(ev)          { return false; }
  transform(ev, stream){ /* override */ }
  wasProcessedBy(ev)   { return this._processed.get(ev)?.has(this.name) || false; }
  markProcessed(ev)    {
    if (!this._processed.has(ev)) this._processed.set(ev, new Set());
    this._processed.get(ev).add(this.name);
  }
}

// ── Stream ────────────────────────────────────────────────────────────────────
export class Stream {
  constructor(id = 1, log = null) {
    this._id    = id;
    this._gates = [];
    this._log   = log || new StreamLog();
    this._q     = [];
    this._run   = false;
  }
  register(gate) {
    if (!(gate instanceof Gate)) throw new Error('[Stream] must be Gate instance');
    this._gates.push(gate);
    return this;
  }
  emit(type, payload = {}, opts = {}) {
    const ev = new SISOEvent(type, payload, { ...opts, streamId: this._id });
    this._log.push(ev);
    this._q.push(ev);
    if (!this._run) this._drain();
    return ev;
  }
  _drain() {
    this._run = true;
    while (this._q.length) {
      const ev = this._q.shift();
      for (const gate of this._gates) {
        if (gate.matches(ev)) {
          try { gate.transform(ev, this); }
          catch (err) {
            this.emit('gate.error', { gate: gate.name, error: err.message, eventId: ev.id });
          }
          break;
        }
      }
    }
    this._run = false;
  }
  get log() { return this._log; }
  get id()  { return this._id; }
}

// ── SISOBus ───────────────────────────────────────────────────────────────────
export class SISOBus {
  constructor(opts = {}) {
    this._h    = new Map();   // pattern → handler[]
    this._log  = new StreamLog(opts.ringSize || 50000);
    this._seq  = 0;
    this._paused = false;
    this._pq   = [];
  }

  on(pattern, fn) {
    if (typeof fn !== 'function') throw new Error(`[SISOBus] handler must be function`);
    if (!this._h.has(pattern)) this._h.set(pattern, []);
    this._h.get(pattern).push(fn);
    return () => {
      const arr = this._h.get(pattern);
      if (arr) { const i = arr.indexOf(fn); if (i >= 0) arr.splice(i, 1); }
    };
  }

  emit(type, payload = {}, opts = {}) {
    if (typeof type !== 'string' || !type) throw new Error(`[SISOBus] type must be non-empty string`);
    const ev = new SISOEvent(type, payload || {}, opts);
    this._log.push(ev);
    this._seq++;
    if (this._paused) { this._pq.push(ev); return ev; }
    this._route(ev);
    return ev;
  }

  _route(ev) {
    for (const [pat, fns] of this._h) {
      if (this._match(pat, ev.type)) {
        for (const fn of fns) {
          try { fn(ev); }
          catch (err) {
            console.error(`[SISOBus] handler error on "${pat}" for "${ev.type}":`, err.message);
            // emit error without infinite loop risk — use raw push
            const errEv = new SISOEvent('bus.handler.error', { pattern: pat, eventType: ev.type, error: err.message });
            this._log.push(errEv);
            // Route error to error handlers only
            const errFns = this._h.get('bus.handler.error') || [];
            errFns.forEach(f => { try { f(errEv); } catch {} });
          }
        }
      }
    }
  }

  _match(pat, type) {
    if (pat === type || pat === '*') return true;
    if (pat.endsWith('.**')) {
      const p = pat.slice(0, -3);
      return type === p || type.startsWith(p + '.');
    }
    if (pat.endsWith('.*')) {
      const p = pat.slice(0, -2);
      const rest = type.slice(p.length + 1);
      return type.startsWith(p + '.') && !rest.includes('.');
    }
    return false;
  }

  pause()  { this._paused = true; }
  resume() {
    this._paused = false;
    const q = this._pq.splice(0);
    q.forEach(ev => this._route(ev));
  }

  history(prefix, n = 100) {
    const e = prefix ? this._log.entries.filter(ev => ev.type.startsWith(prefix)) : this._log.entries;
    return e.slice(-n);
  }

  stats() {
    return { events: this._seq, log: this._log.stats(), patterns: this._h.size };
  }

  get log() { return this._log; }
}

// ── Singleton bus — THE shared surface ───────────────────────────────────────
export const bus = new SISOBus({ ringSize: 100000 });

export const SISO_VERSION = '3.0.0';
export const SISO_UUID    = 'aa000001-0000-4000-8000-000000000001';
