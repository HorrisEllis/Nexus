/**
 * RHEON UI — interaction-contract.js
 * @uuid        cc000001-0000-4000-8000-000000000001
 * @version     3.0.0
 * @axioms      §5.1 §5.7 §6.1
 *
 * THE UI INTERACTION CONTRACT.
 * This is the UI-side equivalent of map/index.js.
 * Every component imports from here — never from other components.
 * UI never imports from modules/ or plugins/ directly.
 *
 * Hook = a named, typed binding point where UI intent meets system reality.
 *   "A hook is an interface contract. Not a subscription. Not an event listener.
 *    The schema declares it. Both sides must honor it."  — LIVING-DOCUMENT.md
 *
 * §5.7: All inter-component communication via the bridge (bus events).
 * Components may call CONTRACT.emit() and CONTRACT.on() only.
 * Direct inter-component calls are prohibited.
 */

'use strict';

// ── Channel mirror (matches server-side CH exactly) ──────────────────────────
export const CH = Object.freeze({
  // Kernel
  KERNEL_CONNECTED:    'ide:kernel:connected',
  KERNEL_DISCONNECTED: 'ide:kernel:disconnected',
  KERNEL_NODE:         'ide:kernel:node:committed',
  KERNEL_GAP:          'ide:kernel:gap:opened',
  KERNEL_BEP:          'ide:kernel:bep:signal',
  KERNEL_STATUS:       'ide:kernel:status',
  KERNEL_MIRROR:       'ide:kernel:node:mirror',

  // Editor
  EDITOR_CONTENT:      'ide:editor:content:changed',
  EDITOR_SUBMIT:       'ide:editor:submit',
  EDITOR_MODE:         'ide:editor:mode:changed',
  EDITOR_FILE:         'ide:editor:file:opened',
  EDITOR_SAVED:        'ide:editor:file:saved',

  // Seam
  SEAM_PARSED:         'ide:seam:parsed',
  FIELD_UPDATED:       'ide:field:updated',
  FIELD_GAPS:          'ide:field:gaps:updated',

  // Preview
  PREVIEW_MODE:        'ide:preview:mode:changed',
  PREVIEW_CONTENT:     'ide:preview:content:updated',

  // Compiler
  COMPILER_STARTED:    'ide:compiler:started',
  COMPILER_PROGRESS:   'ide:compiler:gate:progress',
  COMPILER_DONE:       'ide:compiler:done',
  COMPILER_FAILED:     'ide:compiler:failed',

  // Agents
  AGENT_REQUEST:       'ide:agent:request',
  AGENT_RESPONSE:      'ide:agent:response',
  AGENT_STREAM_CHUNK:  'ide:agent:stream:chunk',
  AGENT_ERROR:         'ide:agent:error',
  AGENT_MODELS:        'ide:agent:ollama:models:updated',

  // Voice
  VOICE_STARTED:       'ide:voice:mic:started',
  VOICE_STOPPED:       'ide:voice:mic:stopped',
  VOICE_FINAL:         'ide:voice:transcript:final',
  VOICE_INTERIM:       'ide:voice:transcript:interim',

  // Console
  CONSOLE_EVENT:       'ide:console:bus:event',
  CONSOLE_RESPONSE:    'ide:console:cli:response',

  // Grammar
  GRAMMAR_UPDATED:     'ide:grammar:words:updated',

  // Plugins
  PLUGIN_LOADED:       'plugin:loaded',
  PLUGIN_UNLOADED:     'plugin:unloaded',
  PLUGIN_DISCOVERED:   'plugin:discovered',
  PLUGIN_HOOKS:        'ide:plugin:hooks:updated',

  // Debug
  DEBUG_COMPONENT:     'ide:debug:component:toggle',
  DEBUG_EVENT:         'ide:debug:event:captured',

  // Drag+drop
  DROP_FILE:           'ide:drop:file',
  DROP_ZIP:            'ide:drop:zip',
  DROP_FOLDER:         'ide:drop:folder',
  DROP_INSTALLED:      'ide:drop:installed',

  // Spec
  SPEC_UPDATED:        'spec:updated',
});

// ── UI Component Hook Registry ────────────────────────────────────────────────
// Every component declares its hook here before mounting.
// This is read by the debug overlay and plugin manager.

export const COMPONENT_HOOKS = Object.freeze({

  'swirl-engine': {
    uuid:    'cc-comp-001-swirl-engine',
    reads:   [],  // purely visual — responds to no events
    emits:   [],
    mounts:  '#swirl-canvas',
    debug:   'pause particle loop',
    isolate: 'hides canvas, UI continues',
  },

  'topbar': {
    uuid:   'cc-comp-002-topbar',
    reads:  [CH.KERNEL_STATUS, CH.AGENT_MODELS, CH.VOICE_STARTED, CH.VOICE_STOPPED, CH.COMPILER_PROGRESS],
    emits:  [CH.EDITOR_SUBMIT],
    mounts: '#topbar',
    debug:  'shows all status as raw JSON badges',
    isolate:'kernel status badge shows ISOLATED',
  },

  'prose-editor': {
    uuid:   'cc-comp-003-prose-editor',
    reads:  [CH.VOICE_FINAL, CH.GRAMMAR_UPDATED, CH.KERNEL_STATUS],
    emits:  [CH.EDITOR_CONTENT, CH.EDITOR_SUBMIT, CH.EDITOR_MODE, CH.EDITOR_SAVED],
    mounts: '#editor-pane',
    debug:  'shows block IDs, keystroke timing, word count per block',
    isolate:'disables submit button, emits to null bus',
  },

  'code-editor': {
    uuid:   'cc-comp-004-code-editor',
    reads:  [CH.VOICE_FINAL, CH.AGENT_RESPONSE],
    emits:  [CH.EDITOR_CONTENT, CH.EDITOR_SUBMIT, CH.EDITOR_SAVED],
    mounts: '#code-pane',
    debug:  'shows token stream, syntax parse errors',
    isolate:'disables submit, highlights unchanged',
  },

  'field-pane': {
    uuid:   'cc-comp-005-field-pane',
    reads:  [CH.KERNEL_NODE, CH.KERNEL_GAP, CH.KERNEL_BEP, CH.FIELD_UPDATED, CH.SEAM_PARSED],
    emits:  [],
    mounts: '#field-pane',
    debug:  'shows raw constraint objects, gap scores, BEP stage',
    isolate:'renders last known field state frozen',
  },

  'preview-pane': {
    uuid:   'cc-comp-006-preview-pane',
    reads:  [CH.PREVIEW_MODE, CH.PREVIEW_CONTENT, CH.COMPILER_PROGRESS, CH.COMPILER_DONE, CH.EDITOR_CONTENT],
    emits:  [CH.PREVIEW_MODE],
    mounts: '#preview-pane',
    debug:  'shows iframe sandbox state, mode tabs with event log',
    isolate:'freezes preview at last render',
  },

  'console-pane': {
    uuid:   'cc-comp-007-console-pane',
    reads:  [CH.CONSOLE_EVENT, CH.CONSOLE_RESPONSE, CH.AGENT_RESPONSE, CH.AGENT_STREAM_CHUNK],
    emits:  [CH.CONSOLE_EVENT],
    mounts: '#console-pane',
    debug:  'shows full event payload expanded, tick numbers visible',
    isolate:'bus stream pauses, CLI still works locally',
  },

  'settings-panel': {
    uuid:   'cc-comp-008-settings-panel',
    reads:  [CH.AGENT_MODELS, CH.PLUGIN_HOOKS],
    emits:  ['ide:agent:ollama:request:model', 'ide:agent:ollama:request:ping'],
    mounts: '#settings-panel',
    debug:  'shows raw catalog JSON, API latency per ping',
    isolate:'read-only, no model changes applied',
  },

  'drag-drop-zone': {
    uuid:   'cc-comp-009-drag-drop',
    reads:  [],
    emits:  [CH.DROP_FILE, CH.DROP_ZIP, CH.DROP_FOLDER, CH.DROP_INSTALLED],
    mounts: 'document (global drop handler)',
    debug:  'shows every drag event, MIME type, file list',
    isolate:'accepts drops but emits to log only, no installs',
  },

  'plugin-manager': {
    uuid:   'cc-comp-010-plugin-manager',
    reads:  [CH.PLUGIN_LOADED, CH.PLUGIN_UNLOADED, CH.PLUGIN_HOOKS],
    emits:  ['plugin:load:request', 'plugin:unload:request'],
    mounts: '#plugin-manager-panel',
    debug:  'shows full registry, hook table, Jaa plugin_hooks table',
    isolate:'read-only view, no load/unload actions',
  },

  'debug-overlay': {
    uuid:   'cc-comp-011-debug-overlay',
    reads:  ['*'],  // listens to everything
    emits:  [CH.DEBUG_COMPONENT, CH.DEBUG_EVENT],
    mounts: '#debug-overlay',
    debug:  'this IS the debug component — cannot debug itself',
    isolate:'N/A',
  },
});

// ── Component isolation states ────────────────────────────────────────────────
// What "debug one component" means for each:
// ACTIVE   → normal operation
// DEBUG    → extra logging, raw data visible, no functional change
// ISOLATED → component input/output disconnected from real bus,
//            routed to debug null-bus instead
// DISABLED → component not mounted, slot shows placeholder

export const ISOLATION_STATE = Object.freeze({
  ACTIVE:   'active',
  DEBUG:    'debug',
  ISOLATED: 'isolated',
  DISABLED: 'disabled',
});

// ── UI Elements Index ─────────────────────────────────────────────────────────
// Maps hookIds (from plugin MANIFEST.json ui_hooks) → DOM slot IDs
// Plugin loader reads this to know where to mount hook UI

export const UI_SLOTS_DOM = Object.freeze({
  'topbar':             '#topbar-hooks',
  'topbar.right':       '#topbar-right-hooks',
  'sidebar':            '#sidebar-hooks',
  'sidebar.section':    '#sidebar-section-hooks',
  'pane.editor':        '#editor-pane-hooks',
  'pane.field':         '#field-pane-hooks',
  'pane.preview':       '#preview-pane-hooks',
  'pane.console':       '#console-pane-hooks',
  'settings.section':   '#settings-hooks',
  'status.bar':         '#statusbar-hooks',
  'context.menu':       '#context-menu-hooks',
});

export const CONTRACT_VERSION = '3.0.0';
export const CONTRACT_UUID    = 'cc000001-0000-4000-8000-000000000001';
