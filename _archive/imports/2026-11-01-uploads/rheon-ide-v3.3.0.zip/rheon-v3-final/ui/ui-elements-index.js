/**
 * RHEON UI — ui-elements-index.js
 * @uuid        cc000002-0000-4000-8000-000000000002
 * @version     3.0.0
 * @axioms      §5.1 §5.3 §6.1
 *
 * EVERY DOM element that has a role in the system is indexed here.
 * The debug overlay reads this to show what each element does.
 * The interaction contract reads this to validate hook mounts.
 *
 * Structure mirrors §5.6 fractal law:
 *   component → element → hook → channel
 */

'use strict';

import { COMPONENT_HOOKS, CH, UI_SLOTS_DOM } from './interaction-contract.js';

// ── Element registry ──────────────────────────────────────────────────────────
// Every significant DOM element. Keyed by element ID.
// Built at mount time — see mount() below.

const _elements = new Map(); // elementId → ElementRecord
const _byComponent = new Map(); // componentId → ElementRecord[]
const _byChannel = new Map(); // channel → ElementRecord[]

export function register(record) {
  // record: { id, componentId, role, channel?, hookId?, debugLabel }
  if (!record.id) throw new Error('[ui-elements-index] id required');
  if (!record.componentId) throw new Error('[ui-elements-index] componentId required');

  _elements.set(record.id, record);

  if (!_byComponent.has(record.componentId)) _byComponent.set(record.componentId, []);
  _byComponent.get(record.componentId).push(record);

  if (record.channel) {
    if (!_byChannel.has(record.channel)) _byChannel.set(record.channel, []);
    _byChannel.get(record.channel).push(record);
  }
}

export const query = {
  byId:        (id)          => _elements.get(id) || null,
  byComponent: (componentId) => _byComponent.get(componentId) || [],
  byChannel:   (channel)     => _byChannel.get(channel) || [],
  all:         ()            => [..._elements.values()],
  summary:     () => ({
    total:      _elements.size,
    components: _byComponent.size,
    channels:   _byChannel.size,
  }),
};

// ── Pre-declared elements (registered before DOM exists) ──────────────────────
// These match the IDs in index.html exactly.

const STATIC_ELEMENTS = [
  // Swirl engine
  { id: 'swirl-canvas',       componentId: 'swirl-engine',   role: 'canvas',   debugLabel: 'Van Gogh particle field' },

  // Topbar
  { id: 'topbar',             componentId: 'topbar',         role: 'container',debugLabel: 'Top bar container' },
  { id: 'topbar-hooks',       componentId: 'topbar',         role: 'hook-slot',debugLabel: 'Plugin hook slot: topbar' },
  { id: 'topbar-right-hooks', componentId: 'topbar',         role: 'hook-slot',debugLabel: 'Plugin hook slot: topbar.right' },
  { id: 'conn-dot',           componentId: 'topbar',         role: 'indicator',channel: CH.KERNEL_STATUS, debugLabel: 'Kernel connection dot' },
  { id: 'conn-label',         componentId: 'topbar',         role: 'text',     channel: CH.KERNEL_STATUS, debugLabel: 'Kernel connection label' },
  { id: 'ollama-dot',         componentId: 'topbar',         role: 'indicator',channel: CH.AGENT_MODELS,  debugLabel: 'Ollama status dot' },
  { id: 'voice-btn',          componentId: 'topbar',         role: 'button',   channel: CH.VOICE_STARTED, debugLabel: 'Voice toggle button' },
  { id: 'bep-badge',          componentId: 'topbar',         role: 'badge',    channel: CH.KERNEL_BEP,    debugLabel: 'BEP stage badge' },
  { id: 'submit-btn',         componentId: 'topbar',         role: 'button',   channel: CH.EDITOR_SUBMIT,  debugLabel: 'Submit expression button' },
  { id: 'build-btn',          componentId: 'topbar',         role: 'button',   channel: CH.COMPILER_STARTED,debugLabel: 'Build button' },
  { id: 'settings-btn',       componentId: 'topbar',         role: 'button',   debugLabel: 'Settings panel toggle' },
  { id: 'debug-btn',          componentId: 'topbar',         role: 'button',   channel: CH.DEBUG_COMPONENT, debugLabel: 'Debug overlay toggle' },

  // Editor pane
  { id: 'editor-pane',        componentId: 'prose-editor',   role: 'container',debugLabel: 'Editor pane outer' },
  { id: 'editor-pane-hooks',  componentId: 'prose-editor',   role: 'hook-slot',debugLabel: 'Plugin hook slot: pane.editor' },
  { id: 'mode-tabs',          componentId: 'prose-editor',   role: 'tabs',     channel: CH.EDITOR_MODE,    debugLabel: 'Seam/Code/Prose/Spec tabs' },
  { id: 'prose-canvas',       componentId: 'prose-editor',   role: 'canvas',   channel: CH.EDITOR_CONTENT, debugLabel: 'Block-based prose canvas' },
  { id: 'signal-ring',        componentId: 'prose-editor',   role: 'indicator',debugLabel: 'Keystroke signal ring' },
  { id: 'editor-footer',      componentId: 'prose-editor',   role: 'status',   debugLabel: 'Editor footer: state, wc, confidence' },
  { id: 'ef-state',           componentId: 'prose-editor',   role: 'text',     debugLabel: 'Write state (flow/thinking/revising)' },
  { id: 'ef-wc',              componentId: 'prose-editor',   role: 'text',     debugLabel: 'Word count' },

  // Code editor pane
  { id: 'code-pane',          componentId: 'code-editor',    role: 'container',debugLabel: 'Code editor pane' },
  { id: 'code-input',         componentId: 'code-editor',    role: 'textarea', channel: CH.EDITOR_CONTENT, debugLabel: 'Code textarea' },
  { id: 'code-highlight',     componentId: 'code-editor',    role: 'overlay',  debugLabel: 'Syntax highlight overlay' },
  { id: 'line-numbers',       componentId: 'code-editor',    role: 'gutter',   debugLabel: 'Line number gutter' },
  { id: 'lang-tabs',          componentId: 'code-editor',    role: 'tabs',     debugLabel: 'JS/PY/HTML/CSS language tabs' },

  // Field pane
  { id: 'field-pane',         componentId: 'field-pane',     role: 'container',debugLabel: 'Constraint field pane' },
  { id: 'field-pane-hooks',   componentId: 'field-pane',     role: 'hook-slot',debugLabel: 'Plugin hook slot: pane.field' },
  { id: 'constraints-list',   componentId: 'field-pane',     role: 'list',     channel: CH.FIELD_UPDATED,  debugLabel: 'Constraint items' },
  { id: 'gaps-list',          componentId: 'field-pane',     role: 'list',     channel: CH.FIELD_GAPS,     debugLabel: 'Open gap items' },
  { id: 'field-node-count',   componentId: 'field-pane',     role: 'badge',    channel: CH.KERNEL_NODE,    debugLabel: 'Node count badge' },
  { id: 'field-gap-count',    componentId: 'field-pane',     role: 'badge',    channel: CH.FIELD_GAPS,     debugLabel: 'Gap count badge' },

  // Preview pane
  { id: 'preview-pane',       componentId: 'preview-pane',   role: 'container',debugLabel: 'Preview pane' },
  { id: 'preview-pane-hooks', componentId: 'preview-pane',   role: 'hook-slot',debugLabel: 'Plugin hook slot: pane.preview' },
  { id: 'preview-mode-tabs',  componentId: 'preview-pane',   role: 'tabs',     channel: CH.PREVIEW_MODE,   debugLabel: 'HTML/Field/Spec/Build tabs' },
  { id: 'preview-body',       componentId: 'preview-pane',   role: 'body',     channel: CH.PREVIEW_CONTENT,debugLabel: 'Preview content area' },
  { id: 'preview-build',      componentId: 'preview-pane',   role: 'log',      channel: CH.COMPILER_PROGRESS,debugLabel: 'Build log stream' },

  // Console pane
  { id: 'console-pane',       componentId: 'console-pane',   role: 'container',debugLabel: 'Console pane' },
  { id: 'console-pane-hooks', componentId: 'console-pane',   role: 'hook-slot',debugLabel: 'Plugin hook slot: pane.console' },
  { id: 'bus-stream',         componentId: 'console-pane',   role: 'stream',   channel: CH.CONSOLE_EVENT,  debugLabel: 'Bus event stream panel' },
  { id: 'cli-output',         componentId: 'console-pane',   role: 'output',   channel: CH.CONSOLE_RESPONSE,debugLabel: 'CLI output panel' },
  { id: 'cli-input',          componentId: 'console-pane',   role: 'input',    debugLabel: 'CLI input field' },

  // Settings panel
  { id: 'settings-panel',     componentId: 'settings-panel', role: 'container',debugLabel: 'Settings panel' },
  { id: 'settings-hooks',     componentId: 'settings-panel', role: 'hook-slot',debugLabel: 'Plugin hook slot: settings.section' },
  { id: 'ollama-catalog',     componentId: 'settings-panel', role: 'catalog',  channel: CH.AGENT_MODELS,   debugLabel: 'Ollama model catalog' },

  // Drag+drop
  { id: 'drop-overlay',       componentId: 'drag-drop-zone', role: 'overlay',  debugLabel: 'Global drag+drop overlay' },

  // Plugin manager
  { id: 'plugin-manager-panel',componentId:'plugin-manager', role: 'container',debugLabel: 'Plugin manager panel' },

  // Debug overlay
  { id: 'debug-overlay',      componentId: 'debug-overlay',  role: 'overlay',  debugLabel: 'Component debug overlay' },
  { id: 'debug-component-select', componentId: 'debug-overlay', role: 'select',debugLabel: 'Component selector for debug' },
  { id: 'debug-event-log',    componentId: 'debug-overlay',  role: 'log',      debugLabel: 'Filtered event log for selected component' },
  { id: 'debug-raw-state',    componentId: 'debug-overlay',  role: 'raw',      debugLabel: 'Raw component state dump' },
  { id: 'debug-isolate-btn',  componentId: 'debug-overlay',  role: 'button',   channel: CH.DEBUG_COMPONENT, debugLabel: 'Isolate component button' },

  // Statusbar
  { id: 'statusbar',          componentId: 'topbar',         role: 'statusbar',debugLabel: 'Status bar' },
  { id: 'statusbar-hooks',    componentId: 'topbar',         role: 'hook-slot',debugLabel: 'Plugin hook slot: status.bar' },
  { id: 'sb-w',               componentId: 'prose-editor',   role: 'text',     debugLabel: 'Word count display' },
  { id: 'sb-l',               componentId: 'prose-editor',   role: 'text',     debugLabel: 'Lines/blocks display' },
  { id: 'sb-snaps',           componentId: 'prose-editor',   role: 'text',     debugLabel: 'Snapshot count' },
  { id: 'sb-session',         componentId: 'prose-editor',   role: 'text',     debugLabel: 'Session timer' },
];

// Register all static elements
STATIC_ELEMENTS.forEach(e => register(e));

export const UI_ELEMENTS_VERSION = '3.0.0';
export const UI_ELEMENTS_UUID    = 'cc000002-0000-4000-8000-000000000002';
