/**
 * RHEON UI — swirl-engine component
 * @uuid        cc-comp-001-0000-4000-8000-000000000001
 * @version     3.0.0
 * @component   swirl-engine
 * @reads       []  (visual only — no bus subscriptions)
 * @emits       []
 * @mounts      #swirl-canvas
 *
 * Van Gogh flow-field particle system from living-editor-v2.html.
 * Fully isolated — removing this component has zero effect on system.
 * Debug mode: pause() / resume() controls exposed.
 * Isolated mode: canvas hidden, rAF loop stopped.
 */

export const COMPONENT_ID = 'swirl-engine';
export const COMPONENT_UUID = 'cc-comp-001-0000-4000-8000-000000000001';

let _canvas, _ctx, _particles = [], _t = 0, _raf = null, _running = false;
let _debugMode = false, _isolatedMode = false;

// ── Mount ─────────────────────────────────────────────────────────────────────
export function mount(canvasEl) {
  _canvas = canvasEl || document.getElementById('swirl-canvas');
  if (!_canvas) throw new Error('[swirl-engine] #swirl-canvas not found');
  _ctx = _canvas.getContext('2d');
  _resize();
  window.addEventListener('resize', _resize);
  _running = true;
  _loop();
  return { unmount, pause, resume, setDebug, setIsolated, status };
}

// ── Unmount ───────────────────────────────────────────────────────────────────
export function unmount() {
  _running = false;
  if (_raf) cancelAnimationFrame(_raf);
  window.removeEventListener('resize', _resize);
  if (_canvas) _canvas.style.display = 'none';
}

// ── Debug mode ────────────────────────────────────────────────────────────────
// Shows particle count, flow field grid, FPS
export function setDebug(on) {
  _debugMode = !!on;
}

// ── Isolated mode ─────────────────────────────────────────────────────────────
// Pauses loop, hides canvas — system unaffected
export function setIsolated(on) {
  _isolatedMode = !!on;
  if (on) {
    _running = false;
    if (_raf) cancelAnimationFrame(_raf);
    if (_canvas) _canvas.style.opacity = '0';
  } else {
    _running = true;
    if (_canvas) _canvas.style.opacity = '0.9';
    _loop();
  }
}

export function pause()  { _running = false; if (_raf) cancelAnimationFrame(_raf); }
export function resume() { if (!_isolatedMode) { _running = true; _loop(); } }

export function status() {
  return {
    ok:        !_isolatedMode,
    running:   _running,
    particles: _particles.length,
    tick:      _t,
    debug:     _debugMode,
    isolated:  _isolatedMode,
  };
}

// ── Core engine (from living-editor-v2.html) ─────────────────────────────────

function _resize() {
  if (!_canvas) return;
  _canvas.width  = window.innerWidth;
  _canvas.height = window.innerHeight;
  _initParticles();
}

function _initParticles() {
  _particles = [];
  const W = _canvas.width, H = _canvas.height;
  const count = Math.floor(W * H / 4000);
  for (let i = 0; i < count; i++) {
    _particles.push({
      x:       Math.random() * W,
      y:       Math.random() * H,
      vx:      0, vy: 0,
      life:    Math.random(),
      maxLife: 0.5 + Math.random() * 0.5,
      size:    0.4 + Math.random() * 1.6,
      speed:   0.2 + Math.random() * 0.6,
      hue:     220 + Math.random() * 80,
      age:     0,
    });
  }
}

function _flowField(x, y, t) {
  const s = 0.0025;
  return Math.sin(x * s + t * 0.007) * Math.PI * 2
    + Math.cos(y * s * 1.4 + t * 0.005) * Math.PI
    + Math.sin((x * 0.6 + y * 0.8) * s + t * 0.003) * Math.PI * 0.6
    + Math.cos((x - y) * s * 0.5 + t * 0.004) * Math.PI * 0.4;
}

function _drawFrame() {
  const W = _canvas.width, H = _canvas.height;

  // Faint trail fade (not full clear — creates motion blur effect)
  _ctx.fillStyle = 'rgba(6,4,14,0.04)';
  _ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < _particles.length; i++) {
    const p = _particles[i];
    const angle = _flowField(p.x, p.y, _t);
    p.vx = p.vx * 0.88 + Math.cos(angle) * p.speed * 0.12;
    p.vy = p.vy * 0.88 + Math.sin(angle) * p.speed * 0.12;
    const px = p.x, py = p.y;
    p.x += p.vx; p.y += p.vy;
    p.life += 0.004; p.age++;

    if (p.life > p.maxLife || p.x < 0 || p.x > W || p.y < 0 || p.y > H) {
      p.x = Math.random() * W; p.y = Math.random() * H;
      p.vx = 0; p.vy = 0; p.life = 0;
      p.maxLife = 0.4 + Math.random() * 0.6;
      p.hue = 220 + Math.random() * 90;
      continue;
    }

    const alpha = Math.sin(p.life / p.maxLife * Math.PI) * 0.28;
    const sat   = 35 + Math.sin(_t * 0.008 + i) * 15;
    const light = 28 + Math.sin(_t * 0.006 + i * 0.4) * 18;

    _ctx.beginPath();
    _ctx.moveTo(px, py);
    _ctx.lineTo(p.x, p.y);
    _ctx.strokeStyle = `hsla(${p.hue},${sat}%,${light}%,${alpha})`;
    _ctx.lineWidth = p.size;
    _ctx.lineCap = 'round';
    _ctx.stroke();
  }

  // Debug overlay: show particle count and tick
  if (_debugMode) {
    _ctx.fillStyle = 'rgba(180,140,255,0.7)';
    _ctx.font = '10px Fragment Mono, monospace';
    _ctx.fillText(`particles: ${_particles.length}  tick: ${_t}`, 10, 20);
  }

  _t++;
}

function _loop() {
  if (!_running) return;
  _drawFrame();
  _raf = requestAnimationFrame(_loop);
}
