/**
 * RHEON UI — drag-drop-zone component
 * @uuid        cc-comp-009-0000-4000-8000-000000000009
 * @version     3.0.0
 * @component   drag-drop-zone
 * @reads       []
 * @emits       [DROP_FILE, DROP_ZIP, DROP_FOLDER, DROP_INSTALLED]
 *
 * DRAG+DROP HANDLER.
 * Intercepts drops anywhere on the document.
 * Detects: .zip files, single JS/JSON files, folders.
 * Routes to plugin-loader via bus event.
 *
 * ENABLED/DISABLED via:
 *   CLI:  ide drop enable / ide drop disable
 *   UI:   Plugin Manager toggle
 *   Bus:  emit 'ide:drop:toggle' { enabled: bool }
 *
 * When DISABLED: drops are rejected with a visual message.
 * When ENABLED:  drops are processed and emitted on bus.
 *
 * ZIP install flow:
 *   User drops .zip → bus emits DROP_ZIP { name, data: ArrayBuffer }
 *   plugin-loader receives DROP_ZIP → extracts → validates MANIFEST.json
 *   → loads module → bus emits DROP_INSTALLED { moduleId, ok, error? }
 *   → drag-drop-zone receives DROP_INSTALLED → shows result toast
 */

import { CH } from '../../interaction-contract.js';

export const COMPONENT_ID   = 'drag-drop-zone';
export const COMPONENT_UUID = 'cc-comp-009-0000-4000-8000-000000000009';

let _bus, _enabled = true, _debugMode = false, _isolatedMode = false;
let _overlay, _toast;
let _onDragEnter, _onDragLeave, _onDragOver, _onDrop;

// ── Mount ─────────────────────────────────────────────────────────────────────
export function mount(busInstance) {
  _bus = busInstance;

  _overlay = document.getElementById('drop-overlay');
  if (!_overlay) {
    _overlay = document.createElement('div');
    _overlay.id = 'drop-overlay';
    _overlay.className = 'drop-overlay';
    document.body.appendChild(_overlay);
  }
  _overlay.innerHTML = '<div class="drop-label">drop to install</div><div class="drop-sub">.zip module or .js/.json file</div>';

  // Toast element
  _toast = document.createElement('div');
  _toast.id = 'drop-toast';
  _toast.className = 'drop-toast';
  document.body.appendChild(_toast);

  // Register drag+drop handlers
  _onDragEnter = (e) => {
    e.preventDefault();
    if (!_enabled) return;
    _overlay.classList.add('active');
  };

  _onDragLeave = (e) => {
    if (e.relatedTarget && document.body.contains(e.relatedTarget)) return;
    _overlay.classList.remove('active');
  };

  _onDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = _enabled ? 'copy' : 'none';
  };

  _onDrop = async (e) => {
    e.preventDefault();
    _overlay.classList.remove('active');

    if (!_enabled) {
      _showToast('Drop is disabled. Enable via CLI: ide drop enable', 'warn');
      return;
    }

    const items = [...(e.dataTransfer.items || [])];
    const files = [...(e.dataTransfer.files || [])];

    if (_debugMode) {
      console.log('[drag-drop-zone] drop:', files.map(f => `${f.name} (${f.type}, ${f.size}B)`));
    }

    for (const file of files) {
      await _handleFile(file, e.dataTransfer);
    }
  };

  document.addEventListener('dragenter',  _onDragEnter);
  document.addEventListener('dragleave',  _onDragLeave);
  document.addEventListener('dragover',   _onDragOver);
  document.addEventListener('drop',       _onDrop);

  // Listen for enable/disable toggle
  _bus.on('ide:drop:toggle', (ev) => {
    _enabled = ev.payload.enabled !== false;
    if (_debugMode) console.log(`[drag-drop-zone] ${_enabled ? 'enabled' : 'disabled'}`);
  });

  // Listen for install results → show toast
  _bus.on(CH.DROP_INSTALLED, (ev) => {
    const { moduleId, ok, error } = ev.payload;
    if (ok) {
      _showToast(`✓ ${moduleId} installed`, 'success');
    } else {
      _showToast(`✗ ${moduleId}: ${error}`, 'error');
    }
  });

  return { unmount, setEnabled, setDebug, setIsolated, status };
}

export function unmount() {
  document.removeEventListener('dragenter',  _onDragEnter);
  document.removeEventListener('dragleave',  _onDragLeave);
  document.removeEventListener('dragover',   _onDragOver);
  document.removeEventListener('drop',       _onDrop);
  _overlay?.remove();
  _toast?.remove();
}

export function setEnabled(on) { _enabled = !!on; }
export function setDebug(on)   { _debugMode = !!on; }
export function setIsolated(on) {
  _isolatedMode = !!on;
  // In isolated mode: accept drops, emit to log only (no real install)
}

export function status() {
  return { ok: true, enabled: _enabled, debug: _debugMode, isolated: _isolatedMode };
}

// ── File handler ──────────────────────────────────────────────────────────────

async function _handleFile(file, dataTransfer) {
  const name = file.name;
  const ext  = name.split('.').pop().toLowerCase();

  if (ext === 'zip') {
    // ZIP → module install
    const data = await _readAsArrayBuffer(file);
    const event = {
      name,
      size: file.size,
      data: _isolatedMode ? null : data,  // null-bus in isolated mode
      ts:   Date.now(),
    };

    if (_debugMode) console.log('[drag-drop-zone] DROP_ZIP:', name, file.size + 'B');

    if (!_isolatedMode) {
      _bus.emit(CH.DROP_ZIP, event);
      _showToast(`Installing ${name}…`, 'info');
    } else {
      _showToast(`[ISOLATED] Would install ${name} — drop disabled in isolated mode`, 'warn');
      console.log('[drag-drop-zone] isolated drop:', name);
    }
    return;
  }

  if (ext === 'js' || ext === 'json') {
    // Single file drop → route to appropriate handler
    const text = await _readAsText(file);
    const event = { name, ext, text, size: file.size, ts: Date.now() };

    if (_debugMode) console.log('[drag-drop-zone] DROP_FILE:', name);

    if (!_isolatedMode) {
      _bus.emit(CH.DROP_FILE, event);
      _showToast(`File received: ${name}`, 'info');
    } else {
      console.log('[drag-drop-zone] isolated file drop:', name);
    }
    return;
  }

  if (ext === 'html') {
    // HTML file → UI hot-swap
    const text = await _readAsText(file);
    if (!_isolatedMode) {
      _bus.emit('ide:ui:swap:request', { html: text, ts: Date.now() });
      _showToast(`UI swap: ${name}`, 'info');
    }
    return;
  }

  _showToast(`Unsupported file type: .${ext} (supported: .zip .js .json .html)`, 'warn');
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _readAsArrayBuffer(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload  = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsArrayBuffer(file);
  });
}

function _readAsText(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload  = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsText(file);
  });
}

let _toastTimer;
function _showToast(msg, type = 'info') {
  if (!_toast) return;
  _toast.textContent = msg;
  _toast.className = `drop-toast ${type} show`;
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => {
    _toast.classList.remove('show');
  }, type === 'error' ? 5000 : 2500);
}
