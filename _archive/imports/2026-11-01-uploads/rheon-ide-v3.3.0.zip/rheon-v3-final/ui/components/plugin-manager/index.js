/**
 * RHEON UI — plugin-manager component
 * @version 3.0.0
 * @component plugin-manager
 * Hooks declared in ui/interaction-contract.js COMPONENT_HOOKS['plugin-manager']
 * Debug mode: see debug-overlay for isolation controls
 */
export const COMPONENT_ID = 'plugin-manager';

// mount() is called by ui/index.html boot sequence
// All state and event handling lives in UI namespace in index.html
// This file is the component's isolated hook registration surface

export function mount(busInstance) {
  // Component wires its bus subscriptions here when loaded standalone
  // In single-file mode, wiring is in ui/index.html UI namespace
  return { unmount, setDebug, setIsolated, status };
}
export function unmount() {}
export function setDebug(on) { console.log(`[plugin-manager] debug: ${on}`); }
export function setIsolated(on) { console.log(`[plugin-manager] isolated: ${on}`); }
export function status() { return { ok: true, component: 'plugin-manager' }; }
