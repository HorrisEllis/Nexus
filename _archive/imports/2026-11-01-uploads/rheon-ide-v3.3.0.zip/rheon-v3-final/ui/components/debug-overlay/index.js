/**
 * RHEON UI — debug-overlay component
 * @uuid        cc-comp-011-0000-4000-8000-000000000011
 * @version     3.0.0
 * @component   debug-overlay
 * @reads       ['*']  — listens to all bus events
 * @emits       [CH.DEBUG_COMPONENT, CH.DEBUG_EVENT]
 *
 * PER-COMPONENT DEBUG SYSTEM.
 * Lets you debug one component at a time without breaking the system.
 *
 * ISOLATION STATES:
 *   ACTIVE   → normal operation
 *   DEBUG    → extra logging, raw data visible in overlay, no functional change
 *   ISOLATED → component bus connections routed to null-bus, not real bus
 *              Other components continue normally.
 *   DISABLED → component unmounted, slot shows placeholder
 *
 * A "null-bus" is a second SISOBus instance with no handlers registered.
 * When a component is ISOLATED, its on() and emit() calls go to null-bus.
 * Real bus is unaffected. The component thinks it's running — it just isn't
 * connected to anything real.
 *
 * §4.1: "A system that cannot be tested cannot be trusted."
 * §4.2: "Fix bugs pre-emptively. Attack the weakest link."
 */

import { CH, COMPONENT_HOOKS, ISOLATION_STATE } from '../../interaction-contract.js';
import { query as elemQuery } from '../../ui-elements-index.js';

export const COMPONENT_ID   = 'debug-overlay';
export const COMPONENT_UUID = 'cc-comp-011-0000-4000-8000-000000000011';

// ── State ─────────────────────────────────────────────────────────────────────
const _componentStates = new Map(); // componentId → ISOLATION_STATE
const _eventLog        = new Map(); // componentId → event[]
const _nullBus         = _makeNullBus();
let   _bus, _selectedComponent = null, _visible = false;
let   _realBusUnsubs = new Map(); // componentId → unsub[]

// Initialize all components as ACTIVE
Object.keys(COMPONENT_HOOKS).forEach(id => {
  _componentStates.set(id, ISOLATION_STATE.ACTIVE);
  _eventLog.set(id, []);
});

// ── Mount ─────────────────────────────────────────────────────────────────────
export function mount(busInstance) {
  _bus = busInstance;

  // Listen to ALL events for debug log
  _bus.on('*', (ev) => {
    const affected = _getAffectedComponents(ev.type);
    affected.forEach(compId => {
      const log = _eventLog.get(compId) || [];
      log.push({ type: ev.type, payload: ev.payload, tick: ev.tick, wall: ev.wall });
      if (log.length > 200) log.shift(); // ring buffer
      _eventLog.set(compId, log);
      if (compId === _selectedComponent && _visible) _renderEventLog();
    });
  });

  // Toggle debug overlay
  _bus.on(CH.DEBUG_COMPONENT, (ev) => {
    if (ev.payload.show !== undefined) {
      _visible = ev.payload.show;
    } else {
      _visible = !_visible;
    }
    _renderOverlay();
  });

  _renderOverlay();
  return { unmount, setComponentState, getComponentState, getBusForComponent, status };
}

export function unmount() {
  _bus = null;
}

// ── Core API ──────────────────────────────────────────────────────────────────

// Set a component's isolation state
export function setComponentState(componentId, state) {
  if (!COMPONENT_HOOKS[componentId]) {
    throw new Error(`[debug-overlay] unknown component: ${componentId}`);
  }
  if (!Object.values(ISOLATION_STATE).includes(state)) {
    throw new Error(`[debug-overlay] unknown state: ${state}`);
  }

  const prev = _componentStates.get(componentId);
  _componentStates.set(componentId, state);

  // Emit debug event so component can react
  _bus?.emit(CH.DEBUG_COMPONENT, {
    componentId,
    state,
    prev,
    ts: Date.now(),
  });

  _renderOverlay();
  return { ok: true, componentId, state, prev };
}

export function getComponentState(componentId) {
  return _componentStates.get(componentId) || ISOLATION_STATE.ACTIVE;
}

// Returns real bus or null-bus depending on component isolation state
export function getBusForComponent(componentId) {
  const state = _componentStates.get(componentId) || ISOLATION_STATE.ACTIVE;
  return state === ISOLATION_STATE.ISOLATED ? _nullBus : _bus;
}

export function status() {
  const states = {};
  _componentStates.forEach((s, id) => { states[id] = s; });
  return {
    ok:        true,
    visible:   _visible,
    selected:  _selectedComponent,
    states,
    eventLogs: Object.fromEntries(
      [..._eventLog.entries()].map(([id, log]) => [id, log.length])
    ),
  };
}

// ── DOM rendering ─────────────────────────────────────────────────────────────

function _renderOverlay() {
  const el = document.getElementById('debug-overlay');
  if (!el) return;

  el.style.display = _visible ? 'flex' : 'none';
  if (!_visible) return;

  el.innerHTML = `
    <div class="dbg-header">
      <span class="dbg-title">⬡ DEBUG</span>
      <button class="dbg-close" onclick="window._debugOverlay?.hide()">×</button>
    </div>
    <div class="dbg-body">
      <div class="dbg-component-list">
        ${Object.keys(COMPONENT_HOOKS).map(id => _renderComponentRow(id)).join('')}
      </div>
      <div class="dbg-detail" id="dbg-detail">
        ${_selectedComponent ? _renderDetail(_selectedComponent) : '<div class="dbg-hint">select a component</div>'}
      </div>
    </div>
  `;

  // Expose to window for onclick handlers
  window._debugOverlay = {
    hide:         () => { _visible = false; _renderOverlay(); },
    select:       (id) => { _selectedComponent = id; _renderOverlay(); },
    setState:     (id, s) => setComponentState(id, s),
    clearLog:     (id) => { _eventLog.set(id, []); _renderOverlay(); },
  };
}

function _renderComponentRow(componentId) {
  const state = _componentStates.get(componentId);
  const hook  = COMPONENT_HOOKS[componentId];
  const log   = _eventLog.get(componentId) || [];
  const sel   = componentId === _selectedComponent;

  const stateColors = {
    [ISOLATION_STATE.ACTIVE]:   '#4ac47a',
    [ISOLATION_STATE.DEBUG]:    '#e8a94a',
    [ISOLATION_STATE.ISOLATED]: '#4a7fc4',
    [ISOLATION_STATE.DISABLED]: '#3d3830',
  };

  return `
    <div class="dbg-row ${sel ? 'selected' : ''}"
         onclick="window._debugOverlay?.select('${componentId}')">
      <div class="dbg-row-dot" style="background:${stateColors[state]}"></div>
      <div class="dbg-row-name">${componentId}</div>
      <div class="dbg-row-state">${state}</div>
      <div class="dbg-row-events">${log.length}</div>
    </div>
  `;
}

function _renderDetail(componentId) {
  const hook  = COMPONENT_HOOKS[componentId];
  const state = _componentStates.get(componentId);
  const log   = (_eventLog.get(componentId) || []).slice(-20).reverse();

  return `
    <div class="dbg-detail-header">
      <span class="dbg-detail-name">${componentId}</span>
      <span class="dbg-uuid">${hook.uuid}</span>
    </div>

    <div class="dbg-state-controls">
      ${Object.values(ISOLATION_STATE).map(s => `
        <button class="dbg-state-btn ${state === s ? 'active' : ''}"
                onclick="window._debugOverlay?.setState('${componentId}','${s}')">
          ${s}
        </button>`).join('')}
    </div>

    <div class="dbg-section-label">WHAT ISOLATION MEANS</div>
    <div class="dbg-isolate-note">${hook.isolate}</div>

    <div class="dbg-section-label">READS</div>
    <div class="dbg-channels">${hook.reads.map(ch => `<div class="dbg-ch read">${ch}</div>`).join('') || '<span class="dbg-none">none</span>'}</div>

    <div class="dbg-section-label">EMITS</div>
    <div class="dbg-channels">${hook.emits.map(ch => `<div class="dbg-ch emit">${ch}</div>`).join('') || '<span class="dbg-none">none</span>'}</div>

    <div class="dbg-section-label">
      RECENT EVENTS
      <button class="dbg-clear" onclick="window._debugOverlay?.clearLog('${componentId}')">clear</button>
    </div>
    <div class="dbg-event-log" id="dbg-detail-log">
      ${log.length ? log.map(ev => `
        <div class="dbg-ev-line">
          <span class="dbg-ev-tick">${ev.tick || '?'}</span>
          <span class="dbg-ev-type">${ev.type}</span>
          <span class="dbg-ev-payload">${JSON.stringify(ev.payload || {}).slice(0, 80)}</span>
        </div>`).join('') : '<span class="dbg-none">no events yet</span>'}
    </div>

    <div class="dbg-section-label">DOM ELEMENTS</div>
    <div class="dbg-elements">
      ${elemQuery.byComponent(componentId).map(el => `
        <div class="dbg-el-row">
          <span class="dbg-el-id">#${el.id}</span>
          <span class="dbg-el-role">${el.role}</span>
          ${el.channel ? `<span class="dbg-el-ch">${el.channel}</span>` : ''}
        </div>`).join('')}
    </div>
  `;
}

function _renderEventLog() {
  const detail = document.getElementById('dbg-detail');
  if (detail && _selectedComponent) {
    detail.innerHTML = _renderDetail(_selectedComponent);
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

// Find which components care about a given channel
function _getAffectedComponents(channelType) {
  const affected = [];
  for (const [id, hook] of Object.entries(COMPONENT_HOOKS)) {
    const allChannels = [...(hook.reads || []), ...(hook.emits || [])];
    if (allChannels.includes(channelType) || allChannels.includes('*')) {
      affected.push(id);
    }
  }
  return affected;
}

// Null bus — accepts events, fires no handlers
function _makeNullBus() {
  const _log = [];
  return {
    on:      (ch, fn) => () => {},  // subscribe does nothing, returns empty unsub
    emit:    (type, payload) => {
      _log.push({ type, payload, ts: Date.now() });
      if (_log.length > 500) _log.shift();
      return { type, payload, tick: -1, id: 'null-bus' };
    },
    history: () => [..._log],
    isNull:  true,
  };
}
