/**
 * RHEON UI — console-pane component
 * @version 3.0.0
 * @component console-pane
 * Hooks declared in ui/interaction-contract.js COMPONENT_HOOKS['console-pane']
 * Debug mode: see debug-overlay for isolation controls
 */
export const COMPONENT_ID = 'console-pane';

// mount() is called by ui/index.html boot sequence
// All state and event handling lives in UI namespace in index.html
// This file is the component's isolated hook registration surface

export function mount(busInstance) {
  // Component wires its bus subscriptions here when loaded standalone
  // In single-file mode, wiring is in ui/index.html UI namespace
  return { unmount, setDebug, setIsolated, status };
}
export function unmount() {}
export function setDebug(on) { console.log(`[console-pane] debug: ${on}`); }
export function setIsolated(on) { console.log(`[console-pane] isolated: ${on}`); }
export function status() { return { ok: true, component: 'console-pane' }; }
