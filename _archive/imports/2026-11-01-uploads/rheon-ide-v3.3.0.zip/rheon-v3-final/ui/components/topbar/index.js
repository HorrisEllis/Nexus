/**
 * RHEON UI — topbar component
 * @version 3.0.0
 * @component topbar
 * Hooks declared in ui/interaction-contract.js COMPONENT_HOOKS['topbar']
 * Debug mode: see debug-overlay for isolation controls
 */
export const COMPONENT_ID = 'topbar';

// mount() is called by ui/index.html boot sequence
// All state and event handling lives in UI namespace in index.html
// This file is the component's isolated hook registration surface

export function mount(busInstance) {
  // Component wires its bus subscriptions here when loaded standalone
  // In single-file mode, wiring is in ui/index.html UI namespace
  return { unmount, setDebug, setIsolated, status };
}
export function unmount() {}
export function setDebug(on) { console.log(`[topbar] debug: ${on}`); }
export function setIsolated(on) { console.log(`[topbar] isolated: ${on}`); }
export function status() { return { ok: true, component: 'topbar' }; }
