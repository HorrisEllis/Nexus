/**
 * RHEON — jaa.js
 * @uuid        aa000002-0000-4000-8000-000000000002
 * @version     3.0.0
 * @layer       0 — ROOT (immutable)
 * @axioms      §2.1 §2.2 §2.3 §5.1 §5.5
 */

import { createHash }  from 'crypto';
import { appendFileSync, readFileSync, writeFileSync, existsSync, statSync, mkdirSync } from 'fs';
import { join }        from 'path';
import { cwd }         from 'process';

const IS_NODE = typeof process !== 'undefined' && process.versions?.node;

// ── Table registry ────────────────────────────────────────────────────────────
export const ALL_TABLES = Object.freeze([
  'nodes', 'threads', 'gaps', 'edges', 'bep_signals',
  'sessions', 'tags', 'personal_vectors',
  'grammar',
  'agent_calls', 'artifacts',
  'ide_sessions',
  'ledger_upgrade', 'ledger_idea',
  'ledger_checkpoints',
  'plugins', 'plugin_hooks',
  'repo_history', 'spec_versions',
  'voice_segments', 'snr_signals',
]);

// ── uid factory ───────────────────────────────────────────────────────────────
export function uid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return createHash('sha256').update(Date.now() + Math.random().toString()).digest('hex').slice(0, 32);
}

// ── hash ──────────────────────────────────────────────────────────────────────
function hashSync(content) {
  return createHash('sha256').update(content).digest('hex').slice(0, 16);
}

// ══════════════════════════════════════════════════════════════════════════════
// NODE BACKEND
// ══════════════════════════════════════════════════════════════════════════════
class NodeBackend {
  constructor(dir) {
    this._dir   = dir || join(cwd(), 'data', 'jaa');
    this._cache = new Map();
    this._ready = false;
  }

  open() {
    mkdirSync(this._dir, { recursive: true });
    for (const t of ALL_TABLES) {
      const f = this._f(t);
      if (!existsSync(f)) writeFileSync(f, '');
      const lines = readFileSync(f, 'utf8').split('\n').filter(Boolean);
      const recs  = [];
      for (const l of lines) {
        try { recs.push(JSON.parse(l)); }
        catch { console.warn(`[Jaa] corrupt line in ${t} — skipped`); }
      }
      this._cache.set(t, recs);
      // Auto-compact if > 4MB
      try {
        if (statSync(f).size > 4 * 1024 * 1024) this._compact(t);
      } catch {}
    }
    this._ready = true;
  }

  insert(table, record) {
    this._chk(); this._chkTable(table);
    const rec = { ...record, uuid: record.uuid || uid(), _ts: Date.now() };
    appendFileSync(this._f(table), JSON.stringify(rec) + '\n');
    this._cache.get(table).push(rec);
    return rec;
  }

  query(table, pred = () => true, limit = Infinity) {
    this._chk(); this._chkTable(table);
    const all = this._cache.get(table); const r = [];
    for (let i = all.length - 1; i >= 0 && r.length < limit; i--) {
      if (pred(all[i])) r.push(all[i]);
    }
    return r;
  }

  get(table, uuid_) {
    this._chk(); this._chkTable(table);
    const all = this._cache.get(table);
    for (let i = all.length - 1; i >= 0; i--) {
      if (all[i].uuid === uuid_) return all[i];
    }
    return null;
  }

  update(table, uuid_, patch) {
    const ex = this.get(table, uuid_);
    if (!ex) throw new Error(`[Jaa] update: ${table}/${uuid_} not found`);
    return this.insert(table, { ...ex, ...patch, uuid: uuid_, _ts: Date.now() });
  }

  count(table)  { this._chk(); this._chkTable(table); return this._cache.get(table).length; }
  tables()      { return [...ALL_TABLES]; }
  compact(t)    { return this._compact(t); }

  _compact(t) {
    const recs = this._cache.get(t) || [];
    writeFileSync(this._f(t), recs.map(r => JSON.stringify(r)).join('\n') + (recs.length ? '\n' : ''));
    return { kept: recs.length };
  }

  _f(t)        { return join(this._dir, `${t}.jsonl`); }
  _chk()       { if (!this._ready) throw new Error('[Jaa] not open — call open() first (§2.2)'); }
  _chkTable(t) {
    if (!ALL_TABLES.includes(t)) throw new Error(`[Jaa] undeclared table "${t}" — add to ALL_TABLES (§5.1)`);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// BROWSER BACKEND (IndexedDB)
// ══════════════════════════════════════════════════════════════════════════════
class BrowserBackend {
  constructor(name = 'rheon') {
    this._name  = name;
    this._db    = null;
    this._cache = new Map();
    this._ready = false;
  }

  async open() {
    await new Promise((res, rej) => {
      const req = indexedDB.open(this._name, 1);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        for (const t of ALL_TABLES) {
          if (!db.objectStoreNames.contains(t)) db.createObjectStore(t, { keyPath: 'uuid' });
        }
      };
      req.onsuccess = async e => {
        this._db = e.target.result;
        for (const t of ALL_TABLES) {
          try { this._cache.set(t, await this._getAll(t)); }
          catch { this._cache.set(t, []); }
        }
        this._ready = true;
        res();
      };
      req.onerror = () => rej(req.error);
    });
  }

  async insert(table, record) {
    this._chk(); this._chkTable(table);
    const rec = { ...record, uuid: record.uuid || uid(), _ts: Date.now() };
    await new Promise((r, j) => {
      const req = this._db.transaction(table, 'readwrite').objectStore(table).put(rec);
      req.onsuccess = () => r(); req.onerror = () => j(req.error);
    });
    this._cache.get(table).push(rec);
    return rec;
  }

  query(table, pred = () => true, limit = Infinity) {
    this._chk(); this._chkTable(table);
    const all = this._cache.get(table) || []; const r = [];
    for (let i = all.length - 1; i >= 0 && r.length < limit; i--) {
      if (pred(all[i])) r.push(all[i]);
    }
    return r;
  }

  get(table, uuid_) {
    this._chk(); this._chkTable(table);
    const all = this._cache.get(table) || [];
    for (let i = all.length - 1; i >= 0; i--) { if (all[i].uuid === uuid_) return all[i]; }
    return null;
  }

  async update(table, uuid_, patch) {
    const ex = this.get(table, uuid_);
    if (!ex) throw new Error(`[Jaa] update: ${table}/${uuid_} not found`);
    return this.insert(table, { ...ex, ...patch, uuid: uuid_ });
  }

  count(table)  { return (this._cache.get(table) || []).length; }
  tables()      { return [...ALL_TABLES]; }
  compact()     { return { kept: 0 }; }

  _getAll(t) {
    return new Promise((r, j) => {
      const req = this._db.transaction(t, 'readonly').objectStore(t).getAll();
      req.onsuccess = () => r(req.result || []); req.onerror = () => j(req.error);
    });
  }

  _chk()       { if (!this._ready) throw new Error('[Jaa] not open'); }
  _chkTable(t) {
    if (!ALL_TABLES.includes(t)) throw new Error(`[Jaa] undeclared table "${t}" (§5.1)`);
  }
}

// ── JaaStore facade ───────────────────────────────────────────────────────────
class JaaStore {
  constructor(dir) {
    this._b     = IS_NODE ? new NodeBackend(dir) : new BrowserBackend();
    this._ready = false;
  }

  // NOTE: open() is synchronous on Node (no async fs needed), async on browser
  open() {
    if (IS_NODE) {
      this._b.open();   // sync
      this._ready = true;
      return Promise.resolve(this);
    } else {
      return this._b.open().then(() => { this._ready = true; return this; });
    }
  }

  // All methods work sync on Node, async on browser
  // Facade wraps both with Promise.resolve for consistent await-ability
  insert(t, r)       { return Promise.resolve(this._b.insert(t, r)); }
  query(t, p, l)     { return Promise.resolve(this._b.query(t, p, l)); }
  get(t, id)         { return Promise.resolve(this._b.get(t, id)); }
  update(t, id, p)   { return Promise.resolve(this._b.update(t, id, p)); }
  count(t)           { return Promise.resolve(this._b.count(t)); }
  tables()           { return Promise.resolve(this._b.tables()); }
  compact(t)         { return Promise.resolve(this._b.compact(t)); }
  get ready()        { return this._ready; }

  // ── Ledger checkpoints (per-file, per-chunk) ──────────────────────────────
  async checkpoint({ file, content, description, phase, chunkIdx = 0, causedBy = null }) {
    if (!file)    throw new Error('[Jaa.checkpoint] file is required');
    if (!content) throw new Error('[Jaa.checkpoint] content is required');

    const hash    = hashSync(content);
    const prev    = await this.query('ledger_checkpoints', c => c.file === file, 1);
    const prevHash = prev[0]?.hash;

    if (prevHash === hash) return { changed: false, hash };

    const entry = await this.insert('ledger_checkpoints', {
      uuid:        uid(),
      file,
      hash,
      prevHash:    prevHash || null,
      chunkIdx,
      description: description || `checkpoint: ${file}`,
      phase:       phase || null,
      causedBy,
      lineCount:   content.split('\n').length,
      byteSize:    content.length,
      ts:          Date.now(),
    });

    return { changed: true, hash, entry };
  }

  async checkpointHistory(file) {
    const all = await this.query('ledger_checkpoints', c => c.file === file);
    return all.sort((a, b) => (a._ts || 0) - (b._ts || 0));
  }

  async checkpointAt(file, index) {
    return (await this.checkpointHistory(file))[index] || null;
  }

  // ── Grammar ───────────────────────────────────────────────────────────────
  async insertGrammarWord(w) {
    return this.insert('grammar', {
      uuid:       w.uuid || uid(),
      keyword:    w.keyword,
      definition: w.definition || '',
      causedBy:   w.causedBy || 'local',
      trustScore: w.trustScore ?? 0.5,
      firstSeen:  w.firstSeen || Date.now(),
      usageCount: w.usageCount || 1,
      status:     w.status || 'emerging',
      fieldCoord: w.fieldCoord || null,
      template:   w.template || null,
    });
  }

  async getGrammarWords(status) {
    return this.query('grammar', status ? w => w.status === status : () => true);
  }

  // ── Dual ledger (§7.1) ────────────────────────────────────────────────────
  async upgradeEntry(description, proof, opts = {}) {
    return this.insert('ledger_upgrade', {
      uuid: uid(), description, proof,
      phase: opts.phase || null, causedBy: opts.causedBy || null, ts: Date.now(),
    });
  }

  async ideaEntry(description, opts = {}) {
    return this.insert('ledger_idea', {
      uuid: uid(), description,
      status:      opts.status || 'unresolved',
      hypothesis:  opts.hypothesis || null,
      failureMode: opts.failureMode || null,
      ts: Date.now(),
    });
  }

  // ── Plugin registry ───────────────────────────────────────────────────────
  async registerPlugin(manifest) {
    const existing = await this.query('plugins', p => p.moduleId === manifest.moduleId, 1);
    if (existing.length) {
      return this.update('plugins', existing[0].uuid, { ...manifest, _updated: Date.now() });
    }
    return this.insert('plugins', { ...manifest, uuid: manifest.uuid || uid() });
  }

  async getPlugins(status) {
    return this.query('plugins', status ? p => p.status === status : () => true);
  }

  // ── Agent calls ───────────────────────────────────────────────────────────
  async insertAgentCall(call) {
    return this.insert('agent_calls', {
      uuid:     call.uuid || uid(),
      agentId:  call.agentId,
      prompt:   (call.prompt || '').slice(0, 500),
      model:    call.model || null,
      status:   call.status || 'pending',
      response: call.response || null,
      latencyMs:call.latencyMs || null,
      taskType: call.taskType || null,
      ts:       Date.now(),
    });
  }
}

// ── Singleton ─────────────────────────────────────────────────────────────────
export const jaa = new JaaStore(
  IS_NODE ? (process.env.JAA_DATA_DIR || join(cwd(), 'data', 'jaa')) : undefined
);

export const JAA_VERSION = '3.0.0';
export const JAA_UUID    = 'aa000002-0000-4000-8000-000000000002';
