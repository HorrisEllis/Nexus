spec:
  # RHEON IDE — Living Specification v3.0.0
  # AUTO-GENERATED from proven build (§6.1)
  # Generated:  2026-05-30T11:33:55Z
  # Tests:      143/143 passing (5 suites)
  # Entry:      node index.js  →  http://localhost:7800

  meta:
    name:         rheon-ide
    version:      3.0.0
    uuid:         rheon-ide-0000-0003-0000-000000000001
    author:       James Brooks
    what:         IDE for the Seam constraint language
    run:          node index.js
    ports:        ide=7800  kernel=7749  guardian=7820  ollama=11434
    tests:        143/143 passing
    modules:      12 (12 implemented, 0 declared)
    files:        57

  seam_language:
    what:         Constraint-based language for expressing tensions and relationships
    kernel_words: [make, show, add, tension, constrain, gap, emit, watch, find, define, fill, field]
    first_expr:   "make documents multidimensional"
    parse_output: verb · constraints · gaps · signals · confidence · template

  architecture:
    root:
      siso.js:             Immutable event bus — SISOBus · SISOEvent · StreamLog
      jaa.js:              Immutable persistent store — 21 tables · checkpoints
      index.js:            Entry point — detects isMain · delegates to server boot
      MANIFEST.json:       Living spec anchor
      package.json:        v3.0.0 · main=index.js · start=node index.js
    plugins/:
      plugin-schema.js:    Module contract · UI_SLOT · validateManifest
      plugin-loader.js:    Discovery · validation · hot-load · drag+drop watcher
    spec/:
      spec-engine.js:      Auto-updates spec/rheon.spec on file change
      rheon.spec:          This file
    server/:
      index.js:            HTTP+WS · 25 routes · CLI handler · rate limiting · startup banner
    ui/:
      index.html:          Shell — Van Gogh swirl · 3-pane layout · toast queue
      interaction-contract.js: All bus channels · component hook declarations
      ui-elements-index.js:    Every DOM element mapped to component + channel
    ui/components/:
      swirl-engine:        Van Gogh flow-field particles · pure visual · no bus deps
      debug-overlay:       Per-component isolation · null-bus · 4 states
      drag-drop-zone:      Global drop handler · zip install · CLI/UI toggle
      prose-editor:        Block-based contenteditable · Seam/prose/code/spec modes
      code-editor:         Syntax highlight overlay · language tabs · line numbers
      field-pane:          Constraint field · gaps · BEP stage
      preview-pane:        HTML/field/spec/build preview · iframe sandbox
      console-pane:        Bus event stream · CLI REPL · history
      topbar:              Status indicators · Ollama · voice · debug toggle
      settings-panel:      Ollama catalog · hardware-filtered models
      plugin-manager:      Plugin registry · load/unload · hook table

  test_suites:
    core:        58 pass  — SISOEvent · SISOBus · Jaa · validateManifest · 12 manifests · version parity
    phase3:      32 pass  — 20 Seam expressions · grammar-engine · field-engine · bus integration [gate OPEN]
    adversarial: 28 pass  — L1 security · L2 interface · L3 failure modes · L4 QA · L5 user · L6 elite
    ollama:      13 pass  — MANIFEST · catalog · hardware compliance · GPU budget
    kernel-bridge: 12 pass — MANIFEST · contract · config · UI hooks · status
    total:      143 pass   0 fail

  debug_isolation:
    states:    active → debug → isolated → disabled
    null_bus:  isolated component routes to null-bus (no handlers, no side effects)
    cli:       ide debug <componentId> <state>
    ui:        topbar debug button → select component → set state

  failure_modes_covered:
    port_in_use:      error log + "set IDE_PORT env var" toast
    jaa_open_fail:    fatal log + process.exit(1) — cannot continue without storage
    module_gap:       warn log + plugin:gap bus event + Jaa gaps record (non-fatal)
    kernel_missing:   info log + warn toast (IDE runs without kernel)
    ollama_missing:   info log + info toast (models unavailable)
    guardian_missing: info log + info toast (browser agents unavailable)
    ws_error:         warn log + client removed (non-fatal)
    route_404:        JSON error with route key
    handler_500:      JSON error + ide:server:error bus event + toast

  modules:
    kernel-bridge         phase:2  ✓ implemented
      uuid:    bb000002-0000-4000-8000-000000000002
      emits:   8  reads: 2  writes: ['nodes', 'gaps', 'sessions', 'bep_signals']  hooks: 1
    field-engine          phase:3  ✓ implemented
      uuid:    bb000005-0000-4000-8000-000000000005
      emits:   3  reads: 4  writes: ['gaps']  hooks: 0
    grammar-engine        phase:3  ✓ implemented
      uuid:    bb000004-0000-4000-8000-000000000004
      emits:   2  reads: 2  writes: ['grammar']  hooks: 1
    seam-engine           phase:3  ✓ implemented
      uuid:    bb000003-0000-4000-8000-000000000003
      emits:   3  reads: 2  writes: ['grammar']  hooks: 0
    guardian-agent        phase:4  ✓ implemented
      uuid:    bb000006-0000-4000-8000-000000000006
      emits:   4  reads: 1  writes: ['agent_calls']  hooks: 1
    ollama-agent          phase:4  ✓ implemented
      uuid:    bb000001-0000-4000-8000-000000000001
      emits:   5  reads: 1  writes: ['agent_calls']  hooks: 3
    snr-passthrough       phase:4  ✓ implemented
      uuid:    bb000007-0000-4000-8000-000000000007
      emits:   2  reads: 2  writes: ['snr_signals']  hooks: 0
    voice-engine          phase:5  ✓ implemented
      uuid:    bb000008-0000-4000-8000-000000000008
      emits:   3  reads: 3  writes: ['voice_segments']  hooks: 1
    compiler              phase:6  ✓ implemented
      uuid:    bb000009-0000-4000-8000-000000000009
      emits:   3  reads: 2  writes: []  hooks: 1
    repo                  phase:7  ✓ implemented
      uuid:    bb000010-0000-4000-8000-000000000010
      emits:   5  reads: 5  writes: ['repo_history']  hooks: 1
    causal-nexus          phase:8  ✓ implemented
      uuid:    bb000012-0000-4000-8000-000000000012
      emits:   1  reads: 2  writes: ['ledger_upgrade']  hooks: 0
    spec-builder          phase:8  ✓ implemented
      uuid:    bb000011-0000-4000-8000-000000000011
      emits:   2  reads: 3  writes: ['spec_versions', 'ledger_upgrade']  hooks: 0

  jaa_tables:
    - nodes
    - threads
    - gaps
    - edges
    - bep_signals
    - sessions
    - tags
    - personal_vectors
    - grammar
    - agent_calls
    - artifacts
    - ide_sessions
    - ledger_upgrade
    - ledger_idea
    - ledger_checkpoints
    - plugins
    - plugin_hooks
    - repo_history
    - spec_versions
    - voice_segments
    - snr_signals

  server_routes:
    GET  /                        HTML UI (ui/index.html)
    GET  /health                  version · uptime · node version
    GET  /api/manifest            MANIFEST.json
    GET  /api/grammar             grammar words [?status=active]
    POST /api/grammar             add grammar word
    GET  /api/nodes               committed nodes [?limit=20]
    GET  /api/gaps                open gaps
    GET  /api/ledger/upgrade      upgrade ledger
    GET  /api/ledger/idea         idea ledger
    GET  /api/jaa/stats           all table counts
    GET  /api/agents/ollama/status
    GET  /api/agents/ollama/catalog
    POST /api/agents/ollama/ping
    POST /api/agents/ollama/complete
    POST /api/agents/ollama/model
    GET  /api/agents/guardian/status
    GET  /api/plugins/hooks       UI hook registrations [?slot=topbar]
    GET  /api/plugins/registry    loaded module registry
    POST /api/plugins/load        load a module by path
    POST /api/plugins/unload      unload a module by id
    POST /api/voice/start
    POST /api/voice/stop
    POST /api/ui/swap             hot-swap UI (base64 HTML)
    GET  /api/bus/history         event history [?prefix=ide:]
    GET  /api/bus/stream          SSE stream of all bus events
    GET  /api/spec                current spec/rheon.spec content
    WS   /ws                      bidirectional bus bridge + CLI

  file_inventory:
    total: 57
    MANIFEST.json                                                   5379B  542e540281
    index.js                                                        1946B  8c34d2d35b
    jaa.js                                                         13637B  14b82edfe2
    package.json                                                    1211B  caaf39e1c9
    siso.js                                                         8085B  598aadd503
    docs/encyclopedia.md                                            8381B  de39cca86d
    modules/causal-nexus/MANIFEST.json                               676B  fa2b306e8f
    modules/causal-nexus/index.js                                   2377B  070103b4d4
    modules/compiler/MANIFEST.json                                   962B  8add07bb77
    modules/compiler/index.js                                       5305B  20aa069307
    modules/field-engine/MANIFEST.json                               806B  845890f45d
    modules/field-engine/index.js                                   1781B  ec49dac230
    modules/grammar-engine/MANIFEST.json                             954B  eada2cbfca
    modules/grammar-engine/index.js                                 1100B  a7672f26c8
    modules/guardian-agent/MANIFEST.json                            1372B  5bb02892ca
    modules/guardian-agent/index.js                                 3236B  c17ab14ea3
    modules/kernel-bridge/MANIFEST.json                             1518B  85abbcf0c3
    modules/kernel-bridge/index.js                                  9875B  0c06a1f1d9
    modules/kernel-bridge/tests/index.test.js                       3088B  52f5e10b11
    modules/ollama-agent/MANIFEST.json                              2196B  991907961f
    modules/ollama-agent/README.md                                  3366B  f8c7cea64c
    modules/ollama-agent/catalog.js                                21402B  4df4721d31
    modules/ollama-agent/index.js                                   9690B  a18b0a677a
    modules/ollama-agent/tests/index.test.js                        4383B  52766d3c09
    modules/repo/MANIFEST.json                                      1039B  dd0ee24c61
    modules/repo/index.js                                           3850B  0cdb7a554c
    modules/seam-engine/MANIFEST.json                                865B  d49ef7f123
    modules/seam-engine/index.js                                    8375B  ee4c9ec746
    modules/snr-passthrough/MANIFEST.json                            692B  a238e5f869
    modules/snr-passthrough/index.js                                5932B  2051e82bc6
    modules/spec-builder/MANIFEST.json                               699B  8bded9abe4
    modules/spec-builder/index.js                                   2971B  ca8fdd730d
    modules/voice-engine/MANIFEST.json                              1053B  2f7bac9afa
    modules/voice-engine/index.js                                   4393B  820d728e91
    plugins/plugin-loader.js                                        7841B  e1ce469de6
    plugins/plugin-schema.js                                        8814B  2d5dad1d8d
    server/index.js                                                35488B  886fc5533f
    spec/rheon.spec                                                 7172B  f49ae3fab3
    spec/spec-engine.js                                             6947B  5a9765ec01
    tests/run-all.js                                                3455B  c161a4630d
    tests/adversarial/six-lenses.test.js                           14636B  083d7682a4
    tests/unit/core.test.js                                         8180B  8f6abcd49f
    tests/unit/phase3.test.js                                       9516B  d07f0ec0e9
    ui/index.html                                                  61241B  82e3a2f281
    ui/interaction-contract.js                                      8836B  74674f01a1
    ui/ui-elements-index.js                                        10130B  0ae2e8ef7d
    ui/components/code-editor/index.js                               949B  d3113cf2ea
    ui/components/console-pane/index.js                              956B  72bc7fa516
    ui/components/debug-overlay/index.js                           10267B  7d86089684
    ui/components/drag-drop-zone/index.js                           7362B  9e71bc28e8
    ui/components/field-pane/index.js                                942B  9f96449b43
    ui/components/plugin-manager/index.js                            970B  d891da38ff
    ui/components/preview-pane/index.js                              956B  c1851f7792
    ui/components/prose-editor/index.js                              956B  5b9337655c
    ui/components/settings-panel/index.js                            970B  744fcc95c0
    ui/components/swirl-engine/index.js                             5658B  ed90295fd9
    ui/components/topbar/index.js                                    914B  fa5c0dc1ac

  upgrade_ledger:
    UL-001:  Core foundation — siso.js jaa.js · plugins/ spec/ · 28 tests
    UL-002:  plugin-schema · plugin-loader · spec-engine · ESM fix · 33 tests
    UL-003:  ollama-agent — 20 models · HW-calibrated catalog · 13 tests
    UL-004:  UI layer — interaction-contract · ui-elements-index · 3 components
    UL-005:  12 modules declared — all MANIFESTs valid
    UL-006:  server/index.js — HTTP+WS · all routes · CLI · rate limiting
    UL-007:  index.js entry point fixed (silent exit bug) · 58 tests
    UL-008:  Phase 3 gate passed — 32/32 · 20 Seam expressions proven
    UL-009:  Six Lenses adversarial — 28/28
    UL-010:  Phases 4-8 fully implemented (snr/voice/compiler/repo/spec-builder/causal-nexus)
    UL-011:  143/143 total · import assertion fix (with not assert) · run-all.js

  next_session:
    gate:    Phase 4 integration tests against live Ollama
    then:    voice-engine MediaRecorder integration
    then:    compiler gate pipeline against real project
    then:    repo git operations via kernel CLI bridge
