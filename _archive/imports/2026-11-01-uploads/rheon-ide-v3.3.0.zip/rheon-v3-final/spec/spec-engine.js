/**
 * RHEON — spec/spec-engine.js
 * @uuid        aa000005-0000-4000-8000-000000000005
 * @version     3.0.0
 * @axioms      §2.1 §2.3 §6.1 §7.1 §7.6
 */

import { bus }                                                from '../siso.js';
import { jaa }                                               from '../jaa.js';
import { readFileSync, writeFileSync, mkdirSync, existsSync, watch } from 'fs';
import { join, relative }                                    from 'path';
import { cwd }                                               from 'process';

const IS_NODE = typeof process !== 'undefined' && process.versions?.node;
let _specTimer = null;

// ── Generate spec from proven state ──────────────────────────────────────────
async function generateSpec() {
  const manifest    = readManifest();
  const plugins     = await jaa.query('plugins', p => p.status === 'active');
  const checkpoints = await jaa.query('ledger_checkpoints', () => true, 100);
  const upgrades    = await jaa.query('ledger_upgrade', () => true, 50);
  const grammar     = await jaa.query('grammar', w => w.status === 'active', 100);
  const gaps        = await jaa.query('gaps', g => g.status === 'open', 20);
  const ts          = new Date().toISOString();

  return `spec:
  # AUTO-GENERATED — do not edit manually (§6.1)
  # Generated: ${ts}

  meta:
    name:        rheon-ide
    version:     ${manifest?.version || '3.0.0'}
    uuid:        ${manifest?.uuid || 'rheon-ide-0000-0003'}
    author:      James Brooks
    generated:   ${ts}
    status:      ${manifest?.status || 'growing'}
    checkpoints: ${checkpoints.length}
    phase:       ${manifest?.current_phase || 1}

  architecture:
    root:
      - siso.js            # SISOBus, SISOEvent, StreamLog, Gate, Stream
      - jaa.js             # Dual-backend persistent store, ledger checkpoints
      - index.js           # Boot sequence, re-exports
    plugins/:
      - plugin-schema.js   # Module/plugin contract, UI_SLOT, validateManifest()
      - plugin-loader.js   # Discovery, validation, hot-load, drag+drop watcher
    spec/:
      - spec-engine.js     # This file — auto-updates spec/rheon.spec
    modules/:
${plugins.map(p => `      - ${p.moduleId}/  # ${p.name} v${p.version} (phase ${p.bootPhase})`).join('\n') || '      # (no modules loaded yet)'}

  ledger_checkpoints:
    total: ${checkpoints.length}
${checkpoints.slice(-5).map((c, i) => `    ledger_${checkpoints.length - 5 + i + 1}:
      file:  ${c.file}
      hash:  ${c.hash}
      desc:  ${c.description}
      phase: ${c.phase || '?'}`).join('\n') || '    # (none yet)'}

  upgrade_ledger:
    total: ${upgrades.length}
${upgrades.slice(-3).map(u => `    - ${u.description}`).join('\n') || '    # (none yet)'}

  grammar:
    words: ${grammar.length}
${grammar.slice(-10).map(w => `    - ${w.keyword}: ${w.definition}`).join('\n') || '    # (none yet)'}

  open_gaps:
    count: ${gaps.length}
${gaps.slice(0, 5).map(g => `    - ${g.reason || g.gapType}`).join('\n') || '    # (none)'}

  modules:
${plugins.map(p => `    ${p.moduleId}:
      uuid:    ${p.uuid}
      version: ${p.version}
      phase:   ${p.bootPhase}
      status:  ${p.status}
      emits:   [${(p.emits || []).join(', ')}]
      reads:   [${(p.reads || []).join(', ')}]
      hooks:   ${(p.ui_hooks || []).length}`).join('\n') || '    # (no modules loaded)'}
`;
}

// ── Write spec to disk ────────────────────────────────────────────────────────
async function writeSpec() {
  if (!IS_NODE) return;
  const specDir  = join(cwd(), 'spec');
  const specPath = join(specDir, 'rheon.spec');

  mkdirSync(specDir, { recursive: true });

  const spec       = await generateSpec();
  const checkpoint = await jaa.checkpoint({ file: 'spec/rheon.spec', content: spec, description: 'spec auto-updated' });

  if (checkpoint.changed) {
    writeFileSync(specPath, spec, 'utf8');
    bus.emit('spec:updated', { path: specPath, hash: checkpoint.hash, ts: Date.now() });
  }
}

// ── File watcher ──────────────────────────────────────────────────────────────
export function watchFiles(dirs = []) {
  if (!IS_NODE) return;
  const dirsToWatch = dirs.length ? dirs : [
    join(cwd(), 'plugins'),
    join(cwd(), 'modules'),
  ];

  for (const dir of dirsToWatch) {
    if (!existsSync(dir)) continue;
    watch(dir, { recursive: true }, async (eventType, filename) => {
      if (!filename || (!filename.endsWith('.js') && !filename.endsWith('.json'))) return;
      const filePath = join(dir, filename);
      let content;
      try {
        if (!existsSync(filePath)) return;
        content = readFileSync(filePath, 'utf8');
      } catch { return; }

      const result = await jaa.checkpoint({
        file:        relative(cwd(), filePath),
        content,
        description: `file changed: ${filename} (${eventType})`,
      });

      if (result.changed) {
        bus.emit('spec:file:changed', {
          file:  relative(cwd(), filePath),
          hash:  result.hash,
          event: eventType,
          ts:    Date.now(),
        });
        clearTimeout(_specTimer);
        _specTimer = setTimeout(writeSpec, 2000);
      }
    });
  }
}

// ── Bus listeners ─────────────────────────────────────────────────────────────
bus.on('plugin:loaded', () => {
  clearTimeout(_specTimer);
  _specTimer = setTimeout(writeSpec, 1000);
});

bus.on('phase:complete', async (ev) => {
  await jaa.upgradeEntry(
    `Phase ${ev.payload.phase} complete`,
    `gate: ${ev.payload.gate || '?'}, exit: ${ev.payload.exit || '?'}`,
    { phase: ev.payload.phase }
  );
  await writeSpec();
});

// ── Init ──────────────────────────────────────────────────────────────────────
export async function init() {
  watchFiles();
  await writeSpec();
  bus.emit('spec:engine:ready', { ts: Date.now() });
}

// ── Helper ────────────────────────────────────────────────────────────────────
function readManifest() {
  if (!IS_NODE) return null;
  const mp = join(cwd(), 'MANIFEST.json');
  if (!existsSync(mp)) return null;
  try { return JSON.parse(readFileSync(mp, 'utf8')); } catch { return null; }
}

export const SPEC_ENGINE_VERSION = '3.0.0';
export const SPEC_ENGINE_UUID    = 'aa000005-0000-4000-8000-000000000005';
