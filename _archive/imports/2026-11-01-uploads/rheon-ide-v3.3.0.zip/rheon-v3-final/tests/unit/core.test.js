/**
 * RHEON IDE — Core tests v3.0.0
 * §4.1: cannot be tested = cannot be trusted
 */
import { strict as assert }                          from 'assert';
import { readFileSync, existsSync, mkdtempSync,
         rmSync, appendFileSync, writeFileSync,
         mkdirSync, readdirSync }                    from 'fs';
import { join }                                      from 'path';
import { tmpdir }                                    from 'os';
import { createHash }                                from 'crypto';
import { fileURLToPath }                             from 'url';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..', '..');
const tmpDir = mkdtempSync(join(tmpdir(), 'rheon-test-'));

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log(`  ✓ ${name}`); }
  catch(e) { fail++; console.error(`  ✗ ${name}: ${e.message}`); }
}

// ── SISO ──────────────────────────────────────────────────────────────────────
console.log('\n  [siso.js]\n');
const { SISOBus, SISOEvent, _resetClock } = await import(join(ROOT, 'siso.js'));

test('SISOEvent: payload immutable', () => {
  const ev = new SISOEvent('t', {a:1}); let m=false;
  try { ev.payload.a=9; m=true; } catch {}
  assert.ok(!m);
});

test('SISOEvent: type immutable', () => {
  const ev = new SISOEvent('t', {}); let m=false;
  try { ev.type='x'; m=true; } catch {}
  assert.ok(!m);
});

test('SISOEvent: monotone tick (§3.2)', () => {
  _resetClock?.();
  const a=new SISOEvent('a'), b=new SISOEvent('b'), c=new SISOEvent('c');
  assert.ok(a.tick < b.tick && b.tick < c.tick);
});

test('SISOEvent: empty type throws (§1.2)', () => {
  assert.throws(() => new SISOEvent(''), /type/);
});

test('SISOBus: exact match', () => {
  const b=new SISOBus(), r=[];
  b.on('x.y', ev=>r.push(ev));
  b.emit('x.y',{}); b.emit('x.z',{});
  assert.strictEqual(r.length, 1);
});

test('SISOBus: wildcard * (one level)', () => {
  const b=new SISOBus(), r=[];
  b.on('k.*', ev=>r.push(ev));
  b.emit('k.a',{}); b.emit('k.b',{}); b.emit('k.a.b',{});
  assert.strictEqual(r.length, 2);
});

test('SISOBus: wildcard ** (deep)', () => {
  const b=new SISOBus(), r=[];
  b.on('k.**', ev=>r.push(ev));
  b.emit('k.a',{}); b.emit('k.a.b',{}); b.emit('k.a.b.c',{});
  assert.strictEqual(r.length, 3);
});

test('SISOBus: pause/resume preserves order', () => {
  const b=new SISOBus(), r=[];
  b.on('n.*', ev=>r.push(ev.payload.i));
  b.pause();
  b.emit('n.a',{i:1}); b.emit('n.b',{i:2}); b.emit('n.c',{i:3});
  assert.strictEqual(r.length, 0);
  b.resume();
  assert.deepStrictEqual(r, [1,2,3]);
});

test('SISOBus: unsubscribe works', () => {
  const b=new SISOBus(), r=[];
  const u=b.on('q', ev=>r.push(ev));
  b.emit('q',{}); u(); b.emit('q',{});
  assert.strictEqual(r.length, 1);
});

test('SISOBus: handler error emits bus.handler.error (§1.2)', () => {
  const b=new SISOBus(), errs=[];
  b.on('bus.handler.error', ev=>errs.push(ev));
  b.on('boom', ()=>{ throw new Error('intentional'); });
  b.emit('boom',{});
  assert.ok(errs.length >= 1);
});

// ── Jaa ───────────────────────────────────────────────────────────────────────
console.log('\n  [jaa.js]\n');
const { ALL_TABLES, uid } = await import(join(ROOT, 'jaa.js'));

test('ALL_TABLES: no duplicates', () => {
  const seen=new Set();
  for (const t of ALL_TABLES) { assert.ok(!seen.has(t), `dup: ${t}`); seen.add(t); }
});

test('ALL_TABLES: includes required tables', () => {
  ['nodes','gaps','grammar','agent_calls','ledger_upgrade','ledger_idea',
   'ledger_checkpoints','plugins','plugin_hooks'].forEach(t =>
    assert.ok(ALL_TABLES.includes(t), `missing: ${t}`)
  );
});

test('uid(): 5000 unique (§5.1)', () => {
  const s=new Set();
  for (let i=0; i<5000; i++) { const id=uid(); assert.ok(!s.has(id)); s.add(id); }
});

test('Jaa NodeBackend: insert persists to disk (§2.2)', () => {
  const dir  = join(tmpDir, 'jaa');
  mkdirSync(dir, { recursive: true });
  const file = join(dir, 'grammar.jsonl');
  writeFileSync(file, '');
  const rec  = { uuid: 'test-001', keyword: 'make', _ts: Date.now() };
  appendFileSync(file, JSON.stringify(rec) + '\n');
  const lines = readFileSync(file, 'utf8').split('\n').filter(Boolean);
  assert.strictEqual(lines.length, 1);
  assert.strictEqual(JSON.parse(lines[0]).keyword, 'make');
});

test('Jaa checkpoint: same content → same hash (no dup write)', () => {
  const h = s => createHash('sha256').update(s).digest('hex').slice(0,16);
  assert.strictEqual(h('same content'), h('same content'));
  assert.notStrictEqual(h('version A'), h('version B'));
});

// ── Plugin schema ─────────────────────────────────────────────────────────────
console.log('\n  [plugins/plugin-schema.js]\n');
const { validateManifest } = await import(join(ROOT, 'plugins', 'plugin-schema.js'));

test('validateManifest: valid manifest passes', () => {
  const { valid, errors } = validateManifest({
    moduleId:'test', uuid:'uuid-001', name:'Test',
    version:'1.0.0', bootPhase:4, description:'d', author:'a',
  });
  assert.ok(valid, errors.join('; '));
});

test('validateManifest: missing required fields fails', () => {
  const { valid } = validateManifest({ uuid: 'x' });
  assert.ok(!valid);
});

test('validateManifest: bootPhase out of range fails', () => {
  const { valid } = validateManifest({
    moduleId:'x', uuid:'x', name:'x', version:'1.0.0',
    bootPhase:99, description:'d', author:'a',
  });
  assert.ok(!valid);
});

// ── All module manifests ──────────────────────────────────────────────────────
console.log('\n  [module manifests]\n');
const moduleDirs = readdirSync(join(ROOT,'modules'), {withFileTypes:true})
  .filter(d=>d.isDirectory()).map(d=>d.name);

for (const mid of moduleDirs) {
  const mp = join(ROOT, 'modules', mid, 'MANIFEST.json');
  if (!existsSync(mp)) { fail++; console.error(`  ✗ ${mid}: MANIFEST.json missing`); continue; }
  const m = JSON.parse(readFileSync(mp,'utf8'));
  test(`${mid}: valid manifest`, () => {
    const {valid,errors} = validateManifest(m);
    assert.ok(valid, errors.join('; '));
  });
  test(`${mid}: uuid (§5.1)`, () => assert.ok(m.uuid?.length > 8));
  test(`${mid}: index.js exists`, () => assert.ok(existsSync(join(ROOT,'modules',mid,'index.js'))));
}

// ── Version parity (§5.4) ─────────────────────────────────────────────────────
console.log('\n  [§5.4 version parity]\n');
const PKG = JSON.parse(readFileSync(join(ROOT,'package.json'),'utf8'));
const MAN = JSON.parse(readFileSync(join(ROOT,'MANIFEST.json'),'utf8'));

test('package.json version matches MANIFEST.json', () => {
  assert.strictEqual(PKG.version, MAN.version);
});
test('package.json main = index.js', () => {
  assert.strictEqual(PKG.main, 'index.js');
});
test('package.json start = node index.js', () => {
  assert.ok(PKG.scripts?.start?.includes('index.js'));
});
test('no require() in root files (ESM §5.5)', () => {
  ['siso.js','jaa.js','index.js'].forEach(f => {
    const c = readFileSync(join(ROOT,f),'utf8');
    assert.ok(!c.includes('require('), `${f} contains require()`);
  });
});

// ── Cleanup ───────────────────────────────────────────────────────────────────
try { rmSync(tmpDir, { recursive:true, force:true }); } catch {}

console.log(`\n  ── Results: ${pass} pass, ${fail} fail ──`);
if (fail > 0) { console.error('  FAILURES — fix before shipping\n'); process.exit(1); }
else console.log('  ✓ All core tests pass\n');
