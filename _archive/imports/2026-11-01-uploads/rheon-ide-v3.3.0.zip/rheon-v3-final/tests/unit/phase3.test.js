/**
 * RHEON IDE — Phase 3 Tests
 * @version 3.0.0
 * @axioms  §4.1 §4.2 §1.1
 *
 * Gate condition: all pass before Phase 4 opens.
 * Tests: seam-engine (20 real expressions), grammar-engine, field-engine
 */
import { strict as assert }   from 'assert';
import { fileURLToPath }       from 'url';
import { join }                from 'path';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..', '..');

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log(`  ✓ ${name}`); }
  catch(e) { fail++; console.error(`  ✗ ${name}: ${e.message}`); }
}

const { parse, MANIFEST: SM } = await import(join(ROOT, 'modules', 'seam-engine', 'index.js'));

// ── Seam Engine ───────────────────────────────────────────────────────────────
console.log('\n  [seam-engine] MANIFEST\n');
test('MANIFEST valid', () => { assert.ok(SM.moduleId === 'seam-engine'); });
test('bootPhase = 3',  () => { assert.strictEqual(SM.bootPhase, 3); });

console.log('\n  [seam-engine] 20 real expressions\n');

// 1. First test expression
test('make documents multidimensional → DECLARE', () => {
  const r = parse('make documents multidimensional');
  assert.strictEqual(r.verb, 'DECLARE');
  assert.ok(r.isKernelWord);
  assert.ok(r.gaps.length > 0, 'should detect gap: dimensions not defined');
  assert.ok(r.confidence > 0.3);
});

// 2. Hard constraint
test('tension between structure and freedom → TENSION', () => {
  const r = parse('tension between structure and freedom');
  assert.strictEqual(r.verb, 'TENSION');
  assert.ok(r.isKernelWord);
});

// 3. Causal constraint extraction
test('constraint extraction: requires', () => {
  const r = parse('every node requires a unique identifier');
  assert.ok(r.constraints.length >= 1, 'should extract constraint');
  assert.strictEqual(r.constraints[0].type, 'causal');
});

// 4. Hard constraint
test('constraint extraction: cannot', () => {
  const r = parse('a gap cannot resolve itself');
  assert.ok(r.constraints.some(c => c.type === 'hard'), 'should be hard constraint');
  assert.ok(r.constraints.some(c => c.strength >= 0.85));
});

// 5. Must constraint
test('constraint extraction: must', () => {
  const r = parse('every event must have a causal parent');
  assert.ok(r.constraints.some(c => c.type === 'hard'));
});

// 6. Show surface
test('show the constraint field → SURFACE', () => {
  const r = parse('show the constraint field');
  assert.strictEqual(r.verb, 'SURFACE');
});

// 7. Gap detection on vague referent
test('gap detected: pronoun without referent', () => {
  const r = parse('it produces inconsistent results');
  assert.ok(r.gaps.some(g => g.missingVariable === 'referent'));
});

// 8. Future temporal gap
test('gap detected: future without timeline', () => {
  const r = parse('we will solve this eventually');
  assert.ok(r.gaps.some(g => g.missingVariable === 'temporal_boundary'));
});

// 9. Vague placeholder gap
test('gap detected: vague placeholder', () => {
  const r = parse('somehow the system should handle this');
  assert.ok(r.gaps.some(g => g.missingVariable === 'undefined_referent'));
});

// 10. QUERY
test('find nodes where coherence < 0.5 → QUERY', () => {
  const r = parse('find nodes where coherence is low');
  assert.strictEqual(r.verb, 'QUERY');
});

// 11. BUS_EMIT
test('emit ide:kernel:node:committed → BUS_EMIT', () => {
  const r = parse('emit ide:kernel:node:committed');
  assert.strictEqual(r.verb, 'BUS_EMIT');
});

// 12. BUS_SUB
test('watch ide:field:updated → BUS_SUB', () => {
  const r = parse('watch ide:field:updated');
  assert.strictEqual(r.verb, 'BUS_SUB');
});

// 13. GAP_FILL
test('fill the dimension gap with x, y, z axes → GAP_FILL', () => {
  const r = parse('fill the dimension gap with x, y, z axes');
  assert.strictEqual(r.verb, 'GAP_FILL');
});

// 14. COMPOSE
test('define a constraint as a named rule with strength → COMPOSE', () => {
  const r = parse('define a constraint as a named rule with strength');
  assert.strictEqual(r.verb, 'COMPOSE');
});

// 15. CONSTRAINT
test('constrain all agents by the SISO bus → CONSTRAINT', () => {
  const r = parse('constrain all agents by the SISO bus');
  assert.strictEqual(r.verb, 'CONSTRAINT');
});

// 16. High confidence kernel word
test('confidence > 0.6 for kernel word expressions', () => {
  const r = parse('make a new session with clean state');
  assert.ok(r.confidence > 0.6, `confidence was ${r.confidence}`);
});

// 17. Low confidence unknown verb
test('confidence < 0.5 for unknown verb', () => {
  const r = parse('the sky is blue and things happen slowly');
  assert.ok(r.confidence < 0.5, `confidence was ${r.confidence}`);
  assert.strictEqual(r.isKernelWord, false);
});

// 18. Multi-constraint extraction
test('multiple constraints in one expression', () => {
  const r = parse('every module must register on the bus and cannot import siblings directly');
  assert.ok(r.constraints.length >= 2, `got ${r.constraints.length} constraints`);
});

// 19. Signals: negation
test('signals.negation detected', () => {
  const r = parse('do not allow direct imports between modules');
  assert.strictEqual(r.signals.negation, 1);
});

// 20. Signals: causality
test('signals.causality from "because"', () => {
  const r = parse('the field updates because the node was committed');
  assert.ok(r.signals.causality > 0);
});

// 21. Null input returns null (§1.2 no silent errors)
test('parse(null) returns null without throw', () => {
  assert.strictEqual(parse(null), null);
  assert.strictEqual(parse(''), null);
  assert.strictEqual(parse('   '), null);
});

// 22. Template present for kernel words
test('kernel word has template', () => {
  const r = parse('make x = y');
  assert.ok(r.template, 'kernel word should have template');
});

// ── Grammar Engine ────────────────────────────────────────────────────────────
console.log('\n  [grammar-engine]\n');
const { MANIFEST: GM } = await import(join(ROOT, 'modules', 'grammar-engine', 'index.js'));

test('MANIFEST valid + phase 3', () => {
  assert.strictEqual(GM.bootPhase, 3);
  assert.ok(GM.writes.includes('grammar'));
});

test('grammar-engine reads seam:submitted', () => {
  assert.ok(GM.reads.includes('ide:seam:submitted'));
});

test('grammar-engine emits grammar:updated', () => {
  assert.ok(GM.emits.includes('ide:grammar:words:updated'));
});

// ── Field Engine ──────────────────────────────────────────────────────────────
console.log('\n  [field-engine]\n');
const { MANIFEST: FM } = await import(join(ROOT, 'modules', 'field-engine', 'index.js'));

test('MANIFEST valid + phase 3', () => {
  assert.strictEqual(FM.bootPhase, 3);
});

test('field-engine reads seam:parsed', () => {
  assert.ok(FM.reads.includes('ide:seam:parsed'));
});

test('field-engine reads kernel:node:committed', () => {
  assert.ok(FM.reads.includes('ide:kernel:node:committed'));
});

test('field-engine emits field:updated', () => {
  assert.ok(FM.emits.includes('ide:field:updated'));
});

// ── Bus-wired integration test ────────────────────────────────────────────────
console.log('\n  [Phase 3 bus integration]\n');
const { SISOBus } = await import(join(ROOT, 'siso.js'));
const { jaa }     = await import(join(ROOT, 'jaa.js'));
import { mkdtempSync, rmSync } from 'fs';
import { tmpdir } from 'os';

const tmpDir = mkdtempSync(join(tmpdir(), 'rheon-p3-'));
process.env.JAA_DATA_DIR = tmpDir;
// Note: jaa is a singleton already open — test with a fresh bus only

const testBus = new SISOBus();
let seam_parsed_count = 0, field_updated_count = 0;
testBus.on('ide:seam:parsed',   () => seam_parsed_count++);
testBus.on('ide:field:updated', () => field_updated_count++);

// Manually simulate what the modules do on the bus
test('seam parse → field update pipeline (bus flow)', () => {
  const expression = 'every node requires a UUID to exist in the system';
  const parsed = parse(expression);

  // seam-engine emits this
  testBus.emit('ide:seam:parsed', parsed);
  assert.strictEqual(seam_parsed_count, 1);

  // field-engine receives ide:seam:parsed and emits ide:field:updated
  // Simulate what field-engine does
  testBus.on('ide:seam:parsed', (ev) => {
    testBus.emit('ide:field:updated', {
      constraints: ev.payload.constraints,
      gaps:        ev.payload.gaps,
      ts:          Date.now(),
    });
  });
  testBus.emit('ide:seam:parsed', parse('tension between speed and accuracy'));
  assert.ok(field_updated_count >= 1, 'field should have been updated');
});

try { rmSync(tmpDir, { recursive: true, force: true }); } catch {}

// ── Summary ───────────────────────────────────────────────────────────────────
console.log(`\n  ── Phase 3 Results: ${pass} pass, ${fail} fail ──`);
if (fail > 0) { console.error('\n  Phase 3 gate BLOCKED — fix failures before Phase 4\n'); process.exit(1); }
else console.log('\n  ✓ Phase 3 gate OPEN — proceeding to Phase 4\n');
