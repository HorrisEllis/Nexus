/**
 * RHEON IDE — tests/run-all.js
 * @version 3.0.0
 * @axioms  §4.1
 *
 * Run with: node tests/run-all.js
 * Runs every test suite in phase order.
 * Prints totals. Exits 1 if any failure.
 */

import { spawnSync }       from 'child_process';
import { fileURLToPath }   from 'url';
import { join }            from 'path';

const ROOT  = join(fileURLToPath(import.meta.url), '..', '..');
const NODE  = process.execPath;

const SUITES = [
  { file: 'tests/unit/core.test.js',             label: 'Core (siso + jaa + manifests)' },
  { file: 'tests/unit/phase3.test.js',           label: 'Phase 3 gate (seam + grammar + field)' },
  { file: 'tests/adversarial/six-lenses.test.js',label: 'Six Lenses adversarial' },
  { file: 'modules/ollama-agent/tests/index.test.js', label: 'ollama-agent module' },
  { file: 'modules/kernel-bridge/tests/index.test.js', label: 'kernel-bridge module' },
];

const PASS_RE  = /Results?:\s*(\d+)\s*pass/;
const FAIL_RE  = /Results?:\s*\d+\s*pass,\s*(\d+)\s*fail/;
const GATE_RE  = /gate (OPEN|BLOCKED)/i;

let totalPass = 0, totalFail = 0;
const results = [];

console.log('\n  ╔═══════════════════════════════════════════════════╗');
console.log('  ║  RHEON IDE — Full Test Run                        ║');
console.log('  ╚═══════════════════════════════════════════════════╝\n');

for (const suite of SUITES) {
  const absPath = join(ROOT, suite.file);
  process.stdout.write(`  Running ${suite.label}…\n`);

  const result = spawnSync(NODE, [absPath], {
    cwd:      ROOT,
    encoding: 'utf8',
    timeout:  30000,
  });

  const output  = result.stdout + result.stderr;
  const passMatch = PASS_RE.exec(output);
  const failMatch = FAIL_RE.exec(output);
  const gateMatch = GATE_RE.exec(output);

  const p = passMatch ? parseInt(passMatch[1]) : 0;
  const f = failMatch ? parseInt(failMatch[1]) : (result.status !== 0 ? 1 : 0);

  totalPass += p;
  totalFail += f;

  const status  = f === 0 ? '✓' : '✗';
  const gate    = gateMatch ? ` [gate ${gateMatch[1]}]` : '';
  const detail  = f === 0
    ? `${p} pass`
    : `${p} pass, ${f} FAIL`;

  results.push({ label: suite.label, status, detail, gate, p, f });
  console.log(`  ${status} ${suite.label}: ${detail}${gate}`);

  // If a gate test fails, show its output
  if (f > 0) {
    const lines = output.split('\n').filter(l => l.includes('✗') || l.includes('FAIL') || l.includes('Error'));
    lines.slice(0,8).forEach(l => console.log(`      ${l.trim()}`));
  }
}

// ── Summary ───────────────────────────────────────────────────────────────────
console.log('\n  ─────────────────────────────────────────────────────');
console.log(`  Total:  ${totalPass} pass,  ${totalFail} fail`);

if (totalFail === 0) {
  console.log('\n  ✓ ALL TESTS PASS');
  console.log(`  ${totalPass} assertions verified across ${SUITES.length} suites`);
  console.log('\n  System is proven. Ready to run: node index.js\n');
} else {
  console.error('\n  ✗ FAILURES — do not ship\n');
  process.exit(1);
}
