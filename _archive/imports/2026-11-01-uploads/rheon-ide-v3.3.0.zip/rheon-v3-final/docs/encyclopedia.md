# RHEON IDE — Encyclopedia v3.0.0

> AUTO-GENERATED from proven code only. §6.1: documentation is generated from proof, not written as aspiration.

---

## System Map

```
rheon-v3-final/
  siso.js                    ← ROOT: Immutable event bus
  jaa.js                     ← ROOT: Immutable persistent store
  index.js                   ← ROOT: Boot sequence + re-exports
  MANIFEST.json              ← Living spec anchor
  package.json               ← v3.0.0, zero runtime deps
  plugins/
    plugin-schema.js         ← Module contract + UI_SLOT definitions
    plugin-loader.js         ← Discovery, hot-load, drag+drop watcher
  spec/
    spec-engine.js           ← Auto-generates spec/rheon.spec on change
    rheon.spec               ← Living spec (this was just generated)
  server/
    index.js                 ← HTTP+WS server, all routes, CLI handler
  modules/                   ← Self-contained plugins (WordPress-style)
    kernel-bridge/           ← Phase 2: WS to Rheon Kernel :7749
    seam-engine/             ← Phase 3: Seam language parser
    grammar-engine/          ← Phase 3: Jaa-backed grammar words
    field-engine/            ← Phase 3: Live constraint field
    ollama-agent/            ← Phase 4: Local LLM (20 models, HW-calibrated)
    guardian-agent/          ← Phase 4: Guardian Firefox extension bridge
    snr-passthrough/         ← Phase 4: Signal quality pipeline
    voice-engine/            ← Phase 5: Mic + Whisper transcription
    compiler/                ← Phase 6: SISO build pipeline
    repo/                    ← Phase 7: Git operations
    spec-builder/            ← Phase 8: Spec file management
    causal-nexus/            ← Phase 8: Causal graph integration
  ui/
    index.html               ← Shell: Van Gogh swirl + 3 panes + console
    interaction-contract.js  ← All bus channels + component hook declarations
    ui-elements-index.js     ← Every DOM element mapped to component+channel
    components/
      swirl-engine/          ← Van Gogh flow-field particles (no bus deps)
      debug-overlay/         ← Per-component debug + null-bus isolation
      drag-drop-zone/        ← Global drop handler + zip install
      prose-editor/          ← Block-based contenteditable
      code-editor/           ← Syntax highlight + line numbers
      field-pane/            ← Constraint field visualization
      preview-pane/          ← HTML/spec/build preview
      console-pane/          ← Bus stream + CLI REPL
      topbar/                ← Status + Ollama + voice + debug
      settings-panel/        ← Ollama catalog + plugin manager
      plugin-manager/        ← Plugin registry + load/unload
  tests/
    unit/                    ← Per-phase unit tests
    adversarial/             ← Six-lens adversarial tests
  data/jaa/                  ← JSONL store (21 tables, append-only)
  docs/
    encyclopedia.md          ← This file
```

---

## Core Concepts

### SISO Bus (`siso.js`)
All inter-module communication goes through this. No module calls another module directly.

```js
import { bus } from './siso.js';
bus.on('ide:kernel:node:committed', (ev) => { /* ... */ });
bus.emit('ide:editor:submit', { text: 'make documents multidimensional' });
```

Pattern matching: `'kernel.*'` matches one level. `'kernel.**'` matches any depth.

### Jaa Store (`jaa.js`)
Write before act. §2.1 is not optional.

```js
import { jaa } from './jaa.js';
await jaa.open();
const node = await jaa.insert('nodes', { text, domain });  // write first
bus.emit('ide:kernel:node:committed', node);                // then emit
```

Ledger checkpoints: `jaa.checkpoint({ file, content, description })` — only writes if content changed (hash differs).

### Plugin contract (`plugins/plugin-schema.js`)
Every module in `modules/*/` must have:
- `MANIFEST.json` — declares uuid, bootPhase, emits, reads, writes, ui_hooks
- `index.js` — exports `register(bus, jaa)`, `unregister()`, `status()`, `MANIFEST`
- `README.md` — documentation
- `tests/` — module tests

```js
// Every module looks like this:
export async function register(bus, jaa) {
  // wire up bus subscriptions
  const unsub = bus.on('ide:editor:submit', async (ev) => { /* ... */ });
  return async () => unsub(); // return cleanup fn = unregister
}
export function status() { return { ok: true }; }
```

### Debug isolation (`ui/components/debug-overlay/`)
Four states per component:

| State | Meaning |
|-------|---------|
| `active` | Normal operation |
| `debug` | Extra logging, raw data visible, no functional change |
| `isolated` | Component's bus calls go to null-bus. Real bus unaffected. Other components continue normally. |
| `disabled` | Component unmounted, slot shows placeholder |

CLI: `ide debug <componentId> isolated`  
UI: topbar → debug button → select component → set state

The null-bus accepts all `on()` and `emit()` calls but fires no handlers. The component thinks it's running — it just isn't connected to anything real.

### Drag + Drop (`ui/components/drag-drop-zone/`)
Drop anywhere on the document:
- `.zip` → bus emits `ide:drop:zip` → plugin-loader extracts + validates MANIFEST → loads
- `.js`/`.json` → bus emits `ide:drop:file`
- `.html` → UI hot-swap request

Toggle: `ide drop enable` / `ide drop disable`  
Isolated mode: accepts drops, emits to log only, no installs.

---

## Ollama Model Catalog

Hardware: R7 3700X + 16GB RAM + GTX 1650 (4GB VRAM, 3.6GB usable)

### GPU-accelerated (fits in 3.6GB VRAM)
| Model | Pull | tok/s | Best for |
|-------|------|-------|----------|
| **Mistral 7B Q4_K_M** ⭐ | `mistral:7b-instruct-q4_K_M` | ~28 | Default. Seam parsing, general |
| Mistral 7B Q4_K_S | `mistral:7b-instruct-q4_K_S` | ~32 | Fastest streaming |
| Phi-3 Mini 3.8B | `phi3:mini-4k-instruct-q4_K_M` | ~45 | Voice assist, quick queries |
| Phi-3 Mini 128K | `phi3:mini-128k-instruct-q4_K_M` | ~40 | Long spec analysis |
| Gemma 2 2B | `gemma2:2b-instruct-q4_K_M` | ~60 | Always-on, status |
| Qwen 2.5 7B | `qwen2.5:7b-instruct-q4_K_M` | ~27 | Code, math, compilation |
| Llama 3.2 3B | `llama3.2:3b-instruct-q4_K_M` | ~50 | Voice post-processing |
| DeepSeek R1 1.5B | `deepseek-r1:1.5b` | ~80 | Reasoning, constraint logic |

### CPU (partial GPU offload, ~7-9 tok/s)
CodeLlama 7B · DeepSeek Coder 6.7B · Neural Chat 7B · Mistral 7B Q5

### CPU only (~4-6 tok/s, background tasks)
Llama 3.1 8B · CodeLlama 13B · DeepSeek R1 7B · Qwen 2.5 14B (slow)

### Embeddings
`nomic-embed-text` · `mxbai-embed-large`

---

## CLI Reference

```
ide help                          all commands
ide status                        server + kernel status
ide connect [--url ws://...]      connect to Rheon Kernel
ide grammar list                  all Seam grammar words
ide grammar list --status active
ide seam parse "<expression>"     parse without submitting
ide agent ollama status           Ollama connection
ide agent ollama catalog          full model catalog
ide agent ollama model <pull>     set active model
ide agent guardian status         Guardian extension status
ide debug <component> <state>     set component isolation state
ide drop enable/disable           toggle drag+drop installs
ide jaa                           Jaa table counts
ide spec                          spec file status
```

---

## Running

```bash
# From rheon-v3-final/
node server/index.js

# Opens:
# http://localhost:7800       — IDE UI
# ws://localhost:7800/ws      — WS bridge
# http://localhost:7800/api/* — REST API
```

Rheon Kernel (separate): `node index.js` from your rheon-kernel directory, port 7749.  
Ollama: `ollama serve` (port 11434).  
Guardian: Firefox extension running.

---

## Axiom compliance

| Axiom | Status |
|-------|--------|
| §1.1 Nothing exists until proven | 104/104 tests verify before shipping |
| §1.2 Nothing silently fails | Every error emits on bus with context |
| §2.1 Persistence is golden rule | All Jaa writes happen before bus emits |
| §3.1 Bottom-up only | Phase order enforced: 0→1→2→...→10 |
| §5.1 UUID + hook + bus registration | Every module, every component, every hook |
| §5.4 Versions persist | 3.0.0 in every file |
| §5.7 Low coupling | No module imports another module directly |
| §8.3 SISO + Jaa load-order prereqs | jaa.open() runs before bootAll() |
