/**
 * RHEON CORE — plugin-schema.js
 * @uuid        aa000003-0000-4000-8000-000000000003
 * @version     3.0.0
 * @layer       0 — ROOT (immutable)
 * @axioms      §5.1 §5.2 §5.6 §5.7 §5.8
 *
 * THE MODULE/PLUGIN CONTRACT.
 * Every module in modules/ must export a MANIFEST conforming to this schema.
 * The plugin loader validates this before registering any module.
 *
 * Inspired by WordPress plugin headers, adapted for event-bus architecture.
 *
 * A module is a self-contained folder with:
 *   modules/my-module/
 *     MANIFEST.json     ← static declaration (validated at load)
 *     index.js          ← entry point (exports: register, unregister, status)
 *     README.md         ← documentation (auto-included in encyclopedia)
 *     tests/            ← module-specific tests
 *
 * The MANIFEST declares everything the module needs before any code runs:
 *   - What bus channels it reads/emits
 *   - What Jaa tables it writes
 *   - What UI slots it occupies (hooks)
 *   - What phase it boots in
 *   - What its dependencies are
 */

'use strict';

// ── MANIFEST SCHEMA ───────────────────────────────────────────────────────────

export const MANIFEST_SCHEMA = Object.freeze({
  // REQUIRED FIELDS
  required: [
    'moduleId',   // kebab-case unique ID e.g. 'seam-engine'
    'uuid',       // stable UUID — never changes after v1.0.0
    'name',       // human-readable name
    'version',    // semver
    'bootPhase',  // 1-10 integer — load order
    'description',// what it does
    'author',     // owner
  ],

  // OPTIONAL BUT RECOMMENDED
  optional: [
    'emits',      // string[] — bus channels this module emits
    'reads',      // string[] — bus channels this module subscribes to
    'writes',     // string[] — Jaa tables this module writes to
    'reads_tables',// string[] — Jaa tables this module reads from
    'ui_hooks',   // UIHook[] — UI slots this module occupies
    'dependencies',// string[] — moduleIds that must be loaded first
    'cli_commands',// string[] — CLI commands this module adds
    'config',     // object — default config values
    'axioms',     // string[] — axioms this module must satisfy
  ],
});

// ── UI HOOK SLOTS ──────────────────────────────────────────────────────────────
// Where a module can mount UI components.
// The UI reads hook registrations from Jaa `plugin_hooks` table on mount.

export const UI_SLOT = Object.freeze({
  TOPBAR:          'topbar',           // buttons/status in the top bar
  TOPBAR_RIGHT:    'topbar.right',     // right side of topbar
  SIDEBAR:         'sidebar',          // left sidebar item
  SIDEBAR_SECTION: 'sidebar.section',  // section within sidebar
  PANE_EDITOR:     'pane.editor',      // inside the editor pane
  PANE_FIELD:      'pane.field',       // inside the field/translation pane
  PANE_PREVIEW:    'pane.preview',     // inside the preview pane
  PANE_CONSOLE:    'pane.console',     // inside the console
  CONSOLE_STREAM:  'console.stream',   // events in the bus stream panel
  CONSOLE_CLI:     'console.cli',      // CLI command output panel
  SETTINGS_SECTION:'settings.section', // a section in the settings panel
  STATUS_BAR:      'status.bar',       // bottom status bar
  MODAL:           'modal',            // modal overlay (use sparingly)
  TOOLBAR:         'toolbar',          // floating toolbar
  CONTEXT_MENU:    'context.menu',     // right-click context menu
});

// ── UI HOOK COMPONENT TYPES ───────────────────────────────────────────────────

export const UI_COMPONENT = Object.freeze({
  BUTTON:        'button',        // clickable button with label + icon
  INDICATOR:     'indicator',     // status dot/badge (connected/disconnected)
  PANEL:         'panel',         // expandable panel with title
  LIST:          'list',          // scrollable list of items
  BADGE:         'badge',         // small count/status badge
  DROPDOWN:      'dropdown',      // dropdown menu
  SELECT:        'select',        // model/option selector
  TEXT:          'text',          // static or dynamic text label
  PROGRESS:      'progress',      // progress bar
  CUSTOM:        'custom',        // arbitrary HTML (sandboxed iframe)
});

// ── UIHook schema ─────────────────────────────────────────────────────────────
// Each entry in manifest.ui_hooks declares one UI component.

export const UI_HOOK_SCHEMA = Object.freeze({
  required: ['hookId', 'slot', 'component', 'label'],
  fields: {
    hookId:    'string — unique within module, e.g. "ollama-status-indicator"',
    slot:      'UI_SLOT value',
    component: 'UI_COMPONENT value',
    label:     'string — display text or aria-label',
    icon:      'string? — optional icon name (from Tabler icons)',
    action:    'string? — bus channel to emit when user interacts',
    dataFrom:  'string? — bus channel that provides display data',
    priority:  'number? — render order within slot (default 50)',
    visible:   'string? — bus channel whose payload.visible controls visibility',
    tooltip:   'string? — hover tooltip',
  },
});

// ── MANIFEST VALIDATOR ────────────────────────────────────────────────────────

export function validateManifest(m) {
  const errors = [];

  // Check required fields
  for (const field of MANIFEST_SCHEMA.required) {
    if (!m[field]) errors.push(`missing required field: ${field}`);
  }

  // bootPhase must be 1-10
  if (m.bootPhase !== undefined && (typeof m.bootPhase !== 'number' || m.bootPhase < 1 || m.bootPhase > 10)) {
    errors.push(`bootPhase must be integer 1-10, got: ${m.bootPhase}`);
  }

  // version must be semver-like
  if (m.version && !/^\d+\.\d+\.\d+/.test(m.version)) {
    errors.push(`version must be semver (x.y.z), got: ${m.version}`);
  }

  // ui_hooks validation
  if (m.ui_hooks) {
    if (!Array.isArray(m.ui_hooks)) {
      errors.push('ui_hooks must be an array');
    } else {
      m.ui_hooks.forEach((h, i) => {
        for (const f of UI_HOOK_SCHEMA.required) {
          if (!h[f]) errors.push(`ui_hooks[${i}] missing ${f}`);
        }
        if (h.slot && !Object.values(UI_SLOT).includes(h.slot)) {
          errors.push(`ui_hooks[${i}] unknown slot: ${h.slot}`);
        }
        if (h.component && !Object.values(UI_COMPONENT).includes(h.component)) {
          errors.push(`ui_hooks[${i}] unknown component: ${h.component}`);
        }
      });
    }
  }

  return { valid: errors.length === 0, errors };
}

// ── MODULE ENTRY CONTRACT ─────────────────────────────────────────────────────
// Every modules/*/index.js must export these functions.

export const MODULE_ENTRY_CONTRACT = Object.freeze({
  // Called by plugin loader after validation. Must register bus listeners, return cleanup fn.
  register:   'async (bus, jaa) => unregisterFn',

  // Called when module is unloaded (hot-unload). Must clean up bus listeners.
  unregister: 'async () => void',

  // Returns current module status. Must always succeed.
  status:     '() => { ok: boolean, details: object }',

  // The module's manifest (also in MANIFEST.json, but accessible programmatically)
  MANIFEST:   'object conforming to MANIFEST_SCHEMA',
});

// ── BOOT PHASE ORDER ──────────────────────────────────────────────────────────
// Phase 1 boots before Phase 2. Dependencies must be lower phase number.

export const BOOT_PHASES = Object.freeze({
  1: 'infrastructure',  // jaa, siso bus (these are core — not phases)
  2: 'kernel-bridge',   // kernel WS connection
  3: 'data-engines',    // seam, grammar, field engines
  4: 'agents',          // ollama, guardian, snr
  5: 'voice',           // mic, whisper bridge
  6: 'compiler',        // build pipeline
  7: 'repo',            // git operations
  8: 'spec-builder',    // spec file management
  9: 'ui',              // UI layer
  10:'docs',            // encyclopedia generation
});

export const PLUGIN_SCHEMA_VERSION = '3.0.0';
export const PLUGIN_SCHEMA_UUID    = 'aa000003-0000-4000-8000-000000000003';
