/**
 * RHEON — plugins/plugin-loader.js
 * @uuid        aa000004-0000-4000-8000-000000000004
 * @version     3.0.0
 * @axioms      §1.1 §1.2 §2.1 §5.1 §5.2 §5.7 §5.8
 */

import { bus }              from '../siso.js';
import { jaa }              from '../jaa.js';
import { validateManifest } from './plugin-schema.js';
import { createHash }       from 'crypto';
import { readFileSync, existsSync, readdirSync, statSync, watch } from 'fs';
import { join }             from 'path';
import { cwd }              from 'process';

const IS_NODE     = typeof process !== 'undefined' && process.versions?.node;
const MODULES_DIR = IS_NODE ? join(cwd(), 'modules') : null;

const _registry = new Map();
const _hooks    = new Map();

// ── Load a single module ──────────────────────────────────────────────────────
export async function loadModule(modulePath) {
  if (!IS_NODE) return { ok: false, error: 'plugin-loader requires Node.js' };

  const manifestPath = join(modulePath, 'MANIFEST.json');
  if (!existsSync(manifestPath)) {
    return _gap(modulePath, 'MANIFEST.json not found (§5.1)');
  }

  let manifest;
  try {
    manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
  } catch (e) {
    return _gap(modulePath, `MANIFEST.json parse error: ${e.message}`);
  }

  const { valid, errors } = validateManifest(manifest);
  if (!valid) {
    return _gap(modulePath, `manifest validation failed: ${errors.join('; ')}`);
  }

  const indexPath = join(modulePath, 'index.js');
  if (!existsSync(indexPath)) {
    return _gap(modulePath, 'index.js not found');
  }

  let mod;
  try {
    // Use file:// URL for cross-platform Windows compatibility
    const normalized = indexPath.replace(/\\/g, '/');
    const fileUrl = normalized.startsWith('/') ? `file://${normalized}` : `file:///${normalized}`;
    mod = await import(fileUrl);
  } catch (e) {
    return _gap(modulePath, `import failed: ${e.message}`);
  }

  if (typeof mod.register !== 'function') {
    return _gap(modulePath, 'module.register() missing — see plugins/plugin-schema.js MODULE_ENTRY_CONTRACT');
  }

  if (_registry.has(manifest.moduleId)) {
    await unloadModule(manifest.moduleId);
  }

  let unregFn;
  try {
    unregFn = await mod.register(bus, jaa);
  } catch (e) {
    return _gap(modulePath, `register() threw: ${e.message}`);
  }

  if (manifest.ui_hooks?.length) {
    for (const hook of manifest.ui_hooks) {
      const rec = { ...hook, moduleId: manifest.moduleId, moduleUuid: manifest.uuid, _ts: Date.now() };
      await jaa.insert('plugin_hooks', { uuid: `${manifest.moduleId}-${hook.hookId}`, ...rec });
      _hooks.set(`${manifest.moduleId}-${hook.hookId}`, rec);
    }
  }

  await jaa.registerPlugin({ ...manifest, status: 'active', loadedAt: Date.now() });

  _registry.set(manifest.moduleId, {
    manifest,
    unregister: unregFn || (() => {}),
    status:     mod.status || (() => ({ ok: true })),
    path:       modulePath,
  });

  bus.emit('plugin:loaded', {
    moduleId:  manifest.moduleId,
    name:      manifest.name,
    version:   manifest.version,
    bootPhase: manifest.bootPhase,
    hooks:     (manifest.ui_hooks || []).length,
    ts:        Date.now(),
  });

  return { ok: true, moduleId: manifest.moduleId };
}

// ── Unload ────────────────────────────────────────────────────────────────────
export async function unloadModule(moduleId) {
  const entry = _registry.get(moduleId);
  if (!entry) return { ok: false, error: `module not loaded: ${moduleId}` };
  try { await entry.unregister(); } catch (e) {
    bus.emit('plugin:unload:error', { moduleId, error: e.message, ts: Date.now() });
  }
  for (const [hookId, hook] of _hooks) {
    if (hook.moduleId === moduleId) _hooks.delete(hookId);
  }
  _registry.delete(moduleId);
  await jaa.insert('plugins', { ...entry.manifest, status: 'unloaded', _ts: Date.now() });
  bus.emit('plugin:unloaded', { moduleId, ts: Date.now() });
  return { ok: true };
}

// ── Boot all in phase order ───────────────────────────────────────────────────
export async function bootAll() {
  if (!IS_NODE || !MODULES_DIR) return;
  if (!existsSync(MODULES_DIR)) {
    bus.emit('plugin:loader:warn', { message: `modules/ not found at ${MODULES_DIR}` });
    return;
  }

  const dirs = readdirSync(MODULES_DIR, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => join(MODULES_DIR, d.name));

  const toLoad = [];
  for (const dir of dirs) {
    const mp = join(dir, 'MANIFEST.json');
    if (!existsSync(mp)) continue;
    try {
      const m = JSON.parse(readFileSync(mp, 'utf8'));
      toLoad.push({ dir, bootPhase: m.bootPhase || 99 });
    } catch {}
  }

  toLoad.sort((a, b) => a.bootPhase - b.bootPhase || a.dir.localeCompare(b.dir));

  for (const { dir } of toLoad) {
    const result = await loadModule(dir);
    if (!result.ok) console.warn(`[plugin-loader] failed: ${dir}: ${result.error}`);
  }

  bus.emit('plugin:loader:ready', { loaded: _registry.size, hooks: _hooks.size, ts: Date.now() });
}

// ── File watcher (drag+drop) ──────────────────────────────────────────────────
export function watchModules() {
  if (!IS_NODE || !MODULES_DIR || !existsSync(MODULES_DIR)) return;

  watch(MODULES_DIR, { recursive: false }, async (eventType, filename) => {
    if (!filename) return;
    const modulePath = join(MODULES_DIR, filename);
    try { if (!statSync(modulePath).isDirectory()) return; } catch { return; }

    bus.emit('plugin:discovered', { path: modulePath, event: eventType, ts: Date.now() });
    setTimeout(async () => {
      const result = await loadModule(modulePath);
      if (!result.ok) bus.emit('plugin:load:failed', { path: modulePath, error: result.error, ts: Date.now() });
    }, 500);
  });

  bus.emit('plugin:loader:watching', { dir: MODULES_DIR, ts: Date.now() });
}

// ── Status ────────────────────────────────────────────────────────────────────
export function getRegistry() {
  return Object.fromEntries(
    [..._registry.entries()].map(([id, e]) => [id, {
      moduleId:  id,
      name:      e.manifest.name,
      version:   e.manifest.version,
      bootPhase: e.manifest.bootPhase,
      status:    e.status(),
      hooks:     (e.manifest.ui_hooks || []).length,
      path:      e.path,
    }])
  );
}

export const getHooks  = (slot) => { const a = [..._hooks.values()]; return slot ? a.filter(h => h.slot === slot) : a; };
export const getModule = (moduleId) => _registry.get(moduleId) || null;

// ── Gap logger ────────────────────────────────────────────────────────────────
function _gap(modulePath, reason) {
  console.warn(`[plugin-loader] ${modulePath}: ${reason}`);
  bus.emit('plugin:gap', { path: modulePath, reason, ts: Date.now() });
  jaa.insert('gaps', {
    uuid:    createHash('sha256').update(modulePath + reason).digest('hex').slice(0, 16),
    gapType: 'plugin_load_failure',
    path:    modulePath,
    reason,
    status:  'open',
    ts:      Date.now(),
  }).catch(() => {});
  return { ok: false, error: reason };
}

export const LOADER_VERSION = '3.0.0';
export const LOADER_UUID    = 'aa000004-0000-4000-8000-000000000004';
