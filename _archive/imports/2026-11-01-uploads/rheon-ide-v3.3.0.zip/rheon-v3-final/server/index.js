/**
 * RHEON IDE — server/index.js
 * @uuid    server-0000-0003-0000-000000000001
 * @version 3.0.0
 * @axioms  §1.2 §2.1 §4.3 §5.1 §5.2
 *
 * ENTRY POINT. Run with: node index.js (or node server/index.js directly)
 *
 * §1.2: Every failure is loud. Every step is logged.
 *       Nothing exits silently. Every handshake is reported.
 *       Every failure mode has a toast/log entry with exact cause.
 */

import { createServer }           from 'http';
import { createHash, randomUUID } from 'crypto';
import { readFileSync, existsSync, mkdirSync } from 'fs';
import { join, resolve }          from 'path';
import { cwd, argv, exit }        from 'process';
import { URL, fileURLToPath }     from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = join(__filename, '..');
const ROOT       = resolve(__dirname, '..');

const PORT    = parseInt(process.env.IDE_PORT || '7800');
const HOST    = process.env.IDE_HOST || '0.0.0.0';
const UI_FILE = join(ROOT, 'ui', 'index.html');
const VERSION = '3.0.0';
const UUID    = 'server-0000-0003-0000-000000000001';

// ── Boot logger — §1.2 every step is visible ─────────────────────────────────
const LOG_LEVELS = { info: '  ', warn: '  ⚠ ', error: '  ✗ ', ok: '  ✓ ', step: '  → ' };

function log(level, msg, detail) {
  const prefix = LOG_LEVELS[level] || '  ';
  const line   = `${prefix}${msg}${detail ? ` — ${detail}` : ''}`;
  if (level === 'error') console.error(line);
  else console.log(line);
}

// ── Lazy-load core (gives good error if files missing) ────────────────────────
let bus, jaa;

async function loadCore() {
  log('step', 'Loading core (siso + jaa)…');
  try {
    const sisoMod = await import(join(ROOT, 'siso.js'));
    const jaaMod  = await import(join(ROOT, 'jaa.js'));
    bus = sisoMod.bus;
    jaa = jaaMod.jaa;
    log('ok', 'Core loaded', `SISOBus v${sisoMod.SISO_VERSION}`);
  } catch (e) {
    log('error', 'Failed to load core', e.message);
    log('error', 'Ensure siso.js and jaa.js exist in root directory');
    throw e;
  }
}

async function openJaa() {
  log('step', 'Opening Jaa store…', join(ROOT, 'data', 'jaa'));
  try {
    mkdirSync(join(ROOT, 'data', 'jaa'), { recursive: true });
    await jaa.open();
    const tables = await jaa.tables();
    const counts = await Promise.all(tables.map(t => jaa.count(t)));
    const total  = counts.reduce((a,b) => a+b, 0);
    log('ok', `Jaa open`, `${tables.length} tables, ${total} records`);
  } catch (e) {
    log('error', 'Jaa failed to open', e.message);
    throw e;
  }
}

async function bootModules() {
  log('step', 'Booting modules…');
  const { bootAll, watchModules, getRegistry } = await import(join(ROOT, 'plugins', 'plugin-loader.js')).catch(e => {
    log('error', 'plugin-loader.js not found', e.message); throw e;
  });

  // Subscribe to plugin events for logging
  bus.on('plugin:loaded',      (ev) => log('ok',   `Module loaded: ${ev.payload.moduleId}`, `v${ev.payload.version} phase${ev.payload.bootPhase} · ${ev.payload.hooks} hooks`));
  bus.on('plugin:gap',         (ev) => log('warn', `Module gap: ${ev.payload.path}`, ev.payload.reason));
  bus.on('plugin:load:failed', (ev) => log('error',`Module load failed: ${ev.payload.path}`, ev.payload.error));
  bus.on('plugin:loader:ready',(ev) => log('ok',   `Plugin loader ready`, `${ev.payload.loaded} modules, ${ev.payload.hooks} hooks`));
  bus.on('plugin:discovered',  (ev) => log('info', `New module dropped`, ev.payload.path));

  await bootAll();
  watchModules();

  const registry = getRegistry();
  const count = Object.keys(registry).length;
  log('ok', `${count} modules active`);
  return registry;
}

async function startSpecEngine() {
  log('step', 'Starting spec engine…');
  try {
    const { init } = await import(join(ROOT, 'spec', 'spec-engine.js'));
    await init();
    log('ok', 'Spec engine running', 'spec/rheon.spec auto-updates on file change');
  } catch (e) {
    log('warn', 'Spec engine failed (non-fatal)', e.message);
    // Non-fatal — system works without spec engine
  }
}

// ── Rate limiter ──────────────────────────────────────────────────────────────
const _rates = new Map();
function rateOk(ip) {
  const now = Date.now();
  const e   = _rates.get(ip) || { n: 0, reset: now + 60000 };
  if (now > e.reset) { e.n = 1; e.reset = now + 60000; }
  else e.n++;
  _rates.set(ip, e);
  return e.n <= 300;
}

// ── HTTP helpers ──────────────────────────────────────────────────────────────
const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'X-IDE-Version':                VERSION,
  'X-IDE-UUID':                   UUID,
};

function jsonRes(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json', ...CORS });
  res.end(JSON.stringify(data));
}
function errRes(res, msg, code = 400) {
  jsonRes(res, { ok: false, error: msg, ts: Date.now() }, code);
}
async function readBody(req) {
  return new Promise((res, rej) => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > 1_048_576) rej(new Error('body too large (max 1MB)')); });
    req.on('end',  () => { try { res(JSON.parse(b || '{}')); } catch { res({}); } });
    req.on('error', rej);
  });
}

// ── Routes ────────────────────────────────────────────────────────────────────
const ROUTES = new Map();
const R = (method, path, fn) => ROUTES.set(`${method} ${path}`, fn);

R('GET', '/health', () => ({
  ok: true, version: VERSION, uuid: UUID,
  ts: Date.now(), uptime: process.uptime(),
  node: process.version,
}));

R('GET', '/api/manifest', async () =>
  JSON.parse(readFileSync(join(ROOT, 'MANIFEST.json'), 'utf8'))
);

R('GET', '/api/grammar', async (req) => {
  const u  = new URL(req.url, 'http://x');
  const st = u.searchParams.get('status');
  const words = await jaa.getGrammarWords(st || undefined);
  return { words, count: words.length, ts: Date.now() };
});

R('POST', '/api/grammar', async (req) => {
  const b = await readBody(req);
  if (!b.keyword) throw new Error('keyword is required');
  const w = await jaa.insertGrammarWord(b);
  bus.emit('ide:grammar:words:updated', { words: [w], ts: Date.now() });
  return { ok: true, word: w };
});

R('GET', '/api/nodes', async (req) => {
  const u   = new URL(req.url, 'http://x');
  const lim = Math.min(parseInt(u.searchParams.get('limit') || '20'), 100);
  const nodes = await jaa.query('nodes', () => true, lim);
  return { nodes, count: nodes.length };
});

R('GET', '/api/gaps', async () => {
  const gaps = await jaa.query('gaps', g => g.status === 'open');
  return { gaps, count: gaps.length };
});

R('GET', '/api/ledger/upgrade', async () => {
  const entries = await jaa.query('ledger_upgrade');
  return { entries, count: entries.length };
});

R('GET', '/api/ledger/idea', async () => {
  const entries = await jaa.query('ledger_idea');
  return { entries, count: entries.length };
});

R('GET', '/api/jaa/stats', async () => {
  const stats = {};
  for (const t of await jaa.tables()) stats[t] = await jaa.count(t);
  return { stats, total: Object.values(stats).reduce((a,b)=>a+b,0), ts: Date.now() };
});

R('GET', '/api/agents/ollama/status', async () => {
  try {
    const { getStatus } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
    return getStatus();
  } catch { return { status: 'unavailable', error: 'ollama-agent not loaded' }; }
});

R('GET', '/api/agents/ollama/catalog', async () => {
  try {
    const { getCatalog } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
    return { catalog: getCatalog(), ts: Date.now() };
  } catch { return { catalog: [], error: 'ollama-agent not loaded' }; }
});

R('POST', '/api/agents/ollama/ping', async () => {
  try {
    const { ping, getStatus } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
    const ok = await ping();
    return { ok, status: getStatus(), ts: Date.now() };
  } catch (e) { throw new Error(`Ollama ping failed: ${e.message}`); }
});

R('POST', '/api/agents/ollama/complete', async (req) => {
  const b = await readBody(req);
  if (!b.prompt) throw new Error('prompt is required');
  const { complete } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
  const content = await complete(b);
  return { ok: true, content, ts: Date.now() };
});

R('POST', '/api/agents/ollama/model', async (req) => {
  const b = await readBody(req);
  if (!b.model) throw new Error('model is required');
  const { setModel } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
  const ok = setModel(b.model);
  return { ok, model: b.model, ts: Date.now() };
});

R('GET', '/api/agents/guardian/status', async () => {
  try {
    const { status } = await import(join(ROOT, 'modules', 'guardian-agent', 'index.js'));
    return status();
  } catch { return { ok: false, error: 'guardian-agent not loaded' }; }
});

R('GET', '/api/plugins/hooks', async (req) => {
  const { getHooks } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
  const u    = new URL(req.url, 'http://x');
  const slot = u.searchParams.get('slot');
  return { hooks: getHooks(slot || undefined), ts: Date.now() };
});

R('GET', '/api/plugins/registry', async () => {
  const { getRegistry } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
  return { registry: getRegistry(), ts: Date.now() };
});

R('POST', '/api/plugins/load', async (req) => {
  const b = await readBody(req);
  if (!b.path) throw new Error('path is required');
  const { loadModule } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
  const result = await loadModule(b.path);
  return result;
});

R('POST', '/api/plugins/unload', async (req) => {
  const b = await readBody(req);
  if (!b.moduleId) throw new Error('moduleId is required');
  const { unloadModule } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
  return unloadModule(b.moduleId);
});

R('POST', '/api/voice/start', async () => {
  bus.emit('ide:voice:mic:started', { ts: Date.now() });
  return { ok: true, status: 'recording' };
});

R('POST', '/api/voice/stop', async () => {
  bus.emit('ide:voice:mic:stopped', { ts: Date.now() });
  return { ok: true, status: 'stopped' };
});

R('POST', '/api/ui/swap', async (req) => {
  const b = await readBody(req);
  if (!b.html) throw new Error('html is required (base64)');
  const html = Buffer.from(b.html, 'base64').toString('utf8');
  if (!html.includes('<html') && !html.includes('<!DOCTYPE'))
    throw new Error('invalid HTML — must be a full HTML document');
  const { writeFileSync } = await import('fs');
  writeFileSync(UI_FILE, html, 'utf8');
  bus.emit('ide:ui:swapped', { ts: Date.now() });
  return { ok: true, ts: Date.now() };
});

R('GET', '/api/bus/history', async (req) => {
  const u   = new URL(req.url, 'http://x');
  const pfx = u.searchParams.get('prefix') || '';
  const n   = Math.min(parseInt(u.searchParams.get('n') || '100'), 500);
  return { events: bus.history(pfx || undefined, n), ts: Date.now() };
});

R('GET', '/api/spec', async () => {
  const specPath = join(ROOT, 'spec', 'rheon.spec');
  if (!existsSync(specPath)) return { ok: false, error: 'spec not yet generated — start the server first' };
  return { ok: true, spec: readFileSync(specPath, 'utf8'), ts: Date.now() };
});

R('GET', '/', (req) => {
  if (!existsSync(UI_FILE)) {
    return { __error503: `UI not found at ${UI_FILE}. Phase 10 must complete first. Run: node server/index.js` };
  }
  return { __html: readFileSync(UI_FILE, 'utf8') };
});

// ── HTTP server ───────────────────────────────────────────────────────────────
const httpServer = createServer(async (req, res) => {
  const ip = req.socket?.remoteAddress || 'unknown';

  if (!rateOk(ip)) {
    errRes(res, `Rate limit exceeded — max 300 req/min per IP (§4.3)`, 429);
    return;
  }

  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS);
    res.end();
    return;
  }

  // SSE stream — handle before route matching to avoid OPTIONS conflict
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/api/bus/stream') {
    res.writeHead(200, {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
      ...CORS,
    });
    res.write('retry: 1000\n\n');
    // Send handshake immediately
    res.write(`data: ${JSON.stringify({ type: 'ide:stream:connected', payload: { version: VERSION }, ts: Date.now() })}\n\n`);

    const unsub = bus.on('*', (ev) => {
      try {
        res.write(`data: ${JSON.stringify({ type: ev.type, payload: ev.payload, tick: ev.tick })}\n\n`);
      } catch {}
    });
    req.on('close', () => { unsub?.(); });
    return;
  }

  const routeKey = `${req.method} ${u.pathname}`;
  const handler  = ROUTES.get(routeKey);

  if (!handler) {
    errRes(res, `Route not found: ${routeKey} — see GET /health for API list`, 404);
    return;
  }

  try {
    const result = await handler(req, res);
    if (result?.__html) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...CORS });
      res.end(result.__html);
    } else if (result?.__error503) {
      res.writeHead(503, { 'Content-Type': 'text/plain', ...CORS });
      res.end(result.__error503);
    } else {
      jsonRes(res, result);
    }
  } catch (e) {
    log('error', `Route error ${routeKey}`, e.message);
    errRes(res, e.message, 500);
    // §1.2: also emit on bus so UI sees it
    bus?.emit('ide:server:error', { route: routeKey, error: e.message, ts: Date.now() });
  }
});

// ── WS server ─────────────────────────────────────────────────────────────────
const _wsClients = new Map(); // id → { socket, ip, connectedAt }

httpServer.on('upgrade', (req, socket, head) => {
  if (req.url !== '/ws') {
    socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
    socket.destroy();
    return;
  }

  const key    = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }

  const accept = createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');

  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\n' +
    'Connection: Upgrade\r\n' +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
  );

  const clientId = randomUUID();
  const ip       = req.socket?.remoteAddress || 'unknown';
  const client   = { socket, id: clientId, ip, connectedAt: Date.now() };
  _wsClients.set(clientId, client);

  log('info', `WS client connected`, `${ip} (${clientId.slice(0,8)})`);

  // Handshake — §1.2: client knows exactly what it connected to
  _wsSend(client, {
    type: 'ide:handshake',
    payload: {
      version:    VERSION,
      uuid:       UUID,
      clientId,
      serverTs:   Date.now(),
      modules:    [], // filled after registry available
      ollama:     'checking…',
      kernel:     'checking…',
      guardian:   'checking…',
      wsPort:     PORT,
      httpPort:   PORT,
    },
  });

  // Forward ALL bus events to this WS client
  const unsub = bus.on('*', (ev) => {
    _wsSend(client, { type: ev.type, payload: ev.payload, tick: ev.tick });
  });

  // Handle incoming frames
  socket.on('data', async (data) => {
    try {
      const msg = _wsParseFrame(data);
      if (!msg) return;
      const m = JSON.parse(msg);
      if (!m?.type) return;
      await _handleWsMessage(client, m);
    } catch (e) {
      log('warn', `WS parse error from ${ip}`, e.message);
      _wsSend(client, { type: 'ide:error', payload: { error: `parse error: ${e.message}`, ts: Date.now() } });
    }
  });

  socket.on('close', () => {
    _wsClients.delete(clientId);
    unsub?.();
    log('info', `WS client disconnected`, `${ip} (${clientId.slice(0,8)})`);
  });

  socket.on('error', (e) => {
    _wsClients.delete(clientId);
    unsub?.();
    log('warn', `WS socket error`, `${ip}: ${e.message}`);
  });
});

// ── WS frame codec ────────────────────────────────────────────────────────────
function _wsSend(client, data) {
  try {
    const payload = JSON.stringify(data);
    const buf     = Buffer.from(payload);
    const frame   = Buffer.alloc(2 + (buf.length < 126 ? 0 : buf.length < 65536 ? 2 : 8) + buf.length);
    frame[0] = 0x81;
    let offset = 2;
    if (buf.length < 126) {
      frame[1] = buf.length;
    } else if (buf.length < 65536) {
      frame[1] = 126;
      frame.writeUInt16BE(buf.length, 2);
      offset = 4;
    } else {
      frame[1] = 127;
      frame.writeBigUInt64BE(BigInt(buf.length), 2);
      offset = 10;
    }
    buf.copy(frame, offset);
    if (client.socket.writable) client.socket.write(frame);
  } catch {}
}

function _wsParseFrame(data) {
  if (data.length < 2) return null;
  const masked = (data[1] & 0x80) !== 0;
  let len = data[1] & 0x7f, offset = 2;
  if (len === 126) { len = data.readUInt16BE(2); offset = 4; }
  else if (len === 127) { len = Number(data.readBigUInt64BE(2)); offset = 10; }
  if (!masked) return data.slice(offset, offset + len).toString();
  const mask = data.slice(offset, offset + 4); offset += 4;
  const out  = Buffer.alloc(len);
  for (let i = 0; i < len; i++) out[i] = data[offset + i] ^ mask[i % 4];
  return out.toString();
}

// ── WS message handler (CLI + bus bridge) ────────────────────────────────────
async function _handleWsMessage(client, msg) {
  const respond = (text, level = 'info') => {
    bus.emit('ide:console:cli:response', { text, level, ts: Date.now() });
  };

  // Forward to bus (UI emitting events)
  if (msg.type && msg.type !== 'ide:cli:command') {
    bus.emit(msg.type, msg.payload || {});
  }

  // CLI commands
  if (msg.type === 'ide:cli:command') {
    await _handleCLI(msg.payload?.command || '', respond);
  }
}

// ── CLI handler ───────────────────────────────────────────────────────────────
async function _handleCLI(input, respond) {
  const parts = input.trim().split(/\s+/);
  const cmd   = parts[0]?.toLowerCase();
  const args  = parts.slice(1);

  switch (cmd) {
    case 'help':
    case '?':
      respond([
        '',
        '  RHEON IDE CLI',
        '  ─────────────',
        '  help                          this message',
        '  status                        server + module status',
        '  grammar list [--status X]     Seam grammar words',
        '  grammar add "<word>" "<def>"  add grammar word',
        '  seam parse "<expression>"     parse Seam (no submit)',
        '  agent ollama status           Ollama status',
        '  agent ollama catalog          all hardware-calibrated models',
        '  agent ollama model <pull>     set active model',
        '  agent ollama ping             test connection',
        '  agent guardian status         Guardian extension status',
        '  agent guardian probe claude   probe identity tab',
        '  debug <component> <state>     set component state (active/debug/isolated/disabled)',
        '  debug list                    show all component states',
        '  drop enable/disable           toggle drag+drop installs',
        '  modules list                  loaded modules',
        '  jaa stats                     Jaa table counts',
        '  spec                          show spec status',
        '  connect                       reconnect to Rheon Kernel',
        '',
      ].join('\n'));
      break;

    case 'status': {
      const nodes    = await jaa.count('nodes').catch(() => '?');
      const grammar  = await jaa.count('grammar').catch(() => '?');
      const sessions = await jaa.count('sessions').catch(() => '?');
      const { getRegistry } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
      const reg = getRegistry();
      respond([
        '',
        `  RHEON IDE v${VERSION}`,
        `  UUID:      ${UUID}`,
        `  Port:      ${PORT}`,
        `  Uptime:    ${Math.floor(process.uptime())}s`,
        `  Modules:   ${Object.keys(reg).length} loaded`,
        `  Nodes:     ${nodes}`,
        `  Grammar:   ${grammar} words`,
        `  Sessions:  ${sessions}`,
        '',
      ].join('\n'));
      break;
    }

    case 'grammar': {
      const sub = args[0];
      if (!sub || sub === 'list') {
        const statusFilter = args.includes('--status') ? args[args.indexOf('--status')+1] : undefined;
        const words = await jaa.getGrammarWords(statusFilter);
        if (!words.length) { respond('  no grammar words yet — submit a Seam expression first'); break; }
        respond('\n' + words.map(w =>
          `  ${(w.status||'').padEnd(12)} ${(w.keyword||'').padEnd(20)} ${(w.definition||'').slice(0,60)}`
        ).join('\n'));
        break;
      }
      if (sub === 'add') {
        const keyword = args[1]?.replace(/^["']|["']$/g,'');
        const def     = args.slice(2).join(' ').replace(/^["']|["']$/g,'');
        if (!keyword) { respond('  usage: grammar add "<word>" "<definition>"', 'warn'); break; }
        const w = await jaa.insertGrammarWord({ keyword, definition: def, causedBy: 'cli', status: 'active' });
        bus.emit('ide:grammar:words:updated', { words: [w], ts: Date.now() });
        respond(`  ✓ grammar word added: ${keyword}`);
        break;
      }
      respond('  grammar: list | add', 'warn');
      break;
    }

    case 'seam': {
      if (args[0] === 'parse') {
        const text = args.slice(1).join(' ').replace(/^["']|["']$/g,'');
        if (!text) { respond('  usage: seam parse "<expression>"', 'warn'); break; }
        try {
          const { parse } = await import(join(ROOT, 'modules', 'seam-engine', 'index.js'));
          const result = parse(text);
          respond([
            '',
            `  verb:        ${result.verb}`,
            `  confidence:  ${(result.confidence*100).toFixed(0)}%`,
            `  kernel word: ${result.isKernelWord ? 'yes' : 'no'}`,
            `  constraints: ${result.constraints.length}`,
            ...result.constraints.map(c => `    ${c.type.padEnd(8)} ${c.name}`),
            `  gaps:        ${result.gaps.length}`,
            ...result.gaps.map(g => `    ⊘ ${g.missingVariable}: ${g.reason}`),
            '',
          ].join('\n'));
        } catch (e) { respond(`  seam-engine not loaded: ${e.message}`, 'error'); }
        break;
      }
      respond('  seam: parse', 'warn');
      break;
    }

    case 'agent': {
      const sub = args[0]?.toLowerCase();
      const sub2 = args[1]?.toLowerCase();
      if (sub === 'ollama') {
        if (!sub2 || sub2 === 'status') {
          try {
            const { getStatus } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
            const s = getStatus();
            respond(`\n  Ollama: ${s.status}\n  Model:  ${s.activeModelName || s.activeModel || 'none'}\n  URL:    ${s.baseUrl}\n  Installed: ${s.installedCount} models\n`);
          } catch { respond('  ollama-agent not loaded', 'warn'); }
          break;
        }
        if (sub2 === 'ping') {
          try {
            const { ping } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
            respond('  pinging Ollama…');
            const ok = await ping();
            respond(ok ? '  ✓ Ollama connected' : '  ✗ Ollama unreachable — is Ollama running?', ok ? 'info' : 'error');
          } catch (e) { respond(`  ping failed: ${e.message}`, 'error'); }
          break;
        }
        if (sub2 === 'catalog') {
          try {
            const { getCatalog } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
            const models = getCatalog().filter(m => m.runMode !== 'not_viable');
            respond('\n' + models.map(m =>
              `  ${m.runMode.padEnd(14)} ${m.params.padEnd(6)} ${(m.name).padEnd(30)} ${(m.tokPerSec?.gpu||m.tokPerSec?.cpu||'?')} tok/s`
            ).join('\n'));
          } catch { respond('  ollama-agent not loaded', 'warn'); }
          break;
        }
        if (sub2 === 'model') {
          const pull = args[2];
          if (!pull) { respond('  usage: agent ollama model <pull-name>', 'warn'); break; }
          try {
            const { setModel } = await import(join(ROOT, 'modules', 'ollama-agent', 'index.js'));
            const ok = setModel(pull);
            respond(ok ? `  ✓ model → ${pull}` : `  ✗ model not in catalog: ${pull}`, ok ? 'info' : 'error');
          } catch (e) { respond(`  failed: ${e.message}`, 'error'); }
          break;
        }
      }
      if (sub === 'guardian') {
        if (!sub2 || sub2 === 'status') {
          try {
            const { status } = await import(join(ROOT, 'modules', 'guardian-agent', 'index.js'));
            const s = status();
            respond(`\n  Guardian bridge: ${s.bridge}\n  Pending: ${s.pending}\n`);
          } catch { respond('  guardian-agent not loaded', 'warn'); }
          break;
        }
        if (sub2 === 'probe') {
          const identity = args[2] || 'claude';
          try {
            const { probe } = await import(join(ROOT, 'modules', 'guardian-agent', 'index.js'));
            respond(`  probing ${identity} tab…`);
            const ok = await probe(identity);
            respond(ok ? `  ✓ ${identity} tab connected` : `  ✗ ${identity} tab not found — open ${identity} in browser with Guardian`, ok ? 'info' : 'warn');
          } catch (e) { respond(`  probe failed: ${e.message}`, 'error'); }
          break;
        }
      }
      respond(`  agent: ollama [status|ping|catalog|model] | guardian [status|probe]`, 'warn');
      break;
    }

    case 'debug': {
      if (args[0] === 'list') {
        bus.emit('ide:debug:component:toggle', { action: 'list', ts: Date.now() });
        respond('  debug list sent to UI');
        break;
      }
      const compId = args[0];
      const state  = args[1];
      if (!compId || !state) { respond('  usage: debug <componentId> <active|debug|isolated|disabled>', 'warn'); break; }
      bus.emit('ide:debug:component:toggle', { componentId: compId, state, ts: Date.now() });
      respond(`  ✓ ${compId} → ${state}`);
      break;
    }

    case 'drop': {
      const enabled = args[0] !== 'disable';
      bus.emit('ide:drop:toggle', { enabled, ts: Date.now() });
      respond(`  drag+drop ${enabled ? 'enabled' : 'disabled'}`);
      break;
    }

    case 'modules': {
      try {
        const { getRegistry } = await import(join(ROOT, 'plugins', 'plugin-loader.js'));
        const reg = getRegistry();
        const entries = Object.values(reg);
        if (!entries.length) { respond('  no modules loaded'); break; }
        respond('\n' + entries.map(m =>
          `  phase${m.bootPhase}  ${m.moduleId.padEnd(20)} v${m.version}  ${m.status?.ok ? '✓' : '✗'}  ${m.hooks} hooks`
        ).join('\n'));
      } catch (e) { respond(`  plugin-loader error: ${e.message}`, 'error'); }
      break;
    }

    case 'jaa': {
      const tables = await jaa.tables();
      const stats  = await Promise.all(tables.map(async t => [t, await jaa.count(t)]));
      respond('\n' + stats.map(([t,n]) => `  ${t.padEnd(25)} ${n}`).join('\n'));
      break;
    }

    case 'spec': {
      const specPath = join(ROOT, 'spec', 'rheon.spec');
      if (!existsSync(specPath)) { respond('  spec not yet generated — will be created on next module load'); break; }
      const stat = (await import('fs')).statSync(specPath);
      respond(`  spec/rheon.spec — ${stat.size} bytes, ${new Date(stat.mtimeMs).toISOString()}`);
      break;
    }

    case 'connect': {
      bus.emit('ide:kernel:reconnect', { ts: Date.now() });
      respond('  reconnect signal sent to kernel-bridge');
      break;
    }

    case '':
    case undefined:
      respond('  type help for commands');
      break;

    default:
      respond(`  unknown command: "${cmd}" — type help`, 'warn');
  }
}

// ── Toast emitter — §1.2 failure modes surface to UI ─────────────────────────
function toast(message, type = 'info') {
  // type: info | success | warn | error
  bus?.emit('ide:toast', { message, type, ts: Date.now() });
  log(type === 'error' ? 'error' : type === 'warn' ? 'warn' : 'info', `[toast:${type}]`, message);
}

// ── Boot sequence ─────────────────────────────────────────────────────────────
export async function boot() {
  console.log('\n');
  console.log('  ╔═══════════════════════════════════════════════════╗');
  console.log(`  ║  RHEON IDE v${VERSION}                              ║`);
  console.log('  ║  Seam language IDE + constraint field engine       ║');
  console.log('  ╚═══════════════════════════════════════════════════╝');
  console.log('');
  console.log(`  Starting on port ${PORT}…`);
  console.log(`  UUID: ${UUID}`);
  console.log('');

  // Phase 0: Core
  await loadCore();

  // Phase 1: Jaa
  await openJaa();

  // Wire boot-time bus event logging
  bus.on('core:boot:start',     (ev) => log('step', 'Core boot start',    `v${ev.payload.version}`));
  bus.on('core:jaa:ready',      ()   => log('ok',   'Jaa ready'));
  bus.on('core:ready',          ()   => log('ok',   'Core ready'));
  bus.on('ide:server:error',    (ev) => log('error','Server error',        ev.payload.error));
  bus.on('ide:toast',           (ev) => {}); // handled by toast() above

  // Phase 2: Spec engine
  await startSpecEngine();

  // Phase 3: Modules
  const registry = await bootModules();

  // Phase 4: Probe optional services (non-blocking)
  _probeServices().catch(() => {});

  // Phase 5: HTTP + WS
  await new Promise((resolve, reject) => {
    httpServer.listen(PORT, HOST, (err) => {
      if (err) { reject(err); return; }
      resolve();
    });
    httpServer.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        log('error', `Port ${PORT} already in use`, `Kill the process using port ${PORT} or set IDE_PORT=<other>`);
        toast(`Port ${PORT} in use — set IDE_PORT env var`, 'error');
      } else {
        log('error', 'HTTP server error', err.message);
      }
      reject(err);
    });
  });

  // Record session in Jaa (§2.1)
  await jaa.insert('ide_sessions', {
    uuid:      randomUUID(),
    startTs:   Date.now(),
    port:      PORT,
    version:   VERSION,
    modules:   Object.keys(registry).length,
  });

  await jaa.upgradeEntry('Server started', `IDE v${VERSION} on port ${PORT}`, { phase: 9 });

  console.log('');
  console.log(`  ✓ http://localhost:${PORT}`);
  console.log(`  ✓ ws://localhost:${PORT}/ws`);
  console.log(`  ✓ SSE:  http://localhost:${PORT}/api/bus/stream`);
  console.log(`  ✓ API:  http://localhost:${PORT}/health`);
  console.log('');
  console.log('  Seam kernel words: make show add tension constrain');
  console.log('  gap emit watch find define fill field');
  console.log('');
  console.log('  Drag a .zip onto the browser window to install a module');
  console.log('  Type Ctrl+C to stop');
  console.log('');

  bus.emit('ide:kernel:status', { version: VERSION, port: PORT, ts: Date.now() });
  toast('Rheon IDE started', 'success');

  // Shutdown handlers
  const shutdown = (signal) => {
    console.log(`\n  [${signal}] Shutting down…`);
    httpServer.close();
    exit(0);
  };
  process.on('SIGINT',  () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

// ── Service probing — connect to optional services, report all states ─────────
async function _probeServices() {
  log('step', 'Probing optional services…');

  // Rheon Kernel
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 2000);
    const r = await fetch(`http://localhost:7749/api/session`, { signal: ctrl.signal });
    if (r.ok) {
      log('ok',   'Rheon Kernel', 'ws://localhost:7749/ws connected');
      toast('Rheon Kernel connected', 'success');
    } else {
      log('warn', 'Rheon Kernel', `HTTP ${r.status} — kernel may be starting up`);
      toast(`Kernel responded HTTP ${r.status}`, 'warn');
    }
  } catch {
    log('info', 'Rheon Kernel', 'not running — start kernel for Seam expression submission');
    toast('Rheon Kernel not found — start with: node index.js (from kernel dir)', 'warn');
  }

  // Ollama
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 2000);
    const r = await fetch('http://localhost:11434/api/tags', { signal: ctrl.signal });
    if (r.ok) {
      const data = await r.json();
      const count = (data.models || []).length;
      log('ok',   'Ollama', `${count} models installed`);
      toast(`Ollama connected — ${count} models available`, 'success');
      // Tell ollama-agent to refresh
      bus.emit('ide:agent:ollama:request:ping', { ts: Date.now() });
    }
  } catch {
    log('info', 'Ollama', 'not running — start with: ollama serve');
    toast('Ollama not found — install from ollama.ai', 'info');
  }

  // Guardian bridge
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 2000);
    const r = await fetch('http://127.0.0.1:7820/health', { signal: ctrl.signal });
    if (r.ok) {
      log('ok',   'Guardian bridge', 'http://127.0.0.1:7820');
      toast('Guardian bridge connected', 'success');
    }
  } catch {
    log('info', 'Guardian bridge', 'not running — start Guardian Firefox extension');
    toast('Guardian not found — open Firefox with Guardian extension', 'info');
  }
}

// ── Entry point ───────────────────────────────────────────────────────────────
const isMain = process.argv[1] &&
  (resolve(process.argv[1]).replace(/\\/g, '/') === __filename.replace(/\\/g, '/') ||
   resolve(process.argv[1]).replace(/\\/g, '/') === resolve(join(ROOT, 'index.js')).replace(/\\/g, '/'));

if (isMain) {
  boot().catch(err => {
    log('error', 'FATAL boot error', err.message);
    console.error(err.stack);
    exit(1);
  });
}

export { httpServer, boot, toast, VERSION, UUID };
