import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };
let _bus, _jaa, _unsubs = [];

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  // Refresh grammar on kernel connect
  _unsubs.push(_bus.on('ide:kernel:connected', async () => {
    const words = await _jaa.getGrammarWords();
    _bus.emit('ide:grammar:words:updated', { words, ts: Date.now() });
  }));

  // Learn from seam submissions
  _unsubs.push(_bus.on('ide:seam:submitted', async (ev) => {
    const { constraints } = ev.payload;
    if (!constraints?.length) return;
    const words = await _jaa.getGrammarWords();
    _bus.emit('ide:grammar:words:updated', { words, ts: Date.now() });
  }));

  // Initial load
  const words = await _jaa.getGrammarWords();
  if (words.length) _bus.emit('ide:grammar:words:updated', { words, ts: Date.now() });

  return unregister;
}

export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}

export function status() {
  return { ok: true, version: MANIFEST.version };
}
