/**
 * modules/snr-passthrough/index.js
 * @module  snr-passthrough
 * @uuid    bb000007-0000-4000-8000-000000000007
 * @version 3.0.0
 * @phase   4
 * @axioms  §1.2 §5.7 §5.8
 *
 * SNR signal quality pipeline.
 * Plugin-based: each plugin in modules/snr-passthrough/plugins/ is a
 * processor in the chain. Matches SNR passthrough architecture from snr-passthrough.zip.
 *
 * Signal flow: emit('ide:snr:signal', { payload, meta }) →
 *   → chain of plugins (each can pass/drop/tag) →
 *   → ide:snr:signal:passed or ide:snr:signal:dropped
 *
 * Built-in plugins (always active):
 *   01-gate:       drops signals with snrScore < threshold
 *   02-tagger:     tags signal with domain + source
 *   03-field-inject: injects field context into agent calls
 */

import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [];

// ── Built-in pipeline ────────────────────────────────────────────────────────
const _pipeline = [

  // Gate: drop low-quality signals
  {
    name:    'snr-gate',
    enabled: true,
    config:  { minScore: 0.3 },
    process(signal) {
      const score = signal.meta?.snrScore;
      if (score !== null && score !== undefined && score < this.config.minScore) {
        this._lastDropReason = `snrScore ${score.toFixed(2)} < threshold ${this.config.minScore}`;
        return null;
      }
      return signal;
    },
  },

  // Tagger: add domain tag from meta
  {
    name:    'tagger',
    enabled: true,
    process(signal) {
      signal.meta.tags = signal.meta.tags || [];
      if (signal.meta.source && !signal.meta.tags.includes(signal.meta.source)) {
        signal.meta.tags.push(signal.meta.source);
      }
      if (signal.meta.topic && !signal.meta.tags.includes(signal.meta.topic)) {
        signal.meta.tags.push(signal.meta.topic);
      }
      signal.meta.passed  = true;
      signal.meta.pipedAt = Date.now();
      return signal;
    },
  },

  // Context injector: adds field state to agent call signals
  {
    name:    'field-inject',
    enabled: true,
    _fieldState: null,
    process(signal) {
      if (signal.meta.topic === 'agent:call' && this._fieldState) {
        signal.meta.fieldContext = {
          constraints: this._fieldState.constraints?.slice(-3) || [],
          gaps:        this._fieldState.gaps?.filter(g => !g.resolved)?.slice(-3) || [],
          bepStage:    this._fieldState.bepStage || null,
        };
      }
      return signal;
    },
  },

];

// ── Pipeline runner ──────────────────────────────────────────────────────────
async function run(signal) {
  let s = signal;
  for (const plugin of _pipeline) {
    if (!plugin.enabled) continue;
    try {
      const result = await plugin.process(s);
      if (result === null || result === false) {
        s.meta.passed = false;
        s.meta.drop   = { plugin: plugin.name, reason: plugin._lastDropReason || 'filtered', ts: Date.now() };
        s.history = s.history || [];
        s.history.push({ plugin: plugin.name, action: 'drop', ts: Date.now() });
        _bus?.emit('ide:snr:signal:dropped', { uuid: s.uuid, plugin: plugin.name, topic: s.meta?.topic, ts: Date.now() });
        _jaa?.insert('snr_signals', { ...s, dropped: true }).catch(() => {});
        return s;
      }
      s = result;
      s.history = s.history || [];
      s.history.push({ plugin: plugin.name, action: 'pass', ts: Date.now() });
    } catch (err) {
      s.history = s.history || [];
      s.history.push({ plugin: plugin.name, action: 'error', note: err.message, ts: Date.now() });
      // §1.2: error is logged but signal continues
    }
  }
  s.meta.passed = true;
  _bus?.emit('ide:snr:signal:passed', { uuid: s.uuid, tags: s.meta.tags, topic: s.meta.topic, ts: Date.now() });
  _jaa?.insert('snr_signals', { ...s, dropped: false }).catch(() => {});
  return s;
}

// ── register() ───────────────────────────────────────────────────────────────
export async function register(busInstance, jaaInstance) {
  _bus = busInstance;
  _jaa = jaaInstance;

  // Process incoming signals
  _unsubs.push(
    _bus.on('ide:snr:signal', async (ev) => {
      const signal = {
        uuid:    ev.id,
        ts:      ev.wall,
        payload: ev.payload.payload || ev.payload,
        meta: {
          source:    ev.payload.source    || 'bus',
          topic:     ev.payload.topic     || 'default',
          tags:      ev.payload.tags      ? [...ev.payload.tags] : [],
          snrScore:  ev.payload.snrScore  ?? null,
          passed:    true,
          drop:      null,
          loopDepth: 0,
        },
        history: [],
      };
      await run(signal);
    }),

    // Track field state for context injection
    _bus.on('ide:field:updated', (ev) => {
      const injector = _pipeline.find(p => p.name === 'field-inject');
      if (injector) injector._fieldState = ev.payload;
    }),
  );

  return unregister;
}

export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}

export function status() {
  return {
    ok:       true,
    plugins:  _pipeline.map(p => ({ name: p.name, enabled: p.enabled })),
    version:  MANIFEST.version,
  };
}

// Expose pipeline for external configuration
export function setPipelinePluginEnabled(name, enabled) {
  const p = _pipeline.find(p => p.name === name);
  if (!p) return false;
  p.enabled = enabled;
  _bus?.emit('ide:toast', { message: `SNR plugin ${name}: ${enabled ? 'enabled' : 'disabled'}`, type: 'info', ts: Date.now() });
  return true;
}
