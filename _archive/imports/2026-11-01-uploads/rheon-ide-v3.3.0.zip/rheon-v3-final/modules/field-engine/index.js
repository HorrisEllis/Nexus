import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };
let _bus, _jaa, _unsubs = [];
const _field = { constraints: [], gaps: [], threads: [], nodes: [], bepStage: null };

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  _unsubs.push(
    _bus.on('ide:seam:parsed', (ev) => {
      const { constraints, gaps } = ev.payload;
      _field.constraints.push(...(constraints || []));
      _field.gaps.push(...(gaps || []));
      if (_field.constraints.length > MANIFEST.config.maxConstraints) _field.constraints.splice(0, _field.constraints.length - MANIFEST.config.maxConstraints);
      _emit();
    }),
    _bus.on('ide:kernel:node:committed', (ev) => {
      _field.nodes.push(ev.payload);
      if (_field.nodes.length > 200) _field.nodes.shift();
      _emit();
    }),
    _bus.on('ide:kernel:gap:opened', (ev) => {
      _field.gaps.push({ ...ev.payload, source: 'kernel' });
      _bus.emit('ide:field:gaps:updated', { gaps: _field.gaps.filter(g => !g.resolved), ts: Date.now() });
    }),
    _bus.on('ide:kernel:bep:signal', (ev) => {
      if (ev.payload.type === 'FOCAL_STAGE') _field.bepStage = ev.payload.stage;
      _emit();
    }),
  );
  return unregister;
}

function _emit() {
  _bus.emit('ide:field:updated', {
    constraints: _field.constraints.slice(-50),
    gaps:        _field.gaps.filter(g => !g.resolved),
    threads:     _field.threads,
    nodes:       _field.nodes.slice(-20),
    bepStage:    _field.bepStage,
    ts:          Date.now(),
  });
}

export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}
export function status() { return { ok: true, constraints: _field.constraints.length, gaps: _field.gaps.length }; }
