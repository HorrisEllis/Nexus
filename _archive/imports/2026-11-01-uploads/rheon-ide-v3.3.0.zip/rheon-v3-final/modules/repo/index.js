/**
 * modules/repo/index.js
 * @module  repo  @uuid bb000010-0000-4000-8000-000000000010
 * @version 3.0.0  @phase 7
 *
 * Git operations via kernel CLI bridge.
 * push/pull/commit/status/SSH.
 * All operations persisted to Jaa repo_history (§2.1).
 * File read/write exposed for IDE file editor.
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [], _repoPath = null, _sshKey = null;

async function _git(cmd, cwd) {
  try {
    const url = _sshKey
      ? `http://localhost:7749/bridge/cli`
      : `http://localhost:7749/bridge/cli`;
    const r = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: `git ${cmd}`, cwd: cwd || _repoPath }),
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const data = await r.json().catch(() => ({}));
    return { ok: data.code === 0, stdout: data.stdout || '', stderr: data.stderr || '', code: data.code };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function _gitOp(operation, cmd, successChannel, errorMsg) {
  _bus?.emit('ide:console:cli:response', { text: `  git ${cmd}…`, level: 'info', ts: Date.now() });
  const result = await _git(cmd);
  await _jaa?.insert('repo_history', { operation, command: `git ${cmd}`, result: result.ok ? 'success' : 'error', output: (result.stdout || result.error || '').slice(0,500), ts: Date.now() });
  if (result.ok) {
    _bus?.emit(successChannel, { output: result.stdout, ts: Date.now() });
    _bus?.emit('ide:toast', { message: `✓ git ${operation}`, type: 'success', ts: Date.now() });
  } else {
    _bus?.emit('ide:console:cli:response', { text: `  ✗ git ${operation}: ${result.stderr || result.error}`, level: 'error', ts: Date.now() });
    _bus?.emit('ide:toast', { message: `git ${operation} failed: ${(result.stderr || result.error || '').slice(0,60)}`, type: 'error', ts: Date.now() });
  }
  return result;
}

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;
  _unsubs.push(
    _bus.on('ide:repo:status',  async (ev) => { _repoPath = ev.payload.path || _repoPath; await _gitOp('status', 'status --short', 'ide:repo:status', 'status failed'); }),
    _bus.on('ide:repo:push',    async (ev) => { _repoPath = ev.payload.path || _repoPath; const branch = ev.payload.branch || 'main'; await _gitOp('push', `push origin ${branch}`, 'ide:repo:pushed', 'push failed'); }),
    _bus.on('ide:repo:pull',    async (ev) => { _repoPath = ev.payload.path || _repoPath; await _gitOp('pull', 'pull --rebase', 'ide:repo:pulled', 'pull failed'); }),
    _bus.on('ide:repo:commit',  async (ev) => { _repoPath = ev.payload.path || _repoPath; const msg = ev.payload.message || 'rheon ide commit'; await _gitOp('commit', `commit -am "${msg.replace(/"/g,"'")}"`, 'ide:repo:committed', 'commit failed'); }),
    _bus.on('ide:repo:file:content', async (ev) => {
      // Read file content for editor
      try {
        const r = await fetch(`http://localhost:7749/bridge/file?path=${encodeURIComponent(ev.payload.path)}`, { signal: AbortSignal.timeout(5000) });
        if (r.ok) { const text = await r.text(); _bus.emit('ide:repo:file:content', { path: ev.payload.path, content: text, ts: Date.now() }); }
        else _bus.emit('ide:toast', { message: `Cannot read file: ${ev.payload.path}`, type: 'error', ts: Date.now() });
      } catch (e) { _bus.emit('ide:toast', { message: `File read error: ${e.message}`, type: 'error', ts: Date.now() }); }
    }),
  );
  return unregister;
}

export async function unregister() { _unsubs.forEach(fn => { try { fn(); } catch {} }); _unsubs = []; _bus = null; _jaa = null; }
export function status() { return { ok: true, repoPath: _repoPath, version: MANIFEST.version }; }
