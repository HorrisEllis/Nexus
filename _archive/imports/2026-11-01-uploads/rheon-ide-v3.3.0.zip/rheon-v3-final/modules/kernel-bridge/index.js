/**
 * modules/kernel-bridge/index.js
 * @module  kernel-bridge
 * @uuid    bb000002-0000-4000-8000-000000000002
 * @version 3.0.0
 * @phase   2
 * @axioms  §1.1 §1.2 §2.1 §5.2 §5.7
 *
 * WebSocket bridge to Rheon Kernel (ws://localhost:7749/ws)
 *
 * §1.2: Every connection state change is logged and toasted.
 *       Every kernel message is routed or logged.
 *       Nothing is swallowed silently.
 *
 * §2.1: Every kernel event is written to Jaa BEFORE emitting on bus.
 *       Callers never act on unverified data.
 */

import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

const IS_NODE = typeof process !== 'undefined' && process.versions?.node;
const CFG     = { ...MANIFEST.config };

let _bus, _jaa, _unsubs = [];
let _ws          = null;
let _connected   = false;
let _sessionId   = null;
let _retries     = 0;
let _delay       = CFG.reconnectBase || 1000;
let _reconnTimer = null;
let _heartbeat   = null;
let _seq         = 0;

// ── register() ────────────────────────────────────────────────────────────────
export async function register(busInstance, jaaInstance) {
  _bus = busInstance;
  _jaa = jaaInstance;

  // §2.1: write session record before connecting
  const session = await _jaa.insert('sessions', {
    kernelUrl: CFG.url,
    status:    'connecting',
    startTs:   Date.now(),
  }).catch(() => ({ uuid: 'fallback-' + Date.now() }));
  _sessionId = session.uuid;

  _toast(`Connecting to Rheon Kernel…`, 'info');
  _connect();

  // Editor submissions → kernel
  _unsubs.push(
    _bus.on('ide:editor:submit', async (ev) => {
      const { text, domain } = ev.payload;
      if (!_connected) {
        _toast('Cannot submit — kernel not connected', 'warn');
        _bus.emit('ide:console:cli:response', { text: '  ✗ kernel not connected — cannot submit', level: 'error', ts: Date.now() });
        return;
      }
      _kernelSend('domain:set', { domain: domain || 'seam' });
      // §2.1: Jaa write before kernel send
      await _jaa.insert('nodes', {
        text, domain: domain || 'seam',
        sessionId: _sessionId, status: 'pending', ts: Date.now(),
      }).catch(() => {});
      _kernelSend('record:start', {});
    }),

    _bus.on('ide:kernel:buffer:flush', () => {
      if (!_connected) { _toast('Cannot flush — kernel not connected', 'warn'); return; }
      _kernelSend('buffer:flush', {});
      _bus.emit('ide:console:cli:response', { text: '  buffer flush sent', level: 'info', ts: Date.now() });
    }),

    _bus.on('ide:kernel:reconnect', () => {
      _bus.emit('ide:console:cli:response', { text: '  reconnecting to kernel…', level: 'info', ts: Date.now() });
      _disconnect();
      setTimeout(_connect, 100);
    }),
  );

  return unregister;
}

// ── unregister() ──────────────────────────────────────────────────────────────
export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = [];
  _disconnect();
  _bus = null; _jaa = null;
}

// ── status() ─────────────────────────────────────────────────────────────────
export function status() {
  return {
    ok:        _connected,
    connected: _connected,
    sessionId: _sessionId,
    url:       CFG.url,
    retries:   _retries,
    seq:       _seq,
  };
}

// ── Connection ────────────────────────────────────────────────────────────────
function _connect() {
  if (!IS_NODE && typeof WebSocket === 'undefined') {
    _toast('WebSocket not available', 'error'); return;
  }

  const WSClass = IS_NODE ? _nodeWebSocket() : WebSocket;
  if (!WSClass) return;

  let ws;
  try { ws = new WSClass(CFG.url); }
  catch (e) { _scheduleReconnect(`connect error: ${e.message}`); return; }

  ws.onopen = async () => {
    _ws        = ws;
    _connected = true;
    _retries   = 0;
    _delay     = CFG.reconnectBase || 1000;
    clearTimeout(_reconnTimer);

    _bus?.emit('ide:kernel:connected', { url: CFG.url, sessionId: _sessionId, ts: Date.now() });
    _toast('Rheon Kernel connected', 'success');
    _log(`✓ Kernel connected at ${CFG.url}`);

    await _jaa?.update('sessions', _sessionId, { status: 'connected', connectedAt: Date.now() }).catch(() => {});

    // Heartbeat
    _heartbeat = setInterval(() => {
      if (_connected) _kernelSend('heartbeat', { clientTs: Date.now() });
    }, CFG.heartbeatMs || 30000);
  };

  ws.onmessage = async (ev) => {
    let msg;
    try { msg = JSON.parse(typeof ev.data === 'string' ? ev.data : ev.data.toString()); }
    catch (e) { _log(`WS parse error: ${e.message}`, 'warn'); return; }
    await _route(msg);
  };

  ws.onerror = (e) => {
    // onclose fires after — don't double-log
  };

  ws.onclose = async (ev) => {
    clearInterval(_heartbeat);
    if (_connected) {
      _connected = false;
      _ws = null;
      _bus?.emit('ide:kernel:disconnected', { url: CFG.url, code: ev?.code, reason: ev?.reason, ts: Date.now() });
      _toast(`Kernel disconnected${ev?.reason ? ': ' + ev.reason : ''}`, 'warn');
      await _jaa?.update('sessions', _sessionId, { status: 'disconnected', disconnectedAt: Date.now() }).catch(() => {});
    }
    _ws = null;
    _scheduleReconnect(`connection closed (code ${ev?.code || '?'})`);
  };
}

function _nodeWebSocket() {
  // Node 22+ has built-in WebSocket as globalThis.WebSocket (no import needed)
  if (typeof globalThis.WebSocket !== 'undefined') return globalThis.WebSocket;
  // Node < 22: WebSocket not built in — need 'ws' package
  _toast('WebSocket not available — Node 22+ required, or run: npm install ws', 'error');
  return null;
}

function _disconnect() {
  clearInterval(_heartbeat);
  clearTimeout(_reconnTimer);
  try { _ws?.close(); } catch {}
  _ws = null; _connected = false;
}

function _scheduleReconnect(reason) {
  const d = _delay;
  _delay  = Math.min(_delay * 2, CFG.reconnectMax || 16000);
  _retries++;

  _bus?.emit('ide:kernel:reconnecting', { delay: d, retries: _retries, reason, ts: Date.now() });
  _reconnTimer = setTimeout(_connect, d);
}

function _kernelSend(type, payload) {
  if (!_connected || !_ws) return false;
  try {
    _ws.send(JSON.stringify({ v: '1.0.0', type, seq: ++_seq, ts: Date.now(), payload: payload || {} }));
    return true;
  } catch (e) {
    _log(`kernel send failed: ${e.message}`, 'warn');
    return false;
  }
}

// ── Kernel message router ─────────────────────────────────────────────────────
async function _route(msg) {
  const payload = msg.payload || {};
  const ts      = msg.ts || Date.now();

  switch (msg.type) {
    case 'kernel:handshake': {
      _sessionId = payload.sessionId || _sessionId;
      await _jaa?.update('sessions', _sessionId, {
        kernelSessionId: payload.sessionId,
        kernelVersion:   payload.version,
      }).catch(() => {});
      _bus?.emit('ide:kernel:status', { ...payload, connected: true, ts });
      _log(`Kernel handshake: v${payload.version || '?'} session:${(payload.sessionId||'?').slice(0,8)}`);
      break;
    }

    case 'node:committed': {
      // §2.1: write before emitting
      await _jaa?.insert('nodes', { ...payload, source: 'kernel', sessionId: _sessionId, ts }).catch(() => {});
      _bus?.emit('ide:kernel:node:committed', { ...payload, ts });
      break;
    }

    case 'node:mirror': {
      _bus?.emit('ide:kernel:node:mirror', { ...payload, ts });
      break;
    }

    case 'gap:opened': {
      await _jaa?.insert('gaps', { ...payload, source: 'kernel', status: 'open', sessionId: _sessionId, ts }).catch(() => {});
      _bus?.emit('ide:kernel:gap:opened', { ...payload, ts });
      break;
    }

    case 'bep:signal': {
      await _jaa?.insert('bep_signals', { ...payload, sessionId: _sessionId, ts }).catch(() => {});
      _bus?.emit('ide:kernel:bep:signal', { ...payload, ts });
      break;
    }

    case 'kernel:status': {
      _bus?.emit('ide:kernel:status', { ...payload, connected: true, ts });
      break;
    }

    case 'buffer:status': {
      _bus?.emit('ide:kernel:buffer:status', { ...payload, ts });
      if (payload.stuck) {
        _toast(`Buffer stuck for ${payload.stalledMs}ms — run: ide buffer flush`, 'error');
        _log(`⚠ Buffer stuck ${payload.stalledMs}ms`, 'warn');
      }
      break;
    }

    case 'error': {
      // §1.2: kernel errors are loud
      _toast(`Kernel error: ${payload.message || JSON.stringify(payload)}`, 'error');
      _log(`Kernel error: ${payload.message || JSON.stringify(payload)}`, 'error');
      _bus?.emit('ide:console:cli:response', { text: `  ✗ kernel: ${payload.message}`, level: 'error', ts: Date.now() });
      break;
    }

    default: {
      // Forward all other events to console stream
      _bus?.emit('ide:console:bus:event', { type: msg.type, payload, ts });
      break;
    }
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _toast(message, type = 'info') {
  _bus?.emit('ide:toast', { message, type, ts: Date.now() });
}

function _log(message, level = 'info') {
  _bus?.emit('ide:console:cli:response', { text: `  [kernel-bridge] ${message}`, level, ts: Date.now() });
}
