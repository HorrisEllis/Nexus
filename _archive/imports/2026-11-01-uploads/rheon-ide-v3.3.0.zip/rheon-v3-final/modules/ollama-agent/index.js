/**
 * modules/ollama-agent/index.js
 * @module      ollama-agent
 * @uuid        bb000001-0000-4000-8000-000000000001
 * @version     3.0.0
 * @phase       4 — AGENTS
 * @axioms      §1.1 §1.2 §2.1 §5.1 §5.7
 *
 * Implements MODULE_ENTRY_CONTRACT: register(), unregister(), status(), MANIFEST
 */

'use strict';

import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

import {
  CATALOG, getDefault, findModel, reconcileWithInstalled,
  getViableModels, RUN_MODE
} from './catalog.js';

// ── Module state ──────────────────────────────────────────────────────────────
let _bus, _jaa;
let _installed   = [];
let _active      = null;
let _status      = 'idle';
let _lastPingTs  = 0;
let _unsubs      = [];

const CFG = { ...MANIFEST.config };

// ── register() ────────────────────────────────────────────────────────────────
export async function register(busInstance, jaaInstance) {
  _bus = busInstance;
  _jaa = jaaInstance;
  _active = getDefault();

  // Subscribe to request events (§5.7 — UI never calls module directly)
  _unsubs.push(
    _bus.on('ide:agent:ollama:request:ping', async () => { await ping(); }),
    _bus.on('ide:agent:ollama:request:catalog', async () => { _emitCatalog(); }),
    _bus.on('ide:agent:ollama:request:model', async (ev) => {
      if (ev.payload.model) setModel(ev.payload.model);
    }),
    _bus.on('ide:agent:ollama:request:complete', async (ev) => {
      if (ev.payload.prompt) {
        await complete({ ...ev.payload, causedBy: ev.id }).catch(e => {
          _bus.emit('ide:agent:error', { agentId: 'ollama', error: e.message, ts: Date.now() });
        });
      }
    }),
  );

  // Initial ping (§1.1 — don't claim available until proven)
  await ping();

  return unregister; // return cleanup function
}

// ── unregister() ─────────────────────────────────────────────────────────────
export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = [];
  _bus = null; _jaa = null;
}

// ── status() ─────────────────────────────────────────────────────────────────
export function status() {
  return {
    ok:          _status !== 'unavailable',
    status:      _status,
    activeModel: _active?.id || null,
    baseUrl:     CFG.baseUrl,
    lastPingTs:  _lastPingTs,
    installed:   _installed.length,
    details:     { version: MANIFEST.version, uuid: MANIFEST.uuid },
  };
}

// ── Core functions ────────────────────────────────────────────────────────────
export async function ping() {
  try {
    const r = await _fetchOllama('/api/tags', { timeout: 3000 });
    if (!r.ok) { _setStatus('unavailable'); return false; }
    const data = await r.json();
    _installed = data.models || [];
    _setStatus('idle');
    _lastPingTs = Date.now();
    _emitCatalog();
    return true;
  } catch (e) {
    _setStatus('unavailable');
    _bus?.emit('ide:agent:error', {
      agentId: 'ollama',
      error:   `Ollama unreachable at ${CFG.baseUrl}: ${e.message}`,
      ts:      Date.now(),
    });
    return false;
  }
}

export function setModel(modelIdOrPull) {
  const found = findModel(modelIdOrPull);
  if (!found) {
    _bus?.emit('ide:agent:error', {
      agentId: 'ollama',
      error:   `Model not in catalog: "${modelIdOrPull}". Run: ide agent ollama catalog`,
      ts:      Date.now(),
    });
    return false;
  }
  if (found.runMode === RUN_MODE.NOT_VIABLE) {
    _bus?.emit('ide:agent:error', {
      agentId: 'ollama',
      error:   `${found.name} is NOT_VIABLE on this hardware. ${found.notes}`,
      ts:      Date.now(),
    });
    return false;
  }
  _active = found;
  _emitCatalog();
  return true;
}

export async function complete(opts = {}) {
  const { prompt, model = _active?.pull || getDefault().pull,
    temperature = 0.15, maxTokens = CFG.numCtx,
    taskType = 'general', causedBy = null } = opts;

  if (!prompt) throw new Error('[ollama-agent] prompt is required');

  _setStatus('busy');
  const callId = _uid();
  const t0 = Date.now();

  // §2.1 persist before act
  await _jaa?.insertAgentCall({ uuid: callId, agentId: 'ollama', prompt, model, status: 'pending', taskType });

  _bus?.emit('ide:agent:request', { callId, agentId: 'ollama', model, taskType,
    tokens: Math.ceil(prompt.length / 3.8), causedBy, ts: Date.now() });

  try {
    const r = await _fetchOllama('/api/generate', {
      method: 'POST',
      body: JSON.stringify({
        model, prompt, stream: false,
        options: { temperature, top_p: 0.92, num_ctx: maxTokens,
          num_thread: CFG.numThreads, repeat_penalty: 1.1 },
      }),
    });
    if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
    const data    = await r.json();
    const content = data.response || '';
    const latency = Date.now() - t0;

    await _jaa?.update('agent_calls', callId, { status: 'complete', response: content.slice(0,1000), latencyMs: latency });
    _setStatus('idle');
    _bus?.emit('ide:agent:response', { callId, agentId: 'ollama', content, model, latencyMs: latency, taskType, ts: Date.now() });
    return content;
  } catch (e) {
    _setStatus('error');
    await _jaa?.update('agent_calls', callId, { status: 'error', error: e.message });
    _bus?.emit('ide:agent:error', { callId, agentId: 'ollama', error: e.message, model, taskType, ts: Date.now() });
    throw e;
  }
}

export async function stream(opts = {}) {
  const { prompt, model = _active?.pull || getDefault().pull,
    temperature = 0.15, onChunk, taskType = 'general',
    signal, causedBy = null } = opts;

  if (!prompt) throw new Error('[ollama-agent] prompt is required');
  if (!onChunk) throw new Error('[ollama-agent] onChunk callback required for stream()');

  _setStatus('busy');
  const callId = _uid();
  const t0 = Date.now();

  await _jaa?.insertAgentCall({ uuid: callId, agentId: 'ollama', prompt, model, status: 'streaming', taskType });
  _bus?.emit('ide:agent:request', { callId, agentId: 'ollama', model, taskType,
    tokens: Math.ceil(prompt.length / 3.8), causedBy, ts: Date.now(), streaming: true });

  try {
    const r = await fetch(`${CFG.baseUrl}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, prompt, stream: true,
        options: { temperature, top_p: 0.92, num_ctx: CFG.numCtx, num_thread: CFG.numThreads } }),
      signal: signal || AbortSignal.timeout(CFG.timeoutMs),
    });
    if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);

    const reader = r.body.getReader(); const dec = new TextDecoder(); let full = '';
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      for (const line of dec.decode(value).split('\n').filter(Boolean)) {
        try { const j = JSON.parse(line); if (j.response) {
          full += j.response; onChunk(j.response);
          _bus?.emit('ide:agent:stream:chunk', { callId, chunk: j.response, agentId: 'ollama', ts: Date.now() });
        }} catch {}
      }
    }

    const latency = Date.now() - t0;
    await _jaa?.update('agent_calls', callId, { status: 'complete', response: full.slice(0,1000), latencyMs: latency });
    _setStatus('idle');
    _bus?.emit('ide:agent:response', { callId, agentId: 'ollama', content: full, model, latencyMs: latency, taskType, ts: Date.now() });
    return full;
  } catch (e) {
    if (e.name !== 'AbortError') {
      _setStatus('error');
      await _jaa?.update('agent_calls', callId, { status: 'error', error: e.message });
      _bus?.emit('ide:agent:error', { callId, agentId: 'ollama', error: e.message, model, taskType, ts: Date.now() });
    }
    throw e;
  }
}

export function getCatalog()  { return reconcileWithInstalled(_installed); }
export function getActiveModel() { return _active; }

// ── Private ───────────────────────────────────────────────────────────────────
function _setStatus(s) {
  _status = s;
  _bus?.emit('ide:agent:ollama:status', { status: s, activeModel: _active?.id, ts: Date.now() });
}

function _emitCatalog() {
  _bus?.emit('ide:agent:ollama:models:updated', {
    models:      reconcileWithInstalled(_installed),
    available:   _status !== 'unavailable',
    activeModel: _active?.id || null,
    installed:   _installed.map(m => m.name),
    ts:          Date.now(),
  });
}

async function _fetchOllama(path, opts = {}) {
  const { timeout = CFG.timeoutMs, ...rest } = opts;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(CFG.baseUrl + path, {
      headers: { 'Content-Type': 'application/json' },
      ...rest,
      signal: ctrl.signal,
    });
    clearTimeout(t); return r;
  } catch (e) { clearTimeout(t); throw e; }
}

function _uid() {
  return typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`;
}
