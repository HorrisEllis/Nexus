/**
 * ollama-agent tests
 * @axioms §4.1 §1.1 §1.2
 *
 * Tests: contract, intent, adversarial, recursive (§5.6)
 */

import { strict as assert } from 'assert';
import { MANIFEST } from '../index.js';
import { CATALOG, getDefault, getViableModels, getByCategory,
         findModel, reconcileWithInstalled, RUN_MODE, HARDWARE, CATEGORY } from '../catalog.js';
import { validateManifest } from '../../../plugins/plugin-schema.js';

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log(`  ✓ ${name}`); }
  catch(e) { fail++; console.error(`  ✗ ${name}: ${e.message}`); }
}

console.log('\n  [ollama-agent] Tests\n');

// CONTRACT: manifest validates
test('MANIFEST passes validateManifest()', () => {
  const { valid, errors } = validateManifest(MANIFEST);
  assert.ok(valid, `Manifest invalid: ${errors.join('; ')}`);
});

test('MANIFEST has all required fields', () => {
  assert.ok(MANIFEST.moduleId);
  assert.ok(MANIFEST.uuid);
  assert.ok(MANIFEST.bootPhase === 4);
  assert.ok(Array.isArray(MANIFEST.emits));
  assert.ok(Array.isArray(MANIFEST.ui_hooks));
});

test('MANIFEST ui_hooks have required fields', () => {
  for (const h of MANIFEST.ui_hooks) {
    assert.ok(h.hookId, `hook missing hookId`);
    assert.ok(h.slot, `hook ${h.hookId} missing slot`);
    assert.ok(h.component, `hook ${h.hookId} missing component`);
    assert.ok(h.label, `hook ${h.hookId} missing label`);
  }
});

// CATALOG: all models have required fields
test('CATALOG: all models have required fields', () => {
  for (const m of CATALOG) {
    assert.ok(m.id,      `missing id`);
    assert.ok(m.pull,    `${m.id} missing pull`);
    assert.ok(m.runMode, `${m.id} missing runMode`);
    assert.ok(Array.isArray(m.categories));
    assert.ok(typeof m.vramGb === 'number');
    assert.ok(typeof m.ramGb  === 'number');
  }
});

// HARDWARE: GPU_ONLY models must fit in VRAM budget
test('GPU_ONLY models within VRAM budget (§4.3 hardware compliance)', () => {
  const violations = CATALOG.filter(m =>
    m.runMode === RUN_MODE.GPU_ONLY && m.vramGb > HARDWARE.usableVramGb
  );
  assert.strictEqual(violations.length, 0,
    `GPU_ONLY models exceed ${HARDWARE.usableVramGb}GB: ${violations.map(m=>m.id).join(', ')}`);
});

// HARDWARE: NOT_VIABLE models excluded from viable list
test('getViableModels() excludes NOT_VIABLE', () => {
  const viable = getViableModels();
  assert.ok(!viable.some(m => m.runMode === RUN_MODE.NOT_VIABLE));
});

// DEFAULT: getDefault() always returns something
test('getDefault() never returns null (§1.1)', () => {
  const def = getDefault();
  assert.ok(def !== null && def !== undefined);
  assert.ok(def.pull);
  assert.ok(def.default === true);
});

// CATEGORY: code models include codellama or deepseek
test('getByCategory(CODE) returns code models', () => {
  const code = getByCategory(CATEGORY.CODE);
  assert.ok(code.length > 0);
  assert.ok(code.every(m => m.categories.includes(CATEGORY.CODE)));
});

// ADVERSARIAL: findModel with unknown returns null (not throws)
test('[adversarial] findModel("unknown-model") returns null', () => {
  const r = findModel('totally-unknown-model-xyz');
  assert.strictEqual(r, null);
});

// ADVERSARIAL: reconcileWithInstalled with empty array
test('[adversarial] reconcileWithInstalled([]) marks all uninstalled', () => {
  const r = reconcileWithInstalled([]);
  assert.ok(r.every(m => !m.installed));
});

// ADVERSARIAL: reconcileWithInstalled with matching model
test('[adversarial] reconcileWithInstalled marks matching model installed', () => {
  const r = reconcileWithInstalled([{ name: 'mistral:7b-instruct-q4_K_M' }]);
  const mistral = r.find(m => m.pull === 'mistral:7b-instruct-q4_K_M');
  assert.ok(mistral, 'mistral must be in catalog');
  assert.ok(mistral.installed, 'must be marked installed');
});

// RECURSIVE §5.6: CATALOG ids are unique
test('CATALOG: all ids unique (§5.1)', () => {
  const seen = new Set();
  for (const m of CATALOG) {
    assert.ok(!seen.has(m.id), `duplicate id: ${m.id}`);
    seen.add(m.id);
  }
});

// RECURSIVE: all pull strings are unique
test('CATALOG: all pull strings unique', () => {
  const seen = new Set();
  for (const m of CATALOG) {
    assert.ok(!seen.has(m.pull), `duplicate pull: ${m.pull}`);
    seen.add(m.pull);
  }
});

console.log(`\n  Results: ${pass} pass, ${fail} fail`);
if (fail > 0) process.exit(1);
