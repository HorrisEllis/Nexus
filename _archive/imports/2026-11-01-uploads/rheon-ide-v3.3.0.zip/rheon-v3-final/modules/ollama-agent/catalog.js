/**
 * RHEON IDE — Ollama Model Catalog v2.0.0
 * @uuid        e5f6a7b8-c9d0-4123-efab-000000000005
 * @axioms      §1.1 §4.3 §5.1 §5.5
 * @phase       5 — AGENTS
 *
 * Hardware profile: AMD R7 3700X (8c/16t) + 16GB RAM + GTX 1650 (4GB VRAM)
 *
 * VRAM BUDGET: GTX 1650 has 4GB VRAM.
 *   ~3.7GB usable after driver overhead.
 *   GPU-accelerated models must fit in 3.7GB.
 *   CPU-only models can use ~12GB RAM (after OS ~4GB).
 *
 * QUANTIZATION KEY:
 *   q4_K_M  — 4-bit, recommended quality/speed tradeoff
 *   q4_K_S  — 4-bit, smaller (faster, slightly lower quality)
 *   q5_K_M  — 5-bit, better quality, more RAM
 *   q8_0    — 8-bit, near-full quality, 2x RAM of q4
 *   f16     — 16-bit float, full quality, requires most RAM
 *
 * SPEED ESTIMATE on R7 3700X:
 *   7B  q4_K_M CPU:  ~8-12 tok/s
 *   13B q4_K_M CPU:  ~4-6  tok/s
 *   7B  q4_K_M GPU:  ~25-40 tok/s (if fits in 4GB)
 *   7B  q5_K_M GPU:  ~20-30 tok/s (tight fit)
 */

'use strict';

// ── Hardware constants ────────────────────────────────────────────────────────
export const HARDWARE = Object.freeze({
  cpu:        'AMD Ryzen 7 3700X',
  cpuThreads: 16,
  ramGb:      16,
  gpu:        'NVIDIA GTX 1650',
  vramGb:     4,
  // Usable budget after OS + Ollama overhead
  usableVramGb: 3.6,
  usableRamGb:  12,
});

// ── Model categories ──────────────────────────────────────────────────────────
export const CATEGORY = Object.freeze({
  CODE:        'code',
  REASONING:   'reasoning',
  CREATIVE:    'creative',
  FAST:        'fast',
  MULTILINGUAL:'multilingual',
  EMBEDDING:   'embedding',
  VISION:      'vision',
  CHAT:        'chat',
  INSTRUCTION: 'instruction',
  SMALL:       'small',       // <3B — very fast on CPU
  MEDIUM:      'medium',      // 3B-7B — good balance
  LARGE:       'large',       // 7B-13B — high quality, slower
  HEAVY:       'heavy',       // 13B+ — CPU only, slow
});

// ── Run mode ──────────────────────────────────────────────────────────────────
export const RUN_MODE = Object.freeze({
  GPU_ONLY:    'gpu_only',    // requires fits in 3.6GB VRAM
  GPU_PREFER:  'gpu_prefer',  // fits with some CPU offload
  CPU_FAST:    'cpu_fast',    // ≤7B q4, ~8 tok/s
  CPU_QUALITY: 'cpu_quality', // 7B-13B q4, ~4 tok/s
  CPU_SLOW:    'cpu_slow',    // 13B+ q4, ~1-2 tok/s, not recommended real-time
  NOT_VIABLE:  'not_viable',  // won't run usably on this hardware
});

// ── Full model catalog ────────────────────────────────────────────────────────
// Each entry: ollama pull name, VRAM/RAM requirement, categories, tags, best-for
export const CATALOG = Object.freeze([

  // ═══════════════════════════════════════════════════════════════════════════
  // TIER 1: GPU-ACCELERATED (fits in 3.6GB VRAM) — RECOMMENDED FOR REAL-TIME
  // ═══════════════════════════════════════════════════════════════════════════

  {
    id:        'mistral:7b-instruct-q4_K_M',
    name:      'Mistral 7B Instruct',
    pull:      'mistral:7b-instruct-q4_K_M',
    family:    'mistral',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    3.5,
    ramGb:     4.5,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 28, cpu: 9 },
    categories:[CATEGORY.INSTRUCTION, CATEGORY.CHAT, CATEGORY.REASONING, CATEGORY.MEDIUM],
    tags:      ['fast', 'balanced', 'instruction-following', 'rheon-default'],
    bestFor:   ['seam parsing', 'gap analysis', 'general assistant', 'code review'],
    notes:     'Rheon IDE default. Best balance of speed + quality on this hardware.',
    default:   true,
  },

  {
    id:        'mistral:7b-instruct-q4_K_S',
    name:      'Mistral 7B Instruct (Small)',
    pull:      'mistral:7b-instruct-q4_K_S',
    family:    'mistral',
    params:    '7B',
    quant:     'q4_K_S',
    vramGb:    3.2,
    ramGb:     4.0,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 32, cpu: 10 },
    categories:[CATEGORY.FAST, CATEGORY.CHAT, CATEGORY.MEDIUM],
    tags:      ['fastest', 'gpu-friendly', 'streaming'],
    bestFor:   ['real-time streaming', 'quick completions', 'voice transcription assist'],
    notes:     'Fastest viable model on GTX 1650. Slight quality reduction vs _M.',
  },

  {
    id:        'phi3:3.8b-mini-instruct-4k-q4_K_M',
    name:      'Phi-3 Mini 3.8B',
    pull:      'phi3:mini-4k-instruct-q4_K_M',
    family:    'phi3',
    params:    '3.8B',
    quant:     'q4_K_M',
    vramGb:    2.2,
    ramGb:     3.0,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 45, cpu: 18 },
    categories:[CATEGORY.FAST, CATEGORY.SMALL, CATEGORY.INSTRUCTION, CATEGORY.REASONING],
    tags:      ['very-fast', 'surprisingly-capable', 'microsoft', 'small-footprint'],
    bestFor:   ['real-time voice assist', 'quick seam suggestions', 'status queries'],
    notes:     'Microsoft Phi-3. Punches above its weight. Fits easily in VRAM.',
  },

  {
    id:        'phi3:3.8b-mini-128k-instruct-q4_K_M',
    name:      'Phi-3 Mini 3.8B (128K context)',
    pull:      'phi3:mini-128k-instruct-q4_K_M',
    family:    'phi3',
    params:    '3.8B',
    quant:     'q4_K_M',
    vramGb:    2.4,
    ramGb:     3.2,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 40, cpu: 16 },
    categories:[CATEGORY.FAST, CATEGORY.SMALL, CATEGORY.REASONING],
    tags:      ['long-context', '128k', 'document-analysis'],
    bestFor:   ['long spec analysis', 'full file review', 'multi-turn conversation'],
    notes:     'Same Phi-3 but with 128K context window. Good for large spec files.',
  },

  {
    id:        'gemma2:2b-instruct-q4_K_M',
    name:      'Gemma 2 2B',
    pull:      'gemma2:2b-instruct-q4_K_M',
    family:    'gemma2',
    params:    '2B',
    quant:     'q4_K_M',
    vramGb:    1.5,
    ramGb:     2.0,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 60, cpu: 25 },
    categories:[CATEGORY.FAST, CATEGORY.SMALL, CATEGORY.CHAT],
    tags:      ['google', 'ultra-fast', 'tiny', 'always-available'],
    bestFor:   ['status messages', 'simple queries', 'always-on assistant'],
    notes:     'Google Gemma 2. Tiny and fast. Good fallback when resources are tight.',
  },

  {
    id:        'qwen2.5:7b-instruct-q4_K_M',
    name:      'Qwen 2.5 7B',
    pull:      'qwen2.5:7b-instruct-q4_K_M',
    family:    'qwen2.5',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    3.5,
    ramGb:     4.5,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 27, cpu: 8 },
    categories:[CATEGORY.CODE, CATEGORY.REASONING, CATEGORY.MULTILINGUAL, CATEGORY.MEDIUM],
    tags:      ['alibaba', 'multilingual', 'strong-coding', 'math'],
    bestFor:   ['code generation', 'mathematical reasoning', 'multilingual tasks', 'seam compilation'],
    notes:     'Strong at code and math. Excellent for Seam → JS compilation tasks.',
  },

  {
    id:        'llama3.2:3b-instruct-q4_K_M',
    name:      'Llama 3.2 3B',
    pull:      'llama3.2:3b-instruct-q4_K_M',
    family:    'llama3.2',
    params:    '3B',
    quant:     'q4_K_M',
    vramGb:    2.0,
    ramGb:     2.8,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 50, cpu: 20 },
    categories:[CATEGORY.FAST, CATEGORY.SMALL, CATEGORY.INSTRUCTION, CATEGORY.CHAT],
    tags:      ['meta', 'fast', 'capable-small', 'rheon-voice'],
    bestFor:   ['voice-to-text post-processing', 'quick gap analysis', 'lightweight mirror'],
    notes:     'Meta Llama 3.2 3B. Great for the LLM mirror in the Rheon Kernel.',
  },

  {
    id:        'deepseek-r1:1.5b-q4_K_M',
    name:      'DeepSeek R1 1.5B',
    pull:      'deepseek-r1:1.5b',
    family:    'deepseek-r1',
    params:    '1.5B',
    quant:     'q4_K_M',
    vramGb:    1.1,
    ramGb:     1.5,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 80, cpu: 35 },
    categories:[CATEGORY.REASONING, CATEGORY.FAST, CATEGORY.SMALL],
    tags:      ['reasoning', 'chain-of-thought', 'ultra-tiny', 'r1'],
    bestFor:   ['constraint reasoning', 'logic checks', 'gap detection reasoning'],
    notes:     'DeepSeek R1 reasoning model at 1.5B. Surprisingly good at structured reasoning.',
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // TIER 2: CPU + PARTIAL GPU (mixed offload) — GOOD QUALITY, MODERATE SPEED
  // ═══════════════════════════════════════════════════════════════════════════

  {
    id:        'mistral:7b-instruct-q5_K_M',
    name:      'Mistral 7B Instruct (Q5)',
    pull:      'mistral:7b-instruct-q5_K_M',
    family:    'mistral',
    params:    '7B',
    quant:     'q5_K_M',
    vramGb:    4.1,  // slightly over — will CPU-offload some layers
    ramGb:     5.0,
    runMode:   RUN_MODE.CPU_FAST,
    tokPerSec: { gpu: null, cpu: 7 },
    categories:[CATEGORY.INSTRUCTION, CATEGORY.CHAT, CATEGORY.MEDIUM],
    tags:      ['higher-quality', 'q5', 'balanced'],
    bestFor:   ['higher quality responses', 'spec generation', 'document writing'],
    notes:     'Q5 quant of Mistral 7B. Higher quality than q4 but runs mostly CPU.',
  },

  {
    id:        'codellama:7b-instruct-q4_K_M',
    name:      'CodeLlama 7B Instruct',
    pull:      'codellama:7b-instruct-q4_K_M',
    family:    'codellama',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    3.5,
    ramGb:     4.5,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 26, cpu: 8 },
    categories:[CATEGORY.CODE, CATEGORY.INSTRUCTION, CATEGORY.MEDIUM],
    tags:      ['meta', 'code-specialized', 'fill-in-middle', 'infill'],
    bestFor:   ['code completion', 'seam-to-js compilation', 'function generation', 'bug fixing'],
    notes:     'Meta CodeLlama fine-tuned on code. Best pure code model for this hardware.',
  },

  {
    id:        'deepseek-coder:6.7b-instruct-q4_K_M',
    name:      'DeepSeek Coder 6.7B',
    pull:      'deepseek-coder:6.7b-instruct-q4_K_M',
    family:    'deepseek-coder',
    params:    '6.7B',
    quant:     'q4_K_M',
    vramGb:    3.4,
    ramGb:     4.3,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 28, cpu: 9 },
    categories:[CATEGORY.CODE, CATEGORY.REASONING, CATEGORY.MEDIUM],
    tags:      ['deepseek', 'code-expert', 'architecture', 'nexus-proven'],
    bestFor:   ['SISO gate generation', 'Jaa schema generation', 'architecture review'],
    notes:     'Previously used in Nexus builds. Proven for architecture-level code tasks.',
  },

  {
    id:        'neural-chat:7b-v3.3-q4_K_M',
    name:      'Neural Chat 7B',
    pull:      'neural-chat:7b-v3.3-q4_K_M',
    family:    'neural-chat',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    3.5,
    ramGb:     4.5,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 26, cpu: 8 },
    categories:[CATEGORY.CHAT, CATEGORY.INSTRUCTION, CATEGORY.MEDIUM],
    tags:      ['intel', 'conversational', 'friendly', 'chat-optimized'],
    bestFor:   ['conversational assistant', 'Guardian chat routing', 'user-facing responses'],
    notes:     'Intel Neural Chat. Good for the Guardian routing layer conversational tasks.',
  },

  {
    id:        'starling-lm:7b-alpha-q4_K_M',
    name:      'Starling LM 7B',
    pull:      'starling-lm:7b-alpha-q4_K_M',
    family:    'starling',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    3.5,
    ramGb:     4.5,
    runMode:   RUN_MODE.GPU_PREFER,
    tokPerSec: { gpu: 25, cpu: 8 },
    categories:[CATEGORY.REASONING, CATEGORY.CHAT, CATEGORY.MEDIUM],
    tags:      ['rlhf', 'helpful', 'berkeley', 'high-coherence'],
    bestFor:   ['constraint field reasoning', 'seam interpretation', 'analytical tasks'],
    notes:     'Berkeley Starling. RLHF-tuned for helpfulness and coherence.',
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // TIER 3: CPU-ONLY — HIGH QUALITY, 4-6 tok/s (non-real-time use cases)
  // ═══════════════════════════════════════════════════════════════════════════

  {
    id:        'llama3.1:8b-instruct-q4_K_M',
    name:      'Llama 3.1 8B Instruct',
    pull:      'llama3.1:8b-instruct-q4_K_M',
    family:    'llama3.1',
    params:    '8B',
    quant:     'q4_K_M',
    vramGb:    4.2,  // slightly over 4GB — CPU-only
    ramGb:     5.5,
    runMode:   RUN_MODE.CPU_FAST,
    tokPerSec: { gpu: null, cpu: 7 },
    categories:[CATEGORY.INSTRUCTION, CATEGORY.REASONING, CATEGORY.CHAT, CATEGORY.LARGE],
    tags:      ['meta', 'latest-llama', 'balanced', 'high-quality'],
    bestFor:   ['background tasks', 'spec generation', 'document analysis', 'non-real-time mirror'],
    notes:     'Meta Llama 3.1 8B. Slightly over VRAM — runs CPU. Good quality.',
  },

  {
    id:        'mistral:7b-v0.3-q8_0',
    name:      'Mistral 7B v0.3 (Q8)',
    pull:      'mistral:7b-v0.3-q8_0',
    family:    'mistral',
    params:    '7B',
    quant:     'q8_0',
    vramGb:    7.0,  // not viable GPU — CPU only
    ramGb:     8.0,
    runMode:   RUN_MODE.CPU_FAST,
    tokPerSec: { gpu: null, cpu: 5 },
    categories:[CATEGORY.INSTRUCTION, CATEGORY.REASONING, CATEGORY.LARGE],
    tags:      ['near-full-quality', 'q8', 'reference-quality'],
    bestFor:   ['highest quality responses when speed not critical', 'reference analysis'],
    notes:     'Near-full precision Mistral 7B. Use for quality-critical batch tasks.',
  },

  {
    id:        'llama3.1:8b-instruct-q5_K_M',
    name:      'Llama 3.1 8B (Q5)',
    pull:      'llama3.1:8b-instruct-q5_K_M',
    family:    'llama3.1',
    params:    '8B',
    quant:     'q5_K_M',
    vramGb:    5.2,
    ramGb:     6.0,
    runMode:   RUN_MODE.CPU_FAST,
    tokPerSec: { gpu: null, cpu: 6 },
    categories:[CATEGORY.INSTRUCTION, CATEGORY.REASONING, CATEGORY.LARGE],
    tags:      ['meta', 'q5', 'balanced-quality'],
    bestFor:   ['high-quality spec writing', 'complex reasoning', 'document generation'],
    notes:     'Q5 Llama 3.1. Best balance of quality/speed in the 8B CPU-only tier.',
  },

  {
    id:        'codellama:13b-instruct-q4_K_M',
    name:      'CodeLlama 13B Instruct',
    pull:      'codellama:13b-instruct-q4_K_M',
    family:    'codellama',
    params:    '13B',
    quant:     'q4_K_M',
    vramGb:    7.0,
    ramGb:     9.0,
    runMode:   RUN_MODE.CPU_QUALITY,
    tokPerSec: { gpu: null, cpu: 4 },
    categories:[CATEGORY.CODE, CATEGORY.LARGE, CATEGORY.INSTRUCTION],
    tags:      ['meta', '13b', 'code-best', 'slower'],
    bestFor:   ['complex code generation', 'full module generation', 'architecture blueprints'],
    notes:     '13B CodeLlama. Best code quality on this hardware. Slow (~4 tok/s).',
  },

  {
    id:        'deepseek-r1:7b-q4_K_M',
    name:      'DeepSeek R1 7B',
    pull:      'deepseek-r1:7b',
    family:    'deepseek-r1',
    params:    '7B',
    quant:     'q4_K_M',
    vramGb:    4.0,  // borderline — test on hardware
    ramGb:     5.0,
    runMode:   RUN_MODE.CPU_FAST,
    tokPerSec: { gpu: null, cpu: 7 },
    categories:[CATEGORY.REASONING, CATEGORY.CODE, CATEGORY.LARGE],
    tags:      ['reasoning', 'chain-of-thought', 'r1', 'structured-thinking'],
    bestFor:   ['constraint field reasoning', 'causal chain analysis', 'gap detection'],
    notes:     'DeepSeek R1 7B reasoning model. Excellent for systematic analysis.',
  },

  {
    id:        'qwen2.5:14b-instruct-q4_K_M',
    name:      'Qwen 2.5 14B',
    pull:      'qwen2.5:14b-instruct-q4_K_M',
    family:    'qwen2.5',
    params:    '14B',
    quant:     'q4_K_M',
    vramGb:    8.0,
    ramGb:     10.0,
    runMode:   RUN_MODE.CPU_SLOW,
    tokPerSec: { gpu: null, cpu: 2 },
    categories:[CATEGORY.REASONING, CATEGORY.CODE, CATEGORY.HEAVY],
    tags:      ['alibaba', '14b', 'high-quality', 'slow', 'batch-only'],
    bestFor:   ['overnight batch tasks', 'comprehensive spec analysis', 'deep code review'],
    notes:     'High quality but ~2 tok/s on CPU. Background/batch tasks only.',
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // EMBEDDING MODELS (for grammar/seam semantic similarity)
  // ═══════════════════════════════════════════════════════════════════════════

  {
    id:        'nomic-embed-text',
    name:      'Nomic Embed Text',
    pull:      'nomic-embed-text',
    family:    'nomic-embed',
    params:    '137M',
    quant:     'f16',
    vramGb:    0.3,
    ramGb:     0.5,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 1000, cpu: 200 },
    categories:[CATEGORY.EMBEDDING, CATEGORY.SMALL],
    tags:      ['embedding', 'semantic-search', 'fast', 'grammar-similarity'],
    bestFor:   ['grammar word similarity', 'seam expression clustering', 'node embedding'],
    notes:     'Fast embedding model. Use for semantic similarity in grammar engine.',
  },

  {
    id:        'mxbai-embed-large',
    name:      'MxBAI Embed Large',
    pull:      'mxbai-embed-large',
    family:    'mxbai-embed',
    params:    '335M',
    quant:     'f16',
    vramGb:    0.7,
    ramGb:     1.0,
    runMode:   RUN_MODE.GPU_ONLY,
    tokPerSec: { gpu: 500, cpu: 100 },
    categories:[CATEGORY.EMBEDDING, CATEGORY.SMALL],
    tags:      ['embedding', 'high-quality', 'mteb-ranked'],
    bestFor:   ['high-quality semantic embedding', 'constraint field vectors', 'resonance scoring'],
    notes:     'Higher quality embeddings than nomic. Good for constraint field similarity.',
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // NOT VIABLE on this hardware (listed for reference / future hardware)
  // ═══════════════════════════════════════════════════════════════════════════

  {
    id:        'llama3:70b-instruct-q4_K_M',
    name:      'Llama 3 70B (NOT VIABLE)',
    pull:      'llama3:70b-instruct-q4_K_M',
    family:    'llama3',
    params:    '70B',
    quant:     'q4_K_M',
    vramGb:    40.0,
    ramGb:     42.0,
    runMode:   RUN_MODE.NOT_VIABLE,
    tokPerSec: { gpu: null, cpu: null },
    categories:[CATEGORY.HEAVY],
    tags:      ['not-viable', 'future-hardware', 'reference'],
    bestFor:   [],
    notes:     'Requires 40GB+ RAM/VRAM. Not viable on R7 3700X + 16GB.',
  },
]);

// ── Catalog helpers ───────────────────────────────────────────────────────────

export function getViableModels() {
  return CATALOG.filter(m => m.runMode !== RUN_MODE.NOT_VIABLE);
}

export function getGPUModels() {
  return CATALOG.filter(m =>
    m.runMode === RUN_MODE.GPU_ONLY || m.runMode === RUN_MODE.GPU_PREFER
  );
}

export function getCPUModels() {
  return CATALOG.filter(m =>
    m.runMode === RUN_MODE.CPU_FAST ||
    m.runMode === RUN_MODE.CPU_QUALITY ||
    m.runMode === RUN_MODE.CPU_SLOW
  );
}

export function getByCategory(category) {
  return CATALOG.filter(m => m.categories.includes(category) && m.runMode !== RUN_MODE.NOT_VIABLE);
}

export function getDefault() {
  return CATALOG.find(m => m.default) || CATALOG.find(m => m.id.includes('mistral:7b'));
}

export function findModel(pullName) {
  return CATALOG.find(m => m.pull === pullName || m.id === pullName) || null;
}

// Reconcile against live /api/tags response
export function reconcileWithInstalled(installedModels = []) {
  const installed = new Set(installedModels.map(m => m.name));
  return CATALOG.map(m => ({
    ...m,
    installed: installed.has(m.pull) || installedModels.some(im => im.name.startsWith(m.family)),
  }));
}

export const CATALOG_VERSION = '2.0.0';
export const CATALOG_UUID    = 'e5f6a7b8-c9d0-4123-efab-000000000005';
