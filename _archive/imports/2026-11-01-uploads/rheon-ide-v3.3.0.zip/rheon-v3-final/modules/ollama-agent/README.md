# ollama-agent

**UUID:** bb000001-0000-4000-8000-000000000001  
**Phase:** 4 — AGENTS  
**Version:** 3.0.0

Local LLM inference via [Ollama](https://ollama.ai). Hardware-calibrated for R7 3700X + 16GB RAM + GTX 1650 (4GB VRAM).

## Model Catalog Summary

### Tier 1 — GPU Accelerated (fits in 3.6GB VRAM)
| Model | Pull | tok/s GPU | Best For |
|-------|------|-----------|----------|
| Mistral 7B Q4_K_M | `mistral:7b-instruct-q4_K_M` | ~28 | **Default.** General assistant, Seam parsing |
| Mistral 7B Q4_K_S | `mistral:7b-instruct-q4_K_S` | ~32 | Fastest real-time streaming |
| Phi-3 Mini 3.8B | `phi3:mini-4k-instruct-q4_K_M` | ~45 | Voice assist, quick queries |
| Phi-3 Mini 128K | `phi3:mini-128k-instruct-q4_K_M` | ~40 | Long spec analysis |
| Gemma 2 2B | `gemma2:2b-instruct-q4_K_M` | ~60 | Always-on, status messages |
| Qwen 2.5 7B | `qwen2.5:7b-instruct-q4_K_M` | ~27 | Code generation, math |
| Llama 3.2 3B | `llama3.2:3b-instruct-q4_K_M` | ~50 | Voice transcript post-processing |
| DeepSeek R1 1.5B | `deepseek-r1:1.5b` | ~80 | Reasoning, constraint logic |

### Tier 2 — CPU + Partial GPU (~7-9 tok/s)
| Model | Pull | Best For |
|-------|------|----------|
| Mistral 7B Q5_K_M | `mistral:7b-instruct-q5_K_M` | Higher quality responses |
| CodeLlama 7B | `codellama:7b-instruct-q4_K_M` | Code completion |
| DeepSeek Coder 6.7B | `deepseek-coder:6.7b-instruct-q4_K_M` | Architecture-level code (Nexus-proven) |
| Neural Chat 7B | `neural-chat:7b-v3.3-q4_K_M` | Guardian routing |

### Tier 3 — CPU Only (~4-6 tok/s, non-real-time)
| Model | Pull | Best For |
|-------|------|----------|
| Llama 3.1 8B Q4 | `llama3.1:8b-instruct-q4_K_M` | Background tasks |
| Llama 3.1 8B Q5 | `llama3.1:8b-instruct-q5_K_M` | High-quality spec writing |
| CodeLlama 13B | `codellama:13b-instruct-q4_K_M` | Complex code generation |
| DeepSeek R1 7B | `deepseek-r1:7b` | Systematic analysis |

### Embedding Models
| Model | Pull | Best For |
|-------|------|----------|
| Nomic Embed | `nomic-embed-text` | Grammar similarity |
| MxBAI Embed | `mxbai-embed-large` | Constraint field vectors |

## Bus Events

**Emits:**
- `ide:agent:request` — when a completion starts
- `ide:agent:response` — when completion finishes
- `ide:agent:stream:chunk` — streaming token
- `ide:agent:error` — failure (loud, specific)
- `ide:agent:ollama:models:updated` — catalog update

**Reads:**
- `ide:agent:ollama:request:ping` — trigger connection test
- `ide:agent:ollama:request:catalog` — emit current catalog
- `ide:agent:ollama:request:model` — set active model
- `ide:agent:ollama:request:complete` — trigger completion

## CLI

```
ide agent ollama status              # connection + active model
ide agent ollama ping                # test connection
ide agent ollama catalog             # full model catalog
ide agent ollama catalog --gpu       # GPU-viable only
ide agent ollama catalog --category code
ide agent ollama model mistral:7b-instruct-q4_K_M
ide agent ollama complete --model phi3:mini "explain constraints"
ide agent ollama models installed    # what's on disk
```

## UI Hooks

- **topbar**: connection indicator (green = available, red = unavailable). Click = ping.
- **topbar.right**: "Ollama" button → opens model catalog panel
- **settings.section**: full model catalog panel with hardware info, categories, install buttons
