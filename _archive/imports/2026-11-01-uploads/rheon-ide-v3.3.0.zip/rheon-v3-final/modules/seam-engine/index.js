/**
 * modules/seam-engine/index.js
 * @module  seam-engine
 * @uuid    bb000003-0000-4000-8000-000000000003
 * @version 3.0.0
 * @phase   3
 */

import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [];

// ── Kernel word set (§10.3 Rheon Kernel Spec) ─────────────────────────────────
const KERNEL_WORDS = new Map([
  ['make',      { type: 'DECLARE',     template: 'make {subject} = {value}' }],
  ['show',      { type: 'SURFACE',     template: 'show {subject}' }],
  ['add',       { type: 'ACCUMULATE',  template: 'add {thing} to {target}' }],
  ['repeat',    { type: 'LOOP',        template: 'repeat {n} times' }],
  ['for',       { type: 'ITERATE',     template: 'for each {item} in {collection}' }],
  ['if',        { type: 'BRANCH',      template: 'if {condition}' }],
  ['when',      { type: 'TRIGGER',     template: 'when {condition}' }],
  ['define',    { type: 'COMPOSE',     template: 'define {name} using {parts}' }],
  ['find',      { type: 'QUERY',       template: 'find {thing} where {condition}' }],
  ['write',     { type: 'PERSIST',     template: 'write {data} to {target}' }],
  ['gap',       { type: 'GAP_REF',     template: 'gap {id}' }],
  ['emit',      { type: 'BUS_EMIT',    template: 'emit {channel}' }],
  ['watch',     { type: 'BUS_SUB',     template: 'watch {channel}' }],
  ['tension',   { type: 'TENSION',     template: 'tension between {a} and {b}' }],
  ['fill',      { type: 'GAP_FILL',    template: 'fill {gap} with {value}' }],
  ['constrain', { type: 'CONSTRAINT',  template: 'constrain {subject} by {rule}' }],
  ['field',     { type: 'FIELD_QUERY', template: 'field of {subject}' }],
]);

// ── Constraint extraction patterns ───────────────────────────────────────────
const C_PATTERNS = [
  { re: /(\w[\w\s]{2,30}?)\s+requires\s+([\w][\w\s]{1,30})/gi,  type: 'causal', strength: 0.85 },
  { re: /(\w[\w\s]{2,30}?)\s+cannot\s+([\w][\w\s]{1,30})/gi,    type: 'hard',   strength: 0.9  },
  { re: /(\w[\w\s]{2,30}?)\s+must\s+([\w][\w\s]{1,30})/gi,      type: 'hard',   strength: 0.85 },
  { re: /(\w[\w\s]{2,30}?)\s+produces\s+([\w][\w\s]{1,30})/gi,  type: 'causal', strength: 0.7  },
  { re: /(\w[\w\s]{2,30}?)\s+prevents\s+([\w][\w\s]{1,30})/gi,  type: 'hard',   strength: 0.8  },
  { re: /without\s+([\w][\w\s]{2,20}?)\s+([\w][\w\s]{1,20}?)\s+(?:is\s+)?impossible/gi, type: 'causal', strength: 0.8 },
];

// ── Gap patterns ──────────────────────────────────────────────────────────────
const G_PATTERNS = [
  { re: /\b(multidimensional|multi-dimensional|distributed|emergent|living|dynamic)\b/i, variable: 'dimensions_or_axes', reason: 'Term implies multiple dimensions but none defined.', uncertainty: 0.7, pressure: 0.6 },
  { re: /\b(it|this|that|they|them)\b/gi, variable: 'referent', reason: 'Pronoun without established referent.', uncertainty: 0.5, pressure: 0.4 },
  { re: /\b(will|going to|eventually|someday|soon)\b/i, variable: 'temporal_boundary', reason: 'Future intent with no timeline or trigger.', uncertainty: 0.6, pressure: 0.35 },
  { re: /\b(somehow|something|someone|somewhere)\b/i, variable: 'undefined_referent', reason: 'Vague placeholder — no concrete referent.', uncertainty: 0.65, pressure: 0.5 },
];

// ── Signals ───────────────────────────────────────────────────────────────────
function extractSignals(text) {
  const l = text.toLowerCase();
  return {
    negation:      /\b(not|never|no|without|cannot|can't)\b/.test(l) ? 1 : 0,
    causality:     Math.min(1, (l.match(/\b(because|therefore|causes|leads to|results in)\b/g)||[]).length * 0.3),
    intensity:     Math.min(1, (l.match(/\b(always|never|must|every|all|completely)\b/g)||[]).length * 0.25),
    uncertainty:   Math.min(1, (l.match(/\b(maybe|perhaps|might|could|possibly)\b/g)||[]).length * 0.3),
    contradiction: Math.min(1, (l.match(/\b(but|however|yet|although|despite)\b/g)||[]).length * 0.35),
    imperative:    Math.min(1, (l.match(/\b(make|do|create|build|must|ensure)\b/g)||[]).length * 0.2),
  };
}

// ── Core parse function ───────────────────────────────────────────────────────
export function parse(raw) {
  if (!raw?.trim()) return null;
  const text  = raw.trim();
  const lower = text.toLowerCase();
  const first = lower.split(/\s+/)[0];
  const wordDef = KERNEL_WORDS.get(first);
  const verb  = wordDef?.type || 'UNKNOWN';

  const signals     = extractSignals(text);
  const constraints = [];
  const gaps        = [];

  // Extract constraints
  for (const { re, type, strength } of C_PATTERNS) {
    let m; re.lastIndex = 0;
    while ((m = re.exec(text)) !== null) {
      const a = m[1].trim(), b = m[2].trim();
      if (a.split(/\s+/).length > 8 || b.split(/\s+/).length > 8) continue; // too long = noise
      constraints.push({
        id:           _uid(),
        name:         `${a} → ${b}`,
        type,
        strength,
        source:       'seam-parser',
        confidence:   0.65 + signals.causality * 0.2,
        violationCost: type === 'hard' ? 1.0 : 0.6,
      });
    }
  }

  // Detect gaps
  const seenVars = new Set();
  for (const { re, variable, reason, uncertainty, pressure } of G_PATTERNS) {
    if (!seenVars.has(variable) && re.test(text)) {
      gaps.push({ id: _uid(), missingVariable: variable, uncertainty, pressure, reason });
      seenVars.add(variable);
    }
  }

  // Parse confidence
  const confidence = wordDef
    ? Math.min(0.95, 0.6 + constraints.length * 0.1 + (1 - signals.uncertainty) * 0.2)
    : Math.min(0.70, 0.3 + constraints.length * 0.1);

  return {
    raw,
    verb,
    template:    wordDef?.template || null,
    signals,
    constraints,
    gaps,
    confidence,
    isKernelWord: !!wordDef,
    ts:          Date.now(),
  };
}

// ── register() ───────────────────────────────────────────────────────────────
export async function register(busInstance, jaaInstance) {
  _bus = busInstance;
  _jaa = jaaInstance;

  // Listen to content changes for live parse
  _unsubs.push(
    _bus.on('ide:editor:content:changed', (ev) => {
      const { text, mode } = ev.payload;
      if (mode !== 'seam' || !text?.trim()) return;
      const parsed = parse(text);
      if (!parsed) return;
      _bus.emit('ide:seam:parsed', { ...parsed, ts: Date.now() });
    }),

    // Full submission
    _bus.on('ide:editor:submit', async (ev) => {
      const { text } = ev.payload;
      if (!text?.trim()) return;
      const parsed = parse(text);
      if (!parsed) return;

      // Learn new kernel words as grammar entries (§2.1 write before emit)
      if (parsed.isKernelWord) {
        const existing = await _jaa.query('grammar', w => w.keyword === text.split(/\s+/)[0].toLowerCase(), 1);
        if (!existing.length) {
          await _jaa.insertGrammarWord({
            keyword:    text.split(/\s+/)[0].toLowerCase(),
            definition: `Seam kernel word — ${parsed.verb}`,
            causedBy:   'seam-engine',
            status:     'active',
            trustScore: 0.9,
          });
        } else {
          await _jaa.update('grammar', existing[0].uuid, {
            usageCount: (existing[0].usageCount || 0) + 1,
          });
        }
      }

      _bus.emit('ide:seam:submitted', { ...parsed, ts: Date.now() });
    }),
  );

  return unregister;
}

export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}

export function status() {
  return { ok: true, version: MANIFEST.version, uuid: MANIFEST.uuid, kernelWords: KERNEL_WORDS.size };
}

function _uid() {
  return typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2) + Date.now().toString(36);
}
