/**
 * modules/causal-nexus/index.js
 * @module  causal-nexus  @uuid bb000012-0000-4000-8000-000000000012
 * @version 3.0.0  @phase 8
 *
 * Causal Nexus integration.
 * Ingests IDE events into the causal graph.
 * Supports replay, snapshot, counterfactual scoring.
 * Connects to Causal Nexus v6 kernel via kernel-bridge events.
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [];
const _graph = new Map(); // eventId → { type, causedBy, causes:[], tick }

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  // Ingest all bus events into causal graph
  _unsubs.push(
    _bus.on('**', (ev) => {
      _graph.set(ev.id, {
        id:       ev.id,
        type:     ev.type,
        tick:     ev.tick,
        wall:     ev.wall,
        causedBy: ev.causedBy || null,
        causes:   [],
        payload:  ev.payload,
      });
      if (ev.causedBy && _graph.has(ev.causedBy)) {
        _graph.get(ev.causedBy).causes.push(ev.id);
      }
      // Keep graph bounded
      if (_graph.size > 10000) {
        const oldest = _graph.keys().next().value;
        _graph.delete(oldest);
      }
    }),

    _bus.on('ide:nexus:snapshot', async () => {
      const snapshot = {
        graphSize: _graph.size,
        events:    [..._graph.values()].slice(-100),
        ts:        Date.now(),
      };
      await _jaa.insert('ledger_upgrade', {
        description: 'Causal Nexus snapshot',
        proof:       `graph: ${_graph.size} events`,
        ts:          Date.now(),
      });
      _bus.emit('ide:toast', { message: `Nexus snapshot: ${_graph.size} events`, type: 'success', ts: Date.now() });
    }),

    _bus.on('ide:nexus:replay', async (ev) => {
      const from = ev.payload.fromTick || 0;
      const chain = [..._graph.values()].filter(e => e.tick >= from).sort((a,b) => a.tick - b.tick);
      _bus.emit('ide:console:cli:response', {
        text: `  Nexus replay from tick ${from}: ${chain.length} events`,
        level: 'info', ts: Date.now(),
      });
    }),
  );

  return unregister;
}

export async function unregister() { _unsubs.forEach(fn => { try { fn(); } catch {} }); _unsubs = []; _bus = null; _jaa = null; }
export function status() { return { ok: true, graphSize: _graph.size, version: MANIFEST.version }; }
export function getGraph() { return _graph; }
