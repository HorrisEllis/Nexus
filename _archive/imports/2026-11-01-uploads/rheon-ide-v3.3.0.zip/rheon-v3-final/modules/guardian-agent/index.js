/**
 * Guardian Agent — routes to Guardian Firefox extension via bridge
 * Architecture: POST /guardian/bus → Guardian polls → tab dispatch → /guardian/response
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };
let _bus, _jaa, _unsubs = [];
const CFG = { ...MANIFEST.config };
const _pending = new Map(); // calltoId → { resolve, reject, timer }

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  _unsubs.push(
    _bus.on('ide:agent:guardian:request', async (ev) => {
      const { prompt, identity, intentType } = ev.payload;
      await complete({ prompt, identity: identity || CFG.defaultIdentity, intentType }).catch(() => {});
    }),
    _bus.on('ide:agent:guardian:request:probe', async (ev) => {
      await probe((ev.payload?.identity) || CFG.defaultIdentity);
    }),
  );

  // Initial probe
  probe(CFG.defaultIdentity).catch(() => {});
  return unregister;
}

export async function unregister() {
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}

export function status() {
  return { ok: true, bridge: CFG.bridgeUrl, pending: _pending.size };
}

export async function probe(identity = 'claude') {
  try {
    const r = await _fetch('/api/agent/probe', 'POST', { identity }, 3000);
    const ok = r?.connected || false;
    _bus?.emit('ide:agent:guardian:status', { identity, connected: ok, ts: Date.now() });
    return ok;
  } catch {
    _bus?.emit('ide:agent:guardian:status', { identity, connected: false, ts: Date.now() });
    return false;
  }
}

export async function complete({ prompt, identity = 'claude', intentType = 'chat' }) {
  const callId = _uid();
  await _jaa?.insertAgentCall({ uuid: callId, agentId: `guardian-${identity}`, prompt, status: 'pending' });
  _bus?.emit('ide:agent:request', { callId, agentId: `guardian-${identity}`, ts: Date.now() });
  try {
    const data = await _fetch('/api/complete', 'POST', { service: identity, prompt, intentType }, CFG.completeTimeoutMs);
    const content = data?.response || data?.content || '';
    await _jaa?.update('agent_calls', callId, { status: 'complete', response: content.slice(0, 1000) });
    _bus?.emit('ide:agent:response', { callId, agentId: `guardian-${identity}`, content, ts: Date.now() });
    return content;
  } catch (e) {
    await _jaa?.update('agent_calls', callId, { status: 'error', error: e.message });
    _bus?.emit('ide:agent:error', { callId, agentId: `guardian-${identity}`, error: e.message, ts: Date.now() });
    throw e;
  }
}

async function _fetch(path, method = 'GET', body = null, timeout = 5000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(CFG.bridgeUrl + path, {
      method, signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json' },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    clearTimeout(t);
    if (!r.ok) throw new Error(`Guardian bridge HTTP ${r.status}`);
    return r.json();
  } catch (e) { clearTimeout(t); throw e; }
}

function _uid() {
  return typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2);
}
