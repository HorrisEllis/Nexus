/**
 * modules/voice-engine/index.js
 * @module  voice-engine  @uuid bb000008-0000-4000-8000-000000000008
 * @version 3.0.0  @phase 5
 *
 * Mic bridge + Whisper transcription.
 * Browser: MediaRecorder API → audio chunks → POST to kernel /api/voice/transcript
 * Node: proxies to kernel WS record:start / record:stop
 *
 * Emits ide:voice:transcript:final when kernel returns transcript.
 * Emits ide:voice:status on every state change.
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [], _recording = false, _mediaRecorder = null, _chunks = [];

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  _unsubs.push(
    _bus.on('ide:voice:mic:started', async () => {
      if (_recording) return;
      _recording = true;
      _bus.emit('ide:voice:status', { status: 'recording', ts: Date.now() });

      // Browser: start MediaRecorder
      if (typeof navigator !== 'undefined' && navigator.mediaDevices) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          _mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
          _chunks = [];
          _mediaRecorder.ondataavailable = e => { if (e.data.size > 0) _chunks.push(e.data); };
          _mediaRecorder.onstop = async () => {
            const blob = new Blob(_chunks, { type: 'audio/webm' });
            await _sendToKernel(blob);
          };
          _mediaRecorder.start(250); // 250ms chunks
          _bus.emit('ide:toast', { message: 'Recording…', type: 'info', ts: Date.now() });
        } catch (e) {
          _recording = false;
          _bus.emit('ide:toast', { message: `Mic error: ${e.message}`, type: 'error', ts: Date.now() });
          _bus.emit('ide:voice:status', { status: 'error', error: e.message, ts: Date.now() });
        }
      } else {
        // Node: tell kernel to start recording on its end
        _bus.emit('ide:console:cli:response', { text: '  voice recording started (kernel-side)', level: 'info', ts: Date.now() });
      }
    }),

    _bus.on('ide:voice:mic:stopped', () => {
      if (!_recording) return;
      _recording = false;
      _bus.emit('ide:voice:status', { status: 'processing', ts: Date.now() });
      if (_mediaRecorder?.state === 'recording') {
        _mediaRecorder.stop();
      }
      _bus.emit('ide:toast', { message: 'Processing voice…', type: 'info', ts: Date.now() });
    }),

    // Kernel sends back transcript
    _bus.on('ide:kernel:node:mirror', (ev) => {
      if (ev.payload.type === 'voice:transcript') {
        const text = ev.payload.text || '';
        _jaa?.insert('voice_segments', { text, ts: Date.now() }).catch(() => {});
        _bus.emit('ide:voice:transcript:final', { text, ts: Date.now() });
        _bus.emit('ide:voice:status', { status: 'idle', ts: Date.now() });
        _bus.emit('ide:toast', { message: `Voice: "${text.slice(0,40)}…"`, type: 'success', ts: Date.now() });
      }
    }),
  );

  return unregister;
}

async function _sendToKernel(blob) {
  try {
    const ab   = await blob.arrayBuffer();
    const b64  = btoa(String.fromCharCode(...new Uint8Array(ab)));
    const r    = await fetch('http://localhost:7749/api/voice/transcript', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ audio: b64, format: 'webm' }),
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) throw new Error(`Kernel voice HTTP ${r.status}`);
    const data = await r.json();
    if (data.text) {
      _bus?.emit('ide:voice:transcript:final', { text: data.text, ts: Date.now() });
      await _jaa?.insert('voice_segments', { text: data.text, ts: Date.now() });
    }
  } catch (e) {
    _bus?.emit('ide:toast', { message: `Voice transcription failed: ${e.message}`, type: 'error', ts: Date.now() });
    _bus?.emit('ide:voice:status', { status: 'error', error: e.message, ts: Date.now() });
  } finally {
    _recording = false;
    _bus?.emit('ide:voice:status', { status: 'idle', ts: Date.now() });
  }
}

export async function unregister() {
  if (_mediaRecorder?.state === 'recording') _mediaRecorder.stop();
  _unsubs.forEach(fn => { try { fn(); } catch {} });
  _unsubs = []; _bus = null; _jaa = null;
}

export function status() { return { ok: true, recording: _recording, version: MANIFEST.version }; }
