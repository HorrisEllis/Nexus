/**
 * modules/compiler/index.js
 * @module  compiler  @uuid bb000009-0000-4000-8000-000000000009
 * @version 3.0.0  @phase 6
 *
 * SISO build pipeline. Gate chain: Validate → Prepare → Install → Execute.
 * Each gate is a pure Gate subclass (§5.8 composability).
 * Never asks user questions mid-run (NEXUS FORGE axiom).
 * Streams gate progress on bus.
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [], _abort = false;

// ── Gates ────────────────────────────────────────────────────────────────────
async function gateValidate(ctx) {
  _progress(ctx, 'validate', 'Checking project structure…');
  const errors = [];
  if (!ctx.projectDir) errors.push('projectDir is required');
  if (ctx.target && !['web','electron','node'].includes(ctx.target)) {
    errors.push(`unknown target: ${ctx.target} (supported: web|electron|node)`);
  }
  if (errors.length) { _fail(ctx, 'validate', errors.join('\n')); return null; }
  _progress(ctx, 'validate', `✓ project: ${ctx.projectDir}  target: ${ctx.target}`);
  return ctx;
}

async function gatePrepare(ctx) {
  _progress(ctx, 'prepare', `Preparing ${ctx.target} build…`);
  ctx.outDir       = ctx.outDir || `${ctx.projectDir}/dist`;
  ctx.productName  = ctx.productName || 'rheon-build';
  ctx.buildVersion = ctx.buildVersion || '1.0.0';
  _progress(ctx, 'prepare', `outDir: ${ctx.outDir}  product: ${ctx.productName} v${ctx.buildVersion}`);
  return ctx;
}

async function gateInstall(ctx) {
  _progress(ctx, 'install', 'Checking dependencies…');
  try {
    const r = await fetch('http://localhost:7749/bridge/cli', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: 'npm install --prefer-offline', cwd: ctx.projectDir }),
      signal: AbortSignal.timeout(60000),
    });
    if (r.ok) {
      const data = await r.json().catch(() => ({}));
      const out  = (data.stdout || '').slice(0, 200);
      if (out) _progress(ctx, 'install', out);
      _progress(ctx, 'install', '✓ dependencies ready');
    } else {
      _progress(ctx, 'install', '⚠ kernel CLI bridge unavailable — skipping npm install');
    }
  } catch {
    _progress(ctx, 'install', '⚠ kernel offline — skipping npm install');
  }
  return ctx;
}

async function gateExecute(ctx) {
  if (_abort) { _fail(ctx, 'execute', 'Build aborted by user'); return null; }
  _progress(ctx, 'execute', `Building ${ctx.target}…`);
  try {
    const cmd = ctx.target === 'electron' ? 'npx electron-builder --dir' : 'npm run build';
    const r   = await fetch('http://localhost:7749/bridge/cli', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: cmd, cwd: ctx.projectDir }),
      signal: AbortSignal.timeout(300000),
    });
    if (r.ok) {
      const data = await r.json().catch(() => ({}));
      (data.stdout || '').split('\n').filter(Boolean).slice(0,20).forEach(l => _progress(ctx, 'execute', l.slice(0,200)));
      if (data.code !== 0 && data.code !== undefined) {
        _fail(ctx, 'execute', `Build failed (exit ${data.code}): ${(data.stderr||'').slice(0,300)}`);
        return null;
      }
    } else {
      _fail(ctx, 'execute', 'Kernel CLI bridge error — cannot run build');
      return null;
    }
  } catch (e) {
    _fail(ctx, 'execute', `Build error: ${e.message}`);
    return null;
  }
  _bus?.emit('ide:compiler:done', { ok: true, gate: 'execute', artifacts: [{ path: ctx.outDir, type: ctx.target }], ts: Date.now() });
  _bus?.emit('ide:toast', { message: `✓ Build complete: ${ctx.outDir}`, type: 'success', ts: Date.now() });
  return ctx;
}

function _progress(ctx, gate, msg) {
  _bus?.emit('ide:compiler:gate:progress', { gate, message: msg, projectDir: ctx.projectDir, ts: Date.now() });
}

function _fail(ctx, gate, msg) {
  _bus?.emit('ide:compiler:failed', { ok: false, gate, message: msg, ts: Date.now() });
  _bus?.emit('ide:toast', { message: `Build failed [${gate}]: ${msg.slice(0,80)}`, type: 'error', ts: Date.now() });
}

async function runBuild(projectDir, target) {
  _abort = false;
  let ctx = { projectDir, target: target || 'web', ts: Date.now() };
  ctx = await gateValidate(ctx);  if (!ctx || _abort) return;
  ctx = await gatePrepare(ctx);   if (!ctx || _abort) return;
  ctx = await gateInstall(ctx);   if (!ctx || _abort) return;
  await gateExecute(ctx);
}

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;
  _unsubs.push(
    _bus.on('ide:compiler:started', (ev) => {
      const { projectDir, target } = ev.payload;
      runBuild(projectDir, target).catch(e => _bus.emit('ide:toast', { message: `Compiler error: ${e.message}`, type: 'error', ts: Date.now() }));
    }),
    _bus.on('ide:compiler:abort', () => { _abort = true; _bus.emit('ide:toast', { message: 'Build aborted', type: 'warn', ts: Date.now() }); }),
  );
  return unregister;
}

export async function unregister() { _abort = true; _unsubs.forEach(fn => { try { fn(); } catch {} }); _unsubs = []; _bus = null; _jaa = null; }
export function status() { return { ok: true, version: MANIFEST.version }; }
