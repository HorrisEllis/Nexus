/**
 * modules/spec-builder/index.js
 * @module  spec-builder  @uuid bb000011-0000-4000-8000-000000000011
 * @version 3.0.0  @phase 8
 *
 * Spec file management.
 * Parse, validate, version, and export .spec files.
 * Integrates with spec/spec-engine.js for checkpoint tracking.
 * Every spec version is a Jaa ledger entry (§7.1).
 */
import MANIFEST from './MANIFEST.json' with { type: 'json' };
export { MANIFEST };

let _bus, _jaa, _unsubs = [];

function parseSpec(content) {
  // Parse YAML-ish spec into structured object
  const lines = content.split('\n');
  const result = { meta: {}, modules: {}, gaps: [], sections: {} };
  let currentSection = null;
  for (const line of lines) {
    if (line.startsWith('  #') || !line.trim()) continue;
    const m = line.match(/^  (\w+):(.*)$/);
    if (m) {
      currentSection = m[1];
      if (m[2].trim()) result[currentSection] = m[2].trim();
      else result.sections[currentSection] = [];
    }
  }
  return result;
}

function validateSpec(parsed) {
  const errors = [];
  if (!parsed.meta?.name && !parsed.sections?.meta) errors.push('missing meta.name');
  return { valid: errors.length === 0, errors };
}

export async function register(bus, jaa) {
  _bus = bus; _jaa = jaa;

  _unsubs.push(
    _bus.on('ide:spec:build', async (ev) => {
      // Trigger spec regeneration
      _bus.emit('phase:complete', { phase: 8, gate: 'spec-builder', exit: 'spec exported', ts: Date.now() });
      _bus.emit('ide:toast', { message: 'Spec updated', type: 'success', ts: Date.now() });
    }),

    _bus.on('ide:spec:validate', async (ev) => {
      const { content } = ev.payload;
      if (!content) return;
      const parsed = parseSpec(content);
      const { valid, errors } = validateSpec(parsed);
      _bus.emit('ide:console:cli:response', {
        text: valid ? '  ✓ spec valid' : `  ✗ spec invalid: ${errors.join(', ')}`,
        level: valid ? 'info' : 'error',
        ts: Date.now(),
      });
    }),

    _bus.on('ide:spec:export', async (ev) => {
      const format = ev.payload.format || 'yaml';
      try {
        const r = await fetch('http://localhost:7800/api/spec', { signal: AbortSignal.timeout(5000) });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        // Record in Jaa spec_versions (§7.1)
        await _jaa.insert('spec_versions', {
          format, content: (data.spec || '').slice(0, 5000),
          exportedAt: Date.now(),
        });
        _bus.emit('ide:toast', { message: `Spec exported as ${format}`, type: 'success', ts: Date.now() });
      } catch (e) {
        _bus.emit('ide:toast', { message: `Spec export failed: ${e.message}`, type: 'error', ts: Date.now() });
      }
    }),
  );

  return unregister;
}

export async function unregister() { _unsubs.forEach(fn => { try { fn(); } catch {} }); _unsubs = []; _bus = null; _jaa = null; }
export function status() { return { ok: true, version: MANIFEST.version }; }
